Fenix AI Studio — ComfyUI model bootstrap
=========================================

What this is
------------
FENIX_DOWNLOAD_MODELS.bat + download_fenix_models.py check for every
model Fenix needs (FLUX image, MiniMax video, ACE-Step music) and
download anything missing into the correct ComfyUI\models\ folders.

Estimated download size (all required): about 65–80 GB.


How to use (recommended)
------------------------
1. Copy BOTH files into your ComfyUI portable folder, e.g.:

     D:\ComfyUI_windows_portable\
       run_nvidia_gpu.bat
       FENIX_DOWNLOAD_MODELS.bat      <— put here
       download_fenix_models.py   <— put here
       python_embeded\
       ComfyUI\
         models\

2. Double-click FENIX_DOWNLOAD_MODELS.bat

3. It auto-detects ComfyUI\models. Missing files download from Hugging Face.

4. Restart ComfyUI when finished.


If it cannot find ComfyUI
-------------------------
You will be asked:

  1) Path to ComfyUI (folder that contains models\)
  2) Any folder to dump a models\ layout (~70 GB) for later manual copy

Option 2 creates:

  <your folder>\
    diffusion_models\
    text_encoders\
    vae\
    loras\

Copy those into ComfyUI\models\ on any PC.


Optional FastLoRA (MiniMax turbo, ≥12 GB VRAM)
----------------------------------------------
  FENIX_DOWNLOAD_MODELS.bat --optional

Check only (no download)
------------------------
  FENIX_DOWNLOAD_MODELS.bat --check-only


What gets downloaded (required)
-------------------------------
Image (Comfy-Org/flux2-klein-4B):
  models\diffusion_models\flux-2-klein-4b.safetensors
  models\text_encoders\qwen_3_4b.safetensors
  models\vae\flux2-vae.safetensors

Video (Comfy-Org/MiniMax-H3):
  models\diffusion_models\minimax_h3_fl2va_pruned_int8_convrot.safetensors
  models\text_encoders\qwen3vl_32b_minimax_h3_nvfp4_awq.safetensors
  models\vae\minimax_h3_video_vae_fp16.safetensors
  models\vae\minimax_h3_audio_vae_fp32.safetensors

Music (Comfy-Org/ace_step_1.5_ComfyUI_files):
  models\diffusion_models\acestep_v1.5_turbo.safetensors
  models\text_encoders\qwen_0.6b_ace15.safetensors
  models\text_encoders\qwen_4b_ace15.safetensors
  models\vae\ace_1.5_vae.safetensors


Notes
-----
- Needs disk space and a stable internet connection.
- Interrupted downloads resume (huggingface_hub).
- HF rate limits: set HF_TOKEN env var if needed (free account).
- Already-present files (including common alt quant names) are skipped.
- Fenix studio tree also keeps a copy under scripts\comfy_model_bootstrap\
  for convenience; the bat is designed to live with Comfy too.
