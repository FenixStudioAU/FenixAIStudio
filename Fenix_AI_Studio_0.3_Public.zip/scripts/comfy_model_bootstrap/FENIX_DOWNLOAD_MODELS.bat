@echo off
setlocal EnableExtensions EnableDelayedExpansion
title Fenix AI Studio — ComfyUI model downloader
cd /d "%~dp0"

echo.
echo   ============================================================
echo     Fenix AI Studio  -  ComfyUI model checker / downloader
echo   ============================================================
echo.
echo   Place this .bat + download_fenix_models.py inside your
echo   ComfyUI portable folder  (next to run_nvidia_gpu.bat),
echo   or run from Fenix scripts\comfy_model_bootstrap\
echo.
echo   Required set is roughly 65-80 GB  (Flux + MiniMax + ACE-Step).
echo   Missing files are downloaded from Hugging Face.
echo.

REM ---------- Find Python ----------
set "PY="
REM 1) ComfyUI portable embed (when bat sits in portable root)
if exist "%~dp0python_embeded\python.exe" set "PY=%~dp0python_embeded\python.exe"
if not defined PY if exist "%~dp0..\python_embeded\python.exe" set "PY=%~dp0..\python_embeded\python.exe"
REM 2) ComfyUI\.. portable layout when bat is inside ComfyUI\
if not defined PY if exist "%~dp0..\..\python_embeded\python.exe" set "PY=%~dp0..\..\python_embeded\python.exe"
REM 3) Fenix studio venv (when running from Fenix tree)
if not defined PY if exist "%~dp0..\..\venv\Scripts\python.exe" set "PY=%~dp0..\..\venv\Scripts\python.exe"
if not defined PY if exist "%~dp0..\..\..\venv\Scripts\python.exe" set "PY=%~dp0..\..\..\venv\Scripts\python.exe"
REM 4) System PATH
if not defined PY (
  where python >nul 2>&1 && set "PY=python"
)
if not defined PY (
  where py >nul 2>&1 && set "PY=py -3"
)

if not defined PY (
  echo ERROR: No Python found.
  echo   Install Python 3.10+ from https://www.python.org/downloads/
  echo   or run this bat from a ComfyUI portable that includes python_embeded.
  pause
  exit /b 1
)

echo   Python: %PY%
echo.

REM Ensure huggingface_hub (best effort; script also tries)
"%PY%" -c "import huggingface_hub" >nul 2>&1
if errorlevel 1 (
  echo   Installing huggingface_hub …
  "%PY%" -m pip install -U huggingface_hub
  if errorlevel 1 (
    echo WARNING: pip install failed. The script will retry.
  )
)

set "SCRIPT=%~dp0download_fenix_models.py"
if not exist "%SCRIPT%" (
  echo ERROR: download_fenix_models.py not found next to this bat:
  echo   %SCRIPT%
  echo Copy BOTH files into the same folder.
  pause
  exit /b 1
)

REM Optional: pass --optional for FastLoRA, --check-only to only scan
"%PY%" "%SCRIPT%" %*
set "ERR=%ERRORLEVEL%"

echo.
if "%ERR%"=="0" (
  echo   Done.
) else (
  echo   Finished with exit code %ERR%.
  echo   See messages above. Failed files can be downloaded manually from Hugging Face.
)
echo.
pause
exit /b %ERR%
