# Clean runtime junk for a GitHub-ready tree.
# Removes: logs, cache, user projects/media, train scratch, __pycache__, coder workspace
# Does NOT remove venv (delete manually before upload).

$ErrorActionPreference = "Continue"
$Root = Split-Path -Parent $PSScriptRoot
if (-not (Test-Path (Join-Path $Root "backend"))) {
  $Root = Get-Location
}

Write-Host "Cleaning for GitHub under: $Root"

function Remove-TreeSafe($path) {
  if (Test-Path $path) {
    Remove-Item -LiteralPath $path -Recurse -Force -ErrorAction SilentlyContinue
    Write-Host "  removed $path"
  }
}

function Clear-DirKeepGitkeep($dir) {
  if (-not (Test-Path $dir)) {
    New-Item -ItemType Directory -Force -Path $dir | Out-Null
    return
  }
  Get-ChildItem -LiteralPath $dir -Force | Where-Object { $_.Name -ne ".gitkeep" } | ForEach-Object {
    Remove-Item -LiteralPath $_.FullName -Recurse -Force -ErrorAction SilentlyContinue
  }
  Write-Host "  cleared $dir"
}

# Logs
Clear-DirKeepGitkeep (Join-Path $Root "logs")

# Cache
Clear-DirKeepGitkeep (Join-Path $Root "cache")

# User / demo content
Clear-DirKeepGitkeep (Join-Path $Root "projects")
Clear-DirKeepGitkeep (Join-Path $Root "studio_media\images")
Clear-DirKeepGitkeep (Join-Path $Root "studio_media\videos")
$studioLib = Join-Path $Root "studio_media\library.json"
Set-Content -Path $studioLib -Value "{`n  `"items`": []`n}`n" -Encoding utf8
Write-Host "  reset studio_media/library.json"

Clear-DirKeepGitkeep (Join-Path $Root "music_tracks\audio")
Set-Content -Path (Join-Path $Root "music_tracks\library.json") -Value "{`n  `"tracks`": []`n}`n" -Encoding utf8
Write-Host "  reset music_tracks/library.json"

Clear-DirKeepGitkeep (Join-Path $Root "shared_references\images")
Set-Content -Path (Join-Path $Root "shared_references\library.json") -Value "{`n  `"characters`": []`n}`n" -Encoding utf8
Write-Host "  reset shared_references/library.json"

# Train scratch
$trainJobs = Join-Path $Root "music_lora_train\jobs.json"
if (Test-Path $trainJobs) { Set-Content -Path $trainJobs -Value "[]`n" -Encoding utf8; Write-Host "  reset music_lora_train/jobs.json" }
Remove-TreeSafe (Join-Path $Root "music_lora_train\datasets")
New-Item -ItemType Directory -Force -Path (Join-Path $Root "music_lora_train\datasets") | Out-Null

# Coder workspace → empty default project
$coder = Join-Path $Root "coder_projects"
Remove-TreeSafe $coder
New-Item -ItemType Directory -Force -Path (Join-Path $coder "default\versions") | Out-Null
$now = (Get-Date).ToUniversalTime().ToString("yyyy-MM-ddTHH:mm:ssZ")
$coderJson = @"
{
  "id": "default",
  "name": "Studio Coder",
  "created_at": "$now",
  "updated_at": "$now",
  "designer_messages": [],
  "build_prompt": "",
  "repair_prompt": "",
  "accepted_version_id": null,
  "active_version_id": null,
  "versions": []
}
"@
Set-Content -Path (Join-Path $coder "default\project.json") -Value $coderJson -Encoding utf8
Set-Content -Path (Join-Path $coder "_meta.json") -Value "{`n  `"active_id`": `"default`"`n}`n" -Encoding utf8
Write-Host "  reset coder_projects (empty default)"

# Python bytecode
Get-ChildItem -Path $Root -Recurse -Directory -Filter "__pycache__" -ErrorAction SilentlyContinue |
  ForEach-Object { Remove-Item $_.FullName -Recurse -Force -ErrorAction SilentlyContinue }
Write-Host "  removed __pycache__ trees"

Write-Host ""
Write-Host "Done. Still delete manually before push:"
Write-Host "  - venv/"
Write-Host "  - settings/user_settings.json (machine paths) if you customized it"
Write-Host "  - any leftover private media"
