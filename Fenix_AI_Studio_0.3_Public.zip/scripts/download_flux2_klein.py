"""
Download ComfyUI-native FLUX.2 Klein weights into ComfyUI/models/.

Uses Comfy-Org split packs only (not Wan2GP quanto).

Usage:
  python scripts/download_flux2_klein.py
  python scripts/download_flux2_klein.py --variant 4b
"""
from __future__ import annotations

import argparse
import shutil
import sys
from pathlib import Path

# Default: portable ComfyUI on this machine (override with --comfy)
COMFY = Path(r"D:\ComfyUI_windows_portable\ComfyUI")

# Exact Comfy-native files (distilled Klein, not base fine-tune pack)
FILES_4B = [
    (
        "Comfy-Org/flux2-klein-4B",
        "split_files/diffusion_models/flux-2-klein-4b.safetensors",
        "diffusion_models/flux-2-klein-4b.safetensors",
    ),
    (
        "Comfy-Org/flux2-klein-4B",
        "split_files/text_encoders/qwen_3_4b.safetensors",
        "text_encoders/qwen_3_4b.safetensors",
    ),
    (
        "Comfy-Org/flux2-klein-4B",
        "split_files/vae/flux2-vae.safetensors",
        "vae/flux2-vae.safetensors",
    ),
]

FILES_9B = [
    (
        "Comfy-Org/flux2-klein-9B",
        "split_files/diffusion_models/flux-2-klein-9b.safetensors",
        "diffusion_models/flux-2-klein-9b.safetensors",
    ),
    (
        "Comfy-Org/flux2-klein-9B",
        "split_files/text_encoders/qwen_3_8b.safetensors",
        "text_encoders/qwen_3_8b.safetensors",
    ),
    (
        "Comfy-Org/flux2-klein-9B",
        "split_files/vae/flux2-vae.safetensors",
        "vae/flux2-vae.safetensors",
    ),
]


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--variant", choices=["4b", "9b"], default="4b")
    parser.add_argument("--comfy", type=Path, default=COMFY)
    args = parser.parse_args()

    try:
        from huggingface_hub import hf_hub_download
    except ImportError:
        print("Install huggingface_hub: pip install huggingface_hub")
        return 1

    comfy = args.comfy
    if not comfy.is_dir():
        print(f"ComfyUI not found at {comfy}")
        return 1

    files = FILES_4B if args.variant == "4b" else FILES_9B
    models = comfy / "models"
    ok = 0

    for repo, remote, rel_dest in files:
        dest = models / rel_dest
        dest.parent.mkdir(parents=True, exist_ok=True)
        if dest.exists() and dest.stat().st_size > 50_000_000:
            print(f"SKIP {dest.name} already present ({dest.stat().st_size / 1e9:.2f} GB)")
            ok += 1
            continue
        print(f"DOWNLOAD {repo} :: {remote}", flush=True)
        print(f"  -> {dest}", flush=True)
        try:
            path = hf_hub_download(
                repo_id=repo,
                filename=remote,
                local_dir=str(models / "_hf_cache"),
            )
            src = Path(path)
            if src.resolve() != dest.resolve():
                shutil.copy2(src, dest)
            print(f"  OK {dest.stat().st_size / 1e9:.2f} GB", flush=True)
            ok += 1
        except Exception as e:
            print(f"  FAIL: {e}", flush=True)

    print(f"\nFinished {ok}/{len(files)} files.")
    if ok < len(files):
        print(
            "Some downloads failed. Set HF_TOKEN if rate-limited, or download manually from:\n"
            "  https://huggingface.co/Comfy-Org/flux2-klein-4B\n"
            "  diffusion_models/flux-2-klein-4b.safetensors\n"
            "  text_encoders/qwen_3_4b.safetensors\n"
            "  vae/flux2-vae.safetensors\n"
        )
        return 2
    print("Restart ComfyUI so it rescans models/ (Wan2GP path is no longer linked).")
    return 0


if __name__ == "__main__":
    sys.exit(main())
