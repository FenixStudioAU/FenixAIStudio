import { api } from "./api.js";
import { HistoryStack } from "./history.js";
import { TimelineView } from "./timeline.js";
import { createChatController } from "./chat.js";
import { recordPreviewWebM, downloadBlob } from "./browser_export.js";

const $ = (s, r = document) => r.querySelector(s);
const $$ = (s, r = document) => [...r.querySelectorAll(s)];

const state = {
  system: null,
  project: null,
  history: new HistoryStack(),
  playing: false,
  loop: false,
  saveTimer: null,
  jobPoll: null,
  localLoras: [],
  /** @type {{id:string,shot_id:string,kind:string,status:string,progress:number,message:string}[]} */
  jobs: [],
  /** Monotonic token so async video seeks can't yank the playhead */
  previewEpoch: 0,
  lastPreviewMode: null,
  lastPreviewKey: null,
  webmAbort: null,
  /** Top-bar activity override while Ollama story pipeline runs */
  clientActivity: null,
};

const els = {
  home: $("#view-home"),
  editor: $("#view-editor"),
  projectList: $("#project-list"),
  systemDetails: $("#system-details"),
  sysPill: $("#sys-pill"),
  projectName: $("#project-name"),
  saveStatus: $("#save-status"),
  previewVideo: $("#preview-video"),
  previewImage: $("#preview-image"),
  previewPlaceholder: $("#preview-placeholder"),
  titleOverlay: $("#preview-title-overlay"),
  mainAudio: $("#main-audio"),
  scrubber: $("#scrubber"),
  timecode: $("#timecode"),
  get jobToast() {
    return $("#job-toast") || { textContent: "" };
  },
};

let timeline;
const chatCtrl = createChatController({
  getSettings: () => api.getSettings(),
});

function showView(name) {
  const views = {
    home: els.home,
    editor: els.editor,
    wizard: $("#view-wizard"),
    amv: $("#view-amv"),
    film: $("#view-film"),
    music: $("#view-music"),
    studio: $("#view-studio"),
    settings: $("#view-settings"),
    characters: $("#view-characters"),
    chat: $("#view-chat"),
  };
  Object.entries(views).forEach(([key, el]) => {
    if (el) el.classList.toggle("active", key === name);
  });
  if (name === "chat") chatCtrl.open();
  if (name === "characters") loadCharacters();
  if (name === "editor") updateEditorModeUi();
  if (name === "music") openMusicStudio();
  if (name === "studio") openMediaStudio();
  if (name === "home") {
    loadHomeMusicTracks();
    loadHomeCharacters();
  }
}

function updateEditorModeUi() {
  const isFilm = (state.project?.kind || "music") === "film";
  const addBtn = $("#btn-add-shot");
  if (addBtn) addBtn.textContent = isFilm ? "+ Scene" : "+ Shot";
  // Soft-hide audio tools for film (still available if needed)
  const audioLabel = document.querySelector('label.btn.file-btn.compact input#audio-upload')?.closest("label");
  if (audioLabel) audioLabel.classList.toggle("hidden", isFilm);
  const analyze = $("#btn-analyze");
  const auto = $("#btn-auto-slots");
  const rebuild = $("#btn-rebuild-slots");
  [analyze, auto, rebuild].forEach((el) => el?.classList.toggle("hidden", isFilm));
}

const FX_TYPES = [
  { id: "film_grain", label: "Film grain" },
  { id: "glitch", label: "Glitch" },
  { id: "hue_cycle", label: "Hue cycle" },
  { id: "vignette", label: "Vignette" },
  { id: "bw", label: "B&W" },
  { id: "blur", label: "Blur" },
  { id: "chromatic", label: "Chromatic" },
  { id: "sharpen", label: "Sharpen" },
];

function fileUrl(rel, bust) {
  if (!state.project || !rel) return null;
  const base = api.fileUrl(state.project.id, rel);
  if (bust === false) return base;
  // Always bust — regenerated stills can reuse names; browser must not show old pixels
  const token = encodeURIComponent(String(bust || Date.now()));
  return base + (base.includes("?") ? "&" : "?") + "t=" + token;
}

function fmtTime(t) {
  t = Math.max(0, t || 0);
  const m = Math.floor(t / 60);
  const s = t % 60;
  return `${m}:${s.toFixed(1).padStart(4, "0")}`;
}

// ---------- Home ----------
async function loadSystem() {
  els.sysPill.textContent = "Checking system…";
  els.sysPill.className = "pill warn";
  if (els.systemDetails) els.systemDetails.textContent = "Contacting backend…";
  try {
    // Fast fail if server is dead
    try {
      await api.health();
    } catch (he) {
      throw he;
    }
    const sys = await api.system();
    state.system = sys;
    const online = sys.comfyui_online;
    els.sysPill.textContent = online
      ? `ComfyUI · ${sys.gpu_name || "GPU"} · ${sys.vram_gb} GB`
      : "ComfyUI offline";
    els.sysPill.className = "pill " + (online ? "good" : "warn");

    const models = (sys.models || []).filter(
      (m) => m.role === "image" || m.role === "video" || m.role === "music"
    );
    const catalog = sys.catalog || {};
    const modelLines = models
      .map((m) => {
        const icon = m.available ? "✓" : "○";
        const role = m.role ? ` · ${m.role}` : "";
        const dl =
          (!m.available &&
            (catalog[m.model_id]?.download?.comfy_org ||
              catalog[m.model_id]?.download?.docs ||
              Object.values(catalog[m.model_id]?.download || {})[0])) ||
          "";
        const missingBit = m.available
          ? `<span class="ok">ready</span>`
          : dl
            ? `<span class="muted">missing <a class="sys-model-dl" href="${escapeHtml(dl)}" target="_blank" rel="noopener" title="Open model download page">⬇</a></span>`
            : `<span class="muted">missing</span>`;
        return `<div class="row"><span>${icon} ${escapeHtml(m.label)}${escapeHtml(role)}</span>${missingBit}</div>`;
      })
      .join("");
    els.systemDetails.innerHTML = `
      <div class="row"><span>GPU</span><span>${escapeHtml(sys.gpu_name || "?")} · ${sys.vram_gb} GB</span></div>
      <div class="row"><span>ComfyUI</span><span class="${online ? "ok" : "bad"}">${online ? "online" : "offline"}</span></div>
      <div class="row"><span>FFmpeg</span><span class="${sys.ffmpeg ? "ok" : "bad"}">${sys.ffmpeg ? "found" : "missing"}</span></div>
      <div class="row"><span>Ollama</span><span class="${sys.ollama?.online ? "ok" : "bad"}">${sys.ollama?.online ? "online" : "offline"}</span></div>
      <div class="sys-models">${modelLines || `<div class="muted small">No models detected</div>`}</div>
    `;
    state.system = sys;
    populateModelSelects();
    try {
      const s = await api.getSettings();
      state.userSettings = s || state.userSettings || {};
      // Keep the Settings checkbox in sync even before opening that view —
      // otherwise Save can write optimize_low_vram=false from an unchecked default.
      if ($("#set-low-vram") && s && s.optimize_low_vram != null) {
        $("#set-low-vram").checked = !!s.optimize_low_vram;
      }
      state._settingsHydrated = true;
      applyDevUiFromSettings(s || {});
    } catch (_) {
      applyDevUiFromSettings({});
    }
  } catch (e) {
    els.sysPill.textContent = "Backend offline";
    els.sysPill.className = "pill bad";
    if (els.systemDetails) {
      els.systemDetails.innerHTML = `
        <p class="muted small"><strong>Backend offline.</strong> Run START.bat and refresh.</p>
        <p class="muted small">${escapeHtml(String(e.message || e))}</p>`;
    }
  }
}

async function loadProjects() {
  try {
    let list = await api.projects();
    list = (list || []).filter((p) => p.name !== "Chat Media (studio)");
    if (!list.length) {
      els.projectList.innerHTML = `<p class="muted">No projects yet. Create one to start.</p>`;
      return;
    }
    _renderProjectList(list);
  } catch (e) {
    els.projectList.innerHTML = `<p class="muted">Could not load projects: ${escapeHtml(String(e.message || e))}</p>`;
  }
}

function _renderProjectList(list) {
  if (!list.length) {
    els.projectList.innerHTML = `<p class="muted">No projects yet. Create one to start.</p>`;
    return;
  }
  els.projectList.innerHTML = list
    .map((p) => {
      const letter = escapeHtml(p.preview_letter || (p.name || "P")[0] || "P");
      const prev = p.preview_path
        ? `<img src="${api.fileUrl(p.id, p.preview_path)}" alt="" loading="lazy" onerror="this.replaceWith(Object.assign(document.createElement('div'),{className:'project-card-letter',textContent:'${letter}'}))" />`
        : `<div class="project-card-letter">${letter}</div>`;
      return `
    <div class="project-card" data-id="${p.id}">
      <div class="project-card-preview">${prev}</div>
      <div class="project-card-body">
        <div>
          <h3>${escapeHtml(p.name)}</h3>
          <div class="meta">${p.shot_count || 0} shots · ${fmtTime(p.duration || 0)}</div>
        </div>
        <div class="project-card-actions">
          <button type="button" class="btn ghost danger-delete compact" data-del="${p.id}">Delete</button>
          <button type="button" class="btn ghost compact" data-clone="${p.id}">Clone</button>
        </div>
      </div>
    </div>`;
    })
    .join("");
  els.projectList.querySelectorAll(".project-card").forEach((card) => {
    card.addEventListener("click", (e) => {
      if (e.target.closest("[data-del], [data-clone]")) return;
      openProject(card.dataset.id);
    });
  });
  els.projectList.querySelectorAll("[data-del]").forEach((btn) => {
    btn.addEventListener("click", async (e) => {
      e.stopPropagation();
      if (!confirm("Delete this project?")) return;
      try {
        await api.deleteProject(btn.dataset.del);
        loadProjects();
      } catch (err) {
        alert(err.message || err);
      }
    });
  });
  els.projectList.querySelectorAll("[data-clone]").forEach((btn) => {
    btn.addEventListener("click", async (e) => {
      e.stopPropagation();
      const id = btn.dataset.clone;
      if (!id) return;
      btn.disabled = true;
      const prev = btn.textContent;
      btn.textContent = "Cloning…";
      try {
        const cloned = await api.cloneProject(id);
        await loadProjects();
        if (els.jobToast) {
          els.jobToast.textContent = `Cloned as “${cloned.name || "copy"}”`;
        }
      } catch (err) {
        alert("Clone failed:\n\n" + (err.message || err));
      } finally {
        btn.disabled = false;
        btn.textContent = prev || "Clone";
      }
    });
  });
}

function _bindCharActions(box, list) {
  if (!box) return;
  box.querySelectorAll("[data-char-del]").forEach((btn) => {
    btn.onclick = async (ev) => {
      ev.stopPropagation();
      if (!confirm("Delete character from library?")) return;
      await api.deleteCharacter(btn.dataset.charDel);
      loadCharacters();
      loadHomeCharacters();
    };
  });
  box.querySelectorAll("[data-char-edit]").forEach((btn) => {
    btn.onclick = async (ev) => {
      ev.stopPropagation();
      const c = list.find((x) => x.id === btn.dataset.charEdit);
      if (!c) return;
      const name = prompt("Name", c.name);
      if (name == null) return;
      const description = prompt("Description", c.description || "") ?? c.description;
      await api.updateCharacter(c.id, { name, description });
      loadCharacters();
      loadHomeCharacters();
    };
  });
}

async function loadCharacters() {
  const box = $("#char-library");
  if (!box) return;
  try {
    const list = await api.characters();
    if (!list.length) {
      box.innerHTML = `<p class="muted small">No characters yet — add one on the left.</p>`;
      loadHomeCharacters(list);
      return;
    }
    box.innerHTML = list
      .map((c) => {
        const img = c.path
          ? `<img src="${api.characterImageUrl(c.id)}" alt="" />`
          : `<div class="char-letter">${escapeHtml((c.name || "?")[0])}</div>`;
        return `<div class="char-card" data-id="${c.id}">
          ${img}
          <strong>${escapeHtml(c.name)}</strong>
          <div class="muted small">${escapeHtml(c.category || "")}</div>
          <div class="muted small">${escapeHtml((c.description || "").slice(0, 80))}</div>
          <div class="char-actions">
            <button class="btn ghost compact" data-char-edit="${c.id}">Edit</button>
            <button class="btn danger compact" data-char-del="${c.id}">Del</button>
          </div>
        </div>`;
      })
      .join("");
    _bindCharActions(box, list);
    loadHomeCharacters(list);
  } catch (e) {
    box.innerHTML = `<p class="muted small">${escapeHtml(e.message)}</p>`;
  }
}

async function loadHomeCharacters(list) {
  const box = $("#home-char-list");
  if (!box) return;
  try {
    if (!list) list = await api.characters();
    if (!list.length) {
      box.innerHTML = `<p class="muted small">No characters yet — open Character Manager to add some.</p>`;
      return;
    }
    box.innerHTML = list
      .map((c) => {
        const img = c.path
          ? `<img src="${api.characterImageUrl(c.id)}" alt="" />`
          : `<div class="char-letter">${escapeHtml((c.name || "?")[0])}</div>`;
        return `<div class="home-char-card cut" data-id="${escapeHtml(c.id)}">
          <div class="home-char-thumb">${img}</div>
          <div class="home-char-meta">
            <strong>${escapeHtml(c.name)}</strong>
            <span class="muted small">${escapeHtml(c.category || "character")}</span>
          </div>
          <button type="button" class="btn ghost compact" data-char-edit="${escapeHtml(c.id)}">Edit</button>
        </div>`;
      })
      .join("");
    _bindCharActions(box, list);
  } catch (e) {
    box.innerHTML = `<p class="muted small">${escapeHtml(e.message || e)}</p>`;
  }
}

function formatHostStats(s) {
  if (!s) return "CPU — · RAM — · GPU —";
  const cpu = s.cpu_percent != null ? `${s.cpu_percent}%` : "—";
  const ram =
    s.ram_percent != null
      ? `${s.ram_percent}% (${s.ram_used_gb ?? "?"}/${s.ram_total_gb ?? "?"}G)`
      : "—";
  let gpu = "—";
  if (s.gpu_util_percent != null || s.gpu_mem_percent != null) {
    const u = s.gpu_util_percent != null ? `${s.gpu_util_percent}%` : "—";
    const m =
      s.gpu_mem_used_gb != null
        ? `${s.gpu_mem_used_gb}/${s.gpu_mem_total_gb}G`
        : s.gpu_mem_percent != null
          ? `${s.gpu_mem_percent}%`
          : "";
    gpu = m ? `${u} ${m}` : u;
  }
  return `CPU ${cpu} · RAM ${ram} · GPU ${gpu}`;
}

async function pollHostStats() {
  try {
    const s = await api.hostStats();
    const text = formatHostStats(s);
    const hot = (s.cpu_percent || 0) > 85 || (s.gpu_util_percent || 0) > 90 || (s.ram_percent || 0) > 90;
    ["host-stats", "host-stats-editor", "host-stats-settings", "host-stats-chat"].forEach((id) => {
      const el = document.getElementById(id);
      if (!el) return;
      el.textContent = text;
      el.classList.toggle("hot", hot);
      el.title = s.gpu_name ? `GPU: ${s.gpu_name}` : "Host resources";
    });
  } catch (_) {}
  // Activity pill shares this poll cadence
  pollActivity();
}

function setClientActivity(label, color = "ollama", detail = "") {
  state.clientActivity = label ? { label, color, detail } : null;
  if (state.clientActivity) applyActivityPills(state.clientActivity);
  else applyActivityPills({ label: "Idle", color: "idle", detail: "" });
}

function applyActivityPills(act) {
  const label = act?.label || "Idle";
  const color = act?.color || "idle";
  const detail = act?.detail || "";
  const title = detail ? `${label} — ${detail}` : label;
  document.querySelectorAll("[data-activity-pill]").forEach((el) => {
    el.textContent = label;
    el.title = title;
    el.className = `activity-pill ${color}`;
  });
}

let _activityBusy = false;
async function pollActivity() {
  if (_activityBusy) return;
  _activityBusy = true;
  try {
    // Local LLM / wizard takes priority while running
    if (state.clientActivity) {
      applyActivityPills(state.clientActivity);
      return;
    }
    const a = await api.activity();
    applyActivityPills({
      label: a.label || "Idle",
      color: a.color || "idle",
      detail: a.detail || "",
    });
  } catch (_) {
    // keep last state on network blip
  } finally {
    _activityBusy = false;
  }
}

const FX_DEFAULT = () => ({
  id: "vfx_" + Math.random().toString(16).slice(2, 10),
  type: "film_grain",
  enabled: true,
  strength: 0.5,
});

function renderEffectsList(containerId, effects, onChange) {
  const box = document.getElementById(containerId);
  if (!box) return;
  const list = effects || [];
  box.innerHTML =
    list
      .map((e, i) => {
        const opts = FX_TYPES.map(
          (t) =>
            `<option value="${t.id}" ${e.type === t.id ? "selected" : ""}>${t.label}</option>`
        ).join("");
        return `<div class="fx-row" data-i="${i}">
          <select data-f="type">${opts}</select>
          <input type="range" min="0" max="1" step="0.05" value="${e.strength ?? 0.5}" data-f="strength" title="strength" />
          <label class="check"><input type="checkbox" data-f="enabled" ${e.enabled !== false ? "checked" : ""} /> on</label>
          <button class="btn ghost compact" data-rm="${i}">✕</button>
        </div>`;
      })
      .join("") || `<p class="muted small">No effects yet</p>`;
  box.querySelectorAll("[data-f]").forEach((el) => {
    el.addEventListener("change", () => {
      const i = +el.closest(".fx-row").dataset.i;
      const f = el.dataset.f;
      let v = el.type === "checkbox" ? el.checked : el.value;
      if (f === "strength") v = parseFloat(v);
      list[i][f] = v;
      onChange(list);
    });
  });
  box.querySelectorAll("[data-rm]").forEach((btn) => {
    btn.onclick = () => {
      list.splice(+btn.dataset.rm, 1);
      onChange(list);
      renderEffectsList(containerId, list, onChange);
    };
  });
}

function renderShotEffects(shot) {
  if (!shot) {
    const b = $("#shot-effects");
    if (b) b.innerHTML = `<p class="muted small">Select a shot</p>`;
    return;
  }
  shot.effects = shot.effects || [];
  renderEffectsList("shot-effects", shot.effects, (list) => {
    shot.effects = list;
    scheduleSave(false);
  });
}

function renderGlobalEffects() {
  if (!state.project) return;
  state.project.export = state.project.export || {};
  state.project.export.global_effects = state.project.export.global_effects || [];
  renderEffectsList("global-effects", state.project.export.global_effects, (list) => {
    state.project.export.global_effects = list;
    scheduleSave(false);
  });
}

function downloadClipsZip() {
  if (!state.project) return;
  window.open(api.clipsZipUrl(state.project.id), "_blank");
}

function wireColResizer() {
  const resizer = $("#col-resizer");
  const body = $("#editor-body");
  if (!resizer || !body) return;
  let dragging = false;
  resizer.addEventListener("mousedown", (e) => {
    e.preventDefault();
    dragging = true;
    resizer.classList.add("dragging");
  });
  window.addEventListener("mousemove", (e) => {
    if (!dragging) return;
    const rect = body.getBoundingClientRect();
    const fromRight = rect.right - e.clientX;
    const w = Math.min(560, Math.max(300, fromRight));
    body.style.gridTemplateColumns = `minmax(0, 1fr) 6px ${w}px`;
  });
  window.addEventListener("mouseup", () => {
    if (!dragging) return;
    dragging = false;
    resizer.classList.remove("dragging");
  });
}

function escapeHtml(s) {
  return String(s)
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;");
}

// ---------- Project ----------
async function openProject(id) {
  const project = await api.getProject(id);
  state.project = project;
  state.history.reset(project);
  showView("editor");
  els.projectName.value = project.name;
  if (project.audio?.path) {
    els.mainAudio.src = fileUrl(project.audio.path);
  } else {
    els.mainAudio.removeAttribute("src");
  }
  timeline.setProject(project);
  populateModelSelects();
  bindInspectorFromShot(null);
  renderTitlesList();
  renderRefs();
  updateExportForm();
  startJobPoll();
  scheduleSave(false);
}

function commitHistory() {
  if (state.project) state.history.push(state.project);
}

/** Flush prompts/settings to disk. Always allowed (server merge_media protects gen paths). */
function scheduleSave(pushHist = true) {
  if (!state.project) return;
  if (pushHist) commitHistory();
  els.saveStatus.textContent = "Saving…";
  clearTimeout(state.saveTimer);
  state.saveTimer = setTimeout(() => flushSave(), 400);
}

/** Immediate save (awaitable). Call before generate / shot switch. */
async function flushSave() {
  if (!state.project) return null;
  clearTimeout(state.saveTimer);
  state.saveTimer = null;
  try {
    // Only the inspector-bound shot (if any) — never invent timing onto a new selection
    readInspectorIntoShot({ timing: true });
    state.project.name = els.projectName.value || state.project.name;
    els.saveStatus.textContent = "Saving…";
    const saved = await api.saveProject(state.project.id, state.project);
    // Keep local prompt/settings if server response is briefly stale for other shots
    state.project = mergeLocalSettings(saved, state.project);
    els.saveStatus.textContent = "Saved";
    timeline.setProject(state.project);
    return state.project;
  } catch (e) {
    els.saveStatus.textContent = "Save failed";
    console.error(e);
    return null;
  }
}

/** Prefer non-empty local prompts when server returned empty (race with concurrent saves). */
function mergeLocalSettings(serverProj, localProj) {
  if (!serverProj || !localProj) return serverProj || localProj;
  const localById = Object.fromEntries(
    (localProj.timeline?.shots || []).map((s) => [s.id, s])
  );
  for (const s of serverProj.timeline?.shots || []) {
    const loc = localById[s.id];
    if (!loc) continue;
    if (loc.image) {
      s.image = s.image || {};
      if ((loc.image.positive_prompt || "").trim() && !(s.image.positive_prompt || "").trim()) {
        s.image.positive_prompt = loc.image.positive_prompt;
      }
      if ((loc.image.negative_prompt || "").trim() && !(s.image.negative_prompt || "").trim()) {
        s.image.negative_prompt = loc.image.negative_prompt;
      }
      if (Array.isArray(loc.image.reference_ids) && loc.image.reference_ids.length) {
        if (!s.image.reference_ids?.length) s.image.reference_ids = [...loc.image.reference_ids];
      }
      // Prefer newer local prompt text when it differs and local is longer (user was typing)
      if (
        (loc.image.positive_prompt || "") !== (s.image.positive_prompt || "") &&
        (loc.image.positive_prompt || "").length > (s.image.positive_prompt || "").length
      ) {
        s.image.positive_prompt = loc.image.positive_prompt;
      }
    }
    if (loc.video) {
      s.video = s.video || {};
      if ((loc.video.animation_prompt || "").trim() && !(s.video.animation_prompt || "").trim()) {
        s.video.animation_prompt = loc.video.animation_prompt;
      }
      if (
        (loc.video.animation_prompt || "") !== (s.video.animation_prompt || "") &&
        (loc.video.animation_prompt || "").length > (s.video.animation_prompt || "").length
      ) {
        s.video.animation_prompt = loc.video.animation_prompt;
      }
    }
  }
  return serverProj;
}

/** Shot id the inspector form fields currently represent (may lag selectedShotId during switch). */
let inspectorBoundShotId = null;

function selectedShot() {
  if (!state.project || !timeline.selectedShotId) return null;
  return state.project.timeline.shots.find((s) => s.id === timeline.selectedShotId) || null;
}

function shotById(id) {
  if (!state.project || !id) return null;
  return state.project.timeline.shots.find((s) => s.id === id) || null;
}

function populateModelSelects() {
  const imgSel = $("#img-model");
  const loraBase = $("#lora-base-model");
  const vidSel = $("#vid-preset");
  const studioImg = $("#studio-img-model");
  const studioVid = $("#studio-vid-model");
  const prefImg = $("#set-preferred-image-model");
  const prefVid = $("#set-preferred-video-preset");
  const models = (state.system?.models || []).filter((m) => m.role === "image");
  const catalog = state.system?.catalog || {};
  const ids = models.length
    ? models
    : Object.entries(catalog)
        .filter(([, v]) => v.role === "image")
        .map(([id, v]) => ({ model_id: id, label: v.label, available: false }));
  const imgOptsAll = ids
    .map(
      (m) =>
        `<option value="${m.model_id}" ${m.available ? "" : "disabled"}>${escapeHtml(m.label)}${m.available ? "" : " (not installed)"}</option>`
    )
    .join("");
  const imgOptsInstalled = ids
    .filter((m) => m.available)
    .map((m) => `<option value="${m.model_id}">${escapeHtml(m.label)}</option>`)
    .join("");
  if (imgSel) imgSel.innerHTML = imgOptsAll || `<option value="flux2-klein-9b">FLUX.2 Klein 9B</option>`;
  if (loraBase) {
    loraBase.innerHTML = ids.map((m) => `<option value="${m.model_id}">${escapeHtml(m.label)}</option>`).join("");
  }
  if (studioImg) {
    studioImg.innerHTML =
      imgOptsInstalled || `<option value="flux2-klein-9b">FLUX.2 Klein 9B</option>`;
  }
  if (prefImg) {
    prefImg.innerHTML =
      `<option value="">Auto</option>` +
      (imgOptsInstalled || `<option value="flux2-klein-9b">FLUX.2 Klein 9B</option>`);
  }
  let presets = state.system?.video_presets || [{ id: "minimax-h3-i2v", label: "MiniMax H3 I2V" }];
  const vram = Number(state.system?.vram_gb || 0);
  // Mirror backend: no FastLoRA turbo under 12 GB
  if (vram > 0 && vram < 12) {
    presets = presets.filter((p) => !/turbo|fastlora/i.test(String(p.id || "") + String(p.label || "")));
  }
  const vidOptsAll = presets
    .map((p) => {
      const ok = p.available !== false;
      return `<option value="${p.id}" ${ok ? "" : "disabled"}>${escapeHtml(p.label)}${ok ? "" : " (not installed)"}</option>`;
    })
    .join("");
  const vidOptsInstalled = presets
    .filter((p) => p.available !== false)
    .map((p) => `<option value="${p.id}">${escapeHtml(p.label)}</option>`)
    .join("");
  if (vidSel) vidSel.innerHTML = vidOptsAll || `<option value="minimax-h3-i2v">MiniMax H3 I2V</option>`;
  if (studioVid) {
    studioVid.innerHTML =
      vidOptsInstalled || `<option value="minimax-h3-i2v">MiniMax H3 I2V</option>`;
    studioVid.onchange = () => updateStudioVideoPresetUI();
    updateStudioVideoPresetUI();
  }
  if (prefVid) {
    prefVid.innerHTML =
      `<option value="">Auto</option>` +
      (vidOptsInstalled || `<option value="minimax-h3-i2v">MiniMax H3 I2V</option>`);
  }
}

function isLtxVideoPreset(pid) {
  const p = String(pid || "").toLowerCase();
  return p.startsWith("ltx") || p.includes("ltx23") || (p.includes("ltx") && p.includes("ia2v"));
}

function isMinimaxVideoPreset(pid) {
  const p = String(pid || "").toLowerCase();
  return p.startsWith("minimax") || p.includes("minimax");
}

/** Lip sync checkbox / audio drive: LTX IA2V or MiniMax Ref2VA */
function supportsLipSync(pid) {
  return isLtxVideoPreset(pid) || isMinimaxVideoPreset(pid);
}

function updateStudioVideoPresetUI() {
  const pid = $("#studio-vid-model")?.value || "";
  const ltx = isLtxVideoPreset(pid);
  const minimax = isMinimaxVideoPreset(pid);
  const lips = supportsLipSync(pid);
  const audioWrap = $("#studio-vid-audio-wrap");
  const dur = $("#studio-vid-duration");
  const durCap = $("#studio-vid-duration-cap");
  const hint = $("#studio-vid-hint");
  const qSel = $("#studio-vid-quality");
  // LTX always needs audio; MiniMax uses audio when uploaded (Ref2VA lip sync)
  audioWrap?.classList.toggle("hidden", !lips);
  if (dur) {
    dur.max = ltx ? "20" : "15";
    const v = parseFloat(dur.value) || 5;
    if (!ltx && v > 15) dur.value = "15";
  }
  if (durCap) durCap.textContent = ltx ? "20" : "15";
  if (qSel) {
    const draftOpt = qSel.querySelector('option[value="draft"]');
    const finalOpt = qSel.querySelector('option[value="final"]');
    if (draftOpt) {
      draftOpt.textContent = ltx
        ? "Fast (single pass, lower res)"
        : "Draft (faster)";
    }
    if (finalOpt) {
      finalOpt.textContent = ltx
        ? "Quality (2-stage + upscale)"
        : "Final (heavier)";
    }
  }
  if (hint) {
    if (ltx) {
      hint.textContent =
        "LTX: upload audio below. Fast = single pass at lower resolution (safer on 8GB). Quality = sharper 2-stage (slower, more VRAM).";
    } else if (minimax) {
      hint.textContent =
        "MiniMax: upload audio to lip-sync (locks your still + drives mouth from audio). Without audio = plain I2V motion.";
    } else {
      hint.textContent =
        "Longer clips and Final quality need more VRAM. Draft is recommended while iterating.";
    }
  }
}

// ---------- Inspector ----------
function bindInspectorFromShot(shot) {
  // Form now represents this shot (must set BEFORE any later readInspectorIntoShot)
  inspectorBoundShotId = shot?.id || null;
  const empty = !shot;
  $("#shot-label").value = shot?.label || "";
  $("#shot-start").value = shot ? shot.start : 0;
  $("#shot-duration").value = shot ? shot.duration : 5;
  $("#shot-transition").value = shot?.transition_out || "hard_cut";
  $("#shot-trans-dur").value = shot?.transition_duration || 0;

  const img = shot?.image || {};
  const vid = shot?.video || {};
  const hasImage = !!(shot?.image_path);
  const hasVideo = !!(shot?.video_path || shot?.draft_video_path);

  // Status + next step
  let status = "Click a shot on the timeline (Shots track).";
  let hint =
    "1) Select a shot · 2) Generate or drop an image · 3) Click Generate video";
  if (shot) {
    status = `${shot.label || "Shot"} · Image: ${shot.image_status} · Video: ${shot.video_status}`;
    if (shot.last_error) status += ` · ${shot.last_error}`;
    if (!hasImage) {
      hint = "This shot needs an image first — Generate image, upload, or drag a file onto the clip.";
    } else if (!hasVideo) {
      hint = "Image ready — enter motion text above, then click Generate video (ComfyUI MiniMax).";
    } else {
      hint =
        "Shot has video. Play it, click <strong>Remove video</strong>, or <strong>Generate image</strong> again (that clears the old video).";
    }
  }
  $("#shot-status").textContent = status;
  const hintEl = $("#gen-hint");
  if (hintEl) hintEl.innerHTML = hint;

  $("#img-positive").value = img.positive_prompt || "";
  $("#img-negative").value = img.negative_prompt || state.project?.global_negative || "";
  $("#img-seed").value = img.seed ?? -1;
  $("#img-batch").value = img.batch_count || 1;
  $("#img-w").value = img.width || 1280;
  $("#img-h").value = img.height || 720;
  $("#img-aspect").value = img.aspect_ratio || "16:9";
  if (img.model_id) $("#img-model").value = img.model_id;
  const strictEl = $("#img-strict-chars");
  if (strictEl) strictEl.checked = !!img.strict_named_characters_only;
  renderShotLoras(shot);
  renderShotRefs(shot);

  const alts = $("#img-alts");
  alts.innerHTML = "";
  (shot?.image_alternatives || []).forEach((rel) => {
    const im = document.createElement("img");
    im.src = fileUrl(rel);
    if (rel === shot.image_path) im.classList.add("active");
    im.addEventListener("click", () => {
      shot.image_path = rel;
      scheduleSave();
      showPreviewAt(state.project.timeline.playhead || shot.start);
      bindInspectorFromShot(shot);
    });
    alts.appendChild(im);
  });

  $("#vid-prompt").value = vid.animation_prompt || "";
  $("#vid-motion").value = vid.motion_strength ?? 1;
  $("#vid-seed").value = vid.seed ?? -1;
  $("#vid-fps").value = vid.fps || 24;
  $("#vid-quality").value = vid.quality || "draft";
  $("#vid-camera").value = vid.camera_movement || "none";
  $("#vid-mute").checked = vid.mute_clip_audio !== false;
  if ($("#vid-lip-sync")) $("#vid-lip-sync").checked = !!vid.lip_sync;
  if (vid.preset_id) {
    const vram = Number(state.system?.vram_gb || 0);
    let pid = vid.preset_id;
    // Force off turbo on <12 GB even if the shot still has the old preset id
    if (vram > 0 && vram < 12 && /turbo|fastlora/i.test(pid)) {
      pid = "minimax-h3-i2v";
      if (shot.video) shot.video.preset_id = pid;
    }
    const vSel = $("#vid-preset");
    if (vSel) {
      // Keep the shot's engine visible even if inventory briefly marks it unavailable
      if (pid && !Array.from(vSel.options).some((o) => o.value === pid)) {
        const opt = document.createElement("option");
        opt.value = pid;
        opt.textContent = pid;
        vSel.appendChild(opt);
      }
      vSel.value = pid;
    }
  }
  updateTimelineLtxControls();

  const btnClearVid = $("#btn-clear-video");
  if (btnClearVid) {
    btnClearVid.disabled = !hasVideo;
    btnClearVid.title = hasVideo
      ? "Remove this shot's video (keeps the still image)"
      : "No video on this shot";
  }

  updateGenerateButtons();
  renderShotEffects(shot);
  renderGlobalEffects();
}

/** Jobs for current project: active image/video work per shot */
function shotJobState(shotId, kind) {
  const jobs = state.jobs || [];
  const mine = jobs.find(
    (j) =>
      j.shot_id === shotId &&
      j.kind === kind &&
      (j.status === "running" || j.status === "queued")
  );
  if (mine) return mine;
  return null;
}

function anyActiveJob(kind) {
  return (state.jobs || []).some(
    (j) => j.kind === kind && (j.status === "running" || j.status === "queued")
  );
}

function updateGenerateButtons() {
  const shot = selectedShot();
  const btnImg = $("#btn-gen-image");
  const btnVid = $("#btn-gen-video");
  if (!btnImg || !btnVid) return;

  if (!shot) {
    btnImg.disabled = true;
    btnVid.disabled = true;
    btnImg.textContent = "Generate image";
    btnVid.textContent = "Generate video";
    return;
  }

  const hasImage = !!(shot.image_path);
  const imgJob = shotJobState(shot.id, "image");
  const vidJob = shotJobState(shot.id, "video");
  const otherImgBusy = anyActiveJob("image") && !imgJob;
  const otherVidBusy = anyActiveJob("video") && !vidJob;

  // --- Image button ---
  if (imgJob) {
    if (imgJob.status === "running") {
      btnImg.disabled = true;
      btnImg.textContent = `Generating… ${Math.round((imgJob.progress || 0) * 100)}%`;
      btnImg.title = imgJob.message || "Image generation in progress";
    } else {
      btnImg.disabled = true;
      btnImg.textContent = "Queued…";
      btnImg.title = "Image job is queued";
    }
  } else if (otherImgBusy) {
    btnImg.disabled = false;
    btnImg.textContent = "Queue image";
    btnImg.title = "Another image is generating — click to queue this shot";
  } else {
    btnImg.disabled = false;
    btnImg.textContent = "Generate image";
    btnImg.title = "Generate image for this shot via ComfyUI";
  }

  // --- Video button ---
  if (!hasImage && !vidJob) {
    btnVid.disabled = true;
    btnVid.textContent = "Generate video";
    btnVid.title = "Generate or upload an image on this shot first";
  } else if (vidJob) {
    if (vidJob.status === "running") {
      btnVid.disabled = true;
      btnVid.textContent = `Generating… ${Math.round((vidJob.progress || 0) * 100)}%`;
      btnVid.title = vidJob.message || "Video generation in progress";
    } else {
      btnVid.disabled = true;
      btnVid.textContent = "Queued…";
      btnVid.title = "Video job is queued";
    }
  } else if (otherVidBusy) {
    btnVid.disabled = false;
    btnVid.textContent = "Queue video";
    btnVid.title = "Another video is generating — click to queue this shot";
  } else {
    btnVid.disabled = false;
    btnVid.textContent = hasImage && shotVideoRel(shot) ? "Regenerate video" : "Generate video";
    btnVid.title = "Animate this shot's image into video via ComfyUI";
  }
}

/**
 * Write form fields into the shot the inspector is bound to.
 * NEVER fall back to timeline.selectedShotId — that is often already the *new* clip when
 * switching shots, which used to stomp its start/duration with empty form values (t=0).
 *
 * @param {{ timing?: boolean }} opts  timing=false when timeline already owns start/duration (drag)
 */
function readInspectorIntoShot(opts = {}) {
  const timing = opts.timing !== false;
  const boundId = inspectorBoundShotId;
  if (!boundId) return;
  const shot = shotById(boundId);
  if (!shot) return;
  shot.image = shot.image || {};
  shot.video = shot.video || {};
  shot.label = $("#shot-label").value;
  if (timing) {
    // Only apply timing if fields look valid numbers — never clobber with NaN
    const startVal = parseFloat($("#shot-start").value);
    const durVal = parseFloat($("#shot-duration").value);
    if (Number.isFinite(startVal) && startVal >= 0) shot.start = startVal;
    if (Number.isFinite(durVal) && durVal > 0) shot.duration = durVal;
    shot.transition_out = $("#shot-transition").value;
    shot.transition_duration = parseFloat($("#shot-trans-dur").value) || 0;
  }
  if ($("#img-positive")) shot.image.positive_prompt = $("#img-positive").value;
  if ($("#vid-prompt")) shot.video.animation_prompt = $("#vid-prompt").value;
  if ($("#img-negative")) shot.image.negative_prompt = $("#img-negative").value;
  shot.image.seed = parseInt($("#img-seed").value, 10);
  shot.image.batch_count = parseInt($("#img-batch").value, 10) || 1;
  shot.image.width = parseInt($("#img-w").value, 10) || 1280;
  shot.image.height = parseInt($("#img-h").value, 10) || 720;
  shot.image.aspect_ratio = $("#img-aspect").value;
  shot.image.model_id = $("#img-model").value;
  const strictEl = $("#img-strict-chars");
  if (strictEl) shot.image.strict_named_characters_only = !!strictEl.checked;
  shot.video.motion_strength = parseFloat($("#vid-motion").value) || 1;
  shot.video.seed = parseInt($("#vid-seed").value, 10);
  shot.video.fps = parseInt($("#vid-fps").value, 10) || 24;
  shot.video.quality = $("#vid-quality").value;
  shot.video.camera_movement = $("#vid-camera").value;
  shot.video.mute_clip_audio = $("#vid-mute").checked;
  // Don't clobber a real shot preset if the select was rebuilt / cleared
  // (e.g. LTX option briefly missing → browser jumps to Wan/MiniMax).
  const selPreset = ($("#vid-preset")?.value || "").trim();
  if (selPreset) {
    shot.video.preset_id = selPreset;
  }
  shot.video.lip_sync = supportsLipSync(shot.video.preset_id)
    ? !!$("#vid-lip-sync")?.checked
    : false;
  shot.video.duration_sec = shot.duration;
  timeline.render();
}

function updateTimelineLtxControls() {
  const pid = $("#vid-preset")?.value || "";
  const ltx = isLtxVideoPreset(pid);
  const lips = supportsLipSync(pid);
  $("#vid-lip-sync-wrap")?.classList.toggle("hidden", !lips);
  $("#vid-lip-sync-hint")?.classList.toggle("hidden", !lips);
  const hint = $("#vid-lip-sync-hint");
  if (hint && lips) {
    hint.textContent = ltx
      ? "Describe singing or talking in the motion prompt. Audio from the timeline track drives the mouth."
      : "MiniMax: locks this shot’s still as frame 0, then drives the mouth from the project audio slice.";
  }
  const qSel = $("#vid-quality");
  if (qSel) {
    const draftOpt = qSel.querySelector('option[value="draft"]');
    const finalOpt = qSel.querySelector('option[value="final"]');
    if (draftOpt) {
      draftOpt.textContent = ltx ? "Fast (single pass, lower res)" : "Draft";
    }
    if (finalOpt) {
      finalOpt.textContent = ltx ? "Quality (2-stage + upscale)" : "Final";
    }
  }
}

/**
 * Exact whole-name match only (word boundary). Not substring / fuzzy.
 * "Sam" does not match "same". "Mary Jane" must appear as that phrase.
 */
function nameInPromptExact(name, prompt) {
  const n = String(name || "").trim();
  const p = String(prompt || "");
  if (n.length < 2 || !p.trim()) return false;
  const escaped = n.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
  return new RegExp(`(?<!\\w)${escaped}(?!\\w)`, "i").test(p);
}

function namesEquivalent(a, b) {
  const key = (s) =>
    String(s || "")
      .trim()
      .toLowerCase()
      .replace(/[\s_\-]+/g, "");
  const ka = key(a);
  const kb = key(b);
  if (!ka || !kb || ka.length < 2 || kb.length < 2) return false;
  if (ka === kb) return true;
  if (ka.length >= 4 && kb.length >= 4 && (ka.includes(kb) || kb.includes(ka))) return true;
  return false;
}

/**
 * Attach library refs: explicit chip selection first, else name match in prompt.
 * Prefer existing reference_ids (set by story apply from cast list).
 */
function autoSelectRefsForShot(shot) {
  if (!shot || !state.project) return [];
  shot.image = shot.image || {};
  shot.image.reference_ids = shot.image.reference_ids || [];
  const prompt = shot.image.positive_prompt || "";
  const noCharRefs = !!shot.image.strict_named_characters_only;
  // Checkbox: strip character/clothing/object refs; keep location/style only.
  if (noCharRefs) {
    const keep = (state.project.references || []).filter((r) => {
      const cat = (r.category || "character").toLowerCase();
      if (!["location", "environment", "style"].includes(cat)) return false;
      return (shot.image.reference_ids || []).includes(r.id);
    });
    const ids = keep.map((r) => r.id).slice(0, 6);
    shot.image.reference_ids = ids;
    return ids;
  }
  // Keep story-bound / user chips; drop dead IDs for deleted cast
  const validIds = new Set((state.project.references || []).map((r) => r.id));
  shot.image.reference_ids = (shot.image.reference_ids || []).filter((id) => validIds.has(id));
  if (shot.image.reference_ids.length) return shot.image.reference_ids;
  if (!prompt.trim()) return [];
  const order = {
    character: 0,
    clothing: 1,
    object: 2,
    location: 3,
    environment: 3,
    style: 4,
    other: 5,
  };
  const tokens = prompt.replace(/[,.]/g, " ").split(/\s+/).filter((t) => t.length >= 3);
  const refs = [...(state.project.references || [])]
    .filter(
      (r) =>
        nameInPromptExact(r.name, prompt) || tokens.some((tok) => namesEquivalent(r.name, tok))
    )
    .sort(
      (a, b) =>
        (order[String(a.category || "other").toLowerCase()] ?? 9) -
          (order[String(b.category || "other").toLowerCase()] ?? 9) ||
        String(b.name || "").length - String(a.name || "").length ||
        String(a.name || "").localeCompare(String(b.name || ""))
    );
  shot.image.reference_ids = refs.slice(0, 6).map((r) => r.id);
  return shot.image.reference_ids;
}

async function doGenerateImage() {
  readInspectorIntoShot();
  const shot = selectedShot();
  if (!shot) {
    alert("Select a shot on the timeline first.");
    return;
  }
  if (shotJobState(shot.id, "image")) {
    return; // already queued/running for this shot
  }
  // Wire character / environment refs into Flux (same as Comfy multi-ref UI)
  const attached = autoSelectRefsForShot(shot);
  if (attached.length) {
    renderShotRefs(shot);
    const names = (state.project.references || [])
      .filter((r) => attached.includes(r.id))
      .map((r) => r.name)
      .join(", ");
    els.jobToast.textContent = `Using refs: ${names}`;
  } else if ((state.project.references || []).length) {
    els.jobToast.textContent =
      "No refs matched — name characters in the prompt or click their chips under the shot.";
  }
  // Persist prompt now (not after jobs finish) so switching shots keeps it
  await flushSave();
  // Optimistically clear old video locally — server does the same when image lands.
  // Playback must follow the still being replaced (last gen wins once job finishes).
  if (shot.video_path || shot.draft_video_path) {
    shot.video_path = null;
    shot.draft_video_path = null;
    shot.video_alternatives = [];
    shot.video_status = "empty";
    updateGenerateButtons();
    bindInspectorFromShot(shot);
  }
  state.lastPreviewKey = null;
  if (els.previewImage) delete els.previewImage.dataset.rel;
  clearPreviewVideo();
  showPreviewAt(shot.start ?? state.project.timeline?.playhead ?? 0, { fromUserSeek: true });
  try {
    els.jobToast.textContent = attached.length
      ? `Queueing image with ${attached.length} ref(s)…`
      : "Queueing image…";
    const res = await api.genImage(state.project.id, shot.id, shot.image);
    // Optimistic local job entry so UI updates immediately
    state.jobs = [
      {
        id: res.job_id,
        shot_id: shot.id,
        kind: "image",
        status: "queued",
        progress: 0,
        message: "Queued",
        project_id: state.project.id,
      },
      ...state.jobs.filter((j) => j.id !== res.job_id),
    ];
    updateGenerateButtons();
    els.jobToast.textContent = `Image job queued — prompt saved`;
  } catch (e) {
    alert(
      "Image generation failed:\n\n" +
        e.message +
        "\n\nCheck ComfyUI is online and FLUX models are installed (see Help), or upload an image onto the shot."
    );
  }
}

function resolveVideoPrompt(shot) {
  shot.video = shot.video || {};
  shot.image = shot.image || {};
  let anim = (shot.video.animation_prompt || "").trim();
  if (!anim) {
    anim = (shot.image.positive_prompt || "").trim();
    if (anim) shot.video.animation_prompt = anim;
  }
  return anim;
}

async function doGenerateVideo() {
  readInspectorIntoShot();
  const shot = selectedShot();
  if (!shot) {
    alert("Select a shot on the timeline first.");
    return;
  }
  if (!shot.image_path) {
    alert(
      "This shot has no image yet.\n\n" +
        "1. Click Generate image, or\n" +
        "2. Upload / drag an image onto the timeline clip\n\n" +
        "Then click Generate video."
    );
    return;
  }
  if (shotJobState(shot.id, "video")) {
    return; // already queued/running for this shot
  }
  shot.video = shot.video || {};
  // Prefer inspector select when set; otherwise keep the shot's saved preset (LTX AMV etc.)
  const selPreset = ($("#vid-preset")?.value || "").trim();
  if (selPreset) shot.video.preset_id = selPreset;
  const preset = String(shot.video.preset_id || "");
  const ltx = isLtxVideoPreset(preset);
  const maxClip = ltx ? 20 : 15;
  let dur = Number(shot.duration) || 5;
  if (dur > maxClip) {
    const engine = ltx ? "LTX" : "MiniMax/Wan";
    if (
      !confirm(
        `This shot is ${dur.toFixed(1)}s. ${engine} clips are capped at ${maxClip}s per generation.\n\n` +
          `Generate a ${maxClip}s clip? (Timeline length stays ${dur.toFixed(1)}s.)`
      )
    ) {
      return;
    }
    dur = maxClip;
  }
  shot.video.duration_sec = dur;
  const usedImagePrompt = !(shot.video.animation_prompt || "").trim() && !!(shot.image.positive_prompt || "").trim();
  resolveVideoPrompt(shot);
  if (usedImagePrompt && $("#vid-prompt")) {
    $("#vid-prompt").value = shot.video.animation_prompt;
  }
  await flushSave();
  try {
    els.jobToast.textContent = usedImagePrompt
      ? `Queueing video (~${dur.toFixed(1)}s, using image prompt)…`
      : `Queueing ${ltx ? "LTX" : "video"} (~${dur.toFixed(1)}s)…`;
    const res = await api.genVideo(state.project.id, shot.id, shot.video);
    state.jobs = [
      {
        id: res.job_id,
        shot_id: shot.id,
        kind: "video",
        status: "queued",
        progress: 0,
        message: "Queued",
        project_id: state.project.id,
      },
      ...state.jobs.filter((j) => j.id !== res.job_id),
    ];
    updateGenerateButtons();
    els.jobToast.textContent = ltx
      ? `LTX video queued (${preset})`
      : `Video job queued (${preset || "default"})`;
  } catch (e) {
    alert("Video generation failed:\n\n" + e.message);
  }
}

async function handleFilesOnShot(shotId, files) {
  if (!state.project || !files?.length) return;
  els.jobToast.textContent = `Importing ${files.length} file(s)…`;
  try {
    for (const file of files) {
      state.project = await api.uploadShotMedia(state.project.id, shotId, file);
    }
    timeline.setProject(state.project);
    timeline.selectedShotId = shotId;
    bindInspectorFromShot(selectedShot());
    const s = selectedShot();
    if (s) showPreviewAt(s.start);
    els.jobToast.textContent = "Media attached to shot";
    state.history.reset(state.project);
  } catch (e) {
    alert("Drop/import failed:\n" + e.message);
    els.jobToast.textContent = "";
  }
}

function applyAspect() {
  const aspect = $("#img-aspect").value;
  const map = {
    "16:9": [1280, 720],
    "9:16": [720, 1280],
    "1:1": [1024, 1024],
    "4:3": [1280, 960],
  };
  const [w, h] = map[aspect] || [1280, 720];
  $("#img-w").value = w;
  $("#img-h").value = h;
}

// ---------- Preview (16:9 letterbox; video replaces image ONLY on that shot) ----------
function shotVideoRel(shot) {
  if (!shot) return null;
  return shot.video_path || shot.draft_video_path || null;
}

function clearPreviewVideo() {
  const v = els.previewVideo;
  if (!v) return;
  try {
    v.pause();
  } catch (_) {}
  v.onloadedmetadata = null;
  v.onseeked = null;
  v.onended = null;
  // Keep element in DOM but unload media so it can't steal focus/time
  v.removeAttribute("src");
  while (v.firstChild) v.removeChild(v.firstChild);
  try {
    v.load();
  } catch (_) {}
  delete v.dataset.rel;
  v.classList.remove("visible");
}

function setVideoFrameAt(offsetSec) {
  const v = els.previewVideo;
  if (!v || !v.src) return;
  const dur = Number.isFinite(v.duration) ? v.duration : null;
  // Display only: clamp frame inside the file — NEVER touch timeline playhead
  let target = Math.max(0, offsetSec);
  if (dur != null && dur > 0) {
    // Hold last frame if timeline slot is longer than the clip
    target = Math.min(target, Math.max(0, dur - 0.04));
  }
  if (Math.abs((v.currentTime || 0) - target) > 0.12) {
    try {
      v.currentTime = target;
    } catch (_) {}
  }
}

/**
 * @param {number} t absolute timeline seconds
 * @param {{fromUserSeek?: boolean}} [opts]
 */
function showPreviewAt(t, opts = {}) {
  if (!state.project) return;
  // Master clock = argument only (audio / scrubber / click). Never derived from video.
  const songDur = state.project.audio?.duration || timeline.duration() || 0;
  t = Math.max(0, Math.min(t, songDur || t));
  state.project.timeline.playhead = t;
  timeline.setPlayhead(t);
  els.scrubber.max = Math.max(1, Math.floor((songDur || 1) * 100));
  els.scrubber.value = Math.floor(t * 100);
  els.timecode.textContent = `${fmtTime(t)} / ${fmtTime(songDur)}`;

  // Sync music only when user seeks (not every animation frame while playing)
  if (opts.fromUserSeek && els.mainAudio.src) {
    try {
      if (Math.abs((els.mainAudio.currentTime || 0) - t) > 0.15) {
        els.mainAudio.currentTime = t;
      }
    } catch (_) {}
  }

  const title = (state.project.timeline.titles || []).find(
    (x) => t >= x.start && t < x.start + x.duration
  );
  if (title) {
    els.titleOverlay.textContent = title.text;
    els.titleOverlay.classList.add("show");
  } else {
    els.titleOverlay.classList.remove("show");
  }

  const shot =
    (state.project.timeline.shots || []).find((s) => t >= s.start && t < s.start + s.duration) ||
    null;
  const videoRel = shotVideoRel(shot);
  const muteClip = shot?.video?.mute_clip_audio !== false;
  const epoch = ++state.previewEpoch;

  if (videoRel && shot) {
    const url = fileUrl(videoRel);
    const offset = Math.max(0, t - shot.start);
    const key = `video:${videoRel}`;

    els.previewPlaceholder.style.display = "none";
    els.previewImage.classList.remove("visible");
    // Don't strip image src — keeps still ready when we leave this shot

    if (state.lastPreviewKey !== key) {
      clearPreviewVideo();
      els.previewVideo.src = url;
      els.previewVideo.dataset.rel = videoRel;
      els.previewVideo.muted = muteClip;
      els.previewVideo.playsInline = true;
      // Prevent HTMLMediaElement from firing weird ended→playhead behavior
      els.previewVideo.onended = (e) => {
        e.preventDefault?.();
        // Freeze last frame; timeline continues via audio clock
        try {
          els.previewVideo.pause();
        } catch (_) {}
      };
      const onMeta = () => {
        if (epoch !== state.previewEpoch) return;
        setVideoFrameAt(offset);
        if (state.playing) {
          // Only play if still inside this clip's media range
          const d = els.previewVideo.duration;
          if (!d || offset < d - 0.05) {
            els.previewVideo.play().catch(() => {});
          } else {
            els.previewVideo.pause();
          }
        }
      };
      els.previewVideo.addEventListener("loadedmetadata", onMeta, { once: true });
      try {
        els.previewVideo.load();
      } catch (_) {}
      state.lastPreviewKey = key;
      state.lastPreviewMode = "video";
    } else {
      els.previewVideo.muted = muteClip;
      setVideoFrameAt(offset);
      if (state.playing) {
        const d = els.previewVideo.duration;
        if (!d || offset < d - 0.05) {
          if (els.previewVideo.paused) els.previewVideo.play().catch(() => {});
        } else {
          els.previewVideo.pause();
        }
      } else {
        els.previewVideo.pause();
      }
    }
    els.previewVideo.classList.add("visible");
  } else if (shot?.image_path) {
    // Image-only shot: must fully release video so stills show again after a video shot
    if (state.lastPreviewMode === "video" || els.previewVideo.classList.contains("visible")) {
      clearPreviewVideo();
    }
    // Prefer the active still (last generated). Key includes path so a regen with a
    // new file always reloads; token busts browser cache if the path ever repeats.
    const imgKey = `image:${shot.image_path}`;
    state.lastPreviewMode = "image";
    els.previewPlaceholder.style.display = "none";
    const imgUrl = fileUrl(shot.image_path, shot.image_path);
    if (state.lastPreviewKey !== imgKey || els.previewImage.dataset.rel !== shot.image_path) {
      els.previewImage.src = imgUrl;
      els.previewImage.dataset.rel = shot.image_path;
      state.lastPreviewKey = imgKey;
    }
    els.previewImage.classList.add("visible");
  } else {
    clearPreviewVideo();
    els.previewImage.classList.remove("visible");
    state.lastPreviewMode = "empty";
    state.lastPreviewKey = null;
    els.previewPlaceholder.style.display = "grid";
    els.previewPlaceholder.querySelector("span").textContent = shot
      ? `Empty · ${shot.label || "Shot"}`
      : "Import audio and create shots";
  }
}

let raf = 0;
function tick() {
  if (!state.playing || !state.project) return;
  const audio = els.mainAudio;
  // Clock source: main music track only (never the clip video)
  let t;
  if (audio.src) {
    t = audio.currentTime || 0;
  } else {
    t = (state.project.timeline.playhead || 0) + 1 / 30;
    state.project.timeline.playhead = t;
  }
  const dur = state.project.audio?.duration || timeline.duration();
  if (t >= dur - 0.02) {
    if (state.loop) {
      t = 0;
      if (audio.src) audio.currentTime = 0;
    } else {
      pause();
      t = dur;
    }
  }
  showPreviewAt(t);
  raf = requestAnimationFrame(tick);
}

function play() {
  state.playing = true;
  const t = state.project?.timeline?.playhead || 0;
  if (els.mainAudio.src) {
    try {
      els.mainAudio.currentTime = t;
    } catch (_) {}
    els.mainAudio.play().catch(() => {});
  }
  showPreviewAt(t);
  cancelAnimationFrame(raf);
  raf = requestAnimationFrame(tick);
  const pb = $("#btn-play");
  if (pb) pb.classList.add("active-play");
}

function pause() {
  state.playing = false;
  els.mainAudio.pause();
  try {
    els.previewVideo.pause();
  } catch (_) {}
  cancelAnimationFrame(raf);
  const pb = $("#btn-play");
  if (pb) pb.classList.remove("active-play");
}

function seekTo(t) {
  pause();
  const songDur = state.project?.audio?.duration || timeline?.duration?.() || 0;
  t = Math.max(0, songDur ? Math.min(t, songDur) : t);
  if (els.mainAudio.src) {
    try {
      els.mainAudio.currentTime = t;
    } catch (_) {}
  }
  showPreviewAt(t, { fromUserSeek: true });
}

// ---------- Titles / refs ----------
function renderTitlesList() {
  const box = $("#titles-list");
  if (!state.project) return;
  box.innerHTML = (state.project.timeline.titles || [])
    .map(
      (t, i) => `
    <div class="panel" style="padding:8px;margin-top:8px">
      <label>Text <input data-ti="${i}" data-f="text" value="${escapeHtml(t.text)}" /></label>
      <div class="grid-2">
        <label>Start <input type="number" step="0.1" data-ti="${i}" data-f="start" value="${t.start}" /></label>
        <label>Dur <input type="number" step="0.1" data-ti="${i}" data-f="duration" value="${t.duration}" /></label>
      </div>
      <label>Size <input type="number" data-ti="${i}" data-f="size" value="${t.size}" /></label>
      <button class="btn danger compact" data-del-title="${i}">Remove</button>
    </div>`
    )
    .join("");
  box.querySelectorAll("input[data-ti]").forEach((inp) => {
    inp.addEventListener("change", () => {
      const i = +inp.dataset.ti;
      const f = inp.dataset.f;
      let v = inp.value;
      if (["start", "duration", "size"].includes(f)) v = parseFloat(v);
      state.project.timeline.titles[i][f] = v;
      timeline.render();
      scheduleSave();
    });
  });
  box.querySelectorAll("[data-del-title]").forEach((btn) => {
    btn.addEventListener("click", () => {
      state.project.timeline.titles.splice(+btn.dataset.delTitle, 1);
      renderTitlesList();
      timeline.render();
      scheduleSave();
    });
  });
  $("#sub-enabled").checked = !!state.project.subtitles?.enabled;
  $("#sub-burn").checked = state.project.subtitles?.burn_in !== false;
}

function renderRefs() {
  const box = $("#ref-library");
  if (!box || !state.project) return;
  box.innerHTML = (state.project.references || [])
    .map(
      (r) => `
    <div class="ref-card">
      <img src="${fileUrl(r.path)}" alt="" />
      <div><strong>${escapeHtml(r.name)}</strong></div>
      <div class="muted">${escapeHtml(r.category || "")}</div>
      <div class="muted small">${escapeHtml(r.description || r.notes || "")}</div>
      <button class="btn ghost compact" data-edit-ref="${r.id}">Edit desc</button>
      <button class="btn danger compact" data-del-ref="${r.id}">Delete</button>
    </div>`
    )
    .join("") || `<p class="muted">No references yet. Import from Character library or upload.</p>`;
  box.querySelectorAll("[data-edit-ref]").forEach((btn) => {
    btn.addEventListener("click", async () => {
      const r = (state.project.references || []).find((x) => x.id === btn.dataset.editRef);
      if (!r) return;
      const description = prompt("Description for LLM / notes", r.description || r.notes || "");
      if (description == null) return;
      state.project = await api.patchReference(state.project.id, r.id, { description });
      renderRefs();
    });
  });
  box.querySelectorAll("[data-del-ref]").forEach((btn) => {
    btn.addEventListener("click", async () => {
      state.project = await api.deleteReference(state.project.id, btn.dataset.delRef);
      renderRefs();
      bindInspectorFromShot(selectedShot());
    });
  });
}

/** Image/style LoRAs only — hide ACE/music/audio adapters from the shot picker. */
function isShotImageLoraName(name) {
  const n = String(name || "").toLowerCase().replace(/\\/g, "/");
  if (!n) return false;
  if (/(^|\/)(ace|music|audio|t2a)\//.test(n)) return false;
  if (/\b(ace.?step|ace15|music.?lora|audio.?lora|minimax.?music)\b/.test(n)) return false;
  return true;
}

function shotLoraChoices() {
  return (state.localLoras || []).filter((x) => isShotImageLoraName(x.name));
}

function shotExtraRefIds(shot) {
  return Array.isArray(shot?.image?.shot_extra_ref_ids) ? shot.image.shot_extra_ref_ids : [];
}

function renderShotRefs(shot) {
  const box = $("#shot-refs");
  if (!box) return;
  const refs = state.project?.references || [];
  const prompt = (shot?.image?.positive_prompt || $("#img-positive")?.value || "").toLowerCase();
  const extras = new Set(shotExtraRefIds(shot));
  const autoHint = refs
    .filter((r) => r.name && prompt.includes(String(r.name).toLowerCase()))
    .map((r) => r.name);
  const uploadInput = $("#shot-ref-upload");
  const uploadBtn = uploadInput?.closest("label");
  if (uploadBtn && uploadInput) {
    const nExtra = extras.size;
    const full = nExtra >= 2;
    uploadBtn.classList.toggle("disabled", full);
    uploadInput.disabled = full;
    uploadBtn.title = full
      ? "Already have 2 extra stills on this shot"
      : "Upload an extra still for this shot (max 2)";
  }
  box.innerHTML =
    (refs.length
      ? `<p class="muted small" style="margin:0 0 6px 0">
          Click chips to attach / detach. Order ≈ characters first.
          ${autoHint.length ? `<br/><strong>Named in prompt:</strong> ${autoHint.map(escapeHtml).join(", ")}` : ""}
          ${extras.size ? `<br/><strong>Extras on this shot:</strong> ${extras.size}/2` : ""}
        </p>`
      : `<p class="muted small" style="margin:0 0 6px 0">No project refs yet — upload a still above, or add cast under References.</p>`) +
    (refs
      .map((r) => {
        const on = shot?.image?.reference_ids?.includes(r.id);
        const mentioned = r.name && prompt.includes(String(r.name).toLowerCase());
        const extra = extras.has(r.id);
        return `<span class="ref-chip ${on ? "on" : ""} ${mentioned && !on ? "mentioned" : ""}" data-ref="${r.id}" title="${escapeHtml(r.category || "")}${extra ? " · shot extra" : ""}">
          ${escapeHtml(r.name)}${extra ? " +" : ""}${on ? " ✓" : mentioned ? " ~" : ""}
        </span>`;
      })
      .join("") || "");
  box.querySelectorAll(".ref-chip").forEach((chip) => {
    chip.addEventListener("click", () => {
      const s = selectedShot();
      if (!s) return;
      s.image.reference_ids = s.image.reference_ids || [];
      const id = chip.dataset.ref;
      if (s.image.reference_ids.includes(id)) {
        s.image.reference_ids = s.image.reference_ids.filter((x) => x !== id);
      } else {
        s.image.reference_ids.push(id);
      }
      renderShotRefs(s);
      scheduleSave();
    });
  });
}

function renderShotLoras(shot) {
  const box = $("#shot-loras");
  if (!box) return;
  const list = shot?.image?.loras || [];
  const choices = shotLoraChoices();
  const optsFor = (selected) => {
    const names = choices.map((x) => x.name);
    // Keep a selected audio/system LoRA visible so the user can clear it to (none)
    if (selected && !names.includes(selected)) names.unshift(selected);
    return (
      `<option value="">(none)</option>` +
      names
        .map(
          (n) =>
            `<option value="${escapeHtml(n)}" ${n === selected ? "selected" : ""}>${escapeHtml(n)}</option>`
        )
        .join("")
    );
  };
  box.innerHTML = list
    .map(
      (l, i) => `
    <div class="shot-lora-row">
      <select data-li="${i}" data-f="name">${optsFor(l.name || "")}</select>
      <input type="number" step="0.05" data-li="${i}" data-f="strength_model" value="${l.strength_model}" title="model" />
      <input type="number" step="0.05" data-li="${i}" data-f="strength_clip" value="${l.strength_clip}" title="clip" />
      <button type="button" class="btn ghost compact" data-rm-lora="${i}" title="Remove">✕</button>
    </div>`
    )
    .join("") || `<p class="muted small">No LoRAs on this shot</p>`;
  box.querySelectorAll("[data-li]").forEach((inp) => {
    inp.addEventListener("change", () => {
      const s = selectedShot();
      if (!s) return;
      const i = +inp.dataset.li;
      if (!s.image.loras?.[i]) return;
      if (inp.dataset.f === "name") {
        const v = inp.value || "";
        if (!v) {
          s.image.loras.splice(i, 1);
          renderShotLoras(s);
          scheduleSave();
          return;
        }
        s.image.loras[i].name = v;
        s.image.loras[i].enabled = true;
      } else {
        s.image.loras[i][inp.dataset.f] = parseFloat(inp.value);
        s.image.loras[i].enabled = true;
      }
      scheduleSave();
    });
  });
  box.querySelectorAll("[data-rm-lora]").forEach((btn) => {
    btn.addEventListener("click", () => {
      const s = selectedShot();
      if (!s?.image?.loras) return;
      s.image.loras.splice(+btn.dataset.rmLora, 1);
      renderShotLoras(s);
      scheduleSave();
    });
  });
}

function updateExportForm() {
  if (!state.project) return;
  $("#exp-preset").value = state.project.export.preset || "final";
  let res = state.project.export.resolution || "1920x1080";
  if (res !== "1920x1080" && res !== "1280x720") res = "1920x1080";
  $("#exp-res").value = res;
  $("#exp-fps").value = state.project.export.fps || 24;
  $("#exp-subs").checked = state.project.export.include_subtitles !== false;
}

// ---------- Jobs ----------
const _handledJobIds = new Set();
let _hadActiveJobs = false;
let _pollBusy = false;
let _pollTimer = null;

function startJobPoll() {
  if (_pollTimer) clearTimeout(_pollTimer);
  const tick = async () => {
    const activeNow = (state.jobs || []).some(
      (j) => j.status === "running" || j.status === "queued"
    );
    // Poll often only while generating; idle = every 8s (stops log spam)
    const delay = activeNow || _hadActiveJobs ? 1500 : 8000;
    _pollTimer = setTimeout(tick, delay);
    if (!state.project || _pollBusy) return;
    _pollBusy = true;
    try {
      await pollJobsOnce();
    } finally {
      _pollBusy = false;
    }
  };
  tick();
}

async function pollJobsOnce() {
  if (!state.project) return;
  try {
    const jobs = await api.jobs(state.project.id);
    state.jobs = jobs || [];
    updateGenerateButtons();

    const active = state.jobs.filter((j) => j.status === "running" || j.status === "queued");
    if (active.length) {
      _hadActiveJobs = true;
      const j = active[0];
      const pct = Math.round((j.progress || 0) * 100);
      const q = active.length > 1 ? ` (+${active.length - 1} queued)` : "";
      els.jobToast.textContent = `${j.kind} ${j.status} ${pct}% — ${j.message || ""}${q}`;
    }

    let needRefresh = false;
    let lastMsg = "";
    for (const j of state.jobs) {
      if (_handledJobIds.has(j.id)) continue;
      if (j.status === "done") {
        _handledJobIds.add(j.id);
        needRefresh = true;
        lastMsg = j.kind === "video" ? "Video ready — on timeline" : "Image ready — on timeline";
      } else if (j.status === "error") {
        _handledJobIds.add(j.id);
        needRefresh = true;
        lastMsg = `Error: ${j.error || "job failed"}`;
      }
    }

    if (needRefresh || (_hadActiveJobs && active.length === 0)) {
      _hadActiveJobs = active.length > 0;
      await reloadProjectPreservePlayhead(lastMsg);
    }
    if (!active.length && !needRefresh) {
      _hadActiveJobs = false;
      if (!els.jobToast.textContent?.startsWith("Error") && !els.jobToast.textContent?.includes("ready")) {
        // leave last "ready" message briefly; clear stale running text
        if (els.jobToast.textContent?.includes("running") || els.jobToast.textContent?.includes("queued")) {
          els.jobToast.textContent = "";
        }
      }
    }
  } catch (_) {}
}

async function reloadProjectPreservePlayhead(msg) {
  const playhead = state.project?.timeline?.playhead || 0;
  const sel = timeline?.selectedShotId;
  // Keep any in-progress typing on the currently selected shot
  readInspectorIntoShot();
  const localSnapshot = state.project;
  const p = await api.getProject(state.project.id);
  clearTimeout(state.saveTimer);
  state.project = mergeLocalSettings(p, localSnapshot);
  // Server media wins after a gen job — never keep a stale local still/video pointer
  const serverById = Object.fromEntries((p.timeline?.shots || []).map((s) => [s.id, s]));
  for (const s of state.project.timeline?.shots || []) {
    const srv = serverById[s.id];
    if (!srv) continue;
    s.image_path = srv.image_path;
    s.thumbnail_path = srv.thumbnail_path;
    s.image_alternatives = srv.image_alternatives || [];
    s.image_status = srv.image_status;
    s.video_path = srv.video_path;
    s.draft_video_path = srv.draft_video_path;
    s.video_alternatives = srv.video_alternatives || [];
    s.video_status = srv.video_status;
    // Engine/quality from server after prompt-regen / jobs (don't let local MiniMax default stick)
    if (srv.video) {
      s.video = s.video || {};
      if (srv.video.preset_id) s.video.preset_id = srv.video.preset_id;
      if (srv.video.quality) s.video.quality = srv.video.quality;
      if (srv.video.ltx_mode != null) s.video.ltx_mode = srv.video.ltx_mode;
      if (srv.video.lip_sync != null) s.video.lip_sync = srv.video.lip_sync;
    }
  }
  state.history.reset(state.project);
  timeline.setProject(state.project);
  if (sel) timeline.selectedShotId = sel;
  state.lastPreviewKey = null;
  state.lastPreviewMode = null;
  if (els.previewImage) {
    delete els.previewImage.dataset.rel;
    els.previewImage.removeAttribute("src");
  }
  clearPreviewVideo();
  bindInspectorFromShot(selectedShot());
  showPreviewAt(playhead, { fromUserSeek: true });
  if (msg) els.jobToast.textContent = msg;
}

async function clearSelectedVideo() {
  const shot = selectedShot();
  if (!shot) return;
  if (!shot.video_path && !shot.draft_video_path) {
    els.jobToast.textContent = "No video on this shot";
    return;
  }
  if (!confirm("Remove video from this shot? The still image stays.")) return;
  try {
    state.project = await api.clearShotVideo(state.project.id, shot.id);
    timeline.setProject(state.project);
    state.history.reset(state.project);
    bindInspectorFromShot(selectedShot());
    showPreviewAt(state.project.timeline.playhead || shot.start, { fromUserSeek: true });
    els.jobToast.textContent = "Video removed";
  } catch (e) {
    alert("Could not remove video:\n" + e.message);
  }
}

// ---------- LoRA modal ----------
async function refreshLocalLoras() {
  state.localLoras = await api.loras();
  const box = $("#local-loras");
  box.innerHTML = state.localLoras
    .map(
      (l) => `
    <div class="lora-card">
      <strong>${escapeHtml(l.name)}</strong>
      <div class="muted">${l.size_mb} MB</div>
    </div>`
    )
    .join("") || `<p class="muted">No LoRAs in ComfyUI/models/loras</p>`;
  renderShotLoras(selectedShot());
}

async function searchLoras() {
  const q = $("#lora-query").value;
  const base = $("#lora-base-model").value || "flux2-klein-4b";
  const box = $("#hf-loras");
  box.innerHTML = `<p class="muted">Searching (compatible only)…</p>`;
  try {
    const results = await api.searchLoras(q, base);
    if (!results.length) {
      box.innerHTML = `<p class="muted">No compatible LoRAs found for ${base}.</p>`;
      return;
    }
    box.innerHTML = results
      .map(
        (r) => `
      <div class="lora-card">
        <img src="${r.preview_url}" alt="" onerror="this.style.display='none'" />
        <strong>${escapeHtml(r.name)}</strong>
        <div class="muted">${escapeHtml(r.creator)} · ${r.downloads || 0} dl</div>
        <div class="muted small">${escapeHtml(r.compatibility)} · ${escapeHtml(r.license)}</div>
        <button class="btn primary compact" data-dl="${r.id}">Download</button>
        <a class="muted small" href="${r.url}" target="_blank" rel="noopener">HF page</a>
      </div>`
      )
      .join("");
    box.querySelectorAll("[data-dl]").forEach((btn) => {
      btn.addEventListener("click", async () => {
        btn.disabled = true;
        btn.textContent = "Downloading…";
        try {
          const res = await api.downloadLora(btn.dataset.dl);
          btn.textContent = "Installed";
          await refreshLocalLoras();
          alert(`Installed ${res.name} (${res.size_mb} MB)`);
        } catch (e) {
          btn.textContent = "Failed";
          alert(e.message);
        }
      });
    });
  } catch (e) {
    box.innerHTML = `<p class="muted">${escapeHtml(e.message)}</p>`;
  }
}

// ---------- Wire UI ----------
function wire() {
  timeline = new TimelineView($("#timeline"), {
    fileUrl,
    onSelectShot: (id) => {
      // Flush prompts/settings for the *previous* bound shot only (never the new id).
      if (inspectorBoundShotId && inspectorBoundShotId !== id) {
        readInspectorIntoShot({ timing: true });
      }
      timeline.selectedShotId = id;
      bindInspectorFromShot(selectedShot());
      timeline.render();
      const s = selectedShot();
      // Preview only — never rewrite shot.start from form here
      if (s) {
        const ph = state.project?.timeline?.playhead ?? 0;
        if (ph >= s.start && ph < s.start + s.duration) {
          showPreviewAt(ph, { fromUserSeek: true });
        } else {
          seekTo(s.start);
        }
      }
      updateGenerateButtons();
      scheduleSave(false);
    },
    onChange: (push = true) => {
      // Timeline owns start/duration after drag/resize/swap — never clobber from form.
      readInspectorIntoShot({ timing: false });
      const s = selectedShot();
      if (s && s.id === inspectorBoundShotId) {
        if ($("#shot-start")) $("#shot-start").value = s.start;
        if ($("#shot-duration")) $("#shot-duration").value = s.duration;
      }
      scheduleSave(push);
    },
    onSeek: (t) => seekTo(t),
    onFilesDrop: (shotId, files) => handleFilesOnShot(shotId, files),
  });

  $("#btn-new-project").onclick = () => $("#modal-new").classList.remove("hidden");
  $("#btn-new-film")?.addEventListener("click", () => openFilmWizard());
  $("#btn-music-gen")?.addEventListener("click", () => {
    showView("music");
    loadMusicLoras();
  });
  $("#btn-comfy-studio")?.addEventListener("click", () => showView("studio"));
  $("#btn-image-editor")?.addEventListener("click", () => {
    window.open("/image-editor/", "_blank", "noopener");
  });
  $("#btn-daw")?.addEventListener("click", () => {
    window.open("/daw/", "_blank", "noopener");
  });
  $("#btn-refresh-music")?.addEventListener("click", () => loadHomeMusicTracks());
  wireMusicStudio();
  wireMediaStudio();
  wireEmergencyStop();
  $("#btn-create-project").onclick = async () => {
    const name = $("#new-project-name").value || "Untitled Music Video";
    const p = await api.createProject(name, { kind: "music" });
    $("#modal-new").classList.add("hidden");
    await openProject(p.id);
  };
  $("#btn-refresh-projects").onclick = loadProjects;
  $("#btn-back-home").onclick = () => {
    pause();
    showView("home");
    loadProjects();
  };
  els.projectName.addEventListener("change", () => scheduleSave());

  $("#btn-undo").onclick = () => {
    const p = state.history.undo();
    if (p) {
      state.project = p;
      timeline.setProject(p);
      bindInspectorFromShot(selectedShot());
      scheduleSave(false);
    }
  };
  $("#btn-redo").onclick = () => {
    const p = state.history.redo();
    if (p) {
      state.project = p;
      timeline.setProject(p);
      bindInspectorFromShot(selectedShot());
      scheduleSave(false);
    }
  };

  // tabs
  $$(".inspector-tabs .tab").forEach((tab) => {
    tab.onclick = () => {
      $$(".inspector-tabs .tab").forEach((t) => t.classList.remove("active"));
      tab.classList.add("active");
      $$(".tab-body").forEach((b) => b.classList.add("hidden"));
      $(`#tab-${tab.dataset.tab}`).classList.remove("hidden");
    };
  });

  // inspector fields
  [
    "shot-label",
    "shot-start",
    "shot-duration",
    "shot-transition",
    "shot-trans-dur",
    "img-positive",
    "img-negative",
    "img-seed",
    "img-batch",
    "img-w",
    "img-h",
    "img-model",
    "vid-prompt",
    "vid-motion",
    "vid-seed",
    "vid-fps",
    "vid-quality",
    "vid-camera",
    "vid-mute",
    "vid-preset",
    "vid-lip-sync",
    "img-strict-chars",
  ].forEach((id) => {
    const el = document.getElementById(id);
    if (!el) return;
    el.addEventListener("change", () => {
      if (id === "vid-preset") {
        const shot = selectedShot();
        const prev = shot?.video?.preset_id || "";
        const next = el.value || "";
        updateTimelineLtxControls();
        if (
          shot &&
          isLtxVideoPreset(prev) &&
          !isLtxVideoPreset(next) &&
          Number(shot.duration) > 10.01
        ) {
          const dur = Number(shot.duration);
          const n = Math.ceil(dur / 10);
          const each = dur / n;
          const ok = confirm(
            `This LTX shot is ${dur.toFixed(1)}s.\n\n` +
              `Split into ${n}×${each.toFixed(1)}s clips for the new engine?\n` +
              `(Same place on the timeline — neighbors stay put.)\n\n` +
              `Cancel = keep one long clip (may clamp at generate).`
          );
          if (ok) {
            timeline.splitShotIntoEqual(shot.id, n, next);
            bindInspectorFromShot(selectedShot());
            scheduleSave();
            return;
          }
        }
      }
      readInspectorIntoShot();
      scheduleSave();
    });
    el.addEventListener("input", () => {
      if (id === "img-positive" || id === "vid-prompt" || id === "img-negative") {
        readInspectorIntoShot();
        scheduleSave(false);
      }
    });
  });
  $("#img-aspect").addEventListener("change", () => {
    applyAspect();
    readInspectorIntoShot();
    scheduleSave();
  });

  $("#btn-add-shot").onclick = () => {
    const t = state.project.timeline.playhead || 0;
    timeline.addShotAt(t);
    bindInspectorFromShot(selectedShot());
  };
  $("#btn-realign-shots")?.addEventListener("click", () => {
    if (!state.project) return;
    timeline.realignShots();
    const s = selectedShot();
    if (s) {
      if ($("#shot-start")) $("#shot-start").value = s.start;
      if ($("#shot-duration")) $("#shot-duration").value = s.duration;
    }
    els.jobToast.textContent = "Shots realigned (gaps closed)";
  });
  $("#btn-delete-shot").onclick = () => {
    timeline.deleteSelected();
    bindInspectorFromShot(null);
  };
  $("#btn-split-shot").onclick = () => {
    timeline.splitAt(state.project.timeline.playhead || 0);
    bindInspectorFromShot(selectedShot());
  };

  $("#audio-upload").onchange = async (e) => {
    const f = e.target.files?.[0];
    if (!f) return;
    els.jobToast.textContent = "Uploading audio…";
    state.project = await api.uploadAudio(state.project.id, f);
    els.mainAudio.src = fileUrl(state.project.audio.path);
    timeline.setProject(state.project);
    state.history.reset(state.project);
    els.jobToast.textContent = "Audio ready";
    showPreviewAt(0);
  };

  $("#btn-rebuild-slots").onclick = async () => {
    const d = parseFloat($("#slot-duration").value) || 5;
    state.project = await api.autoSlots(state.project.id, { mode: "fixed", duration: d });
    timeline.setProject(state.project);
    state.history.reset(state.project);
  };
  $("#btn-analyze").onclick = async () => {
    els.jobToast.textContent = "Analyzing audio…";
    await api.analyzeAudio(state.project.id);
    els.jobToast.textContent = "Analysis complete";
  };
  $("#btn-auto-slots").onclick = async () => {
    const d = parseFloat($("#slot-duration").value) || 5;
    const mode = $("#auto-mode").value;
    state.project = await api.autoSlots(state.project.id, { mode, duration: d });
    timeline.setProject(state.project);
    state.history.reset(state.project);
  };

  $("#snap-toggle").onchange = (e) => {
    timeline.snap = e.target.checked;
    state.project.timeline.snap = e.target.checked;
  };
  $("#btn-zoom-in").onclick = () => timeline.zoom(10);
  $("#btn-zoom-out").onclick = () => timeline.zoom(-10);

  $("#btn-play").onclick = play;
  $("#btn-pause").onclick = pause;
  $("#btn-loop").onclick = (e) => {
    state.loop = !state.loop;
    e.currentTarget.dataset.on = state.loop ? "1" : "0";
    e.currentTarget.textContent = state.loop ? "Loop ✓" : "Loop";
  };
  $("#btn-fullscreen").onclick = () => {
    const stage = $("#preview-stage");
    if (document.fullscreenElement) document.exitFullscreen();
    else stage.requestFullscreen?.();
  };
  els.scrubber.oninput = () => {
    const t = (+els.scrubber.value) / 100;
    seekTo(t);
  };

  $("#btn-gen-image").onclick = () => doGenerateImage();
  $("#btn-gen-video").onclick = () => doGenerateVideo();
  $("#btn-regen-prompts")?.addEventListener("click", () => doRegeneratePrompts());
  $("#btn-bulk-images")?.addEventListener("click", () => doBulkImages());
  $("#btn-bulk-videos")?.addEventListener("click", () => doBulkVideos());
  $("#btn-apply-quality")?.addEventListener("click", async () => {
    if (!state.project) return;
    const q = $("#global-vid-quality")?.value || "draft";
    try {
      state.project = await api.applyVideoQuality(state.project.id, q);
      timeline.setProject(state.project);
      bindInspectorFromShot(selectedShot());
      els.jobToast.textContent = `All shots set to ${q} quality`;
    } catch (e) {
      alert(e.message);
    }
  });
  $("#btn-download-clips")?.addEventListener("click", () => downloadClipsZip());
  $("#btn-download-clips-tab")?.addEventListener("click", () => downloadClipsZip());
  $("#btn-add-shot-fx")?.addEventListener("click", () => {
    const s = selectedShot();
    if (!s) return alert("Select a shot first");
    s.effects = s.effects || [];
    s.effects.push(FX_DEFAULT());
    renderShotEffects(s);
    scheduleSave(false);
  });
  $("#btn-add-global-fx")?.addEventListener("click", () => {
    if (!state.project) return;
    state.project.export = state.project.export || {};
    state.project.export.global_effects = state.project.export.global_effects || [];
    state.project.export.global_effects.push(FX_DEFAULT());
    renderGlobalEffects();
    scheduleSave(false);
  });
  $("#btn-settings")?.addEventListener("click", () => openSettings());
  $("#btn-settings-back")?.addEventListener("click", () => showView("home"));
  $("#btn-settings-save")?.addEventListener("click", () => saveSettingsUi());
  $("#btn-chat")?.addEventListener("click", () => showView("chat"));
  $("#btn-chat-back")?.addEventListener("click", () => showView("home"));
  $("#btn-characters")?.addEventListener("click", () => showView("characters"));
  $("#btn-home-chars-manage")?.addEventListener("click", () => showView("characters"));
  $("#btn-characters-back")?.addEventListener("click", () => showView("home"));
  $("#btn-export-webm")?.addEventListener("click", () => exportWebmFromPreview());
  $("#btn-export-webm-stop")?.addEventListener("click", () => {
    try {
      state.webmAbort?.abort();
    } catch (_) {}
  });
  $("#btn-char-add")?.addEventListener("click", async () => {
    const name = $("#char-name")?.value?.trim();
    if (!name) return alert("Enter a character name");
    const file = $("#char-file")?.files?.[0] || null;
    const category = $("#char-category")?.value || "character";
    const description = $("#char-desc")?.value || "";
    try {
      await api.addCharacter(file, name, category, description);
      $("#char-name").value = "";
      $("#char-desc").value = "";
      if ($("#char-file")) $("#char-file").value = "";
      loadCharacters();
      loadHomeCharacters();
    } catch (e) {
      alert(e.message);
    }
  });
  $("#btn-char-refresh")?.addEventListener("click", () => loadCharacters());
  wireColResizer();
  wireWizard();
  setInterval(pollHostStats, 3000);
  pollHostStats();
  $("#img-upload").onchange = async (e) => {
    const f = e.target.files?.[0];
    const shot = selectedShot();
    if (!f) return;
    if (!shot) {
      alert("Select a shot on the timeline first (or drop the file onto a clip).");
      return;
    }
    await handleFilesOnShot(shot.id, [f]);
  };
  $("#vid-upload").onchange = async (e) => {
    const f = e.target.files?.[0];
    const shot = selectedShot();
    if (!f) return;
    if (!shot) {
      alert("Select a shot on the timeline first (or drop the file onto a clip).");
      return;
    }
    await handleFilesOnShot(shot.id, [f]);
  };
  $("#btn-pick-gallery-image")?.addEventListener("click", () => openGalleryPicker("image"));
  $("#btn-pick-gallery-video")?.addEventListener("click", () => openGalleryPicker("video"));
  $("#dev-skin")?.addEventListener("change", () => {
    if (isDevBuild()) applyDevSkin($("#dev-skin").value);
  });

  $("#btn-add-title").onclick = () => {
    state.project.timeline.titles.push({
      id: "title_" + Math.random().toString(16).slice(2, 8),
      text: "Title",
      font: "Arial",
      size: 48,
      color: "#FFFFFF",
      position: "center",
      x: 0.5,
      y: 0.5,
      start: state.project.timeline.playhead || 0,
      duration: 3,
      fade_in: 0.3,
      fade_out: 0.3,
      as_title_card: false,
      track: 0,
    });
    renderTitlesList();
    timeline.render();
    scheduleSave();
  };
  $("#srt-upload").onchange = async (e) => {
    const f = e.target.files?.[0];
    if (!f) return;
    state.project = await api.uploadSrt(state.project.id, f);
    renderTitlesList();
  };
  $("#sub-enabled").onchange = () => {
    state.project.subtitles.enabled = $("#sub-enabled").checked;
    scheduleSave();
  };
  $("#sub-burn").onchange = () => {
    state.project.subtitles.burn_in = $("#sub-burn").checked;
    scheduleSave();
  };

  $("#btn-do-export").onclick = async () => {
    state.project.export.preset = $("#exp-preset").value;
    state.project.export.resolution = $("#exp-res").value;
    state.project.export.fps = parseInt($("#exp-fps").value, 10) || 24;
    state.project.export.include_subtitles = $("#exp-subs").checked;
    await flushSave();
    const box = $("#export-result");
    box.textContent =
      "Exporting MP4… this can take several minutes for a full song. Keep this tab open.";
    els.jobToast.textContent = "Export running…";
    const btn = $("#btn-do-export");
    if (btn) btn.disabled = true;
    try {
      const res = await api.exportProject(state.project.id);
      box.innerHTML = `Done — <a href="${res.url}" target="_blank" download>Download MP4</a>`;
      els.jobToast.textContent = "Export complete";
    } catch (e) {
      box.textContent = e.message;
      els.jobToast.textContent = "Export failed";
      // If client timed out, check if export finished on disk anyway
      if (String(e.message || "").includes("timed out")) {
        box.textContent +=
          " — export may still finish on the server. Refresh and check the exports folder / Export tab.";
      }
    } finally {
      if (btn) btn.disabled = false;
    }
  };

  $("#btn-clear-video")?.addEventListener("click", () => clearSelectedVideo());

  // modals — Close / × (class or data-close), backdrop click, Escape
  const closeModalById = (id) => {
    if (!id) return;
    if (id === "modal-gallery") {
      closeGalleryPicker();
      return;
    }
    $("#" + id)?.classList.add("hidden");
  };
  $$(".modal-close, [data-close]").forEach((b) => {
    b.addEventListener("click", (e) => {
      e.preventDefault();
      e.stopPropagation();
      closeModalById(b.getAttribute("data-close") || b.dataset.close);
    });
  });
  $$(".modal").forEach((m) => {
    m.addEventListener("click", (e) => {
      if (e.target !== m) return;
      if (m.id === "modal-gallery") closeGalleryPicker();
      else m.classList.add("hidden");
    });
  });
  document.addEventListener("keydown", (e) => {
    if (e.key !== "Escape") return;
    $$(".modal:not(.hidden)").forEach((m) => {
      if (m.id === "modal-gallery") closeGalleryPicker();
      else m.classList.add("hidden");
    });
  });
  $("#btn-lora").onclick = async () => {
    $("#modal-lora").classList.remove("hidden");
    await refreshLocalLoras();
  };
  $("#btn-refs").onclick = () => {
    $("#modal-refs").classList.remove("hidden");
    renderRefs();
  };
  $("#btn-search-lora").onclick = searchLoras;
  $("#btn-refresh-loras").onclick = async () => {
    await api.refreshLoras();
    await refreshLocalLoras();
  };
  $("#btn-import-path").onclick = async () => {
    const p = $("#lora-import-path").value.trim();
    if (!p) return;
    try {
      await api.importLoraPath(p);
      await refreshLocalLoras();
      alert("Imported");
    } catch (e) {
      alert(e.message);
    }
  };
  $("#lora-import-file").onchange = async (e) => {
    const f = e.target.files?.[0];
    if (!f) return;
    try {
      const res = await api.uploadLora(f);
      await refreshLocalLoras();
      alert(`Imported ${res.name} (${res.size_mb} MB)`);
    } catch (err) {
      alert(err.message);
    }
  };
  $("#btn-add-lora-shot").onclick = () => {
    const s = selectedShot();
    if (!s) return;
    const choices = shotLoraChoices();
    if (!choices.length) {
      alert(
        "No image/style LoRAs found.\n\nAudio LoRAs (ACE / music) are hidden here — use LoRA Manager or Music for those."
      );
      return;
    }
    s.image.loras = s.image.loras || [];
    s.image.loras.push({
      name: choices[0].name,
      strength_model: 0.8,
      strength_clip: 0.8,
      enabled: true,
    });
    renderShotLoras(s);
    scheduleSave();
  };
  $("#shot-ref-upload")?.addEventListener("change", async (e) => {
    const f = e.target?.files?.[0];
    e.target.value = "";
    if (!f || !state.project) return;
    const s = selectedShot();
    if (!s) {
      alert("Select a shot first.");
      return;
    }
    s.image = s.image || {};
    s.image.shot_extra_ref_ids = shotExtraRefIds(s);
    if (s.image.shot_extra_ref_ids.length >= 2) {
      alert("This shot already has 2 extra stills. Uncheck or remove one first.");
      return;
    }
    try {
      const label =
        (f.name || "shot ref").replace(/\.[^.]+$/, "").slice(0, 40) || "Shot ref";
      // Project ref for this timeline, not Character Manager
      state.project = await api.addReference(
        state.project.id,
        f,
        label,
        "other",
        "Shot-only extra reference",
        false
      );
      const refs = state.project.references || [];
      const added = refs[refs.length - 1];
      if (!added?.id) {
        alert("Upload worked but could not find the new reference id.");
        return;
      }
      s.image.reference_ids = s.image.reference_ids || [];
      if (!s.image.reference_ids.includes(added.id)) s.image.reference_ids.push(added.id);
      s.image.shot_extra_ref_ids.push(added.id);
      // Re-bind selected shot from updated project if ids reshuffled
      const live = (state.project.timeline?.shots || []).find((x) => x.id === s.id) || s;
      live.image = live.image || {};
      live.image.reference_ids = s.image.reference_ids;
      live.image.shot_extra_ref_ids = s.image.shot_extra_ref_ids;
      timeline.setProject(state.project);
      renderShotRefs(live);
      scheduleSave();
      els.jobToast.textContent = `Added extra still for this shot (${s.image.shot_extra_ref_ids.length}/2)`;
    } catch (err) {
      alert("Could not add still:\n\n" + (err.message || err));
    }
  });
  $("#ref-upload").onchange = async (e) => {
    const f = e.target.files?.[0];
    if (!f) return;
    // Also saves into Character Manager (shared library)
    state.project = await api.addReference(
      state.project.id,
      f,
      $("#ref-name").value,
      $("#ref-category").value,
      "",
      true
    );
    renderRefs();
  };

  $("#btn-export").onclick = () => {
    $$(".inspector-tabs .tab").forEach((t) => t.classList.remove("active"));
    $$(".tab-body").forEach((b) => b.classList.add("hidden"));
    document.querySelector('.tab[data-tab="export"]').classList.add("active");
    $("#tab-export").classList.remove("hidden");
  };

  document.addEventListener("keydown", (e) => {
    if (e.target.matches("input, textarea, select")) return;
    if (e.code === "Space") {
      e.preventDefault();
      state.playing ? pause() : play();
    }
    if (e.ctrlKey && e.code === "KeyZ") {
      e.preventDefault();
      $("#btn-undo").click();
    }
    if (e.ctrlKey && e.code === "KeyY") {
      e.preventDefault();
      $("#btn-redo").click();
    }
  });
}

/**
 * Re-run planner → writer → editor on the open project using saved story fields + cast.
 * Rebuilds the shot list with new prompts (same as wizard, without leaving the editor).
 */
async function doRegeneratePrompts() {
  if (!state.project) return;
  await flushSave();
  const p = state.project;
  const story = p.story || {};
  const idea = (story.idea || "").trim();
  const lyrics = (story.lyrics || "").trim();
  const useStory = story.use_story !== false && !!idea;
  const useLyrics = story.use_lyrics !== false && !!lyrics;
  if (!idea && !lyrics) {
    alert(
      "This project has no saved story idea or lyrics to regenerate from.\n\n" +
        "Open the Music/Film story wizard once (or re-run it) so idea/lyrics are stored on the project, then try again."
    );
    return;
  }
  const cast = (p.references || [])
    .filter((r) => (r.category || "character") === "character")
    .map((r) => ({
      name: r.name,
      description: r.description || r.notes || "",
    }));
  const slot =
    parseFloat($("#slot-duration")?.value) ||
    Number(story.slot_duration) ||
    5;
  const bodyShots = (p.timeline?.shots || []).filter(
    (s) => !(s.image && s.image.strict_named_characters_only)
  );
  const sceneCount =
    bodyShots.length > 0
      ? bodyShots.length
      : p.audio?.duration
        ? Math.max(1, Math.ceil(Number(p.audio.duration) / slot))
        : 12;

  const castNames = cast.map((c) => c.name).filter(Boolean);
  if (!castNames.length) {
    const go = confirm(
      "No characters on this project’s References cast.\n\n" +
        "Regen will write prompts without named cast (anonymous people).\n" +
        "Add cast via the wizard / References / Character Manager import first for named prompts.\n\n" +
        "Continue anyway?"
    );
    if (!go) return;
  }
  const ok = confirm(
    "Regenerate ALL shot prompts with the story AI?\n\n" +
      `• Idea/lyrics: from this project’s saved story\n` +
      `• Style: ${story.style_template || "standard"}\n` +
      `• Cast: ${castNames.join(", ") || "(none — prompts won’t name characters)"}\n` +
      `• Scenes: ~${sceneCount}\n\n` +
      "New image + motion prompts only (cast names will be woven in when cast is set).\n" +
      "Existing images and videos on those shots are kept.\n" +
      "Video engine (LTX etc.) is kept.\n\n" +
      "Continue?"
  );
  if (!ok) return;

  const btn = $("#btn-regen-prompts");
  if (btn) btn.disabled = true;
  try {
    setClientActivity("Ollama: regenerate prompts", "ollama", p.name || "");
    els.jobToast.textContent = "Freeing GPU / starting story AI…";
    // Settings are source of truth; project.story models may be a bad old auto-pick
    let settings = {};
    try {
      settings = (await api.getSettings()) || {};
    } catch (_) {
      settings = {};
    }
    let lastModels = {};
    try {
      lastModels = JSON.parse(localStorage.getItem("fenix_story_models") || "{}") || {};
    } catch (_) {
      lastModels = {};
    }
    const chatM = settings.chat_model || "";
    const plannerM =
      settings.story_planner_model || chatM || lastModels.planner || story.planner_model || null;
    const writerM =
      settings.story_writer_model || chatM || lastModels.writer || story.writer_model || null;
    const editorM =
      settings.story_editor_model || chatM || lastModels.editor || story.editor_model || null;
    const body = {
      idea,
      lyrics,
      use_story: useStory,
      use_lyrics: useLyrics,
      style_id: story.style_template || "standard",
      slot_duration: slot,
      scene_count: sceneCount,
      // Full cast objects (name + description) — names alone lose look/identity for the LLM
      character_names: cast.filter((c) => (c.name || "").trim()),
      planner_model: plannerM,
      writer_model: writerM,
      editor_model: editorM,
      preserve_media: true,
    };
    els.jobToast.textContent = `Story AI starting (${plannerM || "auto"} / ${writerM || "auto"} / ${editorM || "auto"})…`;
    const res = await api.storyGenerate(p.id, body, {
      onEvent: (ev) => {
        if (!ev) return;
        if (ev.type === "status" || ev.type === "done") {
          const msg = ev.message || "Working…";
          els.jobToast.textContent = `Story AI ${Math.round((ev.progress || 0) * 100)}% — ${msg}`;
          if (ev.message) {
            setClientActivity("Ollama: " + String(ev.message).slice(0, 48), "ollama", ev.detail || "");
          }
        }
      },
    });
    // Remember models that actually ran
    const used = res.models_used || {};
    if (used.planner || used.writer || used.editor) {
      try {
        localStorage.setItem(
          "fenix_story_models",
          JSON.stringify({
            planner: used.planner || plannerM,
            writer: used.writer || writerM,
            editor: used.editor || editorM,
          })
        );
      } catch (_) {}
    }
    const pid = res.project?.id || p.id;
    await openProject(pid);
    els.jobToast.textContent = `Prompts regenerated · ${res.scene_count || sceneCount} scenes (images + video engine kept)`;
  } catch (e) {
    const msg = String(e.message || e);
    els.jobToast.textContent = "Prompt regen failed";
    alert("Regenerate prompts failed:\n\n" + msg);
  } finally {
    setClientActivity(null);
    pollActivity();
    if (btn) btn.disabled = false;
  }
}

async function doBulkImages() {
  if (!state.project) return;
  await flushSave();
  if (!confirm("Queue image generation for all shots that have a prompt but no image yet?")) return;
  try {
    els.jobToast.textContent = "Bulk queueing images…";
    const res = await api.bulkImages(state.project.id, { only_missing: true });
    els.jobToast.textContent = `Queued ${res.queued} image job(s) (${res.skipped} skipped)`;
    // Seed optimistic job entries
    for (const id of res.job_ids || []) {
      state.jobs = [
        {
          id,
          shot_id: "",
          kind: "image",
          status: "queued",
          progress: 0,
          message: "Bulk queued",
          project_id: state.project.id,
        },
        ...state.jobs.filter((j) => j.id !== id),
      ];
    }
    updateGenerateButtons();
  } catch (e) {
    alert("Bulk images failed:\n" + e.message);
  }
}

async function doBulkVideos() {
  if (!state.project) return;
  await flushSave();
  const q = $("#global-vid-quality")?.value || "draft";
  const msg =
    q === "final"
      ? `Queue FINAL video for all shots with an image?\n\n` +
        `• Empty shots → generate final\n` +
        `• Draft videos → regenerate as final\n` +
        `• Already-final shots → skipped\n\n` +
        `Empty motion prompts use the image prompt.`
      : `Queue DRAFT video for shots that have an image but no video yet?\n\n` +
        `Shots that already have a video (draft or final) will be skipped.\n` +
        `Set quality to Final first if you want to upgrade drafts.`;
  if (!confirm(msg)) return;
  try {
    // ensure quality applied first
    await api.applyVideoQuality(state.project.id, q);
    els.jobToast.textContent = "Bulk queueing videos…";
    const res = await api.bulkVideos(state.project.id, { only_missing: true, quality: q });
    els.jobToast.textContent = `Queued ${res.queued} video job(s) (${res.skipped} skipped) · ${q}`;
    for (const id of res.job_ids || []) {
      state.jobs = [
        {
          id,
          shot_id: "",
          kind: "video",
          status: "queued",
          progress: 0,
          message: "Bulk queued",
          project_id: state.project.id,
        },
        ...state.jobs.filter((j) => j.id !== id),
      ];
    }
    updateGenerateButtons();
  } catch (e) {
    alert("Bulk videos failed:\n" + e.message);
  }
}

// ---------- Story wizard ----------
// New wizard from home = NEW project.
// Mid-wizard (refresh / Back home / reopen) = RESUME same project with idea/lyrics intact.
const wizard = {
  step: 1,
  projectId: null,
  styles: [],
  models: [],
  defaults: {},
  _diskTimer: null,
  incomplete: false, // true until Generate succeeds or user abandons
};
const LS_WIZ_DRAFT = "amvs_wizard_draft_v1";

function collectWizardDraft() {
  return {
    name: $("#wiz-name")?.value || "",
    idea: $("#wiz-idea")?.value || "",
    lyrics: $("#wiz-lyrics")?.value || "",
    use_story: !!$("#wiz-use-story")?.checked,
    use_lyrics: !!$("#wiz-use-lyrics")?.checked,
    style_id: $("#wiz-style")?.value || "",
    style_prefix: $("#wiz-style-custom")?.value || "",
    slot: $("#wiz-slot")?.value || "5",
    projectId: wizard.projectId || null,
    step: wizard.step || 1,
    incomplete: !!wizard.incomplete,
    savedAt: Date.now(),
  };
}

/** Instant browser backup — survives refresh */
function persistWizardDraftLocal() {
  try {
    localStorage.setItem(LS_WIZ_DRAFT, JSON.stringify(collectWizardDraft()));
  } catch (_) {}
}

function scheduleWizardDraftLocal() {
  // Browser only — no extra API. Survives refresh while this wizard run is incomplete.
  persistWizardDraftLocal();
  const badge = $("#wiz-draft-status");
  if (badge) {
    const idea = ($("#wiz-idea")?.value || "").length;
    const lyr = ($("#wiz-lyrics")?.value || "").length;
    badge.textContent =
      idea || lyr
        ? `Draft in browser · idea ${idea} chars · lyrics ${lyr} chars (saved to project when you Generate)`
        : "Type story/lyrics — kept in this browser until Generate or you start a new wizard";
  }
}

function restoreWizardDraftLocal() {
  try {
    const raw = JSON.parse(localStorage.getItem(LS_WIZ_DRAFT) || "null");
    if (!raw || typeof raw !== "object") return null;
    if (raw.savedAt && Date.now() - raw.savedAt > 7 * 24 * 3600 * 1000) return null;
    return raw;
  } catch {
    return null;
  }
}

function applyWizardDraft(d) {
  if (!d) return;
  if ($("#wiz-name") && d.name != null) $("#wiz-name").value = d.name;
  if ($("#wiz-idea") && d.idea != null) $("#wiz-idea").value = d.idea;
  if ($("#wiz-lyrics") && d.lyrics != null) $("#wiz-lyrics").value = d.lyrics;
  if ($("#wiz-use-story") && d.use_story != null) $("#wiz-use-story").checked = !!d.use_story;
  if ($("#wiz-use-lyrics") && d.use_lyrics != null) $("#wiz-use-lyrics").checked = !!d.use_lyrics;
  if ($("#wiz-style") && d.style_id) $("#wiz-style").value = d.style_id;
  if ($("#wiz-style-custom") && d.style_prefix != null) $("#wiz-style-custom").value = d.style_prefix;
  if ($("#wiz-slot") && d.slot != null) $("#wiz-slot").value = d.slot;
  if (d.projectId) wizard.projectId = d.projectId;
  updateWizStylePreview();
}

/** Load form fields from project.story on disk (source of truth for mid-wizard). */
function applyProjectStoryToForm(proj) {
  if (!proj) return;
  const st = proj.story || {};
  if ($("#wiz-name") && proj.name) $("#wiz-name").value = proj.name;
  if ($("#wiz-idea") && st.idea != null) $("#wiz-idea").value = st.idea;
  if ($("#wiz-lyrics") && st.lyrics != null) $("#wiz-lyrics").value = st.lyrics;
  if ($("#wiz-use-story") && st.use_story != null) $("#wiz-use-story").checked = !!st.use_story;
  if ($("#wiz-use-lyrics") && st.use_lyrics != null) $("#wiz-use-lyrics").checked = !!st.use_lyrics;
  if ($("#wiz-style") && st.style_template) $("#wiz-style").value = st.style_template;
  if ($("#wiz-slot") && st.slot_duration) $("#wiz-slot").value = String(st.slot_duration);
  if (proj.audio?.path || proj.audio?.duration) {
    const slot = parseFloat($("#wiz-slot")?.value) || 5;
    const n = Math.max(1, Math.ceil((proj.audio.duration || 0) / slot));
    const name = proj.audio.filename || proj.audio.original_name || "audio";
    if ($("#wiz-audio-status")) {
      $("#wiz-audio-status").textContent = `Ready: ${name} · ${fmtTime(proj.audio.duration || 0)} · ~${n} scenes`;
    }
    if ($("#wiz-scene-estimate")) {
      $("#wiz-scene-estimate").textContent = `Estimated ${n} scenes from song length / slot.`;
    }
  }
  // resume step from notes marker
  const m = String(proj.notes || "").match(/\[wizard_step:(\d+)\]/);
  if (m) {
    const step = Math.min(6, Math.max(1, parseInt(m[1], 10)));
    wizardGo(step);
  }
  updateWizStylePreview();
  renderWizRefs();
}

function clearWizardDraftLocal() {
  try {
    localStorage.removeItem(LS_WIZ_DRAFT);
  } catch (_) {}
}

function resetWizardFormEmpty() {
  if ($("#wiz-name")) $("#wiz-name").value = "Untitled Music Video";
  if ($("#wiz-idea")) $("#wiz-idea").value = "";
  if ($("#wiz-lyrics")) $("#wiz-lyrics").value = "";
  if ($("#wiz-use-story")) $("#wiz-use-story").checked = true;
  if ($("#wiz-use-lyrics")) $("#wiz-use-lyrics").checked = true;
  if ($("#wiz-audio-status")) $("#wiz-audio-status").textContent = "No audio yet";
  if ($("#wiz-scene-estimate")) $("#wiz-scene-estimate").textContent = "";
  if ($("#wiz-refs")) $("#wiz-refs").innerHTML = "";
  if ($("#wiz-draft-status")) $("#wiz-draft-status").textContent = "";
  if ($("#wiz-gen-status")) $("#wiz-gen-status").textContent = "Ready when you are.";
}

function wireWizard() {
  $("#btn-new-wizard")?.addEventListener("click", () => openWizard({ forceNew: false }));
  $("#btn-new-amv")?.addEventListener("click", () => openAmvWizard());
  $("#btn-wizard-cancel")?.addEventListener("click", async () => {
    wizard.incomplete = true;
    persistWizardDraftLocal();
    showView("home");
  });
  $("#btn-wizard-skip")?.addEventListener("click", async () => {
    const name = ($("#wiz-name")?.value || "Untitled Music Video").trim();
    const p = wizard.projectId
      ? await api.getProject(wizard.projectId)
      : await api.createProject(name);
    if (name && p.name !== name) {
      p.name = name;
      try {
        await api.saveProject(p.id, p);
      } catch (_) {}
    }
    clearWizardDraftLocal();
    wizard.projectId = null;
    wizard.incomplete = false;
    await openProject(p.id);
  });
  $$("[data-wiz-next]").forEach((btn) => {
    btn.addEventListener("click", async () => {
      const next = parseInt(btn.dataset.wizNext, 10);
      if (next > wizard.step) {
        const ok = await wizardEnsureBefore(next);
        if (!ok) return;
      }
      persistWizardDraftLocal();
      wizardGo(next);
      if (next === 3 && wizard.projectId) {
        await renderLibraryPicks("wiz-library-picks", wizard.projectId);
      }
    });
  });
  // Autosave as you type
  ["wiz-name", "wiz-idea", "wiz-lyrics", "wiz-slot"].forEach((id) => {
    const el = $(`#${id}`);
    if (!el) return;
    el.addEventListener("input", () => scheduleWizardDraftLocal());
    el.addEventListener("change", () => scheduleWizardDraftLocal());
  });
  ["wiz-use-story", "wiz-use-lyrics", "wiz-style"].forEach((id) => {
    $(`#${id}`)?.addEventListener("change", () => {
      updateWizStylePreview();
      scheduleWizardDraftLocal();
    });
  });
  window.addEventListener("beforeunload", () => {
    if (wizard.incomplete || wizard.projectId) persistWizardDraftLocal();
  });
  $("#wiz-audio")?.addEventListener("change", async (e) => {
    const f = e.target.files?.[0];
    if (!f) return;
    await wizardEnsureProject();
    persistWizardDraftLocal();
    const statusEl = $("#wiz-audio-status");
    const bar = $("#wiz-audio-progress");
    const barFill = $("#wiz-audio-progress-fill");
    const barLabel = $("#wiz-audio-progress-label");
    if (bar) bar.classList.remove("hidden");
    if (barFill) barFill.style.width = "0%";
    if (barLabel) barLabel.textContent = "0%";
    if (statusEl) statusEl.textContent = `Uploading “${f.name}”…`;
    const fmtMb = (n) => `${(n / (1024 * 1024)).toFixed(1)} MB`;
    try {
      const proj = await api.uploadAudio(wizard.projectId, f, {
        onProgress: (ratio, loaded, total) => {
          if (ratio != null && Number.isFinite(ratio)) {
            const pct = Math.min(100, Math.round(ratio * 100));
            if (barFill) barFill.style.width = `${pct}%`;
            if (barLabel) barLabel.textContent = `${pct}%`;
            if (statusEl && total) {
              statusEl.textContent = `Uploading “${f.name}”… ${fmtMb(loaded)} / ${fmtMb(total)} (${pct}%)`;
            } else if (statusEl) {
              statusEl.textContent = `Uploading “${f.name}”… ${fmtMb(loaded)}`;
            }
          } else if (statusEl && loaded) {
            statusEl.textContent = `Uploading “${f.name}”… ${fmtMb(loaded)}`;
          }
        },
      });
      state.project = proj;
      if (barFill) barFill.style.width = "100%";
      if (barLabel) barLabel.textContent = "100%";
      const slot = parseFloat($("#wiz-slot").value) || 5;
      const n = Math.max(1, Math.ceil((proj.audio.duration || 0) / slot));
      if (statusEl) {
        statusEl.textContent = `Ready: ${f.name} · ${fmtTime(proj.audio.duration)} · ~${n} scenes @ ${slot}s`;
      }
      $("#wiz-scene-estimate").textContent = `Estimated ${n} scenes from song length / slot.`;
      persistWizardDraftLocal();
      setTimeout(() => bar?.classList.add("hidden"), 1200);
    } catch (err) {
      try {
        const proj = await api.getProject(wizard.projectId);
        if (proj?.audio?.path || proj?.audio?.duration) {
          state.project = proj;
          const slot = parseFloat($("#wiz-slot").value) || 5;
          const n = Math.max(1, Math.ceil((proj.audio.duration || 0) / slot));
          const name = proj.audio.original_name || proj.audio.filename || f.name;
          if (statusEl) {
            statusEl.textContent = `Ready: ${name} · ${fmtTime(proj.audio.duration)} · ~${n} scenes @ ${slot}s (finished on server)`;
          }
          $("#wiz-scene-estimate").textContent = `Estimated ${n} scenes from song length / slot.`;
          bar?.classList.add("hidden");
          return;
        }
      } catch (_) {}
      if (statusEl) statusEl.textContent = "Upload failed: " + err.message;
      bar?.classList.add("hidden");
    }
  });
  $("#wiz-slot")?.addEventListener("change", () => {
    const dur = state.project?.audio?.duration || 0;
    const slot = parseFloat($("#wiz-slot").value) || 5;
    if (dur > 0) {
      const n = Math.max(1, Math.ceil(dur / slot));
      $("#wiz-scene-estimate").textContent = `Estimated ${n} scenes from song length / slot.`;
    }
    scheduleWizardDraftLocal();
  });
  $("#wiz-style")?.addEventListener("change", () => {
    updateWizStylePreview();
    scheduleWizardDraftLocal();
  });
  $("#wiz-style-custom")?.addEventListener("input", () => scheduleWizardDraftLocal());
  $("#wiz-ref-file")?.addEventListener("change", async (e) => {
    const f = e.target.files?.[0];
    if (!f) return;
    await wizardEnsureProject();
    const name = ($("#wiz-ref-name").value || f.name).trim();
    const cat = $("#wiz-ref-cat").value || "character";
    try {
      // save_to_library default true on API — also lands in Character Manager
      state.project = await api.addReference(wizard.projectId, f, name, cat, "", true);
      $("#wiz-ref-name").value = "";
      renderWizRefs();
      await renderLibraryPicks("wiz-library-picks", wizard.projectId);
      persistWizardDraftLocal();
    } catch (err) {
      alert(err.message);
    }
    e.target.value = "";
  });
  $("#btn-wiz-run")?.addEventListener("click", () => runWizardGenerate());
  wireFilmWizard();
  wireAmvWizard();
}

// ---------- Advanced Music Video wizard ----------
const amvWiz = { projectId: null, step: 1, planned: false, roles: {} };

function amvGo(step) {
  amvWiz.step = step;
  for (let i = 1; i <= 5; i++) {
    const panel = $(`#amv-panel-${i}`);
    if (panel) panel.classList.toggle("hidden", i !== step);
  }
  $$("#amv-steps .wiz-step").forEach((el) => {
    const s = parseInt(el.dataset.amvstep, 10);
    el.classList.toggle("on", s === step);
    el.classList.toggle("done", s < step);
  });
}

async function amvEnsureProject() {
  if (amvWiz.projectId) return amvWiz.projectId;
  const name = ($("#amv-name")?.value || "Untitled Advanced MV").trim();
  const notes = ($("#amv-concept")?.value || "").trim();
  const p = await api.createProject(name, { kind: "music", notes });
  amvWiz.projectId = p.id;
  state.project = p;
  return p.id;
}

function renderAmvRefs() {
  const box = $("#amv-refs");
  if (!box) return;
  const refs = (state.project?.references || []).filter(
    (r) => (r.category || "") !== "location"
  );
  box.innerHTML =
    refs
      .map((r) => {
        const role = amvWiz.roles[(r.name || "").toLowerCase()] || "performer";
        return `<span class="chip">${escapeHtml(r.name || r.id)} <em class="muted">${escapeHtml(role)}</em></span>`;
      })
      .join("") || `<span class="muted">No cast members yet</span>`;
  const env = (state.project?.references || []).find((r) => (r.category || "") === "location");
  const envStatus = $("#amv-env-status");
  if (envStatus) {
    envStatus.textContent = env
      ? `Venue: ${env.name || env.id}`
      : "No environment image";
  }
}

function amvCollectCastRoles() {
  const cast = [];
  for (const r of state.project?.references || []) {
    if ((r.category || "") === "location") continue;
    const name = (r.name || "").trim();
    if (!name) continue;
    cast.push({
      name,
      role: amvWiz.roles[name.toLowerCase()] || "performer",
    });
  }
  return cast;
}

async function openAmvWizard() {
  showView("amv");
  amvWiz.projectId = null;
  amvWiz.step = 1;
  amvWiz.planned = false;
  amvWiz.roles = {};
  if ($("#amv-name")) $("#amv-name").value = "Untitled Advanced MV";
  if ($("#amv-concept")) $("#amv-concept").value = "";
  if ($("#amv-lyrics")) $("#amv-lyrics").value = "";
  if ($("#amv-window")) $("#amv-window").value = "20";
  if ($("#amv-slot-mode")) $("#amv-slot-mode").value = "fixed";
  if ($("#amv-video-engine")) $("#amv-video-engine").value = "ltx23-ia2v";
  if ($("#amv-ltx-mode")) $("#amv-ltx-mode").value = "fast";
  if ($("#amv-audio-status")) $("#amv-audio-status").textContent = "No track yet";
  if ($("#amv-plan-status")) $("#amv-plan-status").textContent = "Ready to plan.";
  if ($("#amv-summary")) $("#amv-summary").textContent = "Shots will appear here after planning.";
  if ($("#amv-audio")) $("#amv-audio").value = "";
  if ($("#amv-seamless")) $("#amv-seamless").checked = false;
  if ($("#amv-env-name")) $("#amv-env-name").value = "";
  updateAmvEngineUI();
  renderAmvRefs();
  amvGo(1);
}

function updateAmvEngineUI() {
  const eng = ($("#amv-video-engine")?.value || "ltx23-ia2v").toLowerCase();
  const ltx = eng.startsWith("ltx");
  $("#amv-ltx-mode-wrap")?.classList.toggle("hidden", !ltx);
  $("#amv-ltx-mode-note")?.classList.toggle("hidden", !ltx);
  const hint = $("#amv-engine-hint");
  if (hint) {
    hint.textContent = ltx
      ? "LTX: strong singing performance, up to ~20s clips. Pass mode is LTX-only."
      : "MiniMax: lip sync on vocal shots locks each still + drives mouth from audio. Clips up to ~15s.";
  }
  const win = $("#amv-window");
  if (win) {
    win.max = ltx ? "20" : "15";
    const v = parseFloat(win.value) || (ltx ? 20 : 15);
    if (!ltx && v > 15) win.value = "15";
    if (ltx && !win.value) win.value = "20";
  }
}

function wireAmvWizard() {
  $$("[data-amv-next]").forEach((btn) => {
    btn.addEventListener("click", async () => {
      const next = parseInt(btn.dataset.amvNext, 10);
      if (next === 2) {
        const concept = ($("#amv-concept")?.value || "").trim();
        if (!concept) {
          alert("Tell the planner what the video is about (who’s in it, what’s happening).");
          return;
        }
        await amvEnsureProject();
      }
      if (next === 3) {
        if (!state.project?.audio?.path) {
          alert("Upload a music track first.");
          return;
        }
        await renderLibraryPicks("amv-library-picks", amvWiz.projectId);
        renderAmvRefs();
      }
      if (next === 4) {
        const people = (state.project?.references || []).filter(
          (r) => (r.category || "") !== "location"
        );
        if (!people.length) {
          alert("Add at least one cast member (person with a visible mouth for lip sync).");
          return;
        }
      }
      if (next === 5 && !amvWiz.planned) {
        alert("Run Analyze & plan shots first.");
        return;
      }
      amvGo(next);
    });
  });
  $("#btn-amv-cancel")?.addEventListener("click", () => showView("home"));
  $("#amv-audio")?.addEventListener("change", async (e) => {
    const f = e.target?.files?.[0];
    if (!f) return;
    await amvEnsureProject();
    const statusEl = $("#amv-audio-status");
    if (statusEl) statusEl.textContent = "Uploading…";
    try {
      state.project = await api.uploadAudio(amvWiz.projectId, f);
      const dur = state.project.audio?.duration || 0;
      const win = parseFloat($("#amv-window")?.value) || 20;
      const mode = $("#amv-slot-mode")?.value || "fixed";
      const n = Math.max(1, Math.ceil(dur / win));
      if (statusEl) {
        statusEl.textContent =
          mode === "sections"
            ? `Ready: ${f.name} · ${fmtTime(dur)} · section cuts (no gaps), max ${win}s`
            : `Ready: ${f.name} · ${fmtTime(dur)} · ~${n} fixed windows @ ${win}s (last may be shorter)`;
      }
    } catch (err) {
      if (statusEl) statusEl.textContent = "Upload failed: " + (err.message || err);
    }
    e.target.value = "";
  });
  $("#amv-ref-file")?.addEventListener("change", async (e) => {
    const f = e.target?.files?.[0];
    if (!f) return;
    await amvEnsureProject();
    const name = ($("#amv-ref-name")?.value || f.name).trim();
    const role = $("#amv-ref-role")?.value || "performer";
    try {
      state.project = await api.addReference(amvWiz.projectId, f, name, "character", "", true);
      if (name) amvWiz.roles[name.toLowerCase()] = role;
      if ($("#amv-ref-name")) $("#amv-ref-name").value = "";
      renderAmvRefs();
      await renderLibraryPicks("amv-library-picks", amvWiz.projectId);
    } catch (err) {
      alert(err.message || err);
    }
    e.target.value = "";
  });
  $("#amv-env-file")?.addEventListener("change", async (e) => {
    const f = e.target?.files?.[0];
    if (!f) return;
    await amvEnsureProject();
    const name = ($("#amv-env-name")?.value || "Venue").trim();
    try {
      state.project = await api.addReference(amvWiz.projectId, f, name, "location", "", true);
      renderAmvRefs();
    } catch (err) {
      alert(err.message || err);
    }
    e.target.value = "";
  });
  $("#btn-amv-plan")?.addEventListener("click", async () => {
    await amvEnsureProject();
    if (!state.project?.audio?.path) {
      alert("Upload a track first.");
      return;
    }
    const cast = amvCollectCastRoles();
    if (!cast.length) {
      alert("Add cast members first.");
      return;
    }
    const env = (state.project?.references || []).find((r) => (r.category || "") === "location");
    const status = $("#amv-plan-status");
    const btn = $("#btn-amv-plan");
    if (btn) btn.disabled = true;
    if (status) status.textContent = "Analyzing audio and planning the show (local LLM)…";
    try {
      const slotMode = $("#amv-slot-mode")?.value || "fixed";
      const videoEngine = $("#amv-video-engine")?.value || "ltx23-ia2v";
      const engLabel = String(videoEngine).toLowerCase().startsWith("ltx")
        ? "LTX"
        : "MiniMax";
      state.project = await api.amvPrepare(amvWiz.projectId, {
        concept: ($("#amv-concept")?.value || "").trim(),
        lyrics: ($("#amv-lyrics")?.value || "").trim(),
        window_sec: parseFloat($("#amv-window")?.value) || 20,
        slot_mode: slotMode,
        video_engine: videoEngine,
        ltx_mode: $("#amv-ltx-mode")?.value || "fast",
        quality: "draft",
        cast_roles: cast,
        environment_name: env?.name || ($("#amv-env-name")?.value || "").trim(),
        seamless: !!$("#amv-seamless")?.checked,
      });
      amvWiz.planned = true;
      const shots = state.project.timeline?.shots || [];
      const n = shots.length;
      const dur = state.project.audio?.duration || 0;
      // Confirm no gaps for the status line
      let gapNote = "";
      const sorted = [...shots].sort((a, b) => (a.start || 0) - (b.start || 0));
      for (let i = 1; i < sorted.length; i++) {
        const prevEnd = (sorted[i - 1].start || 0) + (sorted[i - 1].duration || 0);
        const gap = (sorted[i].start || 0) - prevEnd;
        if (Math.abs(gap) > 0.05) {
          gapNote = " (warning: timing gap detected)";
          break;
        }
      }
      if (status) {
        status.textContent =
          `Done — ${n} shots (${slotMode === "sections" ? "sections" : "fixed"}), no gaps.` + gapNote;
      }
      if ($("#amv-summary")) {
        $("#amv-summary").textContent =
          `${n} shots across ${fmtTime(dur)} · ${slotMode === "sections" ? "section cuts" : "fixed windows"} · ${cast.length} cast` +
          (env ? ` · venue ${env.name}` : "") +
          `. ${engLabel} + lip sync on vocal shots. Open the editor to generate.`;
      }
      amvGo(5);
    } catch (err) {
      if (status) status.textContent = "Failed: " + (err.message || err);
      alert("Plan failed:\n\n" + (err.message || err));
    } finally {
      if (btn) btn.disabled = false;
    }
  });
  $("#btn-amv-open")?.addEventListener("click", async () => {
    if (!amvWiz.projectId) return;
    try {
      state.project = await api.getProject(amvWiz.projectId);
    } catch (_) {}
    await openProject(amvWiz.projectId);
  });
  const updateAmvSlotHint = () => {
    const hint = $("#amv-slot-hint");
    if (!hint) return;
    const mode = $("#amv-slot-mode")?.value || "fixed";
    hint.textContent =
      mode === "sections"
        ? "Sections: cut on song structure with no gaps between shots. Long spans still split at the window length above."
        : "Fixed: every shot is this long except the final one, which ends when the track ends. No gaps.";
  };
  $("#amv-slot-mode")?.addEventListener("change", updateAmvSlotHint);
  updateAmvSlotHint();
  $("#amv-video-engine")?.addEventListener("change", updateAmvEngineUI);
  updateAmvEngineUI();
}

// ---------- Film / non-music wizard ----------
const filmWiz = { projectId: null, step: 1 };

function filmGo(step) {
  filmWiz.step = step;
  for (let i = 1; i <= 4; i++) {
    const panel = $(`#film-panel-${i}`);
    if (panel) panel.classList.toggle("hidden", i !== step);
  }
  $$("#film-steps .wiz-step").forEach((el) => {
    const s = parseInt(el.dataset.fstep, 10);
    el.classList.toggle("on", s === step);
    el.classList.toggle("done", s < step);
  });
}

async function filmEnsureProject() {
  if (filmWiz.projectId) return filmWiz.projectId;
  const name = ($("#film-name")?.value || "Untitled Film").trim();
  const notes = ($("#film-desc")?.value || "").trim();
  const p = await api.createProject(name, { kind: "film", notes });
  filmWiz.projectId = p.id;
  state.project = p;
  return p.id;
}

async function openFilmWizard() {
  showView("film");
  filmWiz.projectId = null;
  filmWiz.step = 1;
  if ($("#film-name")) $("#film-name").value = "Untitled Film";
  if ($("#film-desc")) $("#film-desc").value = "";
  if ($("#film-idea")) $("#film-idea").value = "";
  if ($("#film-refs")) $("#film-refs").innerHTML = "";
  filmGo(1);
  try {
    const llm = await api.llmModels();
    const forceSmall = !!llm.force_small_models;
    const models = filterModelsForStory(llm.models || [], forceSmall);
    const opts =
      models
        .map(
          (m) =>
            `<option value="${escapeHtml(m.id)}">${escapeHtml(m.id)}${m.size_gb ? ` (${m.size_gb}GB)` : ""}</option>`
        )
        .join("") || `<option value="">(no models)</option>`;
    const filmPref = [
      "qwen3.5:0.8b",
      "qwen3.5:2b",
      "qwen2.5:3b",
      "llama3.2:3b",
      "tinyllama",
      "qwen3.5:4b",
      "qwen3:4b",
    ];
    ["film-model-planner", "film-model-writer", "film-model-editor"].forEach((id) => {
      const sel = $(`#${id}`);
      if (!sel) return;
      const prev = sel.value;
      sel.innerHTML = opts;
      // Never stomp a model the user already picked
      if (prev && [...sel.options].some((o) => o.value === prev)) {
        sel.value = prev;
      } else if (!sel.value) {
        preferModelExact(id, filmPref);
      }
    });
    fillFilmStyles(llm.styles || wizard.styles || state.system?.style_templates || []);
  } catch (_) {}
  updateFilmSceneEstimate();
}

function fillFilmStyles(styles) {
  const sel = $("#film-style");
  if (!sel) return;
  const list = styles.length
    ? styles
    : [
        { id: "standard", label: "Standard video" },
        { id: "cinematic_drama", label: "Cinematic drama" },
        { id: "bright_happy", label: "Bright happy" },
        { id: "childrens", label: "Children's" },
        { id: "custom", label: "Custom (type your own)" },
      ];
  const prev = sel.value;
  sel.innerHTML = list
    .map((s) => `<option value="${escapeHtml(s.id)}">${escapeHtml(s.label || s.id)}</option>`)
    .join("");
  if (prev && [...sel.options].some((o) => o.value === prev)) sel.value = prev;
  else if ([...sel.options].some((o) => o.value === "standard")) sel.value = "standard";
  updateFilmStylePreview();
}

function updateFilmStylePreview() {
  const id = $("#film-style")?.value;
  const s = (wizard.styles || state.system?.style_templates || []).find((x) => x.id === id);
  const el = $("#film-style-preview");
  const customWrap = $("#film-style-custom-wrap");
  const isCustom = id === "custom";
  if (customWrap) customWrap.classList.toggle("hidden", !isCustom);
  if (el) {
    if (isCustom) {
      el.textContent = "Type your own style line below — it is prepended to every scene still.";
    } else if (id === "standard" || !(s?.prefix || "").trim()) {
      el.textContent = "Standard — no look/feel filter. Prompts stay as written (no film grain, etc.).";
    } else {
      el.textContent = s.prefix;
    }
  }
}

function updateFilmSceneEstimate() {
  const dur = parseFloat($("#film-duration")?.value) || 120;
  const slot = parseFloat($("#film-slot")?.value) || 5;
  const n = Math.max(1, Math.ceil(dur / slot));
  if ($("#film-scene-estimate")) $("#film-scene-estimate").textContent = `~${n} scenes (${dur}s / ${slot}s)`;
}

function wireFilmWizard() {
  $("#btn-film-cancel")?.addEventListener("click", () => {
    filmWiz.projectId = null;
    showView("home");
  });
  $("#film-style")?.addEventListener("change", () => updateFilmStylePreview());
  $$("[data-film-next]").forEach((btn) => {
    btn.addEventListener("click", async () => {
      const next = parseInt(btn.dataset.filmNext, 10);
      if (next >= 2) {
        try {
          await filmEnsureProject();
        } catch (e) {
          alert(e.message);
          return;
        }
      }
      if (next === 2) await renderLibraryPicks("film-library-picks", filmWiz.projectId);
      filmGo(next);
    });
  });
  $("#btn-film-mode-next")?.addEventListener("click", async () => {
    await filmEnsureProject();
    const ai = document.querySelector('input[name="film-ai"]:checked')?.value === "yes";
    filmGo(4);
    $("#film-blank-branch")?.classList.toggle("hidden", ai);
    $("#film-ai-branch")?.classList.toggle("hidden", !ai);
    if ($("#film-panel-4-title")) {
      $("#film-panel-4-title").textContent = ai ? "AI short film" : "Blank film timeline";
    }
  });
  $("#film-ref-file")?.addEventListener("change", async (e) => {
    const f = e.target.files?.[0];
    if (!f) return;
    await filmEnsureProject();
    const name = ($("#film-ref-name")?.value || f.name).trim();
    const cat = $("#film-ref-cat")?.value || "character";
    try {
      state.project = await api.addReference(filmWiz.projectId, f, name, cat, "", true);
      if ($("#film-ref-name")) $("#film-ref-name").value = "";
      renderFilmRefs();
      await renderLibraryPicks("film-library-picks", filmWiz.projectId);
    } catch (err) {
      alert(err.message);
    }
    e.target.value = "";
  });
  $("#film-duration")?.addEventListener("input", updateFilmSceneEstimate);
  $("#film-slot")?.addEventListener("input", updateFilmSceneEstimate);
  $("#btn-film-open-blank")?.addEventListener("click", () => openFilmBlankEditor());
  $("#btn-film-run")?.addEventListener("click", () => runFilmAiGenerate());
}

function renderFilmRefs() {
  const box = $("#film-refs");
  if (!box) return;
  const refs = state.project?.references || [];
  box.innerHTML =
    refs
      .map((r) => `<span class="ref-chip on">${escapeHtml(r.name)}</span>`)
      .join("") || `<span class="muted small">No cast yet</span>`;
}

async function openFilmBlankEditor() {
  await filmEnsureProject();
  const pid = filmWiz.projectId;
  filmWiz.projectId = null;
  await openProject(pid);
  // Seed one empty scene if the timeline is empty
  if (!(state.project?.timeline?.shots || []).length) {
    timeline.addShotAt(0);
    const s = selectedShot();
    if (s) {
      s.label = "Scene 1";
      const slot = parseFloat($("#film-slot")?.value) || 5;
      s.duration = slot;
      if (s.video) s.video.duration_sec = slot;
    }
    await flushSave();
    bindInspectorFromShot(selectedShot());
    timeline.render();
  }
}

async function runFilmAiGenerate() {
  const status = $("#film-gen-status");
  const btn = $("#btn-film-run");
  const stream = $("#film-think-stream");
  try {
    await filmEnsureProject();
    const idea = ($("#film-idea")?.value || "").trim();
    const desc = ($("#film-desc")?.value || "").trim();
    if (!idea) {
      alert("Enter a video idea first.");
      return;
    }
    if (
      ($("#film-style")?.value || "") === "custom" &&
      !($("#film-style-custom")?.value || "").trim()
    ) {
      alert("Custom style is selected — type a style string, or pick another preset.");
      return;
    }
    const fullIdea = desc ? `${idea}\n\nNotes: ${desc}` : idea;
    const dur = parseFloat($("#film-duration")?.value) || 120;
    const slot = parseFloat($("#film-slot")?.value) || 5;
    const sceneCount = Math.max(1, Math.min(120, Math.ceil(dur / slot)));
    if (btn) btn.disabled = true;
    if (stream) stream.textContent = "";
    const panel = $("#film-think-panel");
    if (panel) {
      panel.classList.remove("hidden");
      panel.classList.add("thinking");
    }
    if (status) status.textContent = "Running planner → writer → editor…";
    setClientActivity("Ollama: writing story", "ollama", "film pipeline");
    const body = {
      idea: fullIdea,
      lyrics: "",
      use_story: true,
      use_lyrics: false,
      style_id: $("#film-style")?.value || "standard",
      style_prefix:
        ($("#film-style")?.value || "") === "custom"
          ? ($("#film-style-custom")?.value || "").trim()
          : "",
      slot_duration: slot,
      scene_count: sceneCount,
      planner_model: $("#film-model-planner")?.value || null,
      writer_model: $("#film-model-writer")?.value || null,
      editor_model: $("#film-model-editor")?.value || null,
      character_names: (state.project?.references || [])
        .filter((r) => (r.category || "character") === "character")
        .map((r) => ({ name: r.name, description: r.description || r.notes || "" })),
    };
    try {
      localStorage.setItem(
        "fenix_story_models",
        JSON.stringify({
          planner: body.planner_model,
          writer: body.writer_model,
          editor: body.editor_model,
        })
      );
    } catch (_) {}
    // Save idea on project
    state.project = await api.getProject(filmWiz.projectId);
    state.project.story = state.project.story || {};
    state.project.story.idea = fullIdea;
    state.project.story.use_story = true;
    state.project.story.use_lyrics = false;
    await api.saveProject(filmWiz.projectId, state.project);

    const res = await api.storyGenerate(filmWiz.projectId, body, {
      onEvent: (ev) => {
        if (!ev) return;
        if (ev.message) setClientActivity("Ollama: " + String(ev.message).slice(0, 48), "ollama", ev.detail || "");
        if (ev.type === "status" || ev.type === "done") {
          const pct = Math.round((ev.progress || 0) * 100);
          const fill = $("#film-think-meter-fill");
          const pctEl = $("#film-think-pct");
          if (fill) fill.style.width = pct + "%";
          if (pctEl) pctEl.textContent = pct + "%";
          if (status && ev.message) status.textContent = ev.message;
          if (stream && ev.message) {
            const d = (ev.detail || "").trim().replace(/\s+/g, " ");
            stream.textContent +=
              (stream.textContent ? "\n" : "") +
              "● " +
              ev.message +
              (d ? "\n  " + (d.length > 280 ? d.slice(0, 280) + "…" : d) : "");
            stream.scrollTop = stream.scrollHeight;
          }
        }
      },
    });
    if (status) status.textContent = `Done — ${res.scene_count} scenes`;
    const pid = res.project?.id || filmWiz.projectId;
    filmWiz.projectId = null;
    await openProject(pid);
    els.jobToast.textContent = `Film story ready · ${res.scene_count} scenes`;
  } catch (e) {
    if (status) status.textContent = "Failed: " + (e.message || e);
    alert("Film AI failed:\n\n" + (e.message || e));
  } finally {
    setClientActivity(null);
    if (btn) btn.disabled = false;
    $("#film-think-panel")?.classList.remove("thinking");
    pollActivity();
  }
}

/** Shared library checkboxes → import into project references */
async function renderLibraryPicks(containerId, projectId) {
  const box = $(`#${containerId}`);
  if (!box) return;
  if (!projectId) {
    box.innerHTML = `<span class="muted small">Create / open project first…</span>`;
    return;
  }
  let lib = [];
  try {
    lib = await api.characters();
  } catch (_) {
    box.innerHTML = `<span class="muted small">Could not load Character Manager</span>`;
    return;
  }
  if (!lib.length) {
    box.innerHTML = `<span class="muted small">No library characters yet — upload below or use Character Manager.</span>`;
    return;
  }
  let projRefs = [];
  try {
    const p = await api.getProject(projectId);
    projRefs = p.references || [];
    state.project = p;
  } catch (_) {}
  const onNames = new Set(projRefs.map((r) => (r.name || "").toLowerCase()));
  box.innerHTML = lib
    .map((c) => {
      const checked = onNames.has((c.name || "").toLowerCase());
      const img = c.path
        ? `<img src="/api/characters/${c.id}/image" alt="" />`
        : `<span class="muted" style="width:32px;text-align:center">·</span>`;
      return `<label class="library-pick${checked ? " on" : ""}" data-char-id="${escapeHtml(c.id)}">
        <input type="checkbox" data-lib-char="${escapeHtml(c.id)}" ${checked ? "checked" : ""} />
        ${img}
        <span>${escapeHtml(c.name)}</span>
      </label>`;
    })
    .join("");
  box.querySelectorAll("input[data-lib-char]").forEach((inp) => {
    inp.addEventListener("change", async () => {
      const cid = inp.dataset.libChar;
      try {
        if (inp.checked) {
          state.project = await api.importCharacterToProject(projectId, cid);
        } else {
          // Remove matching project ref by library name
          const char = lib.find((x) => x.id === cid);
          const name = (char?.name || "").toLowerCase();
          const ref = (state.project?.references || []).find(
            (r) => (r.name || "").toLowerCase() === name
          );
          if (ref) {
            state.project = await api.deleteReference(projectId, ref.id);
          }
        }
        if (containerId.startsWith("wiz")) renderWizRefs();
        if (containerId.startsWith("film")) renderFilmRefs();
        if (containerId.startsWith("amv")) renderAmvRefs();
        await renderLibraryPicks(containerId, projectId);
      } catch (e) {
        alert(e.message || e);
        inp.checked = !inp.checked;
      }
    });
  });
}

/**
 * @param {{ forceNew?: boolean }} opts
 * forceNew: true = abandon incomplete session and create a brand-new project.
 * default: resume incomplete wizard if one exists, else start new.
 */
async function openWizard(opts = {}) {
  const forceNew = !!opts.forceNew;
  showView("wizard");

  const draft = restoreWizardDraftLocal();
  const hasDraft =
    draft &&
    draft.incomplete !== false &&
    (draft.projectId || (draft.idea && draft.idea.length) || (draft.lyrics && draft.lyrics.length));

  let resume = false;
  if (!forceNew && hasDraft) {
    // Prefer disk project if we have an id
    let diskHint = "";
    if (draft.projectId) {
      try {
        const p = await api.getProject(draft.projectId);
        const ideaLen = (p.story?.idea || "").length;
        const lyrLen = (p.story?.lyrics || "").length;
        const refs = (p.references || []).length;
        diskHint = `\nProject: ${p.name}\nOn disk: idea ${ideaLen} chars · lyrics ${lyrLen} chars · ${refs} character ref(s)`;
      } catch (_) {
        diskHint = "\n(Saved project id no longer found — will use browser draft text.)";
      }
    }
    const ageMin = draft.savedAt ? Math.round((Date.now() - draft.savedAt) / 60000) : "?";
    resume = confirm(
      `Continue your in-progress Story Wizard (~${ageMin} min ago)?\n\n` +
        `OK = resume same project (keeps story, audio, characters)\n` +
        `Cancel = start a BRAND NEW project` +
        diskHint
    );
  }

  if (resume && draft) {
    wizard.incomplete = true;
    applyWizardDraft(draft);
    if (draft.projectId) {
      try {
        state.project = await api.getProject(draft.projectId);
        wizard.projectId = draft.projectId;
        // Disk is source of truth for story + refs
        applyProjectStoryToForm(state.project);
        // Merge longer browser draft text if disk somehow shorter (shouldn't overwrite longer disk)
        const di = state.project.story?.idea || "";
        const dl = state.project.story?.lyrics || "";
        if ((draft.idea || "").length > di.length && $("#wiz-idea")) {
          $("#wiz-idea").value = draft.idea;
        }
        if ((draft.lyrics || "").length > dl.length && $("#wiz-lyrics")) {
          $("#wiz-lyrics").value = draft.lyrics;
        }
        if (draft.step && draft.step >= 1 && draft.step <= 6) wizardGo(draft.step);
      } catch (_) {
        wizard.projectId = null;
        if (draft.step) wizardGo(draft.step);
      }
    } else if (draft.step) {
      wizardGo(draft.step);
    }
  } else {
    // Brand new wizard run = new project (created on first Continue / audio)
    clearWizardDraftLocal();
    wizard.projectId = null;
    wizard.incomplete = true;
    wizard.step = 1;
    state.project = null;
    resetWizardFormEmpty();
    wizardGo(1);
  }

  try {
    const llm = await api.llmModels();
    wizard.models = llm.models || [];
    wizard.defaults = llm.defaults || {};
    wizard.styles = llm.styles || state.system?.style_templates || [];
    wizard.forceSmall = !!llm.force_small_models;
    wizard.vramGb = llm.vram_gb;
    const st = $("#wiz-ollama-status");
    if (st) {
      st.textContent = llm.online
        ? `Ollama online · ${wizard.models.length} models` +
          (llm.force_small_models ? ` · GPU ${llm.vram_gb || "?"}GB → prefer ≤4B` : "")
        : "Ollama offline — start Ollama before generating";
    }
    fillWizModelSelects();
    fillWizStyles();
  } catch (e) {
    const st = $("#wiz-ollama-status");
    if (st) st.textContent = "Could not list LLMs: " + e.message;
  }
  persistWizardDraftLocal();
}

function fillWizStyles() {
  const sel = $("#wiz-style");
  if (!sel) return;
  const styles = wizard.styles.length
    ? wizard.styles
    : [
        { id: "standard", label: "Standard video", prefix: "" },
        { id: "cinematic_drama", label: "Cinematic drama", prefix: "" },
        { id: "bright_happy", label: "Bright happy", prefix: "" },
        { id: "custom", label: "Custom (type your own)", prefix: "" },
      ];
  const prev = sel.value;
  sel.innerHTML = styles.map((s) => `<option value="${s.id}">${escapeHtml(s.label)}</option>`).join("");
  if (prev && [...sel.options].some((o) => o.value === prev)) sel.value = prev;
  else if ([...sel.options].some((o) => o.value === "standard")) sel.value = "standard";
  updateWizStylePreview();
}

function updateWizStylePreview() {
  const id = $("#wiz-style")?.value;
  const s = (wizard.styles || []).find((x) => x.id === id);
  const el = $("#wiz-style-preview");
  const customWrap = $("#wiz-style-custom-wrap");
  const isCustom = id === "custom";
  if (customWrap) customWrap.classList.toggle("hidden", !isCustom);
  if (el) {
    if (isCustom) {
      el.textContent = "Type your own style line below — it is prepended to every scene still.";
    } else if (id === "standard" || !(s?.prefix || "").trim()) {
      el.textContent = "Standard — no look/feel filter. Prompts stay as written (no film grain, etc.).";
    } else {
      el.textContent = s?.prefix || "";
    }
  }
}

/** Parse ~param count (billions) from model id; bare "4b" must not match "14b". */
function modelParamB(id) {
  const n = String(id || "").toLowerCase();
  const m = n.match(/(?:^|[:\-_./])(\d+(?:\.\d+)?)\s*b\b/);
  if (m) return parseFloat(m[1]);
  if (/tiny|mini/.test(n)) return 1.5;
  if (/small/.test(n)) return 3;
  return 99;
}

function filterModelsForStory(models, forceSmall) {
  const list = models || [];
  if (!forceSmall) return list;
  const small = list.filter((m) => modelParamB(m.id || m.name) <= 4.5);
  return small.length ? small : list;
}

function fillWizModelSelects() {
  const forceSmall = !!(wizard.forceSmall || (state.system && state.system.vram_gb > 0 && state.system.vram_gb < 8));
  const models = filterModelsForStory(wizard.models || [], forceSmall);
  wizard.modelsFiltered = models;
  const opts =
    models
      .map(
        (m) =>
          `<option value="${escapeHtml(m.id)}">${escapeHtml(m.id)}${
            m.size_gb ? ` (${m.size_gb}GB)` : ""
          }${modelParamB(m.id) <= 4.5 ? " · fast" : ""}</option>`
      )
      .join("") || `<option value="">(no models)</option>`;
  for (const key of ["wiz-model-planner", "wiz-model-writer", "wiz-model-editor"]) {
    const sel = $(`#${key}`);
    if (!sel) continue;
    const prev = sel.value;
    sel.innerHTML = opts;
    // Keep user's previous choice if still in the list
    if (prev && [...sel.options].some((o) => o.value === prev)) {
      sel.value = prev;
    }
  }
  // Only auto-pick small models if nothing selected yet
  const smallPref = [
    "qwen3.5:0.8b",
    "qwen3.5:2b",
    "qwen2.5:3b",
    "qwen2.5:1.5b",
    "llama3.2:3b",
    "llama3.2:1b",
    "tinyllama",
    "gemma2:2b",
    "phi3:mini",
    "qwen3.5:4b",
    "qwen3:4b",
    "qwen3:1.7b",
    "qwen2.5-coder:3b",
    "qwen2.5-coder:1.5b",
  ];
  // Defaults from Settings (API) / localStorage — never stomp a value already selected
  let lastStoryModels = {};
  try {
    lastStoryModels = JSON.parse(localStorage.getItem("fenix_story_models") || "{}") || {};
  } catch (_) {
    lastStoryModels = {};
  }
  const apiDefs = wizard.defaults || {};
  const roleWant = {
    "wiz-model-planner":
      apiDefs.story_planner || apiDefs.planner || apiDefs.chat || lastStoryModels.planner,
    "wiz-model-writer":
      apiDefs.story_writer || apiDefs.writer || apiDefs.chat || lastStoryModels.writer,
    "wiz-model-editor":
      apiDefs.story_editor || apiDefs.editor || apiDefs.chat || lastStoryModels.editor,
  };
  for (const key of ["wiz-model-planner", "wiz-model-writer", "wiz-model-editor"]) {
    const sel = $(`#${key}`);
    if (!sel) continue;
    if (sel.value) continue;
    const want = roleWant[key];
    if (want && [...sel.options].some((o) => o.value === want)) {
      sel.value = want;
    } else {
      preferModelExact(key, smallPref);
    }
  }
  const st = $("#wiz-ollama-status");
  if (st && forceSmall) {
    st.textContent =
      (st.textContent || "Ollama") +
      " · Low VRAM: only ≤~4B models listed for story speed";
  }
}

/** Match model ids carefully — never treat "4b" as matching "14b". */
function preferModelExact(selectId, preferredIds) {
  const sel = $(`#${selectId}`);
  if (!sel || !sel.options.length) return;
  const values = [...sel.options].map((o) => o.value).filter(Boolean);
  for (const want of preferredIds) {
    const w = want.toLowerCase();
    // Exact
    let hit = values.find((v) => v.toLowerCase() === w);
    if (hit) {
      sel.value = hit;
      return;
    }
    // Same family + similar size only
    const wantB = modelParamB(want);
    const base = w.split(":")[0];
    const candidates = values
      .filter((v) => {
        const vl = v.toLowerCase();
        if (!(vl === base || vl.startsWith(base + ":"))) return false;
        if (wantB < 90) {
          return Math.abs(modelParamB(v) - wantB) <= 1.5;
        }
        return true;
      })
      .sort((a, b) => modelParamB(a) - modelParamB(b));
    if (candidates[0]) {
      sel.value = candidates[0];
      return;
    }
  }
}

function preferModel(selectId, needles) {
  // Back-compat alias used by film wizard
  preferModelExact(selectId, needles);
}

function wizardGo(step) {
  wizard.step = step;
  for (let i = 1; i <= 6; i++) {
    const panel = $(`#wiz-panel-${i}`);
    if (panel) panel.classList.toggle("hidden", i !== step);
  }
  $$("#wizard-steps .wiz-step").forEach((el) => {
    const s = parseInt(el.dataset.step, 10);
    el.classList.toggle("on", s === step);
    el.classList.toggle("done", s < step);
  });
}

async function wizardEnsureProject() {
  if (wizard.projectId) return wizard.projectId;
  const name = ($("#wiz-name")?.value || "Untitled Music Video").trim();
  const p = await api.createProject(name, { kind: "music" });
  wizard.projectId = p.id;
  wizard.incomplete = true;
  state.project = p;
  persistWizardDraftLocal();
  return p.id;
}

async function wizardEnsureBefore(nextStep) {
  // New project is created once per wizard run (first time we leave step 1)
  if (nextStep >= 2) {
    await wizardEnsureProject();
  }
  if (nextStep >= 4) {
    await wizardEnsureProject();
  }
  if (nextStep >= 3) {
    // audio optional but recommended
    if (!state.project?.audio?.path) {
      if (!confirm("No audio uploaded yet. Continue without audio? (You'll need scene_count/slots later.)")) {
        return false;
      }
    }
  }
  if (nextStep >= 5) {
    const useStory = $("#wiz-use-story")?.checked;
    const useLyrics = $("#wiz-use-lyrics")?.checked;
    const idea = ($("#wiz-idea")?.value || "").trim();
    const lyrics = ($("#wiz-lyrics")?.value || "").trim();
    if ((useStory && !idea && !useLyrics) || (useLyrics && !lyrics && !useStory) || (!useStory && !useLyrics)) {
      if (!idea && !lyrics) {
        alert("Add a story idea and/or lyrics, and enable at least one source.");
        return false;
      }
    }
    if (!idea && !lyrics) {
      alert("Add a story idea and/or lyrics.");
      return false;
    }
  }
  return true;
}

function renderWizRefs() {
  const box = $("#wiz-refs");
  if (!box) return;
  const refs = state.project?.references || [];
  box.innerHTML =
    refs
      .map(
        (r) =>
          `<span class="ref-chip on" title="${escapeHtml(r.category)}">${escapeHtml(r.name)}</span>`
      )
      .join("") || `<span class="muted small">No references yet</span>`;
}

function setWizThinkVisible(on) {
  const panel = $("#wiz-think-panel");
  if (panel) panel.classList.toggle("hidden", !on);
  if (panel) panel.classList.toggle("thinking", !!on);
}

function appendWizThink(line, detail) {
  const pre = $("#wiz-think-stream");
  if (!pre) return;
  const bits = [line];
  if (detail && String(detail).trim()) {
    const d = String(detail).trim().replace(/\s+/g, " ");
    bits.push(d.length > 280 ? d.slice(0, 280) + "…" : d);
  }
  const block = bits.join("\n  ");
  pre.textContent = (pre.textContent ? pre.textContent + "\n" : "") + block;
  pre.scrollTop = pre.scrollHeight;
}

function setWizThinkProgress(p, msg) {
  const pct = Math.max(0, Math.min(100, Math.round((p || 0) * 100)));
  const fill = $("#wiz-think-meter-fill");
  const pctEl = $("#wiz-think-pct");
  if (fill) fill.style.width = pct + "%";
  if (pctEl) pctEl.textContent = pct + "%";
  const status = $("#wiz-gen-status");
  if (status && msg) status.textContent = msg;
}

async function runWizardGenerate() {
  const status = $("#wiz-gen-status");
  const btn = $("#btn-wiz-run");
  const stream = $("#wiz-think-stream");
  try {
    await wizardEnsureProject();
    const useStory = $("#wiz-use-story")?.checked !== false;
    const useLyrics = $("#wiz-use-lyrics")?.checked !== false;
    const idea = ($("#wiz-idea")?.value || "").trim();
    const lyrics = ($("#wiz-lyrics")?.value || "").trim();
    if (!idea && !lyrics) {
      alert("Add story and/or lyrics first.");
      return;
    }
    if (
      ($("#wiz-style")?.value || "") === "custom" &&
      !($("#wiz-style-custom")?.value || "").trim()
    ) {
      alert("Custom style is selected — type a style string, or pick another preset.");
      return;
    }
    if (!state.project?.audio?.duration && !confirm("No audio duration — continue with default scene count 12?")) {
      return;
    }
    if (btn) btn.disabled = true;
    if (stream) stream.textContent = "";
    setWizThinkVisible(true);
    setWizThinkProgress(0.02, "Starting… models may take a minute to load into RAM/VRAM.");
    appendWizThink("● Pipeline starting (planner → writer → editor)");
    setClientActivity("Ollama: loading / story", "ollama", "music wizard");
    const body = {
      idea,
      lyrics,
      use_story: useStory && !!idea,
      use_lyrics: useLyrics && !!lyrics,
      style_id: $("#wiz-style")?.value || "standard",
      style_prefix:
        ($("#wiz-style")?.value || "") === "custom"
          ? ($("#wiz-style-custom")?.value || "").trim()
          : "",
      slot_duration: parseFloat($("#wiz-slot")?.value) || 5,
      planner_model: $("#wiz-model-planner")?.value || null,
      writer_model: $("#wiz-model-writer")?.value || null,
      editor_model: $("#wiz-model-editor")?.value || null,
      character_names: (state.project.references || [])
        .filter((r) => (r.category || "character") === "character")
        .map((r) => ({
          name: r.name,
          description: r.description || r.notes || "",
        }))
        .filter((c) => (c.name || "").trim()),
    };
    try {
      localStorage.setItem(
        "fenix_story_models",
        JSON.stringify({
          planner: body.planner_model,
          writer: body.writer_model,
          editor: body.editor_model,
        })
      );
    } catch (_) {}
    if (!state.project?.audio?.duration) body.scene_count = 12;
    await wizardEnsureProject();
    persistWizardDraftLocal();
    const res = await api.storyGenerate(wizard.projectId, body, {
      onEvent: (ev) => {
        if (!ev) return;
        if (ev.type === "status" || ev.type === "done") {
          setWizThinkProgress(ev.progress ?? 0, ev.message || "");
          if (ev.message) {
            appendWizThink("● " + ev.message, ev.detail);
            setClientActivity("Ollama: " + String(ev.message).slice(0, 48), "ollama", ev.detail || "");
          }
        }
      },
    });
    clearWizardDraftLocal();
    wizard.incomplete = false;
    setWizThinkProgress(1, `Done — ${res.scene_count} scenes`);
    appendWizThink(
      `✓ Complete · ${res.scene_count} scenes · models ${JSON.stringify(res.models_used || {})}`
    );
    const pid = res.project?.id || wizard.projectId;
    wizard.projectId = null;
    await openProject(pid);
    els.jobToast.textContent = `Story ready · ${res.scene_count} scenes · use Bulk images when ready`;
  } catch (e) {
    wizard.incomplete = true;
    persistWizardDraftLocal();
    const msg = String(e.message || e);
    if (status) status.textContent = "Failed: " + msg;
    appendWizThink("✗ Failed: " + msg);
    setWizThinkVisible(true);
    const tip =
      /empty response/i.test(msg)
        ? "\n\nTip: Prefer a small instruct model (≤4B, e.g. qwen2.5:3b or tinyllama). Story text stays in the form — retry Generate."
        : /Method Not Allowed/i.test(msg)
          ? "\n\nTip: Hard-refresh the page (Ctrl+F5), then retry."
          : "";
    alert("Story generation failed:\n\n" + msg + tip);
  } finally {
    setClientActivity(null);
    pollActivity();
    if (btn) btn.disabled = false;
    const panel = $("#wiz-think-panel");
    if (panel) panel.classList.remove("thinking");
  }
}

/** Estimate model size in GB from Ollama list fields or name tags. */
function modelSizeGb(m) {
  if (m && typeof m.size_gb === "number" && m.size_gb > 0) return m.size_gb;
  const id = String(m?.id || m?.name || "").toLowerCase();
  const tag = id.match(/(\d+(?:\.\d+)?)\s*b\b/);
  if (tag) {
    const b = parseFloat(tag[1]);
    // Rough VRAM: ~0.6–1× param count for Q4/Q5
    return b * 0.7;
  }
  return 99;
}

function filterModelsForLowVram(models, lowVram) {
  if (!lowVram) return models || [];
  const filtered = (models || []).filter((m) => modelSizeGb(m) <= 6.5);
  return filtered.length ? filtered : models || [];
}

function fillModelSelect(sel, models, current) {
  if (!sel) return;
  const opts = [`<option value="">— auto —</option>`].concat(
    (models || []).map(
      (m) =>
        `<option value="${escapeHtml(m.id || m.name)}">${escapeHtml(m.name || m.id)}${m.size_gb ? ` (${m.size_gb} GB)` : ""}</option>`
    )
  );
  sel.innerHTML = opts.join("");
  if (current) {
    const has = [...sel.options].some((o) => o.value === current);
    if (has) sel.value = current;
  }
}

async function openSettings() {
  showView("settings");
  try {
    const s = await api.getSettings();
    state.userSettings = s;
    if ($("#set-comfy-url")) $("#set-comfy-url").value = s.comfy_url || s.comfy_url_live || "";
    if ($("#set-ollama-url")) $("#set-ollama-url").value = s.ollama_url || s.ollama_url_live || "";
    if ($("#set-comfy-path")) $("#set-comfy-path").value = s.comfy_install_path || "";
    if ($("#set-comfy-start")) $("#set-comfy-start").value = s.comfy_start_script || "";
    if ($("#set-low-vram")) $("#set-low-vram").checked = !!s.optimize_low_vram;
    if ($("#set-video-timeout")) {
      const tm = Number(s.video_timeout_min);
      $("#set-video-timeout").value = Number.isFinite(tm) && tm > 0 ? tm : 60;
    }
    state._settingsHydrated = true;
    let models = [];
    try {
      const lm = await api.llmModels();
      models = lm.models || [];
    } catch (_) {
      models = state.system?.ollama?.models || [];
    }
    state.allLlmModels = models;
    const low = !!s.optimize_low_vram;
    const chatModels = filterModelsForLowVram(models, low);
    fillModelSelect($("#set-chat-model"), chatModels, s.chat_model);
    // Story models: saved settings first; empty → show chat model as current
    const storyFallback = s.chat_model || "";
    fillModelSelect(
      $("#set-story-planner"),
      chatModels,
      s.story_planner_model || storyFallback
    );
    fillModelSelect(
      $("#set-story-writer"),
      chatModels,
      s.story_writer_model || storyFallback
    );
    fillModelSelect(
      $("#set-story-editor"),
      chatModels,
      s.story_editor_model || storyFallback
    );
    fillModelSelect($("#set-coder-designer"), chatModels, s.coder_designer_model);
    fillModelSelect($("#set-coder-model"), chatModels, s.coder_model);
    fillModelSelect($("#set-coder-repair"), chatModels, s.coder_repair_model);
    if ($("#set-watermark-enabled")) {
      $("#set-watermark-enabled").checked =
        s.watermark_enabled === undefined ? true : !!s.watermark_enabled;
    }
    if ($("#set-watermark-text")) {
      $("#set-watermark-text").value =
        s.watermark_text || "Made with Fenix AI Studio";
    }
    if ($("#set-watermark-opacity")) {
      const op = Number(s.watermark_opacity);
      $("#set-watermark-opacity").value = Number.isFinite(op) ? op : 0.45;
    }
    populateModelSelects();
    if ($("#set-preferred-image-model") && s.preferred_image_model != null) {
      const el = $("#set-preferred-image-model");
      const want = s.preferred_image_model || "";
      if ([...el.options].some((o) => o.value === want)) el.value = want;
    }
    if ($("#set-preferred-video-preset") && s.preferred_video_preset != null) {
      const el = $("#set-preferred-video-preset");
      const want = s.preferred_video_preset || "";
      if ([...el.options].some((o) => o.value === want)) el.value = want;
    }
    applyDevUiFromSettings(s);
    if ($("#settings-status")) {
      $("#settings-status").textContent = low
        ? `Loaded · Low VRAM on · ${chatModels.length} chat models ≤~6GB`
        : "Loaded";
    }
  } catch (e) {
    if ($("#settings-status")) $("#settings-status").textContent = e.message;
  }
}

function isDevBuild() {
  return !!(state.system?.app?.dev_build);
}

function applyDevSkin(skin) {
  const s = (skin || "red").toLowerCase();
  const ok = ["red", "purple", "green", "orange"].includes(s) ? s : "red";
  if (ok === "red") document.documentElement.removeAttribute("data-skin");
  else document.documentElement.setAttribute("data-skin", ok);
}

function applyDevUiFromSettings(s) {
  const card = $("#dev-settings-card");
  const showDev = isDevBuild();
  if (card) {
    card.classList.toggle("hidden", !showDev);
    if (showDev) card.removeAttribute("hidden");
    else card.setAttribute("hidden", "");
  }
  if (!showDev) {
    document.documentElement.removeAttribute("data-skin");
    document.documentElement.removeAttribute("data-show-beta");
    return;
  }
  const skin = s?.dev_skin || "red";
  if ($("#dev-skin")) $("#dev-skin").value = skin;
  if ($("#dev-show-beta")) $("#dev-show-beta").checked = !!s?.dev_show_beta;
  if ($("#dev-prefer-flux-9b")) $("#dev-prefer-flux-9b").checked = !!s?.dev_prefer_flux_9b;
  if ($("#dev-extra-anti-mutant")) {
    $("#dev-extra-anti-mutant").checked =
      s?.dev_extra_anti_mutant === undefined ? true : !!s.dev_extra_anti_mutant;
  }
  applyDevSkin(skin);
  if (s?.dev_show_beta) document.documentElement.setAttribute("data-show-beta", "1");
  else document.documentElement.removeAttribute("data-show-beta");
}

let galleryPickKind = "image";

function closeGalleryPicker() {
  $("#modal-gallery")?.classList.add("hidden");
  // Stop any playing preview videos when closing
  $$("#gallery-modal-grid video").forEach((v) => {
    try {
      v.pause();
      v.removeAttribute("src");
      v.load?.();
    } catch (_) {}
  });
}

async function applyGalleryPick(itemId) {
  const shotId = selectedShot()?.id;
  if (!shotId || !state.project?.id || !itemId) return;
  try {
    els.jobToast.textContent = "Applying gallery item…";
    state.project = await api.shotFromStudio(state.project.id, shotId, itemId);
    // Critical: timeline keeps its own project ref — must sync or UI shows stale paths
    timeline.setProject(state.project);
    timeline.selectedShotId = shotId;
    closeGalleryPicker();
    const shot = selectedShot();
    bindInspectorFromShot(shot);
    timeline.render();
    // Force preview to reload the new file (same path can be overwritten)
    state.lastPreviewKey = null;
    state.lastPreviewMode = null;
    clearPreviewVideo();
    const t = shot ? shot.start + 0.05 : state.project.timeline.playhead || 0;
    showPreviewAt(t, { fromUserSeek: true });
    const hasVid = !!(shot?.video_path || shot?.draft_video_path);
    els.jobToast.textContent = hasVid
      ? "Gallery video on shot — check the preview"
      : "Gallery item applied";
  } catch (e) {
    alert(e.message || e);
  }
}

async function openGalleryPicker(kind) {
  const shot = selectedShot();
  if (!shot) {
    alert("Select a shot first.");
    return;
  }
  if (!state.project?.id) return;
  galleryPickKind = kind === "video" ? "video" : "image";
  const isVideo = galleryPickKind === "video";
  const modal = $("#modal-gallery");
  const card = $("#gallery-modal-card");
  const title = $("#gallery-modal-title");
  const hint = $("#gallery-modal-hint");
  const grid = $("#gallery-modal-grid");
  if (title) title.textContent = isVideo ? "Pick a video" : "Pick an image";
  if (hint) {
    hint.textContent = isVideo
      ? "Click thumb = play/pause. Use = apply. Close / Esc cancels."
      : "Click thumb or Use to apply. Close / Esc cancels.";
  }
  card?.classList.remove("is-video");
  if (grid) grid.innerHTML = `<p class="muted small">Loading…</p>`;
  modal?.classList.remove("hidden");
  try {
    const items = await api.studioItems(galleryPickKind);
    if (!grid) return;
    if (!items?.length) {
      grid.innerHTML = `<p class="muted small">No ${galleryPickKind}s in the gallery yet. Generate some first.</p>`;
      return;
    }
    // EXACT same thumb markup as studio "Recent gens" gallery (renderStudioLibraryGrid)
    grid.innerHTML = items
      .map((it) => {
        const url = api.studioItemMediaUrl(it.id);
        const kind = it.kind || "image";
        const titleTxt = escapeHtml((it.title || "").slice(0, 40));
        const media =
          kind === "video"
            ? `<video src="${url}" muted playsinline preload="metadata" controlslist="nodownload noplaybackrate noremoteplayback nopictureinpicture" disablepictureinpicture disableRemotePlayback></video>`
            : `<img src="${url}" alt="" loading="lazy" />`;
        return `<div class="gallery-pick-wrap" data-gallery-id="${escapeHtml(it.id)}">
          <button type="button" class="studio-media-card cut" data-gallery-thumb="1">
            ${media}
            <div class="meta">${escapeHtml(kind)} · ${titleTxt}</div>
          </button>
          <button type="button" class="btn compact primary gallery-pick-use">Use</button>
        </div>`;
      })
      .join("");
    grid.querySelectorAll(".gallery-pick-wrap").forEach((wrap) => {
      const id = wrap.getAttribute("data-gallery-id");
      const thumb = wrap.querySelector("[data-gallery-thumb]");
      const vid = wrap.querySelector("video");
      const img = wrap.querySelector("img");
      if (vid) {
        try {
          vid.disablePictureInPicture = true;
          vid.setAttribute("disablepictureinpicture", "");
        } catch (_) {}
      }
      wrap.querySelector(".gallery-pick-use")?.addEventListener("click", (e) => {
        e.preventDefault();
        e.stopPropagation();
        applyGalleryPick(id);
      });
      // Image: click thumb = use (same as before)
      if (img && thumb) {
        thumb.addEventListener("click", (e) => {
          e.preventDefault();
          applyGalleryPick(id);
        });
      }
      // Video: click thumb = play/pause only (no controls bar). Use = apply.
      if (vid && thumb) {
        thumb.addEventListener("click", (e) => {
          e.preventDefault();
          e.stopPropagation();
          if (vid.paused) {
            $$("#gallery-modal-grid video").forEach((other) => {
              if (other !== vid) other.pause();
            });
            vid.muted = true;
            vid.play()?.catch?.(() => {});
          } else {
            vid.pause();
          }
        });
      }
    });
  } catch (e) {
    if (grid) grid.innerHTML = `<p class="muted small">${escapeHtml(e.message)}</p>`;
  }
}

async function saveSettingsUi() {
  try {
    const storyP = $("#set-story-planner")?.value || "";
    const storyW = $("#set-story-writer")?.value || "";
    const storyE = $("#set-story-editor")?.value || "";
    // Never clobber low-VRAM from an unhydrated checkbox (HTML default = off).
    let lowVram = !!$("#set-low-vram")?.checked;
    if (!state._settingsHydrated && state.userSettings && state.userSettings.optimize_low_vram != null) {
      lowVram = !!state.userSettings.optimize_low_vram;
    }
    await api.saveSettings({
      comfy_url: $("#set-comfy-url")?.value?.trim(),
      ollama_url: $("#set-ollama-url")?.value?.trim(),
      comfy_install_path: $("#set-comfy-path")?.value?.trim() || "",
      comfy_start_script: $("#set-comfy-start")?.value?.trim() || "",
      chat_model: $("#set-chat-model")?.value || "",
      story_planner_model: storyP,
      story_writer_model: storyW,
      story_editor_model: storyE,
      coder_designer_model: $("#set-coder-designer")?.value || "",
      coder_model: $("#set-coder-model")?.value || "",
      coder_repair_model: $("#set-coder-repair")?.value || "",
      optimize_low_vram: lowVram,
      video_timeout_min: Math.max(
        10,
        Math.min(240, parseInt($("#set-video-timeout")?.value, 10) || 60)
      ),
      watermark_enabled: !!$("#set-watermark-enabled")?.checked,
      watermark_text: ($("#set-watermark-text")?.value || "Made with Fenix AI Studio").trim(),
      watermark_opacity: parseFloat($("#set-watermark-opacity")?.value) || 0.45,
      preferred_image_model: $("#set-preferred-image-model")?.value || "",
      preferred_video_preset: $("#set-preferred-video-preset")?.value || "",
      ...(isDevBuild()
        ? {
            dev_skin: $("#dev-skin")?.value || "red",
            dev_show_beta: !!$("#dev-show-beta")?.checked,
            dev_prefer_flux_9b: !!$("#dev-prefer-flux-9b")?.checked,
            dev_extra_anti_mutant: !!$("#dev-extra-anti-mutant")?.checked,
          }
        : {}),
    });
    if (isDevBuild()) {
      applyDevSkin($("#dev-skin")?.value || "red");
      if ($("#dev-show-beta")?.checked) document.documentElement.setAttribute("data-show-beta", "1");
      else document.documentElement.removeAttribute("data-show-beta");
    }
    // Keep localStorage in sync so Regenerate prompts / wizard use the same models
    try {
      localStorage.setItem(
        "fenix_story_models",
        JSON.stringify({
          planner: storyP || $("#set-chat-model")?.value || "",
          writer: storyW || $("#set-chat-model")?.value || "",
          editor: storyE || $("#set-chat-model")?.value || "",
        })
      );
    } catch (_) {}
    if ($("#settings-status")) $("#settings-status").textContent = "Saved";
    try {
      state.userSettings = (await api.getSettings()) || state.userSettings;
    } catch (_) {
      if (state.userSettings) state.userSettings.optimize_low_vram = lowVram;
    }
    updateMiniMaxWarn();
    loadSystem();
    chatCtrl.refreshSettings?.();
    // Re-filter model lists if low-vram toggled
    openSettings();
  } catch (e) {
    if ($("#settings-status")) $("#settings-status").textContent = e.message;
    alert(e.message);
  }
}

async function exportWebmFromPreview() {
  if (!state.project) return;
  const box = $("#export-result");
  const btn = $("#btn-export-webm");
  const stopBtn = $("#btn-export-webm-stop");
  const stage = $("#preview-stage") || document.querySelector(".preview-stage");
  if (!stage) {
    alert("Open the editor preview first.");
    return;
  }
  const duration =
    state.project.audio?.duration ||
    Math.max(
      5,
      ...(state.project.timeline?.shots || []).map((s) => (s.start || 0) + (s.duration || 0))
    );
  state.webmAbort = new AbortController();
  if (btn) btn.disabled = true;
  if (stopBtn) stopBtn.classList.remove("hidden");
  if (box) box.textContent = "Preparing browser WebM capture… keep this tab visible.";
  try {
    if (state.playing) pause();
    const blob = await recordPreviewWebM({
      stageEl: stage,
      previewVideo: els.previewVideo,
      previewImage: els.previewImage,
      mainAudio: els.mainAudio,
      getDuration: () => duration,
      seekTo: async (t) => {
        seekTo(t);
      },
      onStatus: (msg) => {
        if (box) box.textContent = msg;
        els.jobToast.textContent = msg;
      },
      signal: state.webmAbort.signal,
    });
    const name = `${(state.project.name || "export").replace(/\s+/g, "_")}_browser.webm`;
    downloadBlob(blob, name);
    if (box)
      box.innerHTML = `WebM ready (${(blob.size / 1e6).toFixed(1)} MB) — download started as <strong>${escapeHtml(name)}</strong>`;
    els.jobToast.textContent = "WebM export complete";
  } catch (e) {
    if (box) box.textContent = e.message || String(e);
    els.jobToast.textContent = "WebM export failed";
  } finally {
    state.webmAbort = null;
    if (btn) btn.disabled = false;
    if (stopBtn) stopBtn.classList.add("hidden");
  }
}

// ---------- First-run onboarding wizard ----------
const onboard = { step: 1, max: 5 };

function setOnboardStep(n) {
  onboard.step = n;
  for (let i = 1; i <= onboard.max; i++) {
    const panel = $(`#onboard-step-${i}`);
    if (panel) panel.classList.toggle("hidden", i !== n);
  }
  $$("#onboard-steps .onboard-dot").forEach((el) => {
    const s = parseInt(el.dataset.step, 10);
    el.classList.toggle("on", s === n);
    el.classList.toggle("done", s < n);
  });
  const back = $("#btn-onboard-back");
  if (back) back.classList.toggle("hidden", n <= 1);
  const next = $("#btn-onboard-next");
  if (next) next.textContent = n >= onboard.max ? "Finish" : "Next →";
}

async function refreshOnboardChecks() {
  let sys = state.system;
  try {
    sys = await api.system();
    state.system = sys;
  } catch (_) {}
  const comfyOk = !!(sys?.comfyui_online || sys?.comfy?.online || sys?.comfyui?.online);
  const ollamaOk = !!(sys?.ollama?.online);
  let models = sys?.ollama?.models || [];
  if (!models.length) {
    try {
      const lm = await api.llmModels();
      models = lm.models || [];
    } catch (_) {}
  }
  const hasModel = models.length > 0;
  const set = (id, ok, text) => {
    const el = $(id);
    if (!el) return;
    el.className = "onboard-check " + (ok ? "ok" : "bad");
    el.textContent = text;
  };
  set(
    "#onboard-check-comfy",
    comfyOk,
    comfyOk ? "✓ ComfyUI is reachable" : "✗ ComfyUI not detected — start it or set the URL in Settings"
  );
  set(
    "#onboard-check-ollama",
    ollamaOk,
    ollamaOk ? "✓ Ollama is reachable" : "✗ Ollama not detected — install/start Ollama or set the URL"
  );
  set(
    "#onboard-check-models",
    hasModel,
    hasModel
      ? `✓ ${models.length} Ollama model(s) available`
      : "✗ No Ollama models yet — pull a small one (e.g. qwen2.5:3b)"
  );
  return { comfyOk, ollamaOk, hasModel };
}

async function openOnboarding(force = false) {
  const overlay = $("#onboard-overlay");
  if (!overlay) return;
  overlay.classList.remove("hidden");
  setOnboardStep(1);
  await refreshOnboardChecks();
}

async function closeOnboarding(markDone) {
  const overlay = $("#onboard-overlay");
  if (overlay) overlay.classList.add("hidden");
  if (markDone) {
    try {
      await api.saveSettings({ onboarding_complete: true });
    } catch (_) {}
  }
}

async function maybeShowOnboarding() {
  try {
    const s = await api.getSettings();
    state.userSettings = s;
    if (!s.onboarding_complete) await openOnboarding();
  } catch (_) {
    // Don't block the app if settings fail
  }
}

// ---------- Music generation (ACE-Step / Suno-like) ----------
const FENIX_DEMO_LYRICS = `[Verse]
Fire up the screen, turn the noise up loud,
Building something different from the digital crowd.
Games, beats, worlds — whatever comes alive,
Throw it in the furnace, see what survives.

[Pre-Chorus]
No rules, no waiting,
Make it, break it, start again.

[Chorus]
Fenix Studio — rise from the flame,
Build another world, give the madness a name.
From an empty page to a midnight glow,
If we can imagine it — we make it go.

Fenix Studio — louder every time,
Code in the blood and a beat in the mind.
Create. Destroy. Rebuild. Reload.
Fenix Studio — make your own road.

[Outro]
Turn it up.
Light the flame.
Fenix Studio.
`;
const FENIX_DEMO_TAGS = "pop, energetic, electronic, anthem, cinematic, fenix studio";
const FENIX_DEMO_CAPTION =
  "Global Metadata: pop, energetic electronic anthem. 120 BPM, E minor. " +
  "Bright confident mood that builds into a wide final chorus. Headphones / studio listening. " +
  "Clean modern production, punchy drums, polished mix.\n\n" +
  "Vocal Details: Clear contemporary lead vocal, confident delivery, light doubles on chorus, " +
  "subtle reverb, no extreme effects.\n\n" +
  "Arrangement: Punchy kick and snare, synth bass, bright lead synths and pads. " +
  "Intro: sparse pulse. Verses: drums, bass, soft pads. Chorus: full stack with wider synths. " +
  "Bridge: pull back then rebuild. Outro: elements fade.";

const MUSIC_ENGINE_LIMITS = { ace: 240, minimax: 300 };
const MUSIC_STYLE_LS = "fenix_music_style_memory_v1";

/** @type {{ engine: 'ace'|'minimax', ace: string, minimax: string }} */
let musicEngineState = {
  engine: "ace",
  ace: "",
  minimax: "",
};

function loadMusicStyleMemory() {
  try {
    const raw = JSON.parse(localStorage.getItem(MUSIC_STYLE_LS) || "null");
    if (raw && typeof raw === "object") {
      if (typeof raw.ace === "string") musicEngineState.ace = raw.ace;
      if (typeof raw.minimax === "string") musicEngineState.minimax = raw.minimax;
      if (raw.engine === "ace" || raw.engine === "minimax") musicEngineState.engine = raw.engine;
    }
  } catch (_) {}
}

function saveMusicStyleMemory() {
  try {
    localStorage.setItem(
      MUSIC_STYLE_LS,
      JSON.stringify({
        engine: musicEngineState.engine,
        ace: musicEngineState.ace,
        minimax: musicEngineState.minimax,
      })
    );
  } catch (_) {}
}

function currentMusicEngine() {
  return musicEngineState.engine === "minimax" ? "minimax" : "ace";
}

function applyMusicSeed(seed) {
  const n = parseInt(String(seed), 10);
  if (!Number.isFinite(n) || n < 0) return;
  if ($("#music-seed")) $("#music-seed").value = String(n);
  showView("music");
  setMusicTab("create");
  const status = $("#music-gen-status");
  if (status) {
    setLiveStatus(
      status,
      `Seed ${n} loaded — keep style/lyrics, raise duration for a longer take.`,
      false
    );
  }
}

function updateMiniMaxWarn() {
  const low =
    !!(state.userSettings && state.userSettings.optimize_low_vram) ||
    !!$("#set-low-vram")?.checked;
  const el = $("#music-minimax-lowvram-warn");
  if (el) el.classList.toggle("hidden", !low);
}

function snapshotMusicStyleField() {
  const eng = currentMusicEngine();
  if (eng === "minimax") {
    musicEngineState.minimax = ($("#music-caption")?.value || "").trim();
  } else {
    musicEngineState.ace = ($("#music-tags")?.value || "").trim();
  }
  saveMusicStyleMemory();
}

function setMusicEngine(engine, { skipSnapshot = false } = {}) {
  const next = engine === "minimax" ? "minimax" : "ace";
  if (!skipSnapshot) snapshotMusicStyleField();
  musicEngineState.engine = next;
  saveMusicStyleMemory();

  $$("#music-engine-toggle .tab-mode").forEach((b) => {
    b.classList.toggle("active", b.dataset.musicEngine === next);
  });
  const isAce = next === "ace";
  document.querySelectorAll(".music-engine-ace").forEach((el) => {
    el.classList.toggle("hidden", !isAce);
  });
  document.querySelectorAll(".music-engine-minimax").forEach((el) => {
    el.classList.toggle("hidden", isAce);
  });
  // Dedicated style blocks (also have ids)
  $("#music-ace-style-block")?.classList.toggle("hidden", !isAce);
  $("#music-minimax-style-block")?.classList.toggle("hidden", isAce);

  const durEl = $("#music-duration");
  const hint = $("#music-duration-hint");
  const maxSec = MUSIC_ENGINE_LIMITS[next] || 240;
  if (durEl) {
    durEl.max = String(maxSec);
    const cur = parseFloat(durEl.value) || 30;
    if (cur > maxSec) durEl.value = String(maxSec);
    if (next === "minimax" && cur < 10) durEl.min = "5";
    else durEl.min = "10";
  }
  if (hint) hint.textContent = next === "minimax" ? "max 300 MiniMax" : "max 240 ACE";

  // Restore per-engine style into visible field (memory survives engine switches)
  if (next === "minimax") {
    const cap = $("#music-caption");
    if (cap) cap.value = musicEngineState.minimax || FENIX_DEMO_CAPTION;
  } else {
    const tags = $("#music-tags");
    if (tags) tags.value = musicEngineState.ace || FENIX_DEMO_TAGS;
  }

  // Train tab is ACE-only — keep Create selected when on MiniMax
  const trainBtn = document.querySelector('#music-top-tabs [data-music-tab="train"]');
  if (trainBtn) {
    trainBtn.disabled = next === "minimax";
    trainBtn.title =
      next === "minimax" ? "Train style is ACE-only — switch back to ACE-Step" : "";
  }

  if (next === "minimax") updateMiniMaxWarn();
  refreshMusicAceStatus();
}

const MUSIC_ICON_COLORS = [
  "#c41e2a", "#8a1218", "#e84a3a", "#6b2430", "#a01820", "#d42a2a", "#7a141c", "#b83228",
];

function musicLetterIcon(title) {
  const letter = ((title || "T")[0] || "T").toUpperCase();
  const color = MUSIC_ICON_COLORS[letter.charCodeAt(0) % MUSIC_ICON_COLORS.length];
  return { letter, color };
}

function renderMusicTrackGrid(containerId, tracks, { compact = false, maxVisible = 0 } = {}) {
  const box = document.getElementById(containerId);
  if (!box) return;
  const list = tracks || [];
  if (!list.length) {
    box.innerHTML = `<p class="muted small">No saved tracks yet.</p>`;
    box.dataset.showAll = "0";
    return;
  }
  const showAll = box.dataset.showAll === "1";
  const limit =
    maxVisible > 0 && !showAll ? Math.min(maxVisible, list.length) : list.length;
  const visible = list.slice(0, limit);
  const hiddenCount = list.length - visible.length;

  box.innerHTML =
    visible
      .map((t) => {
        const { letter, color } = musicLetterIcon(t.title);
        const dur = t.duration_sec ? `${Math.round(t.duration_sec)}s` : "";
        const bpm = t.bpm ? `${t.bpm} BPM` : "";
        const eng = (t.engine || "").toLowerCase() === "minimax" ? "MiniMax" : t.engine ? "ACE" : "";
        const seedNum =
          t.seed != null && t.seed !== "" && Number(t.seed) >= 0 ? String(t.seed) : "";
        const seedBit = seedNum
          ? `<button type="button" class="music-seed-chip" data-reuse-seed="${escapeHtml(seedNum)}" title="Load this seed into Create (seed field stays -1 after normal generates)">seed ${escapeHtml(seedNum)}</button>`
          : "";
        const meta = [eng, dur, bpm].filter(Boolean).join(" · ");
        const audio = t.path ? api.musicTrackAudioUrl(t.id) : "";
        return `<div class="music-track-card cut" data-track-id="${escapeHtml(t.id)}">
        <div class="music-track-icon" style="background:${color}">${escapeHtml(letter)}</div>
        <div class="music-track-info">
          <strong title="${escapeHtml(t.title || "")}">${escapeHtml(t.title || "Untitled")}</strong>
          <span class="meta">${escapeHtml(meta)}${seedBit ? " · " : ""}${seedBit}</span>
        </div>
        <div class="track-actions">
          ${audio ? `<button type="button" class="btn compact ghost" data-play-track="${escapeHtml(t.id)}">Play</button>` : ""}
          <button type="button" class="btn compact ghost" data-rename-track="${escapeHtml(t.id)}" data-rename-title="${escapeHtml(t.title || "")}">Rename</button>
          <button type="button" class="btn compact ghost danger" data-del-track="${escapeHtml(t.id)}">Delete</button>
        </div>
      </div>`;
      })
      .join("") +
    (hiddenCount > 0
      ? `<button type="button" class="btn ghost music-track-more" data-music-more>
           Show more (${hiddenCount} more)
         </button>`
      : showAll && maxVisible > 0 && list.length > maxVisible
        ? `<button type="button" class="btn ghost music-track-more" data-music-less>
             Show less
           </button>`
        : "");

  box.querySelectorAll("[data-reuse-seed]").forEach((btn) => {
    btn.addEventListener("click", (e) => {
      e.stopPropagation();
      const seed = btn.getAttribute("data-reuse-seed");
      if (seed == null || seed === "") return;
      applyMusicSeed(seed);
    });
  });
  box.querySelectorAll("[data-play-track]").forEach((btn) => {
    btn.addEventListener("click", (e) => {
      e.stopPropagation();
      const id = btn.dataset.playTrack;
      const url = api.musicTrackAudioUrl(id);
      const player = $("#music-player");
      if (player) {
        player.src = url;
        player.play?.().catch(() => {});
        $("#music-player-wrap")?.classList.remove("hidden");
        const dl = $("#music-download");
        if (dl) {
          dl.href = url;
          dl.download = "track.mp3";
        }
        showView("music");
      } else {
        window.open(url, "_blank");
      }
    });
  });
  box.querySelectorAll("[data-rename-track]").forEach((btn) => {
    btn.addEventListener("click", async (e) => {
      e.stopPropagation();
      const id = btn.dataset.renameTrack;
      const current = btn.dataset.renameTitle || "";
      const next = prompt("Rename track:", current);
      if (next == null) return;
      const title = String(next).trim();
      if (!title) {
        alert("Title cannot be empty.");
        return;
      }
      try {
        await api.musicRename(id, title);
        loadHomeMusicTracks();
        loadMusicLibrary();
      } catch (err) {
        alert(err.message || err);
      }
    });
  });
  box.querySelectorAll("[data-del-track]").forEach((btn) => {
    btn.addEventListener("click", async (e) => {
      e.stopPropagation();
      if (!confirm("Delete this track?")) return;
      try {
        await api.musicDelete(btn.dataset.delTrack);
        loadHomeMusicTracks();
        loadMusicLibrary();
      } catch (err) {
        alert(err.message || err);
      }
    });
  });
  box.querySelector("[data-music-more]")?.addEventListener("click", (e) => {
    e.stopPropagation();
    box.dataset.showAll = "1";
    renderMusicTrackGrid(containerId, list, { compact, maxVisible });
  });
  box.querySelector("[data-music-less]")?.addEventListener("click", (e) => {
    e.stopPropagation();
    box.dataset.showAll = "0";
    renderMusicTrackGrid(containerId, list, { compact, maxVisible });
  });
}

async function loadHomeMusicTracks() {
  try {
    const tracks = await api.musicTracks();
    // Home: 2-col grid-list, first 20 tracks, then Show more
    renderMusicTrackGrid("home-music-list", tracks, { compact: true, maxVisible: 20 });
  } catch (_) {
    const box = $("#home-music-list");
    if (box) box.innerHTML = `<p class="muted small">Could not load tracks.</p>`;
  }
}

async function loadMusicLibrary() {
  try {
    const tracks = await api.musicTracks();
    renderMusicTrackGrid("music-lib-list", tracks);
  } catch (e) {
    const box = $("#music-lib-list");
    if (box) box.innerHTML = `<p class="muted small">${escapeHtml(e.message || "Load failed")}</p>`;
  }
}

/** Once the Create form has been seeded, never clobber duration/BPM when re-opening Music or switching Create↔Train. */
let musicCreateDefaultsApplied = false;

async function openMusicStudio() {
  loadMusicStyleMemory();
  try {
    if (!state.userSettings) state.userSettings = (await api.getSettings()) || {};
  } catch (_) {}
  setMusicEngine(musicEngineState.engine || "ace", { skipSnapshot: true });
  updateMiniMaxWarn();
  await refreshMusicAceStatus();
  try {
    const d = await api.musicDefaults();
    if (!musicEngineState.ace && (d.tags || FENIX_DEMO_TAGS)) {
      musicEngineState.ace = d.tags || FENIX_DEMO_TAGS;
    }
    if (!musicEngineState.minimax && (d.caption || FENIX_DEMO_CAPTION)) {
      musicEngineState.minimax = d.caption || FENIX_DEMO_CAPTION;
    }
    if ($("#music-tags") && !$("#music-tags").value.trim()) {
      $("#music-tags").value = musicEngineState.ace || d.tags || FENIX_DEMO_TAGS;
    }
    if ($("#music-caption") && !$("#music-caption").value.trim()) {
      $("#music-caption").value = musicEngineState.minimax || d.caption || FENIX_DEMO_CAPTION;
    }
    if ($("#music-lyrics") && !$("#music-lyrics").value.trim()) {
      $("#music-lyrics").value = d.lyrics || FENIX_DEMO_LYRICS;
    }
    // Duration / BPM: only apply API defaults the first time this session
    // (switching Music↔Train or Home↔Music was resetting back to 30s).
    if (!musicCreateDefaultsApplied) {
      if ($("#music-duration") && d.duration_sec) $("#music-duration").value = d.duration_sec;
      if ($("#music-bpm") && d.bpm) $("#music-bpm").value = d.bpm;
      musicCreateDefaultsApplied = true;
    }
    saveMusicStyleMemory();
  } catch (_) {
    if ($("#music-tags") && !$("#music-tags").value.trim()) $("#music-tags").value = FENIX_DEMO_TAGS;
    if ($("#music-caption") && !$("#music-caption").value.trim()) {
      $("#music-caption").value = FENIX_DEMO_CAPTION;
    }
    if ($("#music-lyrics") && !$("#music-lyrics").value.trim()) $("#music-lyrics").value = FENIX_DEMO_LYRICS;
    musicCreateDefaultsApplied = true;
  }
  setMusicEngine(currentMusicEngine(), { skipSnapshot: true });
  loadMusicLibrary();
}

async function refreshMusicAceStatus() {
  const el = $("#music-ace-status");
  if (!el) return;
  const eng = currentMusicEngine();
  try {
    const s = await api.musicStatus();
    if (!s.comfy_online) {
      el.textContent = "Comfy offline";
      el.className = "pill bad";
      el.title = s.detail || "";
      return;
    }
    if (eng === "minimax") {
      if (s.minimax_ready) {
        el.textContent = "MiniMax ready";
        el.className = "pill good";
        el.title = s.minimax_detail || s.detail || "";
      } else {
        el.textContent = "MiniMax models?";
        el.className = "pill warn";
        el.title = s.minimax_detail || s.detail || "";
      }
    } else if (s.ace_ready) {
      el.textContent = "ACE ready";
      el.className = "pill good";
      el.title = s.ace_detail || s.detail || "";
    } else {
      el.textContent = "ACE models?";
      el.className = "pill warn";
      el.title = s.ace_detail || s.detail || "";
    }
  } catch (e) {
    el.textContent = "Check failed";
    el.className = "pill bad";
    el.title = e.message || "";
  }
}

const MUSIC_STYLE_PRESETS = [
  { id: "pop", label: "Pop", tags: "pop, catchy, radio, bright vocals, polished production, upbeat" },
  { id: "rock", label: "Rock", tags: "rock, electric guitars, drums, energetic, anthemic, live band" },
  { id: "hiphop", label: "Hip-Hop", tags: "hip-hop, trap drums, 808 bass, rhythmic vocals, urban, confident" },
  { id: "edm", label: "EDM", tags: "edm, electronic, big drops, synths, club, high energy, four-on-the-floor" },
  { id: "metal", label: "Metal", tags: "metal, heavy guitars, double kick, aggressive, distorted, powerful" },
  { id: "country", label: "Country", tags: "country, acoustic guitar, storytelling, warm, twang, heartfelt" },
  { id: "jazz", label: "Jazz", tags: "jazz, smooth, saxophone, piano, walking bass, sophisticated, chill" },
  { id: "lofi", label: "Lo-fi", tags: "lo-fi hip hop, chill, dusty drums, soft piano, study beats, warm vinyl" },
  { id: "cinematic", label: "Cinematic", tags: "cinematic, orchestral, epic, trailer, emotional strings, dramatic" },
  { id: "punk", label: "Punk", tags: "punk rock, fast, raw, distorted guitars, shouted vocals, rebellious" },
  { id: "rnb", label: "R&B", tags: "r&b, soulful vocals, smooth groove, modern, sensual, melodic" },
  { id: "fenix", label: "Fenix", tags: FENIX_DEMO_TAGS },
];

let _musicDotsTimer = null;
let _musicDotsStep = 0;

function setMusicThinking(on) {
  const panel = $("#music-thinking");
  const img = $("#music-thinking-img");
  const vid = $("#music-thinking-vid");
  if (panel) panel.classList.toggle("hidden", !on);
  if (_musicDotsTimer) {
    clearInterval(_musicDotsTimer);
    _musicDotsTimer = null;
  }
  if (!on) {
    if (vid) {
      try {
        vid.pause();
      } catch (_) {}
      vid.classList.add("hidden");
    }
    if (img) img.classList.remove("hidden");
    return;
  }
  // Prefer animated avatar while "in the studio"
  if (vid) {
    vid.classList.remove("hidden");
    if (img) img.classList.add("hidden");
    try {
      vid.currentTime = 0;
      vid.play();
    } catch (_) {
      vid.classList.add("hidden");
      if (img) img.classList.remove("hidden");
    }
  }
  const dotsEl = $("#music-thinking-dots");
  _musicDotsStep = 0;
  _musicDotsTimer = setInterval(() => {
    _musicDotsStep = (_musicDotsStep + 1) % 5;
    if (dotsEl) dotsEl.textContent = ".".repeat(_musicDotsStep || 1);
  }, 450);
}

function renderMusicStylePresets() {
  const box = $("#music-style-presets");
  if (!box) return;
  box.innerHTML = MUSIC_STYLE_PRESETS.map(
    (p) =>
      `<button type="button" class="music-style-chip cut" data-style-id="${escapeHtml(p.id)}" title="${escapeHtml(p.tags)}">${escapeHtml(p.label)}</button>`
  ).join("");
  box.querySelectorAll("[data-style-id]").forEach((btn) => {
    btn.addEventListener("click", () => {
      const preset = MUSIC_STYLE_PRESETS.find((x) => x.id === btn.dataset.styleId);
      if (!preset) return;
      box.querySelectorAll(".music-style-chip").forEach((b) => b.classList.remove("on"));
      btn.classList.add("on");
      if ($("#music-tags")) $("#music-tags").value = preset.tags;
      musicEngineState.ace = preset.tags;
      saveMusicStyleMemory();
      if (preset.id === "fenix") {
        if ($("#music-title") && !$("#music-title").value.trim()) $("#music-title").value = "Fenix Studio";
        if ($("#music-key")) $("#music-key").value = "E minor";
      }
    });
  });
}

async function loadMusicLoras() {
  const sel = $("#music-lora");
  const hint = $("#music-lora-hint");
  if (!sel) return;
  const prev = sel.value || "";
  try {
    const res = await api.musicLoras();
    const list = res.loras || [];
    const preferred =
      list.find((l) => l.compatible && /symphonic.?metal|ace15_symphonic/i.test(l.name || l.filename || "")) ||
      list.find((l) => l.compatible && l.likely_ace) ||
      null;
    sel.innerHTML =
      `<option value="">None — base Turbo only (safest)</option>` +
      list
        .map((l) => {
          const name = l.name || l.filename || "";
          const label = l.label || l.filename || name;
          const mark = l.compatible ? "★ " : "⚠ ";
          return `<option value="${escapeHtml(name)}" ${l.compatible ? "" : 'data-incompatible="1"'}>${mark}${escapeHtml(label)}</option>`;
        })
        .join("");
    // Prefer previous only if still compatible; else none or first compatible
    const prevOk =
      prev &&
      list.some((l) => (l.name || "") === prev && l.compatible !== false);
    if (prevOk) {
      sel.value = prev;
    } else if (preferred) {
      sel.value = preferred.name;
    } else {
      sel.value = "";
    }
    const bad = list.filter((l) => l.compatible === false).length;
    if (hint) {
      if (!list.length) {
        hint.textContent =
          "No ACE LoRAs found. Drop .safetensors into ComfyUI/models/loras/ace/ then Refresh.";
      } else if (bad) {
        hint.textContent =
          `${list.length} LoRA(s): ${bad} need ACE SFT (not Turbo) — ⚠ will error if used without SFT UNET. ` +
          `Install acestep_v1.5.safetensors (SFT) for those, or leave LoRA on None for Turbo.`;
      } else {
        hint.textContent = `${list.length} LoRA(s) OK for your installed ACE model. ★ = ready.`;
      }
    }
  } catch (e) {
    if (hint) hint.textContent = "Could not list LoRAs (is Comfy online?): " + (e.message || e);
  }
}

/** @type {{ id: string, clips: any[] } | null} */
let musicTrainDraft = null;

function setMusicTab(tab) {
  const create = $("#music-tab-create");
  const train = $("#music-tab-train");
  const main = $("#music-main");
  $$("#music-top-tabs .tab-mode").forEach((b) => {
    b.classList.toggle("active", b.dataset.musicTab === tab);
  });
  if (tab === "train") {
    create?.classList.add("hidden");
    train?.classList.remove("hidden");
    main?.classList.add("music-main-train");
    refreshTrainCapability();
    loadTrainJobs();
  } else {
    create?.classList.remove("hidden");
    train?.classList.add("hidden");
    main?.classList.remove("music-main-train");
  }
}

function renderTrainClips() {
  const box = $("#train-file-list");
  if (!box) return;
  const clips = musicTrainDraft?.clips || [];
  if (!clips.length) {
    box.innerHTML = `<div class="empty">No clips yet — add 3–20 short tracks of the same vibe.</div>`;
    return;
  }
  box.innerHTML = clips
    .map(
      (c) =>
        `<div class="music-train-file-row"><span>${escapeHtml(c.filename)}</span><span class="muted">${Math.round((c.size_bytes || 0) / 1024)} KB</span></div>`
    )
    .join("");
}

async function ensureTrainDraft() {
  if (musicTrainDraft?.id) return musicTrainDraft;
  const name = ($("#train-style-name")?.value || "My style").trim() || "My style";
  const res = await api.musicTrainCreate({
    name,
    tags: ($("#train-style-tags")?.value || "").trim(),
    epochs: parseInt($("#train-epochs")?.value, 10) || 300,
    rank: parseInt($("#train-rank")?.value, 10) || 16,
    learning_rate: ($("#train-lr")?.value || "1e-4").trim(),
  });
  musicTrainDraft = res.job;
  renderTrainClips();
  return musicTrainDraft;
}

async function refreshTrainCapability() {
  const el = $("#train-capability");
  if (!el) return;
  try {
    const cap = await api.musicTrainCapability();
    el.textContent = `${cap.detail || ""} — ${cap.hint || ""}`.trim();
    el.style.color = cap.can_train ? "var(--good, #6d6)" : "var(--warn, #fa4)";
  } catch (e) {
    el.textContent = "Could not check train capability: " + (e.message || e);
  }
}

async function loadTrainJobs() {
  const box = $("#train-job-list");
  if (!box) return;
  try {
    const res = await api.musicTrainJobs();
    const jobs = res.jobs || [];
    if (!jobs.length) {
      box.innerHTML = `<p class="muted small">No training jobs yet.</p>`;
      return;
    }
    box.innerHTML = jobs
      .map((j) => {
        const clips = (j.clips || []).length;
        return `<div class="music-train-job">
          <strong>${escapeHtml(j.name || j.id)} · ${escapeHtml(j.status || "")}</strong>
          <span class="muted">${clips} clips · epochs ${j.epochs || "?"} · ${escapeHtml(j.message || "")}</span>
          ${j.output_lora ? `<div class="muted small">Output: ${escapeHtml(j.output_lora)}</div>` : ""}
        </div>`;
      })
      .join("");
  } catch (e) {
    box.innerHTML = `<p class="muted small">Failed to load jobs: ${escapeHtml(e.message || e)}</p>`;
  }
}

async function runTrainStart() {
  const status = $("#train-status");
  const btn = $("#btn-train-start");
  try {
    if (btn) btn.disabled = true;
    setLiveStatus(status, "Checking clips…", true);
    const draft = await ensureTrainDraft();
    musicTrainDraft = draft;
    const clips = musicTrainDraft?.clips || [];
    if (clips.length < 2) {
      alert("Add at least 2 audio clips first.");
      setLiveStatus(status, "Need more clips.", false);
      return;
    }
    const meta = {
      name: ($("#train-style-name")?.value || musicTrainDraft.name || "My style").trim(),
      tags: ($("#train-style-tags")?.value || "").trim(),
      epochs: parseInt($("#train-epochs")?.value, 10) || 300,
      rank: parseInt($("#train-rank")?.value, 10) || 16,
      learning_rate: ($("#train-lr")?.value || "1e-4").trim(),
    };
    setLiveStatus(status, "Starting training in Comfy…", true);
    setClientActivity("ACE LoRA train", "music", meta.name || "");
    const res = await api.musicTrainStart(musicTrainDraft.id, meta);
    musicTrainDraft = res.job || musicTrainDraft;
    setLiveStatus(status, res.job?.message || "Running…", true);
    // Poll until done / error (training can take a long time)
    const jobId = musicTrainDraft.id;
    const deadline = Date.now() + 60 * 60 * 1000;
    while (Date.now() < deadline) {
      await new Promise((r) => setTimeout(r, 2500));
      try {
        const jobs = (await api.musicTrainJobs()).jobs || [];
        const cur = jobs.find((x) => x.id === jobId);
        if (!cur) break;
        musicTrainDraft = cur;
        setLiveStatus(status, cur.message || cur.status, cur.status === "running");
        loadTrainJobs();
        if (cur.status === "done") {
          setLiveStatus(status, cur.message || "Done", false);
          loadMusicLoras();
          alert(
            "Training finished.\n\n" +
              (cur.output_lora
                ? "LoRA: " + cur.output_lora + "\n\nOpen Create → Style LoRA → Refresh LoRAs."
                : cur.message || "Check Create → Style LoRA.")
          );
          break;
        }
        if (cur.status === "error" || cur.status === "cancelled") {
          setLiveStatus(status, cur.message || cur.status, false);
          alert("Training failed:\n\n" + (cur.message || cur.error || cur.status));
          break;
        }
      } catch (_) {
        /* keep polling */
      }
    }
    loadTrainJobs();
    loadMusicLoras();
  } catch (e) {
    setLiveStatus(status, "Failed: " + (e.message || e), false);
    alert("Training failed:\n\n" + (e.message || e));
  } finally {
    if (btn) btn.disabled = false;
    setClientActivity(null);
  }
}

function wireMusicStudio() {
  loadMusicStyleMemory();
  $("#btn-music-back")?.addEventListener("click", () => {
    snapshotMusicStyleField();
    setMusicThinking(false);
    showView("home");
  });
  $("#btn-music-lib-refresh")?.addEventListener("click", () => loadMusicLibrary());
  $("#btn-music-lora-refresh")?.addEventListener("click", () => loadMusicLoras());
  $("#btn-music-reset-lyrics")?.addEventListener("click", () => {
    if ($("#music-title")) $("#music-title").value = "Fenix Studio";
    if ($("#music-tags")) $("#music-tags").value = FENIX_DEMO_TAGS;
    if ($("#music-caption")) $("#music-caption").value = FENIX_DEMO_CAPTION;
    if ($("#music-lyrics")) $("#music-lyrics").value = FENIX_DEMO_LYRICS;
    if ($("#music-key")) $("#music-key").value = "E minor";
    if ($("#music-bpm")) $("#music-bpm").value = "120";
    if ($("#music-duration")) $("#music-duration").value = "30";
    musicEngineState.ace = FENIX_DEMO_TAGS;
    musicEngineState.minimax = FENIX_DEMO_CAPTION;
    saveMusicStyleMemory();
  });
  $$("#music-engine-toggle .tab-mode").forEach((btn) => {
    btn.addEventListener("click", () => setMusicEngine(btn.dataset.musicEngine || "ace"));
  });
  $("#btn-music-adv-toggle")?.addEventListener("click", () => {
    const box = $("#music-ace-advanced");
    const btn = $("#btn-music-adv-toggle");
    if (!box) return;
    const open = box.classList.toggle("hidden") === false;
    if (btn) btn.textContent = open ? "Hide advanced ACE options ▴" : "Show advanced ACE options ▾";
  });
  $("#music-ref-audio")?.addEventListener("change", (e) => {
    const f = e.target?.files?.[0] || null;
    window.__musicRefFile = f;
    const lab = $("#music-ref-audio-name");
    if (lab) lab.textContent = f ? f.name : "No reference selected";
  });
  $("#music-tags")?.addEventListener("input", () => {
    if (currentMusicEngine() === "ace") {
      musicEngineState.ace = ($("#music-tags")?.value || "").trim();
      saveMusicStyleMemory();
    }
  });
  $("#music-caption")?.addEventListener("input", () => {
    if (currentMusicEngine() === "minimax") {
      musicEngineState.minimax = ($("#music-caption")?.value || "").trim();
      saveMusicStyleMemory();
    }
  });
  $$("#music-top-tabs .tab-mode").forEach((btn) => {
    btn.addEventListener("click", () => {
      const tab = btn.dataset.musicTab || "create";
      if (tab === "train" && currentMusicEngine() === "minimax") {
        alert("Train style is ACE-only. Switch to ACE-Step first.");
        return;
      }
      setMusicTab(tab);
    });
  });
  $("#btn-music-generate")?.addEventListener("click", () => runMusicGenerate());

  $("#train-audio-upload")?.addEventListener("change", async (e) => {
    const files = [...(e.target.files || [])];
    e.target.value = "";
    if (!files.length) return;
    const status = $("#train-status");
    try {
      setLiveStatus(status, "Uploading clips…", true);
      const draft = await ensureTrainDraft();
      for (const f of files) {
        setLiveStatus(status, `Uploading ${f.name}…`, true);
        const res = await api.musicTrainAddClip(draft.id, f);
        musicTrainDraft = res.job;
      }
      renderTrainClips();
      setLiveStatus(status, `${(musicTrainDraft.clips || []).length} clip(s) ready`, false);
      loadTrainJobs();
    } catch (err) {
      setLiveStatus(status, "Upload failed: " + (err.message || err), false);
      alert("Clip upload failed:\n\n" + (err.message || err));
    }
  });
  $("#btn-train-clear")?.addEventListener("click", async () => {
    if (!musicTrainDraft?.id) {
      renderTrainClips();
      return;
    }
    try {
      const res = await api.musicTrainClearClips(musicTrainDraft.id);
      musicTrainDraft = res.job;
      renderTrainClips();
      setLiveStatus($("#train-status"), "Clips cleared", false);
    } catch (e) {
      alert(e.message || e);
    }
  });
  $("#btn-train-start")?.addEventListener("click", () => runTrainStart());
  $("#btn-train-refresh")?.addEventListener("click", () => {
    refreshTrainCapability();
    loadTrainJobs();
  });

  renderMusicStylePresets();
  loadMusicLoras();
}

function setLiveStatus(el, text, busy = true) {
  if (!el) return;
  el.textContent = text;
  el.classList.toggle("busy", !!busy);
}

function startActivityPoll(statusEl) {
  const tick = async () => {
    try {
      const a = await api.genActivity();
      if (a?.message) setLiveStatus(statusEl, a.message, !!a.busy);
    } catch (_) {}
  };
  tick();
  return setInterval(tick, 900);
}

function wireEmergencyStop() {
  document.addEventListener("click", async (ev) => {
    const btn = ev.target?.closest?.(".btn-emergency-stop");
    if (!btn) return;
    // Single dialog: Cancel = abort; OK (blank or with text) = stop. Reason optional → logs.
    const reasonRaw = window.prompt(
      "EMERGENCY STOP\n\n" +
        "This stops ALL generation in Comfy and clears VRAM.\n\n" +
        "Optional: type why you’re stopping (saved to the logs).\n" +
        "Leave blank and press OK to stop anyway.\n" +
        "Cancel = don’t stop."
    );
    if (reasonRaw === null) return;
    const reason = String(reasonRaw || "").trim();
    btn.disabled = true;
    btn.textContent = "Stopping…";
    try {
      setClientActivity("Emergency stop", "comfy", reason.slice(0, 40) || "clearing VRAM");
      const res = await api.emergencyStop(reason);
      const n = res?.cancelled_jobs != null ? res.cancelled_jobs : "?";
      alert(
        "Emergency stop sent.\n\n" +
          `• Fenix jobs cancelled: ${n}\n` +
          "• Comfy: interrupt + clear queue + free VRAM" +
          (reason ? `\n• Reason logged: ${reason}` : "") +
          (res?.errors?.length ? "\n\nNotes: " + res.errors.join("; ") : "")
      );
    } catch (e) {
      alert("Emergency stop failed:\n\n" + (e.message || e));
    } finally {
      btn.disabled = false;
      btn.textContent = "EMERGENCY STOP";
      setClientActivity(null);
      pollActivity();
    }
  });
}

async function runMusicGenerate() {
  const status = $("#music-gen-status");
  const btn = $("#btn-music-generate");
  const title = ($("#music-title")?.value || "Untitled Track").trim();
  const engine = currentMusicEngine();
  const tags = ($("#music-tags")?.value || "").trim();
  const caption = ($("#music-caption")?.value || "").trim();
  const lyrics = ($("#music-lyrics")?.value || "").trim();
  snapshotMusicStyleField();
  if (engine === "minimax") {
    if (!caption && !lyrics) {
      alert("Add a MiniMax caption and/or lyrics first.");
      return;
    }
  } else if (!tags && !lyrics) {
    alert("Add style tags and/or lyrics first.");
    return;
  }
  const maxSec = MUSIC_ENGINE_LIMITS[engine] || 240;
  let duration = parseFloat($("#music-duration")?.value) || 30;
  if (duration > maxSec) duration = maxSec;
  if (btn) btn.disabled = true;
  setClientActivity(
    engine === "minimax" ? "Comfy: MiniMax Music 3" : "Comfy: ACE-Step music",
    "comfy",
    title
  );
  setMusicThinking(true);
  setLiveStatus(status, "Preparing music job…", true);
  const poll = startActivityPoll(status);
  try {
    const loraName = ($("#music-lora")?.value || "").trim();
    const loraStrength = parseFloat($("#music-lora-strength")?.value);
    const body = {
      title,
      engine,
      lyrics: lyrics || FENIX_DEMO_LYRICS,
      duration_sec: duration,
      seed: parseInt($("#music-seed")?.value, 10),
      save: true,
    };
    if (engine === "minimax") {
      if (duration >= 120) {
        setLiveStatus(
          status,
          `Long MiniMax job (~${Math.round(duration)}s) — freeing VRAM, smaller tiles; AR encode is slow…`,
          true
        );
      }
      body.caption = caption || FENIX_DEMO_CAPTION;
      body.tags = "";
      body.bpm = 120;
      body.keyscale = "E minor";
      body.language = "en";
      body.timesignature = "4";
      body.steps = 30;
      body.generate_audio_codes = false;
      body.lora_name = "";
      body.lora_strength = 0;
    } else {
      body.tags = tags || FENIX_DEMO_TAGS;
      body.caption = "";
      body.bpm = parseInt($("#music-bpm")?.value, 10) || 120;
      body.keyscale = $("#music-key")?.value || "E minor";
      body.language = $("#music-language")?.value || "en";
      body.timesignature = $("#music-timesig")?.value || "4";
      body.steps = 8;
      body.generate_audio_codes = $("#music-audio-codes")?.checked === true;
      body.cfg_scale = parseFloat($("#music-cfg")?.value);
      if (!Number.isFinite(body.cfg_scale)) body.cfg_scale = 2.0;
      body.temperature = parseFloat($("#music-temp")?.value);
      if (!Number.isFinite(body.temperature)) body.temperature = 0.85;
      body.top_p = parseFloat($("#music-top-p")?.value);
      if (!Number.isFinite(body.top_p)) body.top_p = 0.9;
      body.top_k = parseInt($("#music-top-k")?.value, 10);
      if (!Number.isFinite(body.top_k)) body.top_k = 0;
      body.min_p = parseFloat($("#music-min-p")?.value);
      if (!Number.isFinite(body.min_p)) body.min_p = 0;
      body.lora_name = loraName;
      body.lora_strength = Number.isFinite(loraStrength) ? loraStrength : 0.75;
      body.reference_audio = "";
      const refFile = window.__musicRefFile || null;
      if (refFile) {
        setLiveStatus(status, `Uploading reference “${refFile.name}”…`, true);
        const up = await api.musicUploadReference(refFile);
        body.reference_audio = up?.name || "";
        if (body.reference_audio) body.generate_audio_codes = false;
      }
    }
    const res = await api.musicGenerate(body);
    const engLabel = engine === "minimax" ? "MiniMax" : "ACE";
    // Keep Create seed at -1 for the next run. Reuse only when the user clicks
    // "seed …" on a library track.
    if ($("#music-seed")) $("#music-seed").value = "-1";
    const usedSeed =
      res.seed != null && Number(res.seed) >= 0
        ? Number(res.seed)
        : res.track?.seed != null && Number(res.track.seed) >= 0
          ? Number(res.track.seed)
          : null;
    setLiveStatus(
      status,
      usedSeed != null
        ? `Done (${engLabel}) — saved “${res.track?.title || title}”. Seed ${usedSeed} is on the library card — click it to reuse.`
        : `Done (${engLabel}) — saved “${res.track?.title || title}”`,
      false
    );
    if (res.audio_url) {
      const player = $("#music-player");
      const wrap = $("#music-player-wrap");
      const dl = $("#music-download");
      if (player) {
        player.src = res.audio_url + "?t=" + Date.now();
        player.play?.().catch(() => {});
      }
      if (wrap) wrap.classList.remove("hidden");
      if (dl) {
        dl.href = res.audio_url;
        dl.download = (res.track?.title || title).replace(/\s+/g, "_") + ".mp3";
      }
    }
    loadMusicLibrary();
    loadHomeMusicTracks();
  } catch (e) {
    setLiveStatus(status, "Failed: " + (e.message || e), false);
    alert("Music generation failed:\n\n" + (e.message || e));
  } finally {
    clearInterval(poll);
    setMusicThinking(false);
    setClientActivity(null);
    pollActivity();
    if (btn) btn.disabled = false;
  }
}

// ---------- Image / Video Gen studio ----------
const studioState = {
  selectedId: null,
  uploadFile: null,
  audioFile: null,
  items: [], // studio videos + studio images (raw library)
  imagePool: [], // aggregated Images tab (studio + chars + projects)
  galleryTab: "videos", // videos | images
  i2vSourceId: "", // studio id | char:… | proj:…
  i2vSourceMeta: null,
  imageRefs: [], // [{ key, name, url, file?, charId? }]
  // ~5 rows × ~3 columns in the gallery pane; Show more adds another page
  pageSize: 15,
  visibleCount: 15,
};

function studioPageSize() {
  const box = $("#studio-lib-list");
  if (!box) return 15;
  const w = box.clientWidth || 420;
  const cols = Math.max(2, Math.floor(w / 150));
  return cols * 5; // 5 rows
}

async function openMediaStudio() {
  refreshStudioStatus();
  await loadStudioLibrary();
}

async function refreshStudioStatus() {
  const el = $("#studio-comfy-status");
  if (!el) return;
  try {
    const s = await api.studioStatus();
    el.textContent = s.comfy_online ? "Comfy ready" : "Comfy offline";
    el.classList.toggle("ok", !!s.comfy_online);
    el.classList.toggle("warn", !s.comfy_online);
  } catch {
    el.textContent = "Comfy unknown";
    el.classList.add("warn");
  }
}

function showStudioPreview(item) {
  if (!item) return;
  const wrap = $("#studio-preview-wrap");
  const img = $("#studio-preview-img");
  const vid = $("#studio-preview-vid");
  const dl = $("#studio-download");
  const base = studioItemMediaUrl(item) || api.studioItemMediaUrl(item.id);
  const url = base + (base.includes("?") ? "&" : "?") + "t=" + Date.now();
  if (wrap) wrap.classList.remove("hidden");
  if ((item.kind || "") === "video") {
    if (img) img.classList.add("hidden");
    if (vid) {
      vid.classList.remove("hidden");
      vid.src = url;
      vid.play?.().catch(() => {});
    }
    if (dl) {
      dl.href = url;
      dl.download = (item.title || item.id) + ".mp4";
    }
  } else {
    if (vid) {
      vid.pause?.();
      vid.removeAttribute("src");
      vid.classList.add("hidden");
    }
    if (img) {
      img.classList.remove("hidden");
      img.src = url;
    }
    if (dl) {
      dl.href = url;
      dl.download = (item.title || item.id) + ".png";
    }
  }
  studioState.selectedId = item.id;
}

function studioItemMediaUrl(item) {
  if (!item) return "";
  if (item.media_url) return item.media_url;
  if (item.id && !String(item.id).includes(":")) return api.studioItemMediaUrl(item.id);
  return "";
}

function setStudioI2vSource(item) {
  if (!item) {
    studioState.i2vSourceId = "";
    studioState.i2vSourceMeta = null;
    studioState.uploadFile = null;
    if ($("#studio-vid-upload")) $("#studio-vid-upload").value = "";
    if ($("#studio-vid-upload-name")) $("#studio-vid-upload-name").textContent = "No upload selected";
  } else {
    studioState.i2vSourceId = item.id || "";
    studioState.i2vSourceMeta = item;
    // Gallery pick wins over a pending upload
    studioState.uploadFile = null;
    if ($("#studio-vid-upload")) $("#studio-vid-upload").value = "";
    if ($("#studio-vid-upload-name")) $("#studio-vid-upload-name").textContent = "No upload selected";
  }
  renderStudioI2vSource();
  renderStudioLibraryGrid();
}

function renderStudioI2vSource() {
  const box = $("#studio-i2v-source-box");
  const prev = $("#studio-i2v-source-preview");
  const lab = $("#studio-i2v-source-label");
  const clearBtn = $("#btn-studio-i2v-clear");
  const meta = studioState.i2vSourceMeta;
  const upload = studioState.uploadFile;
  if (upload) {
    box?.classList.remove("empty");
    clearBtn?.classList.remove("hidden");
    if (lab) lab.textContent = `Upload: ${upload.name}`;
    if (prev) {
      const url = URL.createObjectURL(upload);
      prev.innerHTML = `<img src="${url}" alt="" />`;
    }
    return;
  }
  if (meta && studioState.i2vSourceId) {
    box?.classList.remove("empty");
    clearBtn?.classList.remove("hidden");
    const url = studioItemMediaUrl(meta);
    if (lab) {
      lab.textContent = `${meta.title || meta.id}${meta.origin ? ` · ${meta.origin}` : ""}`;
    }
    if (prev) prev.innerHTML = url ? `<img src="${url}" alt="" />` : "";
    return;
  }
  box?.classList.add("empty");
  clearBtn?.classList.add("hidden");
  if (lab) lab.textContent = "None — pick from Images gallery or upload";
  if (prev) prev.innerHTML = "";
}

function renderStudioImgRefs() {
  const box = $("#studio-img-refs");
  if (!box) return;
  const refs = studioState.imageRefs || [];
  if (!refs.length) {
    box.innerHTML = `<span class="muted small">No references</span>`;
    return;
  }
  box.innerHTML = refs
    .map(
      (r) => `<div class="studio-ref-chip" data-ref-key="${escapeHtml(r.key)}">
        <img src="${escapeHtml(r.url)}" alt="" />
        <span title="${escapeHtml(r.name)}">${escapeHtml(r.name)}</span>
        <button type="button" title="Remove" data-ref-remove="${escapeHtml(r.key)}">×</button>
      </div>`
    )
    .join("");
  box.querySelectorAll("[data-ref-remove]").forEach((btn) => {
    btn.addEventListener("click", () => {
      const key = btn.getAttribute("data-ref-remove");
      studioState.imageRefs = (studioState.imageRefs || []).filter((r) => r.key !== key);
      renderStudioImgRefs();
    });
  });
}

function studioGalleryItems() {
  if (studioState.galleryTab === "images") return studioState.imagePool || [];
  return (studioState.items || []).filter((i) => (i.kind || "") === "video");
}

function renderStudioLibraryGrid() {
  const box = $("#studio-lib-list");
  const moreBtn = $("#btn-studio-lib-more");
  const heading = $("#studio-lib-heading");
  const hint = $("#studio-gallery-hint");
  if (heading) heading.textContent = studioState.galleryTab === "images" ? "Images" : "Videos";
  if (hint) {
    hint.textContent =
      studioState.galleryTab === "images"
        ? "Studio + characters + project stills. Click to set as I2V source (Video tab)."
        : "Recent video gens from this studio.";
  }
  $$("#studio-gallery-tabs .tab-mode").forEach((b) => {
    b.classList.toggle("active", b.dataset.studioGallery === studioState.galleryTab);
  });
  if (!box) return;
  const items = studioGalleryItems();
  if (!items.length) {
    box.innerHTML =
      studioState.galleryTab === "images"
        ? `<p class="muted small">No images yet — generate stills, add characters, or open projects with shot images.</p>`
        : `<p class="muted small">No videos yet — generate I2V clips.</p>`;
    if (moreBtn) moreBtn.classList.add("hidden");
    return;
  }
  const page = studioPageSize();
  studioState.pageSize = page;
  if (!studioState.visibleCount || studioState.visibleCount < page) {
    studioState.visibleCount = page;
  }
  const shown = items.slice(0, studioState.visibleCount);
  box.innerHTML = shown
    .map((i) => {
      const url = studioItemMediaUrl(i);
      const kind = i.kind || "image";
      const isSource = studioState.i2vSourceId && studioState.i2vSourceId === i.id;
      const media =
        kind === "video"
          ? `<video src="${url}" muted playsinline preload="metadata"></video>`
          : `<img src="${url}" alt="" loading="lazy" />`;
      const on = studioState.selectedId === i.id || isSource ? " on" : "";
      const srcCls = isSource ? " is-i2v-source" : "";
      const origin = i.origin ? ` · ${escapeHtml(i.origin)}` : "";
      return `<button type="button" class="studio-media-card cut${on}${srcCls}" data-studio-id="${escapeHtml(i.id)}">
        ${media}
        <div class="meta">${escapeHtml(kind)}${origin} · ${escapeHtml((i.title || "").slice(0, 36))}</div>
      </button>`;
    })
    .join("");
  box.querySelectorAll("[data-studio-id]").forEach((btn) => {
    btn.addEventListener("click", () => {
      const id = btn.getAttribute("data-studio-id");
      const item = items.find((x) => x.id === id);
      if (!item) return;
      studioState.selectedId = id;
      const wrap = $("#studio-preview-wrap");
      const img = $("#studio-preview-img");
      const vid = $("#studio-preview-vid");
      const dl = $("#studio-download");
      const mediaUrl = studioItemMediaUrl(item);
      if (wrap) wrap.classList.remove("hidden");
      if ((item.kind || "") === "video") {
        if (img) img.classList.add("hidden");
        if (vid) {
          vid.classList.remove("hidden");
          vid.src = mediaUrl;
          vid.play?.().catch(() => {});
        }
        if (dl) {
          dl.href = mediaUrl;
          dl.download = (item.title || item.id) + ".mp4";
        }
      } else {
        if (vid) {
          vid.pause?.();
          vid.removeAttribute("src");
          vid.classList.add("hidden");
        }
        if (img) {
          img.classList.remove("hidden");
          img.src = mediaUrl;
        }
        if (dl) {
          dl.href = mediaUrl;
          dl.download = (item.title || item.id) + ".png";
        }
        // Selecting an image in Images tab = I2V source
        if (studioState.galleryTab === "images") {
          setStudioI2vSource(item);
          return;
        }
      }
      renderStudioLibraryGrid();
    });
  });
  if (moreBtn) {
    const hasMore = studioState.visibleCount < items.length;
    moreBtn.classList.toggle("hidden", !hasMore);
    moreBtn.textContent = hasMore
      ? `Show more (${Math.min(page, items.length - studioState.visibleCount)} more)`
      : "Show more";
  }
}

async function loadStudioLibrary({ resetVisible = true } = {}) {
  const box = $("#studio-lib-list");
  try {
    const [items, images] = await Promise.all([
      api.studioItems(),
      api.studioGalleryImages().catch(() => []),
    ]);
    studioState.items = items || [];
    studioState.imagePool = images || [];
    if (resetVisible) studioState.visibleCount = studioPageSize();
    // Refresh i2v source meta if still present
    if (studioState.i2vSourceId) {
      const hit =
        studioState.imagePool.find((x) => x.id === studioState.i2vSourceId) ||
        studioState.items.find((x) => x.id === studioState.i2vSourceId);
      if (hit) studioState.i2vSourceMeta = hit;
    }
    renderStudioI2vSource();
    if (!box) return;
    renderStudioLibraryGrid();
  } catch (e) {
    if (box) box.innerHTML = `<p class="muted small">Gallery error: ${escapeHtml(e.message || e)}</p>`;
  }
}

function setStudioMode(mode) {
  $$("#studio-mode-toggle .tab-mode").forEach((b) => {
    b.classList.toggle("active", b.dataset.studioMode === mode);
  });
  $("#studio-panel-image")?.classList.toggle("hidden", mode !== "image");
  $("#studio-panel-video")?.classList.toggle("hidden", mode !== "video");
}

function setStudioGalleryTab(tab) {
  studioState.galleryTab = tab === "images" ? "images" : "videos";
  studioState.visibleCount = studioPageSize();
  renderStudioLibraryGrid();
}

async function openStudioCharPicker() {
  const modal = $("#modal-studio-chars");
  const grid = $("#studio-chars-grid");
  if (!modal || !grid) return;
  grid.innerHTML = `<p class="muted small">Loading…</p>`;
  modal.classList.remove("hidden");
  try {
    const chars = await api.characters();
    const withImg = (chars || []).filter((c) => c.path || c.id);
    if (!withImg.length) {
      grid.innerHTML = `<p class="muted small">No characters in the library yet.</p>`;
      return;
    }
    grid.innerHTML = withImg
      .map((c) => {
        const url = `/api/characters/${encodeURIComponent(c.id)}/image`;
        return `<button type="button" class="studio-media-card cut" data-char-pick="${escapeHtml(c.id)}">
          <img src="${url}" alt="" loading="lazy" />
          <div class="meta">${escapeHtml(c.name || c.id)}</div>
        </button>`;
      })
      .join("");
    grid.querySelectorAll("[data-char-pick]").forEach((btn) => {
      btn.addEventListener("click", () => {
        const cid = btn.getAttribute("data-char-pick");
        const c = withImg.find((x) => x.id === cid);
        if (!c) return;
        const key = `char:${cid}`;
        if (studioState.imageRefs.some((r) => r.key === key)) return;
        studioState.imageRefs.push({
          key,
          name: c.name || cid,
          url: `/api/characters/${encodeURIComponent(cid)}/image`,
          charId: cid,
        });
        renderStudioImgRefs();
      });
    });
  } catch (e) {
    grid.innerHTML = `<p class="muted small">${escapeHtml(e.message || e)}</p>`;
  }
}

function wireMediaStudio() {
  $("#btn-studio-back")?.addEventListener("click", () => showView("home"));
  $("#btn-studio-lib-refresh")?.addEventListener("click", () => loadStudioLibrary({ resetVisible: true }));
  $("#btn-studio-lib-more")?.addEventListener("click", () => {
    studioState.visibleCount += studioState.pageSize || studioPageSize();
    renderStudioLibraryGrid();
  });
  $$("#studio-mode-toggle .tab-mode").forEach((btn) => {
    btn.addEventListener("click", () => setStudioMode(btn.dataset.studioMode || "image"));
  });
  $$("#studio-gallery-tabs .tab-mode").forEach((btn) => {
    btn.addEventListener("click", () => setStudioGalleryTab(btn.dataset.studioGallery || "videos"));
  });
  $("#btn-studio-i2v-clear")?.addEventListener("click", () => setStudioI2vSource(null));
  $("#studio-vid-upload")?.addEventListener("change", (e) => {
    const f = e.target?.files?.[0] || null;
    studioState.uploadFile = f;
    studioState.i2vSourceId = "";
    studioState.i2vSourceMeta = null;
    const lab = $("#studio-vid-upload-name");
    if (lab) lab.textContent = f ? f.name : "No upload selected";
    renderStudioI2vSource();
    renderStudioLibraryGrid();
  });
  $("#studio-vid-audio")?.addEventListener("change", (e) => {
    const f = e.target?.files?.[0] || null;
    studioState.audioFile = f;
    const lab = $("#studio-vid-audio-name");
    if (lab) lab.textContent = f ? f.name : "No audio selected";
  });
  $("#studio-img-ref-file")?.addEventListener("change", (e) => {
    const files = [...(e.target?.files || [])];
    for (const f of files) {
      const key = `file:${f.name}:${f.size}:${f.lastModified}`;
      if (studioState.imageRefs.some((r) => r.key === key)) continue;
      studioState.imageRefs.push({
        key,
        name: f.name,
        url: URL.createObjectURL(f),
        file: f,
      });
    }
    e.target.value = "";
    renderStudioImgRefs();
  });
  $("#btn-studio-img-ref-chars")?.addEventListener("click", () => openStudioCharPicker());
  $("#btn-studio-img-refs-clear")?.addEventListener("click", () => {
    studioState.imageRefs = [];
    renderStudioImgRefs();
  });
  $("#studio-img-w")?.addEventListener("input", () => updateStudioResLabel());
  $("#studio-img-h")?.addEventListener("input", () => updateStudioResLabel());
  $("#studio-img-batch")?.addEventListener("input", () => updateStudioGenImageBtn());
  $$("[data-studio-aspect]").forEach((btn) => {
    btn.addEventListener("click", () => applyStudioAspect(btn.dataset.studioAspect || "16:9"));
  });
  $("#studio-vid-model")?.addEventListener("change", () => updateStudioVideoPresetUI());
  $("#btn-studio-gen-image")?.addEventListener("click", () => runStudioImage());
  $("#btn-studio-gen-video")?.addEventListener("click", () => runStudioVideo());
  updateStudioVideoPresetUI();
  updateStudioResLabel();
  updateStudioGenImageBtn();
  renderStudioImgRefs();
  renderStudioI2vSource();
}

function studioSnap16(n, fallback) {
  let v = parseInt(n, 10);
  if (!Number.isFinite(v)) v = fallback;
  v = Math.max(256, Math.min(2048, v));
  // Multiples of 16 — real 720p (1280×720) stays 720, not 704
  return Math.max(256, Math.min(2048, Math.round(v / 16) * 16));
}

/** Old 64px snap left many UIs stuck on 704 — map common false-720p sizes up. */
function studioNormalizeRes(w, h) {
  w = studioSnap16(w, 1280);
  h = studioSnap16(h, 720);
  if (w === 1280 && h === 704) h = 720;
  if (h === 1280 && w === 704) w = 720;
  if (w === 1920 && h === 1072) h = 1080;
  if (h === 1920 && w === 1072) w = 1080;
  return [w, h];
}

function updateStudioResLabel() {
  const wEl = $("#studio-img-w");
  const hEl = $("#studio-img-h");
  if (!wEl || !hEl) return;
  let [w, h] = studioNormalizeRes(wEl.value, hEl.value);
  if (String(wEl.value) !== String(w)) wEl.value = String(w);
  if (String(hEl.value) !== String(h)) hEl.value = String(h);
  const wVal = $("#studio-img-w-val");
  const hVal = $("#studio-img-h-val");
  if (wVal) wVal.textContent = String(w);
  if (hVal) hVal.textContent = String(h);
  const lab = $("#studio-img-res-label");
  if (lab) {
    const mp = ((w * h) / 1e6).toFixed(2);
    lab.textContent = `${w} × ${h} · ~${mp} MP`;
  }
}

function applyStudioAspect(ratio) {
  const wEl = $("#studio-img-w");
  const hEl = $("#studio-img-h");
  if (!wEl || !hEl) return;
  let w = studioSnap16(wEl.value, 1280);
  let h = studioSnap16(hEl.value, 720);
  const long = Math.max(w, h, 1024);
  if (ratio === "1:1") {
    w = h = studioSnap16(long, 1024);
  } else if (ratio === "9:16") {
    h = studioSnap16(long, 1280);
    w = studioSnap16(Math.round((h * 9) / 16), 720);
  } else if (ratio === "4:3") {
    w = studioSnap16(long, 1280);
    h = studioSnap16(Math.round((w * 3) / 4), 960);
  } else {
    // 16:9 — real 720p
    w = studioSnap16(long, 1280);
    h = studioSnap16(Math.round((w * 9) / 16), 720);
  }
  wEl.value = String(w);
  hEl.value = String(h);
  updateStudioResLabel();
}

function updateStudioGenImageBtn() {
  const btn = $("#btn-studio-gen-image");
  if (!btn) return;
  const n = Math.max(1, Math.min(100, parseInt($("#studio-img-batch")?.value, 10) || 1));
  btn.textContent = n > 1 ? `Generate ${n} images` : "Generate image";
}

async function runStudioImage() {
  const status = $("#studio-gen-status");
  const btn = $("#btn-studio-gen-image");
  const prompt = ($("#studio-img-prompt")?.value || "").trim();
  if (!prompt) {
    alert("Enter an image prompt.");
    return;
  }
  updateStudioResLabel();
  const [width, height] = studioNormalizeRes(
    $("#studio-img-w")?.value,
    $("#studio-img-h")?.value
  );
  const batch = Math.max(1, Math.min(100, parseInt($("#studio-img-batch")?.value, 10) || 1));
  const refs = studioState.imageRefs || [];
  if (btn) btn.disabled = true;
  setClientActivity(
    batch > 1 ? `Comfy: Flux ×${batch}` : "Comfy: Flux image",
    "comfy",
    prompt.slice(0, 40)
  );
  setLiveStatus(
    status,
    batch > 1
      ? `Preparing ${batch} variations at ${width}×${height}…`
      : `Preparing image at ${width}×${height}…`,
    true
  );
  const poll = startActivityPoll(status);
  try {
    const res = await api.studioGenerateImage({
      prompt,
      negative_prompt: ($("#studio-img-negative")?.value || "").trim(),
      width,
      height,
      batch_count: batch,
      steps: 0, // backend/api: Klein draft=4 / final=8
      seed: parseInt($("#studio-img-seed")?.value, 10),
      model_id: $("#studio-img-model")?.value || "flux2-klein-4b",
      refFiles: refs.filter((r) => r.file).map((r) => r.file),
      refCharIds: refs.filter((r) => r.charId).map((r) => r.charId),
    });
    const n = (res.items && res.items.length) || (res.item ? 1 : 0);
    setLiveStatus(status, n > 1 ? `${n} images ready.` : "Image ready.", false);
    if (res.item) showStudioPreview(res.item);
    await loadStudioLibrary();
    setStudioGalleryTab("images");
  } catch (e) {
    // Request may die on Emergency Stop / app quit even after Comfy wrote the PNG.
    // Always refresh gallery so a salvaged/saved still shows up.
    setLiveStatus(status, "Failed: " + (e.message || e), false);
    try {
      await loadStudioLibrary({ resetVisible: true });
      setStudioGalleryTab("images");
      const newest = (studioState.imagePool || []).find((x) => (x.origin || "studio") === "studio");
      if (newest) {
        showStudioPreview({
          id: newest.id,
          kind: "image",
          title: newest.title,
          media_url: studioItemMediaUrl(newest),
        });
        setLiveStatus(
          status,
          `Request failed, but newest studio still is in the gallery (${newest.title || newest.id}).`,
          false
        );
      }
    } catch (_) {}
    alert("Image generation failed:\n\n" + (e.message || e));
  } finally {
    clearInterval(poll);
    setClientActivity(null);
    pollActivity();
    if (btn) btn.disabled = false;
  }
}

async function runStudioVideo() {
  const status = $("#studio-gen-status");
  const btn = $("#btn-studio-gen-video");
  const motion = ($("#studio-vid-prompt")?.value || "").trim();
  const duration = parseFloat($("#studio-vid-duration")?.value) || 5;
  const seed = parseInt($("#studio-vid-seed")?.value, 10);
  const quality = $("#studio-vid-quality")?.value || "draft";
  const sourceId = studioState.i2vSourceId || "";
  const videoPreset = $("#studio-vid-model")?.value || "";
  const audioFile = studioState.audioFile || $("#studio-vid-audio")?.files?.[0] || null;
  if (!studioState.uploadFile && !sourceId) {
    alert("Pick an image in the Images gallery tab, or upload a frame first.");
    return;
  }
  if (isLtxVideoPreset(videoPreset) && !audioFile) {
    alert("LTX lip-sync needs an audio file. Upload speech or music in the Video panel first.");
    return;
  }
  if (btn) btn.disabled = true;
  setClientActivity("Comfy: video", "comfy", motion.slice(0, 40) || "video");
  const studioLip =
    (isLtxVideoPreset(videoPreset) || (isMinimaxVideoPreset(videoPreset) && !!audioFile));
  setLiveStatus(
    status,
    studioLip
      ? `Preparing ${isLtxVideoPreset(videoPreset) ? "LTX" : "MiniMax"} lip-sync (${quality}, ~${duration}s)…`
      : `Preparing ${quality} video job…`,
    true
  );
  const poll = startActivityPoll(status);
  try {
    let res;
    if (studioState.uploadFile) {
      res = await api.studioGenerateVideoUpload(studioState.uploadFile, {
        animation_prompt: motion,
        duration_sec: duration,
        seed,
        quality,
        video_preset: videoPreset,
        audioFile,
      });
      studioState.uploadFile = null;
      if ($("#studio-vid-upload")) $("#studio-vid-upload").value = "";
      if ($("#studio-vid-upload-name")) $("#studio-vid-upload-name").textContent = "No upload selected";
      if (res.source_item_id) {
        studioState.i2vSourceId = res.source_item_id;
      }
      renderStudioI2vSource();
    } else {
      res = await api.studioGenerateVideo({
        source_item_id: sourceId,
        animation_prompt: motion,
        duration_sec: duration,
        seed,
        quality,
        video_preset: videoPreset,
        audioFile,
      });
    }
    setLiveStatus(status, "Video ready.", false);
    if (res.item) showStudioPreview(res.item);
    await loadStudioLibrary();
    setStudioGalleryTab("videos");
  } catch (e) {
    setLiveStatus(status, "Failed: " + (e.message || e), false);
    alert("Video generation failed:\n\n" + (e.message || e));
  } finally {
    clearInterval(poll);
    setClientActivity(null);
    pollActivity();
    if (btn) btn.disabled = false;
  }
}

async function main() {
  chatCtrl.wire();
  wire();
  wireOnboarding();
  await loadSystem();
  await loadProjects();
  await loadHomeMusicTracks();
  await loadHomeCharacters();
  try {
    state.localLoras = await api.loras();
  } catch (_) {}
  await maybeShowOnboarding();
}

function wireOnboarding() {
  $("#btn-onboard-skip")?.addEventListener("click", () => closeOnboarding(true));
  $("#btn-onboard-back")?.addEventListener("click", () => {
    if (onboard.step > 1) setOnboardStep(onboard.step - 1);
  });
  $("#btn-onboard-next")?.addEventListener("click", async () => {
    if (onboard.step < onboard.max) {
      setOnboardStep(onboard.step + 1);
      if (onboard.step === onboard.max) await refreshOnboardChecks();
      return;
    }
    await refreshOnboardChecks();
    await closeOnboarding(true);
  });
  $("#btn-onboard-recheck")?.addEventListener("click", () => refreshOnboardChecks());
  $("#btn-onboard-open-help")?.addEventListener("click", () => {
    window.open("/help.html", "_blank", "noopener");
  });
  // Re-open from settings if present
  $("#btn-rerun-onboarding")?.addEventListener("click", () => openOnboarding(true));
}

main();
