const BASE = "";

async function req(path, opts = {}) {
  const timeoutMs = opts.timeoutMs ?? 20000;
  const { timeoutMs: _t, ...fetchOpts } = opts;
  const ctrl = new AbortController();
  const timer = setTimeout(() => ctrl.abort(), timeoutMs);
  if (fetchOpts.signal) {
    fetchOpts.signal.addEventListener("abort", () => ctrl.abort());
  }
  try {
    const res = await fetch(BASE + path, { ...fetchOpts, signal: ctrl.signal });
    if (!res.ok) {
      let detail = res.statusText;
      try {
        const j = await res.json();
        detail = j.detail || JSON.stringify(j);
      } catch (_) {
        try {
          detail = await res.text();
        } catch (__) {}
      }
      throw new Error(detail || `HTTP ${res.status}`);
    }
    const ct = res.headers.get("content-type") || "";
    if (ct.includes("application/json")) return res.json();
    return res;
  } catch (e) {
    if (e?.name === "AbortError") {
      throw new Error(`Request timed out (${timeoutMs / 1000}s): ${path}`);
    }
    if (e instanceof TypeError) {
      throw new Error(
        `Backend unreachable at ${window.location.origin}. Start the studio (START.bat) and refresh.`
      );
    }
    throw e;
  } finally {
    clearTimeout(timer);
  }
}

export const api = {
  health: () => req("/api/health", { timeoutMs: 5000 }),
  system: () => req("/api/system", { timeoutMs: 25000 }),
  projects: () => req("/api/projects", { timeoutMs: 10000 }),
  createProject: (name, { kind = "music", notes = "" } = {}) =>
    req("/api/projects", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ name, kind, notes }),
    }),
  getProject: (id) => req(`/api/projects/${id}`),
  saveProject: (id, project) =>
    req(`/api/projects/${id}`, {
      method: "PUT",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(project),
    }),
  deleteProject: (id) => req(`/api/projects/${id}`, { method: "DELETE" }),
  cloneProject: (id, name) =>
    req(`/api/projects/${encodeURIComponent(id)}/clone`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(name ? { name } : {}),
      timeoutMs: 10 * 60 * 1000,
    }),
  fileUrl: (projectId, rel) =>
    rel ? `/api/projects/${projectId}/files/${rel.replace(/^\/+/, "")}` : null,

  /**
   * Upload project audio with optional progress (0–1).
   * Uses XHR so upload progress events work (fetch cannot).
   */
  uploadAudio: (projectId, file, { onProgress, timeoutMs = 15 * 60 * 1000 } = {}) => {
    const fd = new FormData();
    fd.append("file", file);
    return new Promise((resolve, reject) => {
      const xhr = new XMLHttpRequest();
      const url = `${BASE}/api/projects/${projectId}/audio`;
      let settled = false;
      const timer = setTimeout(() => {
        if (settled) return;
        settled = true;
        try {
          xhr.abort();
        } catch (_) {}
        reject(new Error(`Request timed out (${timeoutMs / 1000}s): ${url}`));
      }, timeoutMs);

      xhr.open("POST", url);
      xhr.responseType = "json";
      xhr.upload.onprogress = (ev) => {
        if (!onProgress) return;
        if (ev.lengthComputable && ev.total > 0) {
          onProgress(ev.loaded / ev.total, ev.loaded, ev.total);
        } else if (ev.loaded > 0) {
          onProgress(null, ev.loaded, null); // indeterminate size
        }
      };
      xhr.onload = () => {
        if (settled) return;
        settled = true;
        clearTimeout(timer);
        if (xhr.status >= 200 && xhr.status < 300) {
          resolve(xhr.response || {});
          return;
        }
        let detail = xhr.statusText || `HTTP ${xhr.status}`;
        try {
          const j = typeof xhr.response === "object" && xhr.response
            ? xhr.response
            : JSON.parse(xhr.responseText || "{}");
          detail = j.detail || JSON.stringify(j) || detail;
        } catch (_) {
          if (xhr.responseText) detail = xhr.responseText.slice(0, 300);
        }
        reject(new Error(typeof detail === "string" ? detail : JSON.stringify(detail)));
      };
      xhr.onerror = () => {
        if (settled) return;
        settled = true;
        clearTimeout(timer);
        reject(
          new Error(
            `Backend unreachable at ${window.location.origin}. Start the studio (START.bat) and refresh.`
          )
        );
      };
      xhr.onabort = () => {
        if (settled) return;
        settled = true;
        clearTimeout(timer);
        reject(new Error("Upload aborted"));
      };
      xhr.send(fd);
    });
  },
  analyzeAudio: (projectId) =>
    req(`/api/projects/${projectId}/audio/analyze`, {
      method: "POST",
      timeoutMs: 10 * 60 * 1000,
    }),
  amvPrepare: (projectId, body) =>
    req(`/api/projects/${projectId}/amv/prepare`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(body || {}),
      timeoutMs: 10 * 60 * 1000,
    }),
  autoSlots: (projectId, body) =>
    req(`/api/projects/${projectId}/timeline/auto-slots`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(body),
    }),
  uploadShotImage: async (projectId, shotId, file) => {
    const fd = new FormData();
    fd.append("file", file);
    return req(`/api/projects/${projectId}/shots/${shotId}/upload-image`, {
      method: "POST",
      body: fd,
      timeoutMs: 10 * 60 * 1000,
    });
  },
  uploadShotVideo: async (projectId, shotId, file) => {
    const fd = new FormData();
    fd.append("file", file);
    return req(`/api/projects/${projectId}/shots/${shotId}/upload-video`, {
      method: "POST",
      body: fd,
      timeoutMs: 15 * 60 * 1000,
    });
  },
  uploadShotMedia: async (projectId, shotId, file) => {
    const fd = new FormData();
    fd.append("file", file);
    return req(`/api/projects/${projectId}/shots/${shotId}/upload-media`, {
      method: "POST",
      body: fd,
      timeoutMs: 15 * 60 * 1000,
    });
  },
  genImage: (projectId, shotId, settings) =>
    req(`/api/projects/${projectId}/generate/image`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ shot_id: shotId, settings }),
      timeoutMs: 60000,
    }),
  genVideo: (projectId, shotId, settings) =>
    req(`/api/projects/${projectId}/generate/video`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ shot_id: shotId, settings }),
      timeoutMs: 60000,
    }),
  bulkImages: (projectId, body = { only_missing: true }) =>
    req(`/api/projects/${projectId}/generate/bulk-images`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(body),
      timeoutMs: 120000,
    }),
  bulkVideos: (projectId, body = { only_missing: true }) =>
    req(`/api/projects/${projectId}/generate/bulk-videos`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(body),
      timeoutMs: 120000,
    }),
  applyVideoQuality: (projectId, quality, shotIds = []) =>
    req(`/api/projects/${projectId}/apply-video-quality`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ quality, shot_ids: shotIds }),
    }),
  clipsZipUrl: (projectId) => `/api/projects/${projectId}/export/clips-zip`,
  hostStats: () => req("/api/system/host-stats", { timeoutMs: 5000 }),
  activity: () => req("/api/activity", { timeoutMs: 6000 }),
  musicDefaults: () => req("/api/music/defaults", { timeoutMs: 10000 }),
  musicStatus: () => req("/api/music/status", { timeoutMs: 15000 }),
  musicLoras: () => req("/api/music/loras", { timeoutMs: 20000 }),
  musicTracks: () => req("/api/music/tracks", { timeoutMs: 15000 }),
  musicTrackAudioUrl: (id) => `/api/music/tracks/${id}/audio`,
  musicDelete: (id) => req(`/api/music/tracks/${id}`, { method: "DELETE" }),
  musicRename: (id, title) =>
    req(`/api/music/tracks/${encodeURIComponent(id)}`, {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ title }),
      timeoutMs: 15000,
    }),
  musicGenerate: (body) =>
    req("/api/music/generate", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(body),
      timeoutMs: 45 * 60 * 1000,
    }),
  musicUploadReference: async (file) => {
    const fd = new FormData();
    fd.append("file", file);
    return req("/api/music/upload-reference", {
      method: "POST",
      body: fd,
      timeoutMs: 5 * 60 * 1000,
    });
  },
  musicTrainCapability: () => req("/api/music/train/capability", { timeoutMs: 60000 }),
  musicTrainJobs: () => req("/api/music/train/jobs", { timeoutMs: 15000 }),
  musicTrainGet: (jobId) =>
    req(`/api/music/train/jobs/${encodeURIComponent(jobId)}`, { timeoutMs: 15000 }),
  musicTrainCreate: (body) =>
    req("/api/music/train/jobs", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(body || {}),
    }),
  musicTrainAddClip: async (jobId, file) => {
    const fd = new FormData();
    fd.append("file", file);
    return req(`/api/music/train/jobs/${encodeURIComponent(jobId)}/clips`, {
      method: "POST",
      body: fd,
      timeoutMs: 120000,
    });
  },
  musicTrainClearClips: (jobId) =>
    req(`/api/music/train/jobs/${encodeURIComponent(jobId)}/clear-clips`, { method: "POST" }),
  musicTrainStart: (jobId, body) =>
    req(`/api/music/train/jobs/${encodeURIComponent(jobId)}/start`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(body || {}),
      timeoutMs: 120000,
    }),
  musicTrainDelete: (jobId) =>
    req(`/api/music/train/jobs/${encodeURIComponent(jobId)}`, { method: "DELETE" }),
  studioStatus: () => req("/api/studio/status", { timeoutMs: 15000 }),
  studioItems: (kind) =>
    req(kind ? `/api/studio/items?kind=${encodeURIComponent(kind)}` : "/api/studio/items", {
      timeoutMs: 15000,
    }),
  studioItemMediaUrl: (id) => `/api/studio/items/${id}/media`,
  studioDelete: (id) => req(`/api/studio/items/${id}`, { method: "DELETE" }),
  shotFromStudio: (projectId, shotId, itemId) =>
    req(
      `/api/projects/${encodeURIComponent(projectId)}/shots/${encodeURIComponent(shotId)}/from-studio/${encodeURIComponent(itemId)}`,
      { method: "POST", timeoutMs: 120000 }
    ),
  genActivity: () => req("/api/gen-activity", { timeoutMs: 5000 }),
  emergencyStop: (reason = "") =>
    req("/api/emergency-stop", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ reason: reason || "" }),
      timeoutMs: 60000,
    }),
  studioGalleryImages: () =>
    req("/api/studio/gallery-images", { timeoutMs: 30000 }),
  studioGenerateImage: async ({
    prompt = "",
    negative_prompt = "",
    width = 0,
    height = 0,
    seed = -1,
    steps = 0,
    model_id = "flux2-klein-4b",
    quality = "final",
    batch_count = 1,
    refFiles = [],
    refCharIds = [],
  } = {}) => {
    const fd = new FormData();
    const batch = Math.max(1, Math.min(100, parseInt(batch_count, 10) || 1));
    const q = (quality || "final").toLowerCase();
    const stepN =
      steps > 0 ? steps : q === "draft" ? 4 : 8; // Klein distilled: 4 draft / 8 final
    fd.append("prompt", prompt || "");
    fd.append("negative_prompt", negative_prompt || "");
    fd.append("width", String(width || 0));
    fd.append("height", String(height || 0));
    fd.append("seed", String(seed));
    fd.append("steps", String(stepN));
    fd.append("model_id", model_id || "flux2-klein-4b");
    fd.append("quality", quality || "final");
    fd.append("batch_count", String(batch));
    if (refCharIds?.length) fd.append("ref_char_ids", refCharIds.join(","));
    for (const f of refFiles || []) {
      if (f) fd.append("ref_files", f);
    }
    // Long queues: ~10 min/image budget, floor 30 min, cap 10 hours
    const timeoutMs = Math.min(
      10 * 60 * 60 * 1000,
      Math.max(30 * 60 * 1000, batch * 10 * 60 * 1000)
    );
    return req("/api/studio/generate/image", {
      method: "POST",
      body: fd,
      timeoutMs,
    });
  },
  studioGenerateVideo: async ({
    source_item_id = "",
    animation_prompt = "",
    duration_sec = 5,
    seed = -1,
    quality = "draft",
    video_preset = "",
    audioFile = null,
  } = {}) => {
    const fd = new FormData();
    fd.append("source_item_id", source_item_id || "");
    fd.append("animation_prompt", animation_prompt || "");
    fd.append("duration_sec", String(duration_sec));
    fd.append("seed", String(seed));
    fd.append("quality", quality || "draft");
    if (video_preset) fd.append("video_preset", video_preset);
    if (audioFile) fd.append("audio", audioFile);
    return req("/api/studio/generate/video", {
      method: "POST",
      body: fd,
      timeoutMs: 45 * 60 * 1000,
    });
  },
  studioGenerateVideoUpload: async (
    file,
    {
      animation_prompt = "",
      duration_sec = 5,
      seed = -1,
      quality = "draft",
      video_preset = "",
      audioFile = null,
    } = {}
  ) => {
    const fd = new FormData();
    fd.append("file", file);
    fd.append("animation_prompt", animation_prompt);
    fd.append("duration_sec", String(duration_sec));
    fd.append("seed", String(seed));
    fd.append("quality", quality || "draft");
    if (video_preset) fd.append("video_preset", video_preset);
    if (audioFile) fd.append("audio", audioFile);
    return req("/api/studio/generate/video-upload", {
      method: "POST",
      body: fd,
      timeoutMs: 45 * 60 * 1000,
    });
  },
  getSettings: () => req("/api/settings"),
  saveSettings: (body) =>
    req("/api/settings", {
      method: "PUT",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(body),
    }),
  characters: () => req("/api/characters"),
  addCharacter: async (file, name, category, description) => {
    const fd = new FormData();
    if (file) fd.append("file", file);
    fd.append("name", name || "Character");
    fd.append("category", category || "character");
    fd.append("description", description || "");
    return req("/api/characters", {
      method: "POST",
      body: fd,
      timeoutMs: 5 * 60 * 1000,
    });
  },
  updateCharacter: async (id, { name, category, description, file } = {}) => {
    const fd = new FormData();
    if (name != null) fd.append("name", name);
    if (category != null) fd.append("category", category);
    if (description != null) fd.append("description", description);
    if (file) fd.append("file", file);
    return req(`/api/characters/${id}`, { method: "PUT", body: fd });
  },
  deleteCharacter: (id) => req(`/api/characters/${id}`, { method: "DELETE" }),
  characterImageUrl: (id) => `/api/characters/${id}/image`,
  importCharacterToProject: (projectId, charId) =>
    req(`/api/projects/${projectId}/references/from-library/${charId}`, { method: "POST" }),
  llmModels: () => req("/api/llm/models", { timeoutMs: 15000 }),
  chat: (body) =>
    req("/api/chat", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(body),
      timeoutMs: 10 * 60 * 1000,
    }),
  chatMedia: (body) =>
    req("/api/chat/media", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(body),
      timeoutMs: 60000,
    }),
  chatContinueVideo: (projectId, shotId) =>
    req(`/api/chat/media/${projectId}/shots/${shotId}/continue-video`, {
      method: "POST",
      timeoutMs: 60000,
    }),
  chatUpload: async (file) => {
    const fd = new FormData();
    fd.append("file", file);
    return req("/api/chat/upload", {
      method: "POST",
      body: fd,
      timeoutMs: 120000,
    });
  },
  coderProjects: () => req("/api/coder/projects"),
  coderCreateProject: (name, switchTo = true) =>
    req("/api/coder/projects", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ name: name || "", switch: !!switchTo }),
    }),
  coderActivateProject: (id) =>
    req(`/api/coder/projects/${encodeURIComponent(id)}/activate`, { method: "POST" }),
  coderRenameProject: (id, name) =>
    req(`/api/coder/projects/${encodeURIComponent(id)}/rename`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ name }),
    }),
  coderDeleteProject: (id) =>
    req(`/api/coder/projects/${encodeURIComponent(id)}`, { method: "DELETE" }),
  coderProject: (projectId) =>
    req(projectId ? `/api/coder/project?project_id=${encodeURIComponent(projectId)}` : "/api/coder/project"),
  coderSaveProject: (body) =>
    req("/api/coder/project", {
      method: "PUT",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(body),
    }),
  coderAddVersion: (body) =>
    req("/api/coder/versions", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(body),
      timeoutMs: 30_000,
    }),
  coderVersion: (id, projectId) =>
    req(
      projectId
        ? `/api/coder/versions/${encodeURIComponent(id)}?project_id=${encodeURIComponent(projectId)}`
        : `/api/coder/versions/${encodeURIComponent(id)}`
    ),
  coderVersionHtmlUrl: (id, projectId, { cacheBust = false } = {}) => {
    let url = projectId
      ? `/api/coder/versions/${encodeURIComponent(id)}/html?project_id=${encodeURIComponent(projectId)}`
      : `/api/coder/versions/${encodeURIComponent(id)}/html`;
    if (cacheBust) url += `${url.includes("?") ? "&" : "?"}t=${Date.now()}`;
    return url;
  },
  coderAcceptVersion: (id, projectId) =>
    req(
      projectId
        ? `/api/coder/versions/${encodeURIComponent(id)}/accept?project_id=${encodeURIComponent(projectId)}`
        : `/api/coder/versions/${encodeURIComponent(id)}/accept`,
      { method: "POST" }
    ),
  coderDeleteVersion: (id, projectId) =>
    req(
      projectId
        ? `/api/coder/versions/${encodeURIComponent(id)}?project_id=${encodeURIComponent(projectId)}`
        : `/api/coder/versions/${encodeURIComponent(id)}`,
      { method: "DELETE" }
    ),
  coderBaseline: (projectId) =>
    req(projectId ? `/api/coder/baseline?project_id=${encodeURIComponent(projectId)}` : "/api/coder/baseline"),

  chatSearch: (query, limit = 5) =>
    req("/api/chat/search", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ query, limit }),
      timeoutMs: 30000,
    }),
  /**
   * Stream story generation as NDJSON events.
   * onEvent({type, message, progress, detail, ...}) — type status|done|error
   */
  storyGenerate: async (projectId, body, { onEvent, timeoutMs = 45 * 60 * 1000 } = {}) => {
    const ctrl = new AbortController();
    const timer = setTimeout(() => ctrl.abort(), timeoutMs);
    try {
      const res = await fetch(`${BASE}/api/projects/${projectId}/story/generate`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(body),
        signal: ctrl.signal,
      });
      if (!res.ok) {
        let detail = res.statusText;
        try {
          const j = await res.json();
          detail = j.detail || JSON.stringify(j);
        } catch (_) {
          try {
            detail = await res.text();
          } catch (__) {}
        }
        throw new Error(detail || `HTTP ${res.status}`);
      }
      // Non-stream fallback (old servers)
      const ct = res.headers.get("content-type") || "";
      if (ct.includes("application/json") && !ct.includes("ndjson")) {
        const data = await res.json();
        onEvent?.({ type: "done", ...data, progress: 1, message: "Complete" });
        return data;
      }
      const reader = res.body.getReader();
      const dec = new TextDecoder();
      let buf = "";
      let final = null;
      while (true) {
        const { value, done } = await reader.read();
        if (done) break;
        buf += dec.decode(value, { stream: true });
        const lines = buf.split("\n");
        buf = lines.pop() || "";
        for (const line of lines) {
          if (!line.trim()) continue;
          let ev;
          try {
            ev = JSON.parse(line);
          } catch {
            continue;
          }
          onEvent?.(ev);
          if (ev.type === "done") final = ev;
          if (ev.type === "error") throw new Error(ev.error || ev.message || "Story generation failed");
        }
      }
      if (buf.trim()) {
        try {
          const ev = JSON.parse(buf);
          onEvent?.(ev);
          if (ev.type === "done") final = ev;
          if (ev.type === "error") throw new Error(ev.error || ev.message || "Story generation failed");
        } catch (e) {
          if (e.message && !e.message.includes("JSON")) throw e;
        }
      }
      if (!final) throw new Error("Story generation ended without a result");
      return final;
    } catch (e) {
      if (e?.name === "AbortError") {
        throw new Error(`Request timed out (${timeoutMs / 1000}s): story generate`);
      }
      throw e;
    } finally {
      clearTimeout(timer);
    }
  },
  clearShotVideo: (projectId, shotId) =>
    req(`/api/projects/${projectId}/shots/${shotId}/video`, { method: "DELETE" }),
  clearShotImage: (projectId, shotId) =>
    req(`/api/projects/${projectId}/shots/${shotId}/image`, { method: "DELETE" }),
  jobs: (projectId) =>
    req(projectId ? `/api/jobs?project_id=${projectId}` : "/api/jobs"),
  job: (id) => req(`/api/jobs/${id}`),
  cancelJob: (id) => req(`/api/jobs/${id}/cancel`, { method: "POST" }),
  /** Export can take several minutes for long songs — do not use default 20s. */
  exportProject: (projectId) =>
    req(`/api/projects/${projectId}/export`, {
      method: "POST",
      timeoutMs: 15 * 60 * 1000,
    }),

  loras: () => req("/api/loras"),
  searchLoras: (query, base_model, limit = 20) =>
    req("/api/loras/search", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ query, base_model, limit }),
    }),
  downloadLora: async (repoId) => {
    const fd = new FormData();
    fd.append("repo_id", repoId);
    return req("/api/loras/download", { method: "POST", body: fd });
  },
  importLoraPath: (source_path, name) =>
    req("/api/loras/import", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ source_path, name }),
    }),
  uploadLora: async (file) => {
    const fd = new FormData();
    fd.append("file", file);
    return req("/api/loras/upload", { method: "POST", body: fd });
  },
  refreshLoras: () => req("/api/loras/refresh", { method: "POST" }),

  addReference: async (projectId, file, name, category, description = "", saveToLibrary = true) => {
    const fd = new FormData();
    fd.append("file", file);
    fd.append("name", name || file.name);
    fd.append("category", category || "other");
    fd.append("description", description || "");
    fd.append("save_to_library", saveToLibrary ? "1" : "0");
    return req(`/api/projects/${projectId}/references`, {
      method: "POST",
      body: fd,
      timeoutMs: 5 * 60 * 1000,
    });
  },
  deleteReference: (projectId, refId) =>
    req(`/api/projects/${projectId}/references/${refId}`, { method: "DELETE" }),
  patchReference: async (projectId, refId, fields = {}) => {
    const fd = new FormData();
    for (const [k, v] of Object.entries(fields)) {
      if (v != null) fd.append(k, v);
    }
    return req(`/api/projects/${projectId}/references/${refId}`, { method: "PATCH", body: fd });
  },
  uploadSrt: async (projectId, file) => {
    const fd = new FormData();
    fd.append("file", file);
    return req(`/api/projects/${projectId}/subtitles`, { method: "POST", body: fd });
  },
};
