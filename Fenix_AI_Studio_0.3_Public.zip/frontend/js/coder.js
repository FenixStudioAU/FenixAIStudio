/** Code Companion–style workspace for Studio Coder mode. */
import { api } from "./api.js";

const $ = (s, r = document) => r.querySelector(s);
const $$ = (s, r = document) => [...r.querySelectorAll(s)];

const MODEL_SELECT_IDS = [
  "coder-designer-model",
  "coder-build-model",
  "coder-repair-model",
  "coder-inspector-model",
];

function escapeHtml(s) {
  return String(s ?? "")
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;");
}

function extractImplPrompt(text) {
  const t = String(text || "");
  const m = t.match(/IMPLEMENTATION PROMPT\s*[:\-]?\s*([\s\S]+)/i);
  if (m) return m[1].trim();
  return t.trim();
}

export function createCoderController({ getSettings }) {
  let project = null;
  let projectList = [];
  let settingsCache = {};
  /** User picks on Coder dropdowns — Settings are only defaults, never override these. */
  let localModelPicks = {};
  let modelsLoaded = false;
  let modelChangeWired = false;
  let busy = false;
  let lastAssistantText = "";
  let lastInspectorReport = "";
  let runtimeLines = [];

  function currentProjectId() {
    return project?.id || "";
  }

  function setStatus(show, text, loading = false) {
    const bar = $("#coder-status");
    const t = $("#coder-status-text");
    if (!bar || !t) return;
    bar.classList.toggle("hidden", !show);
    bar.classList.toggle("loading", !!loading);
    t.textContent = text || "";
  }

  /** Disable send / build / repair while an LLM call is in flight (no flood). */
  function setBusyUi(on, label = "") {
    busy = !!on;
    const ids = [
      "btn-coder-designer-send",
      "btn-coder-build",
      "btn-coder-inspect",
      "btn-coder-repair",
      "btn-coder-to-build",
      "btn-coder-to-repair",
      "btn-coder-project-new",
      "btn-coder-project-save",
      "btn-coder-project-delete",
      "coder-project-select",
      "coder-designer-input",
    ];
    for (const id of ids) {
      const el = $(`#${id}`);
      if (!el) continue;
      el.disabled = !!on;
    }
    // Re-enable to-build/to-repair only when not busy and log has assistant
    if (!on) {
      const hasAsst = (project?.designer_messages || []).some((m) => m.role === "assistant");
      $("#btn-coder-to-build") && ($("#btn-coder-to-build").disabled = !hasAsst);
      $("#btn-coder-to-repair") && ($("#btn-coder-to-repair").disabled = !hasAsst);
      const del = $("#btn-coder-project-delete");
      if (del) del.disabled = !project?.id || project.id === "default";
    }
    const send = $("#btn-coder-designer-send");
    if (send) {
      send.textContent = on ? "Working…" : "Send";
      send.classList.toggle("is-busy", !!on);
    }
    const hint = $("#coder-designer-hint");
    if (hint) {
      hint.textContent = on
        ? label || "Model is answering — wait for it to finish…"
        : "Models also live in Settings";
      hint.classList.toggle("coder-busy-hint", !!on);
    }
    const panel = $("#coder-mode-panel");
    if (panel) panel.classList.toggle("coder-is-busy", !!on);
  }

  function showTypingInLog(show) {
    const box = $("#coder-designer-log");
    if (!box) return;
    let el = box.querySelector(".coder-typing");
    if (!show) {
      el?.remove();
      return;
    }
    if (!el) {
      el = document.createElement("div");
      el.className = "chat-message assistant coder-typing";
      el.innerHTML =
        '<div class="chat-bubble coder-typing-bubble"><span class="coder-typing-dots" aria-hidden="true"></span> Thinking…</div>';
      box.appendChild(el);
    }
    box.scrollTop = box.scrollHeight;
  }

  function logEvent(line) {
    const el = $("#coder-event-stream");
    const stamp = new Date().toLocaleTimeString();
    const prev = el?.textContent || "";
    if (el) {
      el.textContent = `${prev}${prev ? "\n" : ""}[${stamp}] ${line}`;
      el.scrollTop = el.scrollHeight;
    }
  }

  function setStreamContent(text) {
    const el = $("#coder-content-stream");
    if (el) {
      el.textContent = text || "";
      el.scrollTop = el.scrollHeight;
    }
    const chars = $("#coder-stream-chars");
    if (chars) chars.textContent = `${(text || "").length.toLocaleString()} chars`;
  }

  function setStage(label) {
    const el = $("#coder-stream-stage");
    if (el) el.textContent = label;
  }

  function updatePromptChars() {
    const ta = $("#coder-build-prompt");
    const n = (ta?.value || "").length;
    const el = $("#coder-prompt-chars");
    if (el) el.textContent = `${n.toLocaleString()} characters`;
  }

  function renderDesignerLog() {
    const box = $("#coder-designer-log");
    if (!box) return;
    const msgs = project?.designer_messages || [];
    if (!msgs.length) {
      box.innerHTML = `<div class="chat-empty muted">Discuss what you want to build. Then use “Use as build prompt”.</div>`;
      return;
    }
    box.innerHTML = msgs
      .map((m) => {
        const role = m.role === "user" ? "user" : "assistant";
        return `<div class="chat-message ${role}"><div class="chat-bubble">${escapeHtml(m.content)}</div></div>`;
      })
      .join("");
    box.scrollTop = box.scrollHeight;
    const hasAsst = msgs.some((m) => m.role === "assistant");
    $("#btn-coder-to-build") && ($("#btn-coder-to-build").disabled = !hasAsst);
    $("#btn-coder-to-repair") && ($("#btn-coder-to-repair").disabled = !hasAsst);
  }

  function renderVersionList() {
    const list = $("#coder-version-list");
    const sel = $("#coder-preview-version");
    if (!list || !sel) return;
    const versions = project?.versions || [];
    const active = project?.active_version_id;
    const accepted = project?.accepted_version_id;

    if (!versions.length) {
      list.innerHTML = `<p class="muted small">No versions yet.</p>`;
      sel.innerHTML = `<option value="">No versions</option>`;
      $("#coder-version-badge") && ($("#coder-version-badge").textContent = "No version");
      $("#btn-coder-accept") && ($("#btn-coder-accept").disabled = true);
      $("#btn-coder-delete-version") && ($("#btn-coder-delete-version").disabled = true);
      return;
    }

    list.innerHTML = versions
      .map((v) => {
        const tags = [];
        if (v.id === accepted) tags.push("accepted");
        if (v.id === active) tags.push("active");
        if (v.valid === false) tags.push("invalid");
        return `<button type="button" class="coder-version-item ${v.id === active ? "active" : ""}" data-vid="${escapeHtml(v.id)}">
          <strong>${escapeHtml(v.id)}</strong>
          <span class="muted small">${escapeHtml(v.kind || "build")} · ${(v.char_count || 0).toLocaleString()} chars ${tags.length ? "· " + tags.join(", ") : ""}</span>
        </button>`;
      })
      .join("");

    list.querySelectorAll("[data-vid]").forEach((btn) => {
      btn.addEventListener("click", () => selectVersion(btn.dataset.vid));
    });

    sel.innerHTML = versions
      .map(
        (v) =>
          `<option value="${escapeHtml(v.id)}" ${v.id === active ? "selected" : ""}>${escapeHtml(v.id)} (${escapeHtml(v.kind || "build")})</option>`
      )
      .join("");

    const cur = versions.find((v) => v.id === active) || versions[0];
    $("#coder-version-badge") && ($("#coder-version-badge").textContent = cur?.id || "No version");
    const st = $("#coder-version-status");
    if (st && cur) {
      st.textContent = [
        cur.complete === false ? "incomplete" : "complete",
        cur.valid === false ? "validation failed" : "validation ok",
        cur.id === accepted ? "ACCEPTED" : "",
      ]
        .filter(Boolean)
        .join(" · ");
    }
    $("#btn-coder-accept") && ($("#btn-coder-accept").disabled = !cur);
    $("#btn-coder-delete-version") && ($("#btn-coder-delete-version").disabled = !cur);
  }

  function renderProjectBar() {
    const sel = $("#coder-project-select");
    const nameIn = $("#coder-project-name");
    if (sel) {
      const active = project?.id || "";
      sel.innerHTML = (projectList || [])
        .map(
          (p) =>
            `<option value="${escapeHtml(p.id)}" ${p.id === active ? "selected" : ""}>${escapeHtml(p.name || p.id)}</option>`
        )
        .join("") || `<option value="">No projects</option>`;
      if (active) sel.value = active;
    }
    if (nameIn && project) {
      nameIn.value = project.name || "";
    }
    const del = $("#btn-coder-project-delete");
    if (del) del.disabled = !project?.id || project.id === "default";
  }

  function clearRuntime() {
    runtimeLines = [];
    const el = $("#coder-runtime-log");
    if (el) el.textContent = "Preview messages and browser errors will appear here.";
  }

  function pushRuntime(line) {
    runtimeLines.push(line);
    if (runtimeLines.length > 200) runtimeLines.shift();
    const el = $("#coder-runtime-log");
    if (el) {
      el.textContent = runtimeLines.join("\n");
      el.scrollTop = el.scrollHeight;
    }
  }

  function loadPreview(versionId) {
    const frame = $("#coder-preview-frame");
    const ph = $("#coder-preview-placeholder");
    if (!versionId) {
      if (frame) frame.removeAttribute("src");
      if (ph) ph.classList.remove("hidden");
      return;
    }
    if (ph) ph.classList.add("hidden");
    if (frame) {
      frame.src = api.coderVersionHtmlUrl(versionId, currentProjectId(), { cacheBust: true });
    }
    clearRuntime();
    pushRuntime(`Loaded version ${versionId}`);
  }

  async function selectVersion(versionId) {
    if (!versionId || !project) return;
    project.active_version_id = versionId;
    try {
      await api.coderSaveProject({
        active_version_id: versionId,
        project_id: currentProjectId(),
      });
    } catch (_) {}
    renderVersionList();
    loadPreview(versionId);
  }

  /**
   * Populate model <select>s. Settings values are defaults only.
   * Never overwrite a value the user already chose in Coder.
   */
  async function fillModels({ forceRefreshList = false } = {}) {
    try {
      settingsCache = (await getSettings()) || {};
    } catch {
      settingsCache = {};
    }
    let models = [];
    try {
      const o = await api.llmModels();
      models = (o.models || o || [])
        .map((m) => (typeof m === "string" ? m : m.id || m.name || m.model))
        .filter(Boolean);
    } catch (_) {
      models = [];
    }

    const defaults = {
      "coder-designer-model": settingsCache.coder_designer_model || settingsCache.chat_model || "",
      "coder-build-model": settingsCache.coder_model || settingsCache.chat_model || "",
      "coder-repair-model": settingsCache.coder_repair_model || settingsCache.coder_model || "",
      "coder-inspector-model":
        settingsCache.coder_repair_model || settingsCache.chat_model || settingsCache.coder_model || "",
    };

    for (const id of MODEL_SELECT_IDS) {
      const sel = $(`#${id}`);
      if (!sel) continue;

      // Capture what the user currently has selected (before we rebuild options)
      const live = (sel.value || "").trim();
      if (live) localModelPicks[id] = live;

      const opts = models.length
        ? models.map((m) => `<option value="${escapeHtml(m)}">${escapeHtml(m)}</option>`).join("")
        : `<option value="">(no models — start Ollama)</option>`;
      sel.innerHTML = opts;

      // Priority: session pick > live DOM > Settings default > first model
      const preferred =
        localModelPicks[id] ||
        live ||
        defaults[id] ||
        "";
      if (preferred && models.includes(preferred)) {
        sel.value = preferred;
        localModelPicks[id] = preferred;
      } else if (models[0]) {
        sel.value = models[0];
        // Only seed local pick if we never chose one (first open)
        if (!localModelPicks[id]) localModelPicks[id] = models[0];
        else if (!models.includes(localModelPicks[id])) localModelPicks[id] = models[0];
      }
    }

    if (!modelChangeWired) {
      modelChangeWired = true;
      for (const id of MODEL_SELECT_IDS) {
        $(`#${id}`)?.addEventListener("change", (e) => {
          const v = e.target?.value || "";
          localModelPicks[id] = v;
          logEvent(`Model pick · ${id.replace("coder-", "").replace(/-/g, " ")} → ${v || "(none)"}`);
        });
      }
    }
    modelsLoaded = true;
  }

  /** Read the dropdown as-is — never re-fill from Settings first. */
  function readModel(selectId, fallbackKeys = []) {
    const live = ($(`#${selectId}`)?.value || "").trim();
    if (live) {
      localModelPicks[selectId] = live;
      return live;
    }
    if (localModelPicks[selectId]) return localModelPicks[selectId];
    for (const k of fallbackKeys) {
      const v = (settingsCache[k] || "").trim();
      if (v) return v;
    }
    return "";
  }

  async function refreshProjectList() {
    try {
      const res = await api.coderProjects();
      projectList = res.projects || [];
    } catch (e) {
      console.warn("coder projects list failed", e);
      projectList = project ? [{ id: project.id, name: project.name, active: true }] : [];
    }
    renderProjectBar();
  }

  async function refresh() {
    project = await api.coderProject();
    if ($("#coder-build-prompt") && project.build_prompt != null) {
      $("#coder-build-prompt").value = project.build_prompt || "";
    }
    if ($("#coder-repair-prompt") && project.repair_prompt != null) {
      $("#coder-repair-prompt").value = project.repair_prompt || "";
    }
    updatePromptChars();
    renderDesignerLog();
    renderVersionList();
    await refreshProjectList();
    if (project.active_version_id) loadPreview(project.active_version_id);
    else loadPreview(null);
  }

  async function persistSoft() {
    if (!project) return;
    try {
      const name = ($("#coder-project-name")?.value || "").trim();
      project = await api.coderSaveProject({
        project_id: currentProjectId(),
        name: name || project.name || undefined,
        designer_messages: project.designer_messages || [],
        build_prompt: $("#coder-build-prompt")?.value || "",
        repair_prompt: $("#coder-repair-prompt")?.value || "",
        active_version_id: project.active_version_id,
        accepted_version_id: project.accepted_version_id,
      });
      await refreshProjectList();
    } catch (e) {
      console.warn("coder save failed", e);
    }
  }

  async function switchProject(projectId) {
    if (!projectId || projectId === currentProjectId()) return;
    if (busy) {
      alert("Wait for the current coder run to finish before switching projects.");
      renderProjectBar();
      return;
    }
    await persistSoft();
    try {
      const res = await api.coderActivateProject(projectId);
      project = res.project || (await api.coderProject(projectId));
      lastInspectorReport = "";
      const reportEl = $("#coder-inspector-report");
      if (reportEl) reportEl.textContent = "No inspection has been run for this version.";
      $("#btn-coder-use-report") && ($("#btn-coder-use-report").disabled = true);
      if ($("#coder-build-prompt")) $("#coder-build-prompt").value = project.build_prompt || "";
      if ($("#coder-repair-prompt")) $("#coder-repair-prompt").value = project.repair_prompt || "";
      updatePromptChars();
      renderDesignerLog();
      renderVersionList();
      await refreshProjectList();
      if (project.active_version_id) loadPreview(project.active_version_id);
      else loadPreview(null);
      logEvent(`Switched to project “${project.name || project.id}”`);
    } catch (e) {
      alert(`Could not switch project: ${e.message}`);
      await refreshProjectList();
    }
  }

  async function newProject() {
    if (busy) {
      alert("Wait for the current run to finish.");
      return;
    }
    const name = window.prompt("Name for the new coder project:", `Project ${new Date().toLocaleDateString()}`);
    if (name === null) return;
    await persistSoft();
    try {
      const res = await api.coderCreateProject((name || "").trim(), true);
      project = res.project || (await api.coderProject());
      lastInspectorReport = "";
      const reportEl = $("#coder-inspector-report");
      if (reportEl) reportEl.textContent = "No inspection has been run for this version.";
      $("#btn-coder-use-report") && ($("#btn-coder-use-report").disabled = true);
      if ($("#coder-build-prompt")) $("#coder-build-prompt").value = "";
      if ($("#coder-repair-prompt")) $("#coder-repair-prompt").value = "";
      setStreamContent("");
      updatePromptChars();
      renderDesignerLog();
      renderVersionList();
      await refreshProjectList();
      loadPreview(null);
      logEvent(`Created project “${project.name || project.id}”`);
    } catch (e) {
      alert(`New project failed: ${e.message}`);
    }
  }

  async function saveProjectNamed() {
    if (!project) return;
    const name = ($("#coder-project-name")?.value || "").trim();
    if (!name) {
      alert("Enter a project name.");
      return;
    }
    try {
      project = await api.coderSaveProject({
        project_id: currentProjectId(),
        name,
        designer_messages: project.designer_messages || [],
        build_prompt: $("#coder-build-prompt")?.value || "",
        repair_prompt: $("#coder-repair-prompt")?.value || "",
        active_version_id: project.active_version_id,
        accepted_version_id: project.accepted_version_id,
      });
      await refreshProjectList();
      logEvent(`Saved project as “${project.name}”`);
      setStatus(true, `Saved “${project.name}”`, false);
      setTimeout(() => setStatus(false, ""), 1500);
    } catch (e) {
      alert(`Save failed: ${e.message}`);
    }
  }

  async function deleteCurrentProject() {
    if (!project || project.id === "default") {
      alert("The default project cannot be deleted. Create a new one and switch away first.");
      return;
    }
    if (!confirm(`Delete coder project “${project.name || project.id}”? Versions will be removed.`)) return;
    try {
      await api.coderDeleteProject(project.id);
      project = await api.coderProject();
      await refresh();
      logEvent("Project deleted — switched to active project");
    } catch (e) {
      alert(`Delete failed: ${e.message}`);
    }
  }

  async function designerSend() {
    if (busy) return;
    const input = $("#coder-designer-input");
    const text = (input?.value || "").trim();
    if (!text) return;
    if (!modelsLoaded) await fillModels();
    const model = readModel("coder-designer-model", ["coder_designer_model", "chat_model"]);
    project.designer_messages = project.designer_messages || [];
    project.designer_messages.push({ role: "user", content: text, at: Date.now() });
    if (input) input.value = "";
    renderDesignerLog();

    setBusyUi(true, model ? `Designer answering (${model})…` : "Designer answering…");
    setStatus(true, model ? `Designer · waiting on ${model}…` : "Designer · waiting on model…", true);
    setStage("Designer running");
    showTypingInLog(true);
    logEvent(`Designer send → ${model || "auto"}`);
    try {
      const history = project.designer_messages.map((m) => ({ role: m.role, content: m.content }));
      const res = await api.chat({
        mode: "coder",
        stage: "designer",
        model: model || null,
        messages: history,
        num_predict: 4096,
      });
      const content = res.content || "";
      lastAssistantText = content;
      project.designer_messages.push({ role: "assistant", content, at: Date.now() });
      await persistSoft();
      showTypingInLog(false);
      renderDesignerLog();
      setStreamContent(content);
      logEvent("Designer reply received");
      setStatus(false, "");
      setStage("Idle");
    } catch (e) {
      showTypingInLog(false);
      setStatus(true, `Designer error: ${e.message}`, false);
      setStage("Error");
      logEvent(`Designer error: ${e.message}`);
      alert(`Designer failed: ${e.message}`);
    } finally {
      setBusyUi(false);
    }
  }

  function useAsBuildPrompt() {
    const msgs = project?.designer_messages || [];
    const last = [...msgs].reverse().find((m) => m.role === "assistant");
    if (!last) return;
    const prompt = extractImplPrompt(last.content);
    const ta = $("#coder-build-prompt");
    if (ta) ta.value = prompt;
    updatePromptChars();
    persistSoft();
    logEvent("Copied designer reply → build prompt");
  }

  function useAsRepairPrompt() {
    const msgs = project?.designer_messages || [];
    const last = [...msgs].reverse().find((m) => m.role === "assistant");
    if (!last) return;
    const ta = $("#coder-repair-prompt");
    if (ta) ta.value = extractImplPrompt(last.content);
    persistSoft();
    logEvent("Copied designer reply → repair prompt");
  }

  async function runBuild() {
    if (busy) return;
    const prompt = ($("#coder-build-prompt")?.value || "").trim();
    if (!prompt) {
      alert("Write or paste an implementation prompt first.");
      return;
    }
    if (!modelsLoaded) await fillModels();
    const model = readModel("coder-build-model", ["coder_model", "chat_model"]);
    setBusyUi(true, model ? `Building with ${model}…` : "Building…");
    setStatus(true, model ? `Coder · generating with ${model}…` : "Coder · generating…", true);
    setStage("Building complete file");
    setStreamContent("");
    logEvent(`Build start → ${model || "auto"}`);
    try {
      const res = await api.chat({
        mode: "coder",
        stage: "coder",
        model: model || null,
        messages: [{ role: "user", content: prompt }],
        num_predict: 12288,
      });
      const raw = res.content || "";
      setStreamContent(raw);
      logEvent(`Build response ${raw.length} chars — saving version…`);
      const saved = await api.coderAddVersion({
        prompt,
        raw_response: raw,
        kind: "build",
        model: res.model || model || "",
        project_id: currentProjectId(),
      });
      project = saved.project || (await api.coderProject());
      renderVersionList();
      if (saved.version?.id) loadPreview(saved.version.id);
      const val = saved.validation;
      if (val) {
        logEvent(
          `Validation: ${val.valid ? "OK" : "FAILED"} — ${(val.results || [])
            .map((r) => (r.ok ? "✓" : "✗") + " " + r.message)
            .join("; ")}`
        );
      }
      setStatus(false, "");
      setStage(val?.valid ? "Build complete" : "Build complete (validation issues)");
    } catch (e) {
      setStatus(true, `Build error: ${e.message}`, false);
      setStage("Error");
      logEvent(`Build error: ${e.message}`);
      alert(`Build failed: ${e.message}`);
    } finally {
      setBusyUi(false);
      await persistSoft();
    }
  }

  async function runInspect() {
    if (busy) return;
    const vid = project?.active_version_id || project?.accepted_version_id;
    if (!vid) {
      alert("Generate a version first.");
      return;
    }
    const fault = ($("#coder-repair-prompt")?.value || "").trim() || "Review the code for bugs.";
    if (!modelsLoaded) await fillModels();
    const model = readModel("coder-inspector-model", [
      "coder_repair_model",
      "chat_model",
      "coder_model",
    ]);
    setBusyUi(true, model ? `Inspecting with ${model}…` : "Inspecting…");
    setStatus(true, model ? `Inspector · waiting on ${model}…` : "Inspector · waiting…", true);
    setStage("Inspecting");
    logEvent(`Inspect ${vid} → ${model || "auto"}`);
    try {
      const detail = await api.coderVersion(vid, currentProjectId());
      const html = detail.html || "";
      const runtime = runtimeLines.slice(-40).join("\n");
      const userMsg = [
        "CURRENT HTML FILE:",
        html.slice(0, 120000),
        "",
        "USER FAULT DESCRIPTION:",
        fault,
        "",
        "RUNTIME CONSOLE (if any):",
        runtime || "(none)",
      ].join("\n");
      const res = await api.chat({
        mode: "coder",
        stage: "inspect",
        model: model || null,
        messages: [{ role: "user", content: userMsg }],
        num_predict: 4096,
      });
      lastInspectorReport = res.content || "";
      const reportEl = $("#coder-inspector-report");
      if (reportEl) reportEl.textContent = lastInspectorReport;
      $("#btn-coder-use-report") && ($("#btn-coder-use-report").disabled = !lastInspectorReport);
      setStreamContent(lastInspectorReport);
      logEvent("Inspector report ready");
      setStatus(false, "");
      setStage("Inspect done");
      return lastInspectorReport;
    } catch (e) {
      setStatus(true, `Inspect error: ${e.message}`, false);
      setStage("Error");
      logEvent(`Inspect error: ${e.message}`);
      alert(`Inspect failed: ${e.message}`);
      return "";
    } finally {
      setBusyUi(false);
    }
  }

  async function runRepair() {
    if (busy) return;
    let fault = ($("#coder-repair-prompt")?.value || "").trim();
    if (!fault) {
      alert("Describe the fault to repair.");
      return;
    }
    const auto = !!$("#coder-auto-inspect")?.checked;
    if (auto && !lastInspectorReport) {
      const rep = await runInspect();
      if (!rep) return;
    }

    const vid = project?.accepted_version_id || project?.active_version_id;
    if (!vid) {
      alert("No baseline version to repair.");
      return;
    }
    if (!modelsLoaded) await fillModels();
    const model = readModel("coder-repair-model", ["coder_repair_model", "coder_model"]);
    setBusyUi(true, model ? `Repairing with ${model}…` : "Repairing…");
    setStatus(true, model ? `Repair · generating with ${model}…` : "Repair · generating…", true);
    setStage("Repairing full file");
    setStreamContent("");
    logEvent(`Repair from ${vid} → ${model || "auto"}`);
    try {
      const detail = await api.coderVersion(vid, currentProjectId());
      const html = detail.html || "";
      const promptParts = [
        "You must return a COMPLETE updated HTML document (no markdown fences).",
        "",
        "ORIGINAL / CURRENT FILE:",
        html.slice(0, 120000),
        "",
        "REPAIR REQUEST:",
        fault,
      ];
      if (lastInspectorReport) {
        promptParts.push("", "INSPECTOR REPORT:", lastInspectorReport);
      }
      const prompt = promptParts.join("\n");
      const res = await api.chat({
        mode: "coder",
        stage: "repair",
        model: model || null,
        messages: [{ role: "user", content: prompt }],
        num_predict: 12288,
      });
      const raw = res.content || "";
      setStreamContent(raw);
      const saved = await api.coderAddVersion({
        prompt: fault,
        raw_response: raw,
        kind: "repair",
        inspector_report: lastInspectorReport || "",
        model: res.model || model || "",
        project_id: currentProjectId(),
      });
      project = saved.project || (await api.coderProject());
      renderVersionList();
      if (saved.version?.id) loadPreview(saved.version.id);
      logEvent(`Repair version saved: ${saved.version?.id}`);
      setStatus(false, "");
      setStage("Repair complete");
    } catch (e) {
      setStatus(true, `Repair error: ${e.message}`, false);
      setStage("Error");
      logEvent(`Repair error: ${e.message}`);
      alert(`Repair failed: ${e.message}`);
    } finally {
      setBusyUi(false);
      await persistSoft();
    }
  }

  function appendReportToRepair() {
    if (!lastInspectorReport) return;
    const ta = $("#coder-repair-prompt");
    if (!ta) return;
    const cur = ta.value || "";
    ta.value = cur
      ? `${cur}\n\n--- Inspector report ---\n${lastInspectorReport}`
      : lastInspectorReport;
    persistSoft();
  }

  async function acceptVersion() {
    const vid = project?.active_version_id;
    if (!vid) return;
    if (!confirm(`Accept ${vid} as the new baseline?`)) return;
    project = await api.coderAcceptVersion(vid, currentProjectId());
    renderVersionList();
    logEvent(`Accepted ${vid}`);
  }

  async function deleteVersion() {
    const vid = project?.active_version_id;
    if (!vid) return;
    if (!confirm(`Delete version ${vid}?`)) return;
    project = await api.coderDeleteVersion(vid, currentProjectId());
    renderVersionList();
    if (project.active_version_id) loadPreview(project.active_version_id);
    else loadPreview(null);
    logEvent(`Deleted ${vid}`);
  }

  function wire() {
    $("#btn-coder-designer-send")?.addEventListener("click", () => designerSend());
    $("#coder-designer-input")?.addEventListener("keydown", (e) => {
      if (e.key === "Enter" && !e.shiftKey) {
        e.preventDefault();
        designerSend();
      }
    });
    $("#btn-coder-to-build")?.addEventListener("click", () => useAsBuildPrompt());
    $("#btn-coder-to-repair")?.addEventListener("click", () => useAsRepairPrompt());
    $("#btn-coder-build")?.addEventListener("click", () => runBuild());
    $("#btn-coder-inspect")?.addEventListener("click", () => runInspect());
    $("#btn-coder-repair")?.addEventListener("click", () => runRepair());
    $("#btn-coder-use-report")?.addEventListener("click", () => appendReportToRepair());
    $("#btn-coder-accept")?.addEventListener("click", () => acceptVersion());
    $("#btn-coder-delete-version")?.addEventListener("click", () => deleteVersion());
    $("#btn-coder-preview-refresh")?.addEventListener("click", () => {
      if (project?.active_version_id) loadPreview(project.active_version_id);
    });
    $("#btn-coder-preview-external")?.addEventListener("click", () => {
      if (project?.active_version_id) {
        window.open(api.coderVersionHtmlUrl(project.active_version_id, currentProjectId()), "_blank");
      }
    });
    $("#btn-coder-clear-runtime")?.addEventListener("click", () => clearRuntime());
    $("#coder-preview-version")?.addEventListener("change", (e) => {
      selectVersion(e.target.value);
    });
    $("#coder-build-prompt")?.addEventListener("input", () => {
      updatePromptChars();
    });
    $("#coder-build-prompt")?.addEventListener("change", () => persistSoft());
    $("#coder-repair-prompt")?.addEventListener("change", () => persistSoft());

    $("#coder-project-select")?.addEventListener("change", (e) => {
      switchProject(e.target.value);
    });
    $("#btn-coder-project-new")?.addEventListener("click", () => newProject());
    $("#btn-coder-project-save")?.addEventListener("click", () => saveProjectNamed());
    $("#btn-coder-project-delete")?.addEventListener("click", () => deleteCurrentProject());
    $("#coder-project-name")?.addEventListener("keydown", (e) => {
      if (e.key === "Enter") {
        e.preventDefault();
        saveProjectNamed();
      }
    });

    $$("[data-coder-stream]").forEach((btn) => {
      btn.addEventListener("click", () => {
        const tab = btn.dataset.coderStream;
        $$("[data-coder-stream]").forEach((b) => b.classList.toggle("active", b === btn));
        $("#coder-content-stream")?.classList.toggle("active", tab === "content");
        $("#coder-event-stream")?.classList.toggle("active", tab === "events");
      });
    });

    window.addEventListener("message", (ev) => {
      if (ev?.data?.type === "coder-runtime") {
        pushRuntime(String(ev.data.message || ev.data));
      }
    });
  }

  async function open() {
    await fillModels();
    await refresh();
  }

  return { wire, open, refresh, fillModels };
}
