/** Undo/redo stack for project snapshots. */
export class HistoryStack {
  constructor(limit = 50) {
    this.limit = limit;
    this.stack = [];
    this.index = -1;
  }

  push(project) {
    const snap = JSON.stringify(project);
    // drop redo branch
    this.stack = this.stack.slice(0, this.index + 1);
    if (this.stack[this.index] === snap) return;
    this.stack.push(snap);
    if (this.stack.length > this.limit) {
      this.stack.shift();
    }
    this.index = this.stack.length - 1;
  }

  canUndo() {
    return this.index > 0;
  }

  canRedo() {
    return this.index >= 0 && this.index < this.stack.length - 1;
  }

  undo() {
    if (!this.canUndo()) return null;
    this.index -= 1;
    return JSON.parse(this.stack[this.index]);
  }

  redo() {
    if (!this.canRedo()) return null;
    this.index += 1;
    return JSON.parse(this.stack[this.index]);
  }

  reset(project) {
    this.stack = [JSON.stringify(project)];
    this.index = 0;
  }
}
