/** Studio chat — ChatGPT-like mode with history sidebar + avatar. */
import { api } from "./api.js";
import { createCoderController } from "./coder.js";

const LS_CHAT_LEGACY = "amvs_chat_v1";
const LS_SESSIONS = "amvs_chat_sessions_v2";
const LS_LAST_MEDIA = "amvs_chat_last_media_v1";

const $ = (s, r = document) => r.querySelector(s);
const $$ = (s, r = document) => [...r.querySelectorAll(s)];

function escapeHtml(s) {
  return String(s ?? "")
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;");
}

function uid() {
  return `c_${Date.now().toString(36)}_${Math.random().toString(36).slice(2, 8)}`;
}

function loadLastMedia() {
  try {
    return JSON.parse(localStorage.getItem(LS_LAST_MEDIA) || "null");
  } catch {
    return null;
  }
}

function saveLastMedia(meta) {
  try {
    if (meta) localStorage.setItem(LS_LAST_MEDIA, JSON.stringify(meta));
    else localStorage.removeItem(LS_LAST_MEDIA);
  } catch (_) {}
}

function defaultSession() {
  return {
    id: uid(),
    title: "New chat",
    createdAt: Date.now(),
    updatedAt: Date.now(),
    messages: [],
  };
}

function loadStore() {
  try {
    const raw = JSON.parse(localStorage.getItem(LS_SESSIONS) || "null");
    if (raw?.sessions?.length) {
      return {
        activeId: raw.activeId || raw.sessions[0].id,
        sessions: raw.sessions,
      };
    }
  } catch (_) {}

  // Migrate single-thread legacy history
  let legacy = [];
  try {
    legacy = JSON.parse(localStorage.getItem(LS_CHAT_LEGACY) || "[]") || [];
  } catch (_) {}
  const s = defaultSession();
  if (legacy.length) {
    s.messages = legacy.slice(-80);
    s.title = titleFromMessages(s.messages);
    s.updatedAt = Date.now();
  }
  const store = { activeId: s.id, sessions: [s] };
  saveStore(store);
  return store;
}

function saveStore(store) {
  try {
    // Cap sessions and message length for localStorage
    const sessions = (store.sessions || [])
      .slice(0, 40)
      .map((s) => ({
        ...s,
        messages: (s.messages || []).slice(-80),
      }));
    localStorage.setItem(
      LS_SESSIONS,
      JSON.stringify({ activeId: store.activeId, sessions })
    );
  } catch (_) {}
}

function titleFromMessages(msgs) {
  const firstUser = (msgs || []).find((m) => m.role === "user" && (m.content || "").trim());
  if (!firstUser) return "New chat";
  const t = String(firstUser.content).replace(/\s+/g, " ").trim();
  return t.length > 42 ? t.slice(0, 42) + "…" : t;
}

function formatWhen(ts) {
  if (!ts) return "";
  const d = new Date(ts);
  const now = new Date();
  const sameDay = d.toDateString() === now.toDateString();
  if (sameDay) {
    return d.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" });
  }
  return d.toLocaleDateString([], { month: "short", day: "numeric" });
}

const ACTION_NAMES = new Set(["generate_image", "generate_video", "web_search"]);

/** Find balanced `{...}` objects that look like chat actions. */
function extractJsonObjects(text) {
  const out = [];
  const s = String(text || "");
  for (let i = 0; i < s.length; i++) {
    if (s[i] !== "{") continue;
    let depth = 0;
    let inStr = false;
    let esc = false;
    for (let j = i; j < s.length; j++) {
      const ch = s[j];
      if (inStr) {
        if (esc) esc = false;
        else if (ch === "\\") esc = true;
        else if (ch === '"') inStr = false;
        continue;
      }
      if (ch === '"') {
        inStr = true;
        continue;
      }
      if (ch === "{") depth++;
      else if (ch === "}") {
        depth--;
        if (depth === 0) {
          out.push(s.slice(i, j + 1));
          i = j;
          break;
        }
      }
    }
  }
  return out;
}

function tryParseActionJson(raw) {
  if (!raw || typeof raw !== "string") return null;
  let t = raw.trim();
  // strip common wrappers / trailing commas that break JSON.parse
  t = t.replace(/^\uFEFF/, "");
  t = t.replace(/,\s*([}\]])/g, "$1");
  try {
    const j = JSON.parse(t);
    if (j && typeof j === "object" && ACTION_NAMES.has(String(j.action || ""))) return j;
  } catch (_) {}
  // single-quoted keys/values (some models)
  try {
    const fixed = t
      .replace(/'/g, '"')
      .replace(/,\s*([}\]])/g, "$1");
    const j = JSON.parse(fixed);
    if (j && typeof j === "object" && ACTION_NAMES.has(String(j.action || ""))) return j;
  } catch (_) {}
  return null;
}

/**
 * Parse media / search action JSON from model reply.
 * Tolerates ```json fences, bare ``` fences, raw objects, and extra chatter.
 */
function extractActions(text) {
  const actions = [];
  const seen = new Set();
  let raw = String(text || "");
  // Drop model "thinking" blocks so they don't confuse matching
  raw = raw.replace(/<think>[\s\S]*?<\/think>/gi, " ");
  raw = raw.replace(/<thinking>[\s\S]*?<\/thinking>/gi, " ");

  const push = (j) => {
    if (!j?.action || !ACTION_NAMES.has(String(j.action))) return;
    const key = JSON.stringify(j);
    if (seen.has(key)) return;
    seen.add(key);
    actions.push(j);
  };

  // 1) Fenced blocks: ```json ... ``` or ``` ... ```
  const fenceRe = /```(?:json|JSON)?\s*([\s\S]*?)```/g;
  let m;
  while ((m = fenceRe.exec(raw))) {
    const body = (m[1] || "").trim();
    const direct = tryParseActionJson(body);
    if (direct) {
      push(direct);
      continue;
    }
    for (const chunk of extractJsonObjects(body)) {
      push(tryParseActionJson(chunk));
    }
  }

  // 2) Any balanced {...} containing an action field
  if (!actions.length) {
    for (const chunk of extractJsonObjects(raw)) {
      if (!/"action"\s*:/.test(chunk) && !/'action'\s*:/.test(chunk)) continue;
      push(tryParseActionJson(chunk));
    }
  }

  return actions;
}

/** Remove action JSON from assistant text so the user doesn't only see raw JSON. */
function stripActionJsonFromText(text) {
  let t = String(text || "");
  t = t.replace(/```(?:json|JSON)?\s*\{[\s\S]*?"action"\s*:\s*"(?:generate_image|generate_video|web_search)"[\s\S]*?\}\s*```/gi, "");
  // bare objects (balanced enough for display cleanup)
  for (const chunk of extractJsonObjects(t)) {
    if (/"action"\s*:\s*"(?:generate_image|generate_video|web_search)"/.test(chunk)) {
      t = t.split(chunk).join("");
    }
  }
  return t.replace(/\n{3,}/g, "\n\n").trim();
}

function wantsImageFromUser(userText) {
  const t = (userText || "").toLowerCase();
  if (!t.trim()) return false;
  // explicit image gen intent
  if (
    /\b(generate|create|make|draw|render|paint|design)\b[\s\S]{0,40}\b(image|picture|pic|photo|still|artwork|illustration)\b/.test(
      t
    )
  )
    return true;
  if (/\b(image|picture|photo|still)\b[\s\S]{0,20}\b(of|for|please|gen)\b/.test(t)) return true;
  if (/^(an?|the)\s+.+\s+(image|picture|photo)\b/.test(t)) return true;
  return false;
}

function wantsVideoFromExisting(userText, action) {
  if (action?.use_attached_image === true) return true;
  if (action?.action !== "generate_video") return false;
  if (!action.image_prompt) return true;
  const t = (userText || "").toLowerCase();
  return /\b(this|that|it|same|attached|my image|the image|make this|animate)\b/.test(t);
}

export function createChatController({ getSettings }) {
  let mode = "chat"; // chat | coder
  let busy = false;
  let settingsCache = {};
  const coder = createCoderController({ getSettings });
  /** @type {Array<{id:string,kind:string,filename:string,path?:string,url?:string,text?:string,project_id?:string}>} */
  let attachments = [];
  let lastMedia = loadLastMedia();
  let store = loadStore();

  function activeSession() {
    return (
      store.sessions.find((s) => s.id === store.activeId) || store.sessions[0] || null
    );
  }

  function getMessages() {
    return activeSession()?.messages || [];
  }

  function setMessages(msgs) {
    const s = activeSession();
    if (!s) return;
    s.messages = msgs;
    s.updatedAt = Date.now();
    if (!s.title || s.title === "New chat") {
      s.title = titleFromMessages(msgs);
    } else if (msgs.some((m) => m.role === "user")) {
      // Keep title from first user message
      const t = titleFromMessages(msgs);
      if (s.title === "New chat") s.title = t;
    }
    // Always refresh title from first user line if still default
    if (s.title === "New chat") s.title = titleFromMessages(msgs);
    saveStore(store);
    renderHistoryList();
  }

  function setAvatarSpeaking(speaking, caption) {
    const img = $("#chat-avatar-img");
    const vid = $("#chat-avatar-vid");
    const wrap = $("#chat-avatar-wrap");
    const cap = $("#chat-avatar-caption");
    if (cap) cap.textContent = caption || (speaking ? "Thinking…" : "Ready");
    wrap?.classList.toggle("speaking", !!speaking);
    if (!img || !vid) return;
    if (speaking) {
      img.classList.add("hidden");
      vid.classList.remove("hidden");
      try {
        vid.muted = true;
        vid.loop = true;
        const p = vid.play();
        if (p && typeof p.catch === "function") p.catch(() => {});
      } catch (_) {}
    } else {
      try {
        vid.pause();
        vid.currentTime = 0;
      } catch (_) {}
      vid.classList.add("hidden");
      img.classList.remove("hidden");
    }
  }

  function setStatus(show, text, loading = false) {
    const bar = $("#chat-status");
    const t = $("#chat-status-text");
    if (!bar || !t) return;
    bar.classList.toggle("hidden", !show);
    bar.classList.toggle("loading", !!loading);
    t.textContent = text || "";
    if (loading || show) {
      setAvatarSpeaking(true, text || "Thinking…");
    } else if (!busy) {
      setAvatarSpeaking(false, "Ready");
    }
  }

  function modelForTurn() {
    return settingsCache?.chat_model || "";
  }

  function updateModelLabel() {
    const el = $("#chat-model-label");
    if (!el) return;
    el.textContent = `Chat: ${modelForTurn() || "(auto first Ollama model)"}`;
  }

  function applyModeUi() {
    const chatPanel = $("#chat-mode-panel");
    const coderPanel = $("#coder-mode-panel");
    const clearBtn = $("#btn-chat-clear");
    const title = $("#chat-view-title");
    const sub = $("#chat-view-sub");
    chatPanel?.classList.toggle("hidden", mode !== "chat");
    coderPanel?.classList.toggle("hidden", mode !== "coder");
    if (clearBtn) clearBtn.classList.toggle("hidden", mode !== "chat");
    if (title) title.textContent = mode === "coder" ? "Code Companion" : "Fenix AI Studio";
    if (sub) {
      sub.textContent =
        mode === "coder"
          ? "Designer → complete-file build → inspect/repair · versions on disk"
          : "Chat · local Ollama · history in this browser";
    }
    $$(".tab-mode").forEach((b) => b.classList.toggle("active", b.dataset.chatMode === mode));
  }

  function updateSourcePanel() {
    const label = $("#chat-source-label");
    const thumb = $("#chat-source-thumb");
    if (!label || !thumb) return;
    const imgAtt = [...attachments].reverse().find((a) => a.kind === "image");
    const src = imgAtt
      ? { url: imgAtt.url, path: imgAtt.path, name: imgAtt.filename }
      : lastMedia?.image_url || lastMedia?.image_path
        ? {
            url:
              lastMedia.image_url ||
              (lastMedia.project_id && lastMedia.image_path
                ? api.fileUrl(lastMedia.project_id, lastMedia.image_path)
                : null),
            path: lastMedia.image_path,
            name: lastMedia.image_path || "last image",
          }
        : null;
    if (!src?.url && !src?.path) {
      label.textContent =
        "None yet — attach an image or generate one. “Make this a video” reuses it.";
      thumb.classList.add("hidden");
      thumb.innerHTML = "";
      return;
    }
    label.textContent = `Will reuse: ${src.name || src.path || "image"}`;
    if (src.url) {
      thumb.classList.remove("hidden");
      thumb.innerHTML = `<img src="${escapeHtml(src.url)}" alt="source" />`;
    } else {
      thumb.classList.add("hidden");
    }
  }

  function renderAttachChips() {
    const box = $("#chat-attach-chips");
    if (!box) return;
    if (!attachments.length) {
      box.classList.add("hidden");
      box.innerHTML = "";
      updateSourcePanel();
      return;
    }
    box.classList.remove("hidden");
    box.innerHTML = attachments
      .map((a, i) => {
        const icon = a.kind === "image" ? "🖼" : a.kind === "pdf" ? "📄" : "📎";
        const preview =
          a.kind === "image" && a.url
            ? `<img class="chip-thumb" src="${escapeHtml(a.url)}" alt="" />`
            : "";
        return `<span class="chat-chip" data-att-i="${i}" title="${escapeHtml(a.filename)}">
          ${preview}<span>${icon} ${escapeHtml(a.filename)}</span>
          <button type="button" class="chip-x" data-remove-att="${i}" aria-label="Remove">×</button>
        </span>`;
      })
      .join("");
    box.querySelectorAll("[data-remove-att]").forEach((btn) => {
      btn.addEventListener("click", (e) => {
        e.preventDefault();
        const i = Number(btn.dataset.removeAtt);
        attachments.splice(i, 1);
        renderAttachChips();
      });
    });
    updateSourcePanel();
  }

  function buildAttachmentContext() {
    if (!attachments.length) return "";
    const parts = ["Attached files for this turn:"];
    for (const a of attachments) {
      parts.push(`- [${a.kind}] ${a.filename}${a.path ? ` (path: ${a.path})` : ""}`);
      if (a.kind === "image") {
        parts.push(
          `  This image is available for Comfy video. If the user asks to animate / make a video of it, set use_attached_image:true and do NOT invent a new image_prompt.`
        );
      }
      if (a.text) {
        const t = a.text.length > 6000 ? a.text.slice(0, 6000) + "\n…[truncated]" : a.text;
        parts.push(`  Extracted text:\n${t}`);
      }
    }
    if (lastMedia?.image_path) {
      parts.push(
        `Last studio image (for reuse): path=${lastMedia.image_path} shot_id=${lastMedia.shot_id || "—"}`
      );
    }
    return parts.join("\n");
  }

  function resolveSourceImage(action, userText) {
    const imgAtt = [...attachments].reverse().find((a) => a.kind === "image" && a.path);
    if (imgAtt) {
      return {
        source_image_rel: imgAtt.path,
        source_shot_id: null,
        project_id: imgAtt.project_id,
      };
    }
    if (wantsVideoFromExisting(userText, action) && lastMedia?.image_path) {
      return {
        source_image_rel: lastMedia.image_path,
        source_shot_id: lastMedia.shot_id || null,
        project_id: lastMedia.project_id,
      };
    }
    if (action?.use_attached_image && lastMedia?.image_path) {
      return {
        source_image_rel: lastMedia.image_path,
        source_shot_id: lastMedia.shot_id || null,
        project_id: lastMedia.project_id,
      };
    }
    return null;
  }

  function renderHistoryList() {
    const box = $("#chat-history-list");
    if (!box) return;
    const sessions = [...(store.sessions || [])].sort(
      (a, b) => (b.updatedAt || 0) - (a.updatedAt || 0)
    );
    if (!sessions.length) {
      box.innerHTML = `<p class="muted small chat-history-empty">No chats yet.</p>`;
      return;
    }
    box.innerHTML = sessions
      .map((s) => {
        const active = s.id === store.activeId ? "active" : "";
        const count = (s.messages || []).length;
        return `<div class="chat-history-item ${active}" data-sid="${escapeHtml(s.id)}">
          <button type="button" class="chat-history-open" data-open-sid="${escapeHtml(s.id)}">
            <span class="chat-history-title">${escapeHtml(s.title || "New chat")}</span>
            <span class="chat-history-meta muted small">${escapeHtml(formatWhen(s.updatedAt))} · ${count} msg</span>
          </button>
          <button type="button" class="chat-history-del" data-del-sid="${escapeHtml(s.id)}" title="Delete chat" aria-label="Delete">×</button>
        </div>`;
      })
      .join("");

    box.querySelectorAll("[data-open-sid]").forEach((btn) => {
      btn.addEventListener("click", () => selectSession(btn.dataset.openSid));
    });
    box.querySelectorAll("[data-del-sid]").forEach((btn) => {
      btn.addEventListener("click", (e) => {
        e.stopPropagation();
        deleteSession(btn.dataset.delSid);
      });
    });
  }

  function selectSession(id) {
    if (!id || busy) return;
    if (!store.sessions.some((s) => s.id === id)) return;
    store.activeId = id;
    saveStore(store);
    attachments = [];
    renderAttachChips();
    renderHistoryList();
    renderLog();
    $("#chat-input")?.focus();
  }

  function newChat() {
    if (busy) return;
    // If current is empty New chat, just focus it
    const cur = activeSession();
    if (cur && !(cur.messages || []).length && cur.title === "New chat") {
      $("#chat-input")?.focus();
      return;
    }
    const s = defaultSession();
    store.sessions.unshift(s);
    store.activeId = s.id;
    saveStore(store);
    attachments = [];
    renderAttachChips();
    renderHistoryList();
    renderLog();
    $("#chat-input")?.focus();
  }

  function deleteSession(id) {
    if (busy) return;
    const s = store.sessions.find((x) => x.id === id);
    if (!s) return;
    const label = s.title || "this chat";
    if (!confirm(`Delete “${label}”?`)) return;
    store.sessions = store.sessions.filter((x) => x.id !== id);
    if (!store.sessions.length) {
      const n = defaultSession();
      store.sessions = [n];
      store.activeId = n.id;
    } else if (store.activeId === id) {
      store.activeId = store.sessions[0].id;
    }
    saveStore(store);
    attachments = [];
    renderAttachChips();
    renderHistoryList();
    renderLog();
  }

  function renderLog() {
    const box = $("#chat-log");
    if (!box) return;
    const msgs = getMessages();
    if (!msgs.length) {
      box.innerHTML = `<div class="chat-empty muted">
        Ask anything. Attach images/PDFs, toggle Web for search, or request images/videos via Comfy.
      </div>`;
      return;
    }
    box.innerHTML = msgs
      .map((m) => {
        const role = m.role === "user" ? "user" : "assistant";
        const meta = m.meta ? `<small>${escapeHtml(m.meta)}</small>` : "";
        let media = "";
        if (m.mediaHtml) media = `<div class="chat-inline-media">${m.mediaHtml}</div>`;
        let chips = "";
        if (m.attachNames?.length) {
          chips = `<div class="chat-msg-atts">${m.attachNames
            .map((n) => `<span class="chat-chip mini">${escapeHtml(n)}</span>`)
            .join("")}</div>`;
        }
        return `<div class="chat-message ${role}"><div class="chat-bubble">${escapeHtml(m.content)}${meta}</div>${chips}${media}</div>`;
      })
      .join("");
    box.scrollTop = box.scrollHeight;
  }

  function setMode(next) {
    mode = next === "coder" ? "coder" : "chat";
    applyModeUi();
    updateModelLabel();
    if (mode === "chat") {
      renderHistoryList();
      renderLog();
      setAvatarSpeaking(false, "Ready");
    } else {
      setAvatarSpeaking(false, "Ready");
      coder.open().catch((e) => console.warn(e));
    }
  }

  async function refreshSettings() {
    try {
      settingsCache = (await getSettings()) || {};
    } catch {
      settingsCache = {};
    }
    updateModelLabel();
  }

  async function pollJob(jobId, onProgress) {
    const t0 = Date.now();
    while (Date.now() - t0 < 45 * 60 * 1000) {
      const j = await api.job(jobId);
      onProgress?.(j);
      if (
        j.status === "done" ||
        j.status === "ready" ||
        j.status === "error" ||
        j.status === "failed" ||
        j.status === "cancelled"
      ) {
        return j;
      }
      await new Promise((r) => setTimeout(r, 2000));
    }
    throw new Error("Generation timed out");
  }

  async function runMediaAction(action, userText = "") {
    const kind = action.action === "generate_video" ? "video" : "image";
    const enhance = !!$("#chat-enhance-prompt")?.checked;
    const source = kind === "video" ? resolveSourceImage(action, userText) : null;

    setStatus(
      true,
      kind === "image"
        ? "ComfyUI: generating image…"
        : source
          ? "ComfyUI: animating your image (reusing still)…"
          : "ComfyUI: preparing video…",
      true
    );

    const body = {
      kind,
      prompt: action.prompt || action.image_prompt || action.motion_prompt || "",
      negative: action.negative || "",
      image_prompt: source ? "" : action.image_prompt || action.prompt || "",
      motion_prompt: action.prompt || action.motion_prompt || "",
      enhance_prompt: enhance,
    };
    if (source?.source_image_rel) body.source_image_rel = source.source_image_rel;
    if (source?.source_shot_id) body.source_shot_id = source.source_shot_id;

    let res = await api.chatMedia(body);
    let job = await pollJob(res.job_id, (j) => {
      setStatus(
        true,
        `${j.message || j.status || "Working…"} (${Math.round((j.progress || 0) * 100)}%)`,
        true
      );
    });
    if (job.status === "error" || job.status === "failed") {
      throw new Error(job.message || job.error || "Generation failed");
    }

    if (res.needs_image_first || res.pending_video) {
      setStatus(true, "Step 2/2: animating to video…", true);
      res = await api.chatContinueVideo(res.project_id, res.shot_id);
      job = await pollJob(res.job_id, (j) => {
        setStatus(
          true,
          `${j.message || j.status || "Animating…"} (${Math.round((j.progress || 0) * 100)}%)`,
          true
        );
      });
      if (job.status === "error" || job.status === "failed") {
        throw new Error(job.message || "Video generation failed");
      }
    }

    const proj = await api.getProject(res.project_id || job.project_id);
    const shot = (proj.timeline?.shots || []).find((s) => s.id === (res.shot_id || job.shot_id));
    let mediaHtml = "";
    if (shot?.video_path || shot?.draft_video_path) {
      const rel = shot.video_path || shot.draft_video_path;
      const url = api.fileUrl(proj.id, rel);
      mediaHtml = `<video controls src="${url}"></video>`;
    } else if (shot?.image_path) {
      const url = api.fileUrl(proj.id, shot.image_path);
      mediaHtml = `<img src="${url}" alt="generated" />`;
    }

    if (shot?.image_path) {
      lastMedia = {
        project_id: proj.id,
        shot_id: shot.id,
        image_path: shot.image_path,
        image_url: api.fileUrl(proj.id, shot.image_path),
        kind: shot.video_path || shot.draft_video_path ? "video" : "image",
      };
      saveLastMedia(lastMedia);
      updateSourcePanel();
    }

    const prev = $("#chat-media-preview");
    const bodyEl = $("#chat-media-body");
    if (prev && bodyEl && mediaHtml) {
      prev.classList.remove("hidden");
      bodyEl.innerHTML = mediaHtml;
    }
    setStatus(false, "");
    return { mediaHtml, reused: !!res.reused_image || !!source };
  }

  async function uploadFiles(fileList) {
    const files = [...(fileList || [])];
    if (!files.length) return;
    setStatus(true, `Uploading ${files.length} file(s)…`, true);
    try {
      for (const file of files) {
        const res = await api.chatUpload(file);
        attachments.push({
          id: res.id,
          kind: res.kind || "file",
          filename: res.filename || file.name,
          path: res.path,
          url: res.url,
          text: res.text || "",
          project_id: res.project_id,
        });
        if (res.kind === "image" && res.path) {
          lastMedia = {
            project_id: res.project_id,
            shot_id: null,
            image_path: res.path,
            image_url: res.url,
            kind: "image",
          };
          saveLastMedia(lastMedia);
        }
      }
      renderAttachChips();
    } catch (e) {
      alert(`Upload failed: ${e.message}`);
    } finally {
      setStatus(false, "");
    }
  }

  async function send() {
    if (busy || mode !== "chat") return;
    const input = $("#chat-input");
    const text = (input?.value || "").trim();
    if (!text && !attachments.length) return;

    await refreshSettings();
    const model = modelForTurn();
    const userText = text || "(see attachments)";
    const attachNames = attachments.map((a) => a.filename);
    const attachCtx = buildAttachmentContext();
    const webOn = !!$("#chat-web-search")?.checked;

    const msgs = getMessages();
    msgs.push({
      role: "user",
      content: userText,
      attachNames: attachNames.length ? attachNames : undefined,
      at: Date.now(),
    });
    setMessages(msgs);
    if (input) input.value = "";
    renderLog();

    busy = true;
    const btn = $("#btn-chat-send");
    if (btn) btn.disabled = true;
    setStatus(true, model ? `Loading / running ${model}…` : "Loading model…", true);

    const turnAttachments = [...attachments];

    try {
      const history = getMessages().map((m) => ({ role: m.role, content: m.content }));
      let res = await api.chat({
        mode: "chat",
        stage: "chat",
        model: model || null,
        messages: history,
        attachment_context: attachCtx || null,
        enable_web_search: webOn,
        web_search_query: webOn ? userText : null,
      });
      let content = res.content || "";
      if (res.web_search) {
        content = `(Web search used.)\n\n${content}`;
      }

      let mediaHtml = "";
      let actions = extractActions(content);

      if (
        !actions.some((a) => a.action === "generate_video" || a.action === "generate_image")
      ) {
        const t = userText.toLowerCase();
        const hasSource =
          turnAttachments.some((a) => a.kind === "image") || lastMedia?.image_path;
        if (hasSource && /\b(video|animate|comfy|i2v|motion)\b/.test(t)) {
          actions = [
            {
              action: "generate_video",
              prompt: userText,
              use_attached_image: true,
            },
          ];
          content += "\n\n(Using attached/last image for video…)";
        } else if (wantsImageFromUser(userText)) {
          // Model forgot JSON or used a format we couldn't parse — still generate.
          actions = [
            {
              action: "generate_image",
              prompt: userText,
            },
          ];
          content += "\n\n(Starting image generation…)";
        }
      }

      for (const act of actions.filter((a) => a.action === "web_search")) {
        try {
          setStatus(true, `Web search: ${act.query || userText}…`, true);
          const sr = await api.chatSearch(act.query || userText, 5);
          const history2 = getMessages().map((m) => ({ role: m.role, content: m.content }));
          history2.push({ role: "assistant", content: content });
          history2.push({
            role: "user",
            content: `Use these search results to answer:\n${sr.context || ""}\n\nOriginal question: ${userText}`,
          });
          res = await api.chat({
            mode: "chat",
            stage: "chat",
            model: model || null,
            messages: history2,
            attachment_context: attachCtx || null,
          });
          content = res.content || content;
          actions = extractActions(content).filter((a) => a.action !== "web_search");
        } catch (se) {
          content += `\n\n(Web search failed: ${se.message})`;
        }
      }

      let ranMedia = false;
      for (const action of actions) {
        if (action.action !== "generate_image" && action.action !== "generate_video") continue;
        try {
          const out = await runMediaAction(action, userText);
          mediaHtml = (mediaHtml || "") + (out.mediaHtml || "");
          ranMedia = true;
          content += out.reused
            ? "\n\n(Media: video from your attached/last image — no new still.)"
            : "\n\n(Media generation finished.)";
        } catch (me) {
          content += `\n\nMedia generation failed: ${me.message}`;
          setStatus(false, "");
        }
      }
      if (!actions.some((a) => a.action === "generate_image" || a.action === "generate_video")) {
        setStatus(false, "");
      }

      // Don't leave raw action JSON as the only visible reply
      if (ranMedia || actions.some((a) => a.action === "generate_image" || a.action === "generate_video")) {
        const cleaned = stripActionJsonFromText(content);
        content =
          cleaned ||
          (ranMedia ? "On it — generating with ComfyUI…" : content);
      }

      const next = getMessages();
      next.push({
        role: "assistant",
        content,
        meta: `${res.model || model} · chat`,
        mediaHtml,
        at: Date.now(),
      });
      setMessages(next);
      attachments = [];
      renderAttachChips();
      renderLog();
    } catch (e) {
      setStatus(false, "");
      const next = getMessages();
      next.push({
        role: "assistant",
        content: `Error: ${e.message}`,
        meta: "error",
        at: Date.now(),
      });
      setMessages(next);
      renderLog();
    } finally {
      busy = false;
      if (btn) btn.disabled = false;
      setAvatarSpeaking(false, "Ready");
    }
  }

  function clearHistory() {
    if (mode !== "chat") return;
    const s = activeSession();
    if (!s) return;
    if (!confirm("Clear messages in this chat?")) return;
    s.messages = [];
    s.title = "New chat";
    s.updatedAt = Date.now();
    saveStore(store);
    renderHistoryList();
    renderLog();
  }

  function wire() {
    coder.wire();
    $("#btn-chat-send")?.addEventListener("click", () => send());
    $("#chat-input")?.addEventListener("keydown", (e) => {
      if (e.key === "Enter" && !e.shiftKey) {
        e.preventDefault();
        send();
      }
    });
    $("#btn-chat-clear")?.addEventListener("click", () => clearHistory());
    $("#btn-chat-new")?.addEventListener("click", () => newChat());
    $$(".tab-mode").forEach((b) => {
      b.addEventListener("click", () => setMode(b.dataset.chatMode));
    });

    $("#btn-chat-attach")?.addEventListener("click", () => {
      $("#chat-file-input")?.click();
    });
    $("#chat-file-input")?.addEventListener("change", (e) => {
      const input = e.target;
      if (input?.files?.length) {
        uploadFiles(input.files);
        input.value = "";
      }
    });

    const dropTargets = [
      $("#chat-mode-panel .chat-compose"),
      $("#chat-log"),
      $("#chat-input"),
    ].filter(Boolean);
    const onDrag = (e) => {
      e.preventDefault();
      e.stopPropagation();
    };
    const onDrop = (e) => {
      e.preventDefault();
      e.stopPropagation();
      if (mode !== "chat") return;
      const files = e.dataTransfer?.files;
      if (files?.length) uploadFiles(files);
    };
    dropTargets.forEach((el) => {
      el.addEventListener("dragover", onDrag);
      el.addEventListener("drop", onDrop);
    });
    $("#chat-mode-panel")?.addEventListener("dragover", onDrag);
    $("#chat-mode-panel")?.addEventListener("drop", onDrop);

    // Avatar video always muted
    const vid = $("#chat-avatar-vid");
    if (vid) {
      vid.muted = true;
      vid.defaultMuted = true;
      vid.setAttribute("muted", "");
      vid.setAttribute("playsinline", "");
    }
  }

  async function open() {
    store = loadStore();
    await refreshSettings();
    applyModeUi();
    if (mode === "chat") {
      renderHistoryList();
      renderAttachChips();
      updateSourcePanel();
      renderLog();
      setAvatarSpeaking(false, "Ready");
      $("#chat-input")?.focus();
    } else {
      await coder.open();
    }
  }

  return { wire, open, refreshSettings, setMode };
}
