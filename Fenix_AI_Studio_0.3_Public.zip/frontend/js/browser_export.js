/**
 * Browser-side WebM export: capture preview stage + project audio while timeline plays.
 * Requires tab visible; quality = canvas/preview size. Fallback when FFmpeg is missing.
 */

function wait(ms) {
  return new Promise((r) => setTimeout(r, ms));
}

/**
 * @param {object} opts
 * @param {HTMLElement} opts.stageEl - .preview-stage element
 * @param {HTMLVideoElement} opts.previewVideo
 * @param {HTMLImageElement} opts.previewImage
 * @param {HTMLAudioElement} opts.mainAudio
 * @param {() => number} opts.getDuration - total timeline seconds
 * @param {(t: number) => void | Promise<void>} opts.seekTo - seek project to time t
 * @param {(msg: string) => void} [opts.onStatus]
 * @param {AbortSignal} [opts.signal]
 * @returns {Promise<Blob>}
 */
export async function recordPreviewWebM(opts) {
  const {
    stageEl,
    previewVideo,
    previewImage,
    mainAudio,
    getDuration,
    seekTo,
    onStatus,
    signal,
  } = opts;

  if (!stageEl) throw new Error("Preview stage not found");
  if (typeof MediaRecorder === "undefined") {
    throw new Error("MediaRecorder not supported in this browser");
  }

  const duration = Math.max(0.5, Number(getDuration()) || 5);
  const w = Math.max(320, Math.min(1280, stageEl.clientWidth || 640));
  const h = Math.max(180, Math.min(720, stageEl.clientHeight || 360));
  // Snap to even dimensions for encoders
  const cw = w - (w % 2);
  const ch = h - (h % 2);

  const canvas = document.createElement("canvas");
  canvas.width = cw;
  canvas.height = ch;
  const ctx = canvas.getContext("2d");
  if (!ctx) throw new Error("Canvas 2D unavailable");

  const fps = 24;
  let raf = 0;
  let drawing = true;

  const drawFrame = () => {
    if (!drawing) return;
    ctx.fillStyle = "#000";
    ctx.fillRect(0, 0, cw, ch);
    const vid = previewVideo;
    const img = previewImage;
    let src = null;
    if (vid && vid.classList.contains("visible") && vid.readyState >= 2) src = vid;
    else if (img && img.classList.contains("visible") && img.naturalWidth) src = img;
    if (src) {
      const sw = src.videoWidth || src.naturalWidth || cw;
      const sh = src.videoHeight || src.naturalHeight || ch;
      const scale = Math.min(cw / sw, ch / sh);
      const dw = sw * scale;
      const dh = sh * scale;
      const dx = (cw - dw) / 2;
      const dy = (ch - dh) / 2;
      try {
        ctx.drawImage(src, dx, dy, dw, dh);
      } catch (_) {
        /* CORS / empty frame */
      }
    }
    raf = requestAnimationFrame(drawFrame);
  };
  drawFrame();

  const vStream = canvas.captureStream(fps);
  const tracks = [...vStream.getVideoTracks()];

  // Mix project audio if available (prefer captureStream — no WebAudio rebind issues)
  let audioCtx = null;
  try {
    if (mainAudio && mainAudio.src) {
      if (typeof mainAudio.captureStream === "function") {
        const aStream = mainAudio.captureStream();
        aStream.getAudioTracks().forEach((t) => tracks.push(t));
      } else {
        audioCtx = new (window.AudioContext || window.webkitAudioContext)();
        const dest = audioCtx.createMediaStreamDestination();
        // May throw if already connected once — catch below
        const src = audioCtx.createMediaElementSource(mainAudio);
        src.connect(dest);
        src.connect(audioCtx.destination);
        dest.stream.getAudioTracks().forEach((t) => tracks.push(t));
      }
    }
  } catch (e) {
    onStatus?.(`Audio capture limited: ${e.message}`);
  }

  const stream = new MediaStream(tracks);
  const mimeCandidates = [
    "video/webm;codecs=vp9,opus",
    "video/webm;codecs=vp8,opus",
    "video/webm",
  ];
  const mime = mimeCandidates.find((m) => MediaRecorder.isTypeSupported(m)) || "";
  const chunks = [];
  const recorder = new MediaRecorder(stream, mime ? { mimeType: mime, videoBitsPerSecond: 2_500_000 } : undefined);

  recorder.ondataavailable = (ev) => {
    if (ev.data && ev.data.size) chunks.push(ev.data);
  };

  const stopped = new Promise((resolve, reject) => {
    recorder.onstop = () => resolve();
    recorder.onerror = (e) => reject(e.error || new Error("MediaRecorder error"));
  });

  if (signal) {
    signal.addEventListener("abort", () => {
      try {
        if (recorder.state !== "inactive") recorder.stop();
      } catch (_) {}
    });
  }

  // Start from 0 and play through
  await seekTo(0);
  if (mainAudio) {
    try {
      mainAudio.currentTime = 0;
      await mainAudio.play();
    } catch (_) {}
  }
  recorder.start(250);
  onStatus?.(`Recording WebM ${cw}×${ch} · ${duration.toFixed(1)}s — keep tab visible…`);

  const step = 1 / fps;
  let t = 0;
  while (t < duration) {
    if (signal?.aborted) break;
    await seekTo(t);
    if (mainAudio && Math.abs((mainAudio.currentTime || 0) - t) > 0.25) {
      try {
        mainAudio.currentTime = t;
      } catch (_) {}
    }
    await wait(step * 1000);
    t += step;
    if (Math.floor(t) !== Math.floor(t - step)) {
      onStatus?.(`Recording… ${Math.min(duration, t).toFixed(0)}s / ${duration.toFixed(0)}s`);
    }
  }

  drawing = false;
  cancelAnimationFrame(raf);
  try {
    if (recorder.state !== "inactive") recorder.stop();
  } catch (_) {}
  await stopped;
  try {
    mainAudio?.pause();
  } catch (_) {}
  try {
    audioCtx?.close();
  } catch (_) {}
  tracks.forEach((tr) => {
    try {
      tr.stop();
    } catch (_) {}
  });

  if (signal?.aborted) throw new Error("Recording cancelled");
  if (!chunks.length) throw new Error("No video data captured");
  return new Blob(chunks, { type: mime || "video/webm" });
}

export function downloadBlob(blob, filename) {
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = filename;
  a.click();
  setTimeout(() => URL.revokeObjectURL(url), 30_000);
}
