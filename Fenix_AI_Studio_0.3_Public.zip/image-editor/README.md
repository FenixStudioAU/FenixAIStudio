# Fenix Image Studio

A Fenix Desktop image editor based on the supplied Fabric.js Logo Lab.

Features include layers, text, shapes, drawing, raster and magic erasing, portable project save/open, undo/redo, zoom and fit controls, social/canvas presets, image adjustments, grouping, alignment and PNG/JPG/SVG export. Selected files are processed in the browser. Fabric.js and optional Google fonts are loaded from public CDNs.
