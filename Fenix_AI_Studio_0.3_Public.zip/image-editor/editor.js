(() => {
  const canvas = new fabric.Canvas('c', {
    preserveObjectStacking: true,
    selection: true,
    backgroundColor: null
  });

  let mode = 'select'; // select | text | eraser | brush | pen(line) | spray | magic
  let eraserBrush = null;
  let drawBrush = null;

  // Pen line tool state
  let lineStart = null;   // {x,y} or null
  let linePreview = null; // fabric.Line or null

  // UI refs
  const modeChip = document.getElementById('modeChip');
  const sizeChip = document.getElementById('sizeChip');
  const hintChip = document.getElementById('hintChip');
  const statusLine = document.getElementById('statusLine');

  const toolSelect = document.getElementById('toolSelect');
  const toolText = document.getElementById('toolText');
  const toolEraser = document.getElementById('toolEraser');
  const toolBrush = document.getElementById('toolBrush');
  const toolPen = document.getElementById('toolPen');
  const toolSpray = document.getElementById('toolSpray');
  const toolMagic = document.getElementById('toolMagic');

  const layersEl = document.getElementById('layers');

  const selHint = document.getElementById('selHint');
  const propsArea = document.getElementById('propsArea');
  const textProps = document.getElementById('textProps');

  const opacity = document.getElementById('opacity');
  const opacityRead = document.getElementById('opacityRead');

  const shapeProps = document.getElementById('shapeProps');
  const shapeFill = document.getElementById('shapeFill');
  const shapeStroke = document.getElementById('shapeStroke');
  const shapeStrokeW = document.getElementById('shapeStrokeW');
  const rasterizeSelectedBtn = document.getElementById('rasterizeSelected');

  const textValue = document.getElementById('textValue');
  const fontFamily = document.getElementById('fontFamily');
  const fontSize = document.getElementById('fontSize');
  const fillColor = document.getElementById('fillColor');
  const strokeColor = document.getElementById('strokeColor');
  const strokeWidth = document.getElementById('strokeWidth');

  const cw = document.getElementById('cw');
  const ch = document.getElementById('ch');

  const eraserSize = document.getElementById('eraserSize');
  const eraserSizeRead = document.getElementById('eraserSizeRead');

  const brushColor = document.getElementById('brushColor');
  const brushSize = document.getElementById('brushSize');
  const brushSizeRead = document.getElementById('brushSizeRead');
  const brushSoft = document.getElementById('brushSoft');
  const brushSoftRead = document.getElementById('brushSoftRead');

  const magicTol = document.getElementById('magicTol');
  const magicTolRead = document.getElementById('magicTolRead');
  const magicFeather = document.getElementById('magicFeather');
  const magicFeatherRead = document.getElementById('magicFeatherRead');

  const shadowOff = document.getElementById('shadowOff');
  const shadowOn = document.getElementById('shadowOn');
  const glowOff = document.getElementById('glowOff');
  const glowOn = document.getElementById('glowOn');
  const fxColor = document.getElementById('fxColor');
  const fxBlur = document.getElementById('fxBlur');
  const fxOffX = document.getElementById('fxOffX');
  const fxOffY = document.getElementById('fxOffY');

  const selectionType = document.getElementById('selectionType');
  const imageProps = document.getElementById('imageProps');
  const brightness = document.getElementById('brightness');
  const contrast = document.getElementById('contrast');
  const saturation = document.getElementById('saturation');
  const imageBlur = document.getElementById('imageBlur');
  const grayscale = document.getElementById('grayscale');
  const sepia = document.getElementById('sepia');
  const brightnessRead = document.getElementById('brightnessRead');
  const contrastRead = document.getElementById('contrastRead');
  const saturationRead = document.getElementById('saturationRead');
  const imageBlurRead = document.getElementById('imageBlurRead');
  const canvasWrap = document.getElementById('canvasWrap');
  const zoomValue = document.getElementById('zoomValue');
  const undoBtn = document.getElementById('undoBtn');
  const redoBtn = document.getElementById('redoBtn');
  let viewZoom = 1;
  let rasterEraserActive = false;
  let rasterEraseObj = null;
  let rasterEraseSurface = null;
  let rasterEraseCtx = null;
  let rasterEraseLast = null;
  let rasterEraseDrawing = false;

  const setStatus = (t) => statusLine.textContent = t;

  function updateCanvasSizeChip() {
    sizeChip.textContent = `CANVAS: ${canvas.getWidth()}×${canvas.getHeight()}`;
    cw.value = canvas.getWidth();
    ch.value = canvas.getHeight();
  }

  function activeObj() { return canvas.getActiveObject(); }

  function isTextObj(o){
    return o && (o.type === 'i-text' || o.type === 'text' || o.type === 'textbox');
  }

  function isShapeLike(o){
    if (!o) return false;
    if (o.type === 'rect' || o.type === 'circle' || o.type === 'triangle') return true;
    if (o.type === 'path') return true; // drawn strokes
    if (o.type === 'line') return true; // pen tool lines
    return false;
  }

  function objectLabel(obj) {
    if (!obj) return 'None';
    if (isTextObj(obj)) return 'Text';
    if (obj.type === 'image') return 'Image';
    if (obj.type === 'rect') return 'Rectangle';
    if (obj.type === 'circle') return 'Circle';
    if (obj.type === 'triangle') return 'Triangle';
    if (obj.type === 'group') return 'Group';
    if (obj.type === 'path') return 'Draw';
    if (obj.type === 'line') return 'Line';
    return obj.type || 'Object';
  }

  function toHex(v) {
    if (!v) return '#ffffff';
    if (typeof v === 'string' && v.startsWith('#')) return v;
    if (typeof v === 'string' && v.startsWith('rgb')) {
      const m = v.match(/rgba?\((\d+),\s*(\d+),\s*(\d+)/i);
      if (!m) return '#ffffff';
      const r = Number(m[1]), g = Number(m[2]), b = Number(m[3]);
      return '#' + [r,g,b].map(n => n.toString(16).padStart(2,'0')).join('');
    }
    return '#ffffff';
  }

  function setActiveButton(btn){
    [toolSelect, toolText, toolEraser, toolBrush, toolPen, toolSpray, toolMagic].forEach(b => b.classList.remove('active'));
    if (btn) btn.classList.add('active');
  }

  function cancelLinePreview() {
    lineStart = null;
    if (linePreview) {
      canvas.remove(linePreview);
      linePreview = null;
      canvas.requestRenderAll();
    }
  }

  function setMode(next) {
    mode = next;
    modeChip.textContent = `MODE: ${next.toUpperCase()}`;

    // reset
    canvas.isDrawingMode = false;
    canvas.selection = true;
    canvas.defaultCursor = 'default';
    eraserBrush = null;
    drawBrush = null;
    rasterEraserActive = false;

    // Cancel line preview when leaving pen mode
    if (mode !== 'pen') cancelLinePreview();

    if (mode === 'select') {
      hintChip.textContent = 'Drag • Resize • Rotate';
      setActiveButton(toolSelect);
      setStatus('Select mode.');
      return;
    }

    if (mode === 'text') {
      hintChip.textContent = 'Click to add text';
      setActiveButton(toolText);
      setStatus('Text tool armed. Click canvas to place.');
      return;
    }

    if (mode === 'eraser') {
      hintChip.textContent = 'Paint to erase';
      setActiveButton(toolEraser);

      canvas.selection = false;
      if (fabric.EraserBrush) {
        canvas.isDrawingMode = true;
        eraserBrush = new fabric.EraserBrush(canvas);
        eraserBrush.width = Number(eraserSize.value);
        canvas.freeDrawingBrush = eraserBrush;
        setStatus('Object eraser mode. Paint over objects to erase.');
      } else {
        canvas.isDrawingMode = false;
        canvas.defaultCursor = 'crosshair';
        rasterEraserActive = true;
        setStatus('Raster eraser: select an image layer, then paint to erase pixels.');
      }
      return;
    }

    if (mode === 'brush' || mode === 'spray') {
      hintChip.textContent = 'Draw on canvas';
      setActiveButton(mode === 'brush' ? toolBrush : toolSpray);

      canvas.isDrawingMode = true;
      canvas.selection = false;

      if (mode === 'spray') {
        drawBrush = new fabric.SprayBrush(canvas);
        drawBrush.density = 25;
        drawBrush.dotWidth = 1;
        drawBrush.dotWidthVariance = 2;
      } else {
        drawBrush = new fabric.PencilBrush(canvas);
        drawBrush.decimate = 8;
      }

      drawBrush.color = brushColor.value;
      drawBrush.width = Number(brushSize.value);
      drawBrush.strokeLineCap = 'round';
      drawBrush.strokeLineJoin = 'round';
      canvas.freeDrawingBrush = drawBrush;

      setStatus(`${mode.toUpperCase()} mode. Draw on the canvas.`);
      return;
    }

    if (mode === 'pen') {
      hintChip.textContent = 'Click start, click end';
      setActiveButton(toolPen);

      canvas.isDrawingMode = false;
      canvas.selection = false;

      cancelLinePreview();
      setStatus('Pen (Line) tool armed. Click start point, then click end point.');
      return;
    }

    if (mode === 'magic') {
      hintChip.textContent = 'Select an image then click background';
      setActiveButton(toolMagic);
      canvas.isDrawingMode = false;
      canvas.selection = false;
      setStatus('Magic eraser armed. Select an image layer, then click the background area.');
      return;
    }
  }

  function refreshLayers() {
    layersEl.innerHTML = '';
    const objs = canvas.getObjects();
    const active = activeObj();

    [...objs].reverse().forEach((obj, idxFromTop) => {
      const idx = objs.length - 1 - idxFromTop;
      const item = document.createElement('div');
      item.className = 'layer-item' + (obj === active ? ' active' : '');

      const left = document.createElement('div');
      left.className = 'layer-title';
      const b = document.createElement('b');
      b.textContent = obj.name || `${objectLabel(obj)} ${idx+1}`;
      const span = document.createElement('span');
      span.textContent = `type=${obj.type} • op=${Math.round((obj.opacity ?? 1)*100)}%`;
      left.appendChild(b);
      left.appendChild(span);

      const actions = document.createElement('div');
      actions.className = 'layer-actions';

      const btnHide = document.createElement('button');
      btnHide.className = 'iconbtn';
      btnHide.textContent = (obj.visible === false) ? '👁‍🗨' : '👁';
      btnHide.title = 'Toggle visibility';
      btnHide.onclick = (e) => {
        e.stopPropagation();
        obj.visible = !(obj.visible !== false);
        canvas.requestRenderAll();
        refreshLayers();
      };

      const btnLock = document.createElement('button');
      btnLock.className = 'iconbtn';
      btnLock.textContent = (obj.selectable === false) ? '🔒' : '🔓';
      btnLock.title = 'Toggle lock';
      btnLock.onclick = (e) => {
        e.stopPropagation();
        const locked = (obj.selectable === false);
        if (locked) {
          obj.selectable = true;
          obj.evented = true;
        } else {
          obj.selectable = false;
          obj.evented = false;
          if (obj === activeObj()) canvas.discardActiveObject();
        }
        canvas.requestRenderAll();
        refreshLayers();
        refreshProps();
      };

      const btnDel = document.createElement('button');
      btnDel.className = 'iconbtn bad';
      btnDel.textContent = '🗑';
      btnDel.title = 'Delete layer';
      btnDel.onclick = (e) => {
        e.stopPropagation();
        canvas.remove(obj);
        canvas.requestRenderAll();
        refreshLayers();
        refreshProps();
      };

      actions.appendChild(btnHide);
      actions.appendChild(btnLock);
      actions.appendChild(btnDel);

      item.appendChild(left);
      item.appendChild(actions);

      item.ondblclick = (e) => {
        if (e.target.closest('button')) return;
        const next = prompt('Layer name', obj.name || objectLabel(obj));
        if (next && next.trim()) { obj.name = next.trim().slice(0, 80); refreshLayers(); scheduleHistory(); setStatus('Layer renamed.'); }
      };

      item.onclick = () => {
        if (obj.selectable === false) return;
        canvas.setActiveObject(obj);
        canvas.requestRenderAll();
        refreshLayers();
        refreshProps();
      };

      layersEl.appendChild(item);
    });
  }

  function refreshProps() {
    const obj = activeObj();
    if (!obj) {
      selHint.textContent = 'Nothing selected.';
      propsArea.hidden = true;
      selectionType.textContent = 'No selection';
      imageProps.hidden = true;
      return;
    }

    selHint.textContent = `${objectLabel(obj)} selected.`;
    propsArea.hidden = false;
    selectionType.textContent = objectLabel(obj);

    const op = Math.round((obj.opacity ?? 1) * 100);
    opacity.value = op;
    opacityRead.textContent = `${op}%`;

    const isText = isTextObj(obj);
    textProps.hidden = !isText;

    const showShape = isShapeLike(obj);
    shapeProps.hidden = !showShape;

    const isImage = obj.type === 'image';
    imageProps.hidden = !isImage;
    if (isImage) {
      const state = Object.assign({brightness:0,contrast:0,saturation:0,blur:0,grayscale:false,sepia:false}, obj.fenixFilterState || {});
      brightness.value = Math.round(state.brightness || 0); contrast.value = Math.round(state.contrast || 0); saturation.value = Math.round(state.saturation || 0); imageBlur.value = Math.round(state.blur || 0);
      grayscale.checked = Boolean(state.grayscale); sepia.checked = Boolean(state.sepia);
      brightnessRead.textContent = brightness.value; contrastRead.textContent = contrast.value; saturationRead.textContent = saturation.value; imageBlurRead.textContent = imageBlur.value;
    }

    if (showShape) {
      // Lines/paths may not have fill; default to black for picker
      shapeFill.value = obj.fill ? toHex(obj.fill) : '#000000';
      shapeStroke.value = obj.stroke ? toHex(obj.stroke) : '#000000';
      shapeStrokeW.value = Math.round(obj.strokeWidth || 0);
    }

    if (isText) {
      textValue.value = obj.text || '';
      fontFamily.value = obj.fontFamily || 'Arial';
      fontSize.value = Math.round(obj.fontSize || 72);
      fillColor.value = toHex(obj.fill || '#ffffff');
      strokeColor.value = toHex(obj.stroke || '#000000');
      strokeWidth.value = Math.round(obj.strokeWidth || 0);

      if (obj.shadow && typeof obj.shadow === 'object') {
        fxColor.value = toHex(obj.shadow.color || '#00ffff');
        fxBlur.value = Number(obj.shadow.blur || 25);
        fxOffX.value = Number(obj.shadow.offsetX || 0);
        fxOffY.value = Number(obj.shadow.offsetY || 0);
      }
    }
  }

  function applyShadow(type){
    const obj = activeObj();
    if (!isTextObj(obj)) return;

    const color = fxColor.value;
    const blur = Number(fxBlur.value) || 0;
    const offX = Number(fxOffX.value) || 0;
    const offY = Number(fxOffY.value) || 0;

    if (type === 'off'){
      obj.set('shadow', null);
    } else if (type === 'drop'){
      obj.set('shadow', new fabric.Shadow({ color, blur, offsetX: offX, offsetY: offY, affectStroke: false }));
    } else if (type === 'glow'){
      obj.set('shadow', new fabric.Shadow({ color, blur, offsetX: 0, offsetY: 0, affectStroke: false }));
    }

    canvas.requestRenderAll();
    refreshLayers();
    refreshProps();
    setStatus('Text FX updated.');
  }

  // Magic eraser helpers (no AI)
  async function getImagePixels(fabricImg) {
    const el = fabricImg.getElement();
    if (!el) throw new Error('Image element not available');

    const w = el.naturalWidth || el.width;
    const h = el.naturalHeight || el.height;

    const tmp = document.createElement('canvas');
    tmp.width = w;
    tmp.height = h;

    const ctx = tmp.getContext('2d', { willReadFrequently: true });
    ctx.drawImage(el, 0, 0);

    const imgData = ctx.getImageData(0, 0, w, h);
    return { w, h, imgData, ctx };
  }

  function magicFloodFill(imgData, w, h, startX, startY, tol) {
    const data = imgData.data;
    const idx0 = (startY * w + startX) * 4;
    const r0 = data[idx0], g0 = data[idx0 + 1], b0 = data[idx0 + 2], a0 = data[idx0 + 3];
    if (a0 === 0) return 0;

    const visited = new Uint8Array(w * h);
    const qx = new Int32Array(w * h);
    const qy = new Int32Array(w * h);
    let qs = 0, qe = 0;

    qx[qe] = startX;
    qy[qe] = startY;
    visited[startY * w + startX] = 1;
    qe++;

    let cleared = 0;
    const within = (r,g,b,a) => (Math.abs(r - r0) + Math.abs(g - g0) + Math.abs(b - b0)) <= tol * 3;

    while (qs < qe) {
      const x = qx[qs];
      const y = qy[qs];
      qs++;

      const i = (y * w + x) * 4;
      const r = data[i], g = data[i+1], b = data[i+2], a = data[i+3];

      if (a !== 0 && within(r,g,b,a)) {
        data[i+3] = 0;
        cleared++;

        if (x > 0) {
          const p = y * w + (x-1);
          if (!visited[p]) { visited[p] = 1; qx[qe] = x-1; qy[qe] = y; qe++; }
        }
        if (x < w-1) {
          const p = y * w + (x+1);
          if (!visited[p]) { visited[p] = 1; qx[qe] = x+1; qy[qe] = y; qe++; }
        }
        if (y > 0) {
          const p = (y-1) * w + x;
          if (!visited[p]) { visited[p] = 1; qx[qe] = x; qy[qe] = y-1; qe++; }
        }
        if (y < h-1) {
          const p = (y+1) * w + x;
          if (!visited[p]) { visited[p] = 1; qx[qe] = x; qy[qe] = y+1; qe++; }
        }
      }
    }
    return cleared;
  }

  function featherAlpha(imgData, w, h, radius) {
    if (!radius) return;
    const data = imgData.data;
    const copy = new Uint8ClampedArray(data);
    const r = radius;

    for (let y = 0; y < h; y++) {
      for (let x = 0; x < w; x++) {
        let sum = 0, count = 0;
        for (let oy = -r; oy <= r; oy++) {
          const yy = y + oy;
          if (yy < 0 || yy >= h) continue;
          for (let ox = -r; ox <= r; ox++) {
            const xx = x + ox;
            if (xx < 0 || xx >= w) continue;
            const j = (yy*w + xx) * 4;
            sum += copy[j+3];
            count++;
          }
        }
        const i = (y*w + x) * 4;
        data[i+3] = Math.round(sum / count);
      }
    }
  }

  function addImageFromBlob(blob, name, center=true) {
    const reader = new FileReader();
    reader.onerror = () => setStatus('Could not read that image.');
    reader.onload = () => {
      fabric.Image.fromURL(String(reader.result || ''), (img) => {
        const maxW = canvas.getWidth() * 0.75;
        const maxH = canvas.getHeight() * 0.75;
        const scale = Math.min(maxW / img.width, maxH / img.height, 1);
        img.set({
          left: center ? canvas.getWidth()/2 : 100,
          top: center ? canvas.getHeight()/2 : 100,
          originX: center ? 'center' : 'left',
          originY: center ? 'center' : 'top',
          scaleX: scale,
          scaleY: scale,
          name: name || 'Image',
          fenixFilterState: { brightness:0, contrast:0, saturation:0, blur:0, grayscale:false, sepia:false }
        });
        canvas.add(img);
        canvas.setActiveObject(img);
        canvas.requestRenderAll();
        refreshLayers();
        refreshProps();
        setStatus(`Added image: ${img.name}`);
      }, { crossOrigin: 'anonymous' });
    };
    reader.readAsDataURL(blob);
  }

  // Buttons
  toolSelect.onclick = () => setMode('select');
  toolText.onclick = () => setMode('text');
  toolEraser.onclick = () => setMode('eraser');
  toolBrush.onclick = () => setMode('brush');
  toolPen.onclick = () => setMode('pen');
  toolSpray.onclick = () => setMode('spray');
  toolMagic.onclick = () => setMode(mode === 'magic' ? 'select' : 'magic');

  // Sliders reads + apply
  magicTol.addEventListener('input', () => magicTolRead.textContent = `${magicTol.value}`);
  magicFeather.addEventListener('input', () => magicFeatherRead.textContent = `${magicFeather.value}`);

  brushSize.addEventListener('input', () => {
    brushSizeRead.textContent = `${brushSize.value} px`;
    if (drawBrush) drawBrush.width = Number(brushSize.value);
  });
  brushColor.addEventListener('input', () => {
    if (drawBrush) drawBrush.color = brushColor.value;
  });
  brushSoft.addEventListener('input', () => brushSoftRead.textContent = `${brushSoft.value}`);

  // Shapes with current shape fill/stroke defaults
  document.getElementById('addRect').onclick = () => {
    const r = new fabric.Rect({
      left: 120, top: 120, width: 360, height: 220,
      fill: shapeFill.value,
      stroke: shapeStroke.value,
      strokeWidth: Number(shapeStrokeW.value) || 4,
      rx: 16, ry: 16,
      name: 'Rectangle'
    });
    canvas.add(r);
    canvas.setActiveObject(r);
    canvas.requestRenderAll();
    refreshLayers();
    refreshProps();
    setStatus('Rectangle added.');
  };

  document.getElementById('addCircle').onclick = () => {
    const c = new fabric.Circle({
      left: 200, top: 200, radius: 140,
      fill: shapeFill.value,
      stroke: shapeStroke.value,
      strokeWidth: Number(shapeStrokeW.value) || 4,
      name: 'Circle'
    });
    canvas.add(c);
    canvas.setActiveObject(c);
    canvas.requestRenderAll();
    refreshLayers();
    refreshProps();
    setStatus('Circle added.');
  };

  document.getElementById('addTriangle').onclick = () => {
    const t = new fabric.Triangle({
      left: 220, top: 170, width: 280, height: 250,
      fill: shapeFill.value, stroke: shapeStroke.value,
      strokeWidth: Number(shapeStrokeW.value) || 4,
      name: 'Triangle'
    });
    canvas.add(t); canvas.setActiveObject(t); canvas.requestRenderAll();
    refreshLayers(); refreshProps(); setStatus('Triangle added.');
  };

  // Eraser size
  eraserSize.addEventListener('input', () => {
    eraserSizeRead.textContent = `${eraserSize.value} px`;
    if (eraserBrush) eraserBrush.width = Number(eraserSize.value);
  });

  // Import image as layer (hidden input + label trigger)
  document.getElementById('fileInput').addEventListener('change', async (e) => {
    const file = e.target.files?.[0];
    e.target.value = '';
    if (!file) return;
    addImageFromBlob(file, file.name, true);
  });

  // Paste image from clipboard (Ctrl+V)
  window.addEventListener('paste', async (e) => {
    const items = e.clipboardData?.items;
    if (!items) return;

    for (const it of items) {
      if (it.type && it.type.startsWith('image/')) {
        const file = it.getAsFile();
        if (!file) continue;
        addImageFromBlob(file, 'Clipboard Image', true);
        e.preventDefault();
        return;
      }
    }
  });

  // Drag and drop images onto canvas
  const dropEl = canvas.upperCanvasEl;
  dropEl.addEventListener('dragover', (e) => e.preventDefault());
  dropEl.addEventListener('drop', (e) => {
    e.preventDefault();
    const file = e.dataTransfer?.files?.[0];
    if (!file || !file.type.startsWith('image/')) return;
    addImageFromBlob(file, file.name || 'Dropped Image', true);
  });

  // Selection hooks
  canvas.on('selection:created', () => { refreshLayers(); refreshProps(); });
  canvas.on('selection:updated', () => { refreshLayers(); refreshProps(); });
  canvas.on('selection:cleared', () => { refreshLayers(); refreshProps(); });

  canvas.on('erasing:end', () => {
    canvas.requestRenderAll();
    refreshLayers();
    refreshProps();
    setStatus('Erased.');
  });

  // Path creation: name + Glow via shadow blur (applies to all drawn paths)
  canvas.on('path:created', () => {
    const p = canvas.getObjects().at(-1);
    if (!p) return;
    p.name = 'Draw';
    p.set('strokeLineCap', 'round');
    p.set('strokeLineJoin', 'round');

    const glow = Number(brushSoft.value) || 0;
    if (glow > 0) {
      const col = p.stroke || '#ffffff';
      p.set('shadow', new fabric.Shadow({ color: col, blur: glow, offsetX: 0, offsetY: 0 }));
    } else {
      p.set('shadow', null);
    }

    refreshLayers();
    refreshProps();
  });

  // Pen line preview updates
  canvas.on('mouse:move', (opt) => {
    if (mode !== 'pen') return;
    if (!lineStart || !linePreview) return;
    const p = canvas.getPointer(opt.e);
    linePreview.set({ x2: p.x, y2: p.y });
    linePreview.setCoords();
    canvas.requestRenderAll();
  });

  // Properties bindings
  opacity.addEventListener('input', () => {
    const obj = activeObj();
    if (!obj) return;
    const v = Number(opacity.value);
    obj.set('opacity', v / 100);
    opacityRead.textContent = `${v}%`;
    canvas.requestRenderAll();
    refreshLayers();
  });

  // Shape props (also covers Line)
  shapeFill.addEventListener('input', () => {
    const obj = activeObj();
    if (!obj || !isShapeLike(obj)) return;
    obj.set('fill', shapeFill.value);
    canvas.requestRenderAll();
    refreshLayers();
  });

  shapeStroke.addEventListener('input', () => {
    const obj = activeObj();
    if (!obj || !isShapeLike(obj)) return;
    obj.set('stroke', shapeStroke.value);
    canvas.requestRenderAll();
    refreshLayers();
  });

  shapeStrokeW.addEventListener('input', () => {
    const obj = activeObj();
    if (!obj || !isShapeLike(obj)) return;
    obj.set('strokeWidth', Number(shapeStrokeW.value) || 0);
    canvas.requestRenderAll();
    refreshLayers();
  });

  // Rasterize selected vector
  rasterizeSelectedBtn.onclick = () => {
    const obj = activeObj();
    if (!obj) return;
    if (obj.type === 'image') { setStatus('Already an image layer.'); return; }

    const dataUrl = obj.toDataURL({ format: 'png', multiplier: 1 });

    fabric.Image.fromURL(dataUrl, (img) => {
      img.set({
        left: obj.left,
        top: obj.top,
        originX: obj.originX,
        originY: obj.originY,
        angle: obj.angle,
        scaleX: obj.scaleX,
        scaleY: obj.scaleY,
        name: (obj.name || objectLabel(obj)) + ' (raster)'
      });

      canvas.remove(obj);
      canvas.add(img);
      canvas.setActiveObject(img);
      canvas.requestRenderAll();
      refreshLayers();
      refreshProps();
      setStatus('Rasterized to image layer.');
    }, { crossOrigin: 'anonymous' });
  };

  // Text props
  textValue.addEventListener('input', () => {
    const obj = activeObj();
    if (!isTextObj(obj)) return;
    obj.text = textValue.value;
    canvas.requestRenderAll();
    refreshLayers();
  });

  fontFamily.addEventListener('change', () => {
    const obj = activeObj();
    if (!isTextObj(obj)) return;
    obj.fontFamily = fontFamily.value;
    canvas.requestRenderAll();
  });

  fontSize.addEventListener('input', () => {
    const obj = activeObj();
    if (!isTextObj(obj)) return;
    obj.fontSize = Number(fontSize.value);
    canvas.requestRenderAll();
  });

  fillColor.addEventListener('input', () => {
    const obj = activeObj();
    if (!isTextObj(obj)) return;
    obj.fill = fillColor.value;
    canvas.requestRenderAll();
  });

  strokeColor.addEventListener('input', () => {
    const obj = activeObj();
    if (!isTextObj(obj)) return;
    obj.stroke = strokeColor.value;
    canvas.requestRenderAll();
  });

  strokeWidth.addEventListener('input', () => {
    const obj = activeObj();
    if (!isTextObj(obj)) return;
    obj.strokeWidth = Number(strokeWidth.value);
    canvas.requestRenderAll();
  });

  shadowOff.onclick = () => applyShadow('off');
  shadowOn.onclick = () => applyShadow('drop');
  glowOff.onclick = () => applyShadow('off');
  glowOn.onclick = () => applyShadow('glow');

  // Canvas size
  document.getElementById('applyCanvasSize').onclick = () => {
    const w = Math.max(64, Math.min(8000, Number(cw.value) || 1200));
    const h = Math.max(64, Math.min(8000, Number(ch.value) || 800));
    canvas.setWidth(w);
    canvas.setHeight(h);
    canvas.requestRenderAll();
    updateCanvasSizeChip();
    setViewZoom(1); fitCanvasToView(); scheduleHistory(); setStatus(`Canvas resized to ${w}×${h}.`);
  };

  document.getElementById('fitView').onclick = () => {
    const obj = activeObj();
    if (!obj) { setStatus('Nothing selected.'); return; }
    obj.center();
    obj.setCoords();
    canvas.requestRenderAll();
    setStatus('Centered selected object.');
  };

  // Deselect / delete
  document.getElementById('clearSelection').onclick = () => {
    canvas.discardActiveObject();
    canvas.requestRenderAll();
    refreshLayers();
    refreshProps();
  };

  document.getElementById('deleteSelected').onclick = () => {
    const obj = activeObj();
    if (!obj) return;
    canvas.remove(obj);
    canvas.discardActiveObject();
    canvas.requestRenderAll();
    refreshLayers();
    refreshProps();
    setStatus('Deleted.');
  };

  function downloadUrl(url, filename) {
    const a = document.createElement('a'); a.href = url; a.download = filename;
    document.body.appendChild(a); a.click(); a.remove();
  }
  function baseFilename(ext) { return `fenix_image_${canvas.getWidth()}x${canvas.getHeight()}.${ext}`; }
  function exportRaster(format) {
    canvas.discardActiveObject(); canvas.requestRenderAll();
    const multiplier = Number(document.getElementById('exportScale').value) || 1;
    const quality = Number(document.getElementById('jpgQuality').value) || .85;
    const priorBg = canvas.backgroundColor;
    if (format === 'jpeg' && !priorBg) { canvas.backgroundColor = '#ffffff'; canvas.renderAll(); }
    const url = canvas.toDataURL({ format, quality, multiplier, enableRetinaScaling:false });
    if (format === 'jpeg' && !priorBg) { canvas.backgroundColor = null; canvas.renderAll(); }
    downloadUrl(url, baseFilename(format === 'jpeg' ? 'jpg' : 'png'));
    setStatus(`Exported ${format === 'jpeg' ? 'JPG' : 'PNG'} at ${multiplier}×.`);
  }
  document.getElementById('exportPNG').onclick = () => exportRaster('png');
  document.getElementById('exportJPG').onclick = () => exportRaster('jpeg');
  document.getElementById('exportSVG').onclick = () => {
    canvas.discardActiveObject(); canvas.requestRenderAll();
    const blob = new Blob([canvas.toSVG()], { type:'image/svg+xml;charset=utf-8' });
    const url = URL.createObjectURL(blob); downloadUrl(url, baseFilename('svg')); setTimeout(()=>URL.revokeObjectURL(url), 1000);
    setStatus('Exported SVG.');
  };

  // Layer ordering
  document.getElementById('layerUp').onclick = () => {
    const obj = activeObj();
    if (!obj) return;
    canvas.bringForward(obj);
    canvas.requestRenderAll();
    refreshLayers(); scheduleHistory();
  };
  document.getElementById('layerDown').onclick = () => {
    const obj = activeObj();
    if (!obj) return;
    canvas.sendBackwards(obj);
    canvas.requestRenderAll();
    refreshLayers(); scheduleHistory();
  };

  // MAIN mouse down handler (text + pen line + magic)
  canvas.on('mouse:down', async (opt) => {
    // Pen = Line tool
    if (mode === 'pen') {
      const p = canvas.getPointer(opt.e);

      if (!lineStart) {
        lineStart = { x: p.x, y: p.y };

        linePreview = new fabric.Line([p.x, p.y, p.x, p.y], {
          stroke: brushColor.value,
          strokeWidth: Number(brushSize.value) || 2,
          strokeLineCap: 'round',
          strokeLineJoin: 'round',
          selectable: false,
          evented: false,
          name: 'Line'
        });

        canvas.add(linePreview);
        canvas.requestRenderAll();
        setStatus('Line start set. Click end point.');
        return;
      }

      // second click finalize
      linePreview.set({
        x2: p.x,
        y2: p.y,
        selectable: true,
        evented: true
      });
      linePreview.setCoords();
      canvas.setActiveObject(linePreview);

      lineStart = null;
      linePreview = null;

      canvas.requestRenderAll();
      refreshLayers();
      refreshProps();
      setStatus('Line created.');
      return;
    }

    // Text tool
    if (mode === 'text') {
      const p = canvas.getPointer(opt.e);
      const t = new fabric.IText('Type here', {
        left: p.x,
        top: p.y,
        fontFamily: 'Montserrat',
        fontSize: 72,
        fill: '#ffffff',
        strokeWidth: 0,
        stroke: '#000000',
        name: 'Text',
        originX: 'left',
        originY: 'top'
      });
      canvas.add(t);
      canvas.setActiveObject(t);
      canvas.requestRenderAll();
      refreshLayers();
      refreshProps();
      t.enterEditing();
      t.selectAll();
      setStatus('Text added.');
      return;
    }

    // Magic eraser click
    if (mode === 'magic') {
      const obj = activeObj();
      if (!obj || obj.type !== 'image') {
        alert('Select an Image layer first.');
        return;
      }
      if (opt.target !== obj) return;

      try {
        setStatus('Magic erasing...');

        const p = canvas.getPointer(opt.e);
        const inv = fabric.util.invertTransform(obj.calcTransformMatrix());
        const lp = fabric.util.transformPoint(new fabric.Point(p.x, p.y), inv);

        const el = obj.getElement();
        const iw = el.naturalWidth || el.width;
        const ih = el.naturalHeight || el.height;

        const ox = (obj.originX === 'center') ? iw/2 : 0;
        const oy = (obj.originY === 'center') ? ih/2 : 0;

        const px = Math.floor(lp.x + ox);
        const py = Math.floor(lp.y + oy);

        if (px < 0 || py < 0 || px >= iw || py >= ih) return;

        const { imgData, ctx } = await getImagePixels(obj);

        const tol = Number(magicTol.value);
        const cleared = magicFloodFill(imgData, iw, ih, px, py, tol);

        const feather = Number(magicFeather.value);
        if (feather > 0) featherAlpha(imgData, iw, ih, feather);

        ctx.putImageData(imgData, 0, 0);

        const outUrl = ctx.canvas.toDataURL('image/png');
        fabric.Image.fromURL(outUrl, (newImg) => {
          newImg.set({
            left: obj.left,
            top: obj.top,
            originX: obj.originX,
            originY: obj.originY,
            angle: obj.angle,
            scaleX: obj.scaleX,
            scaleY: obj.scaleY,
            name: (obj.name || 'Image') + ' (magic)'
          });

          canvas.remove(obj);
          canvas.add(newImg);
          canvas.setActiveObject(newImg);
          canvas.requestRenderAll();
          refreshLayers();
          refreshProps();

          setStatus(`Magic erased. Cleared pixels: ${cleared}`);
        }, { crossOrigin: 'anonymous' });

      } catch (err) {
        console.error(err);
        alert('Magic eraser failed on this image.');
        setStatus('Magic eraser failed.');
      }
    }
  });

  function imageLocalPoint(obj, pointer) {
    const inv = fabric.util.invertTransform(obj.calcTransformMatrix());
    const lp = fabric.util.transformPoint(new fabric.Point(pointer.x, pointer.y), inv);
    const el = obj.getElement();
    const iw = el.naturalWidth || el.width, ih = el.naturalHeight || el.height;
    const ox = obj.originX === 'center' ? iw/2 : (obj.originX === 'right' ? iw : 0);
    const oy = obj.originY === 'center' ? ih/2 : (obj.originY === 'bottom' ? ih : 0);
    return { x:lp.x + ox, y:lp.y + oy, iw, ih };
  }
  function beginRasterErase(opt) {
    if (!rasterEraserActive) return;
    const obj = activeObj();
    if (!obj || obj.type !== 'image') { setStatus('Select an image layer before using the eraser.'); return; }
    const el = obj.getElement(); const iw = el.naturalWidth || el.width, ih = el.naturalHeight || el.height;
    rasterEraseSurface = document.createElement('canvas'); rasterEraseSurface.width = iw; rasterEraseSurface.height = ih;
    rasterEraseCtx = rasterEraseSurface.getContext('2d'); rasterEraseCtx.drawImage(el, 0, 0, iw, ih);
    rasterEraseCtx.globalCompositeOperation = 'destination-out'; rasterEraseCtx.lineCap = 'round'; rasterEraseCtx.lineJoin = 'round';
    rasterEraseObj = obj; rasterEraseDrawing = true; rasterEraseLast = null;
    continueRasterErase(opt);
  }
  function continueRasterErase(opt) {
    if (!rasterEraseDrawing || !rasterEraseObj || !rasterEraseCtx) return;
    const pointer = canvas.getPointer(opt.e); const p = imageLocalPoint(rasterEraseObj, pointer);
    const scale = rasterEraseObj.getTotalObjectScaling ? rasterEraseObj.getTotalObjectScaling() : {x:rasterEraseObj.scaleX||1,y:rasterEraseObj.scaleY||1};
    const width = Math.max(1, Number(eraserSize.value) / Math.max(.01, (Math.abs(scale.x)+Math.abs(scale.y))/2));
    rasterEraseCtx.lineWidth = width;
    rasterEraseCtx.beginPath();
    if (rasterEraseLast) { rasterEraseCtx.moveTo(rasterEraseLast.x, rasterEraseLast.y); rasterEraseCtx.lineTo(p.x, p.y); }
    else { rasterEraseCtx.arc(p.x, p.y, width/2, 0, Math.PI*2); }
    rasterEraseCtx.stroke(); rasterEraseCtx.fill(); rasterEraseLast = p;
    rasterEraseObj.setElement(rasterEraseSurface); rasterEraseObj.dirty = true; canvas.requestRenderAll();
  }
  function finishRasterErase() {
    if (!rasterEraseDrawing || !rasterEraseObj || !rasterEraseSurface) return;
    const old = rasterEraseObj; const dataUrl = rasterEraseSurface.toDataURL('image/png');
    const props = { left:old.left, top:old.top, originX:old.originX, originY:old.originY, angle:old.angle, scaleX:old.scaleX, scaleY:old.scaleY, skewX:old.skewX, skewY:old.skewY, flipX:old.flipX, flipY:old.flipY, opacity:old.opacity, name:old.name || 'Image', fenixFilterState:old.fenixFilterState || null };
    fabric.Image.fromURL(dataUrl, (img) => {
      img.set(props); canvas.remove(old); canvas.add(img); canvas.setActiveObject(img); applyImageFilters(img, false);
      canvas.requestRenderAll(); refreshLayers(); refreshProps(); scheduleHistory(); setStatus('Image pixels erased.');
    });
    rasterEraseDrawing=false; rasterEraseObj=null; rasterEraseSurface=null; rasterEraseCtx=null; rasterEraseLast=null;
  }
  canvas.on('mouse:down', beginRasterErase);
  canvas.on('mouse:move', continueRasterErase);
  canvas.on('mouse:up', finishRasterErase);

  function selectedClone() {
    const obj = activeObj(); if (!obj) { setStatus('Nothing selected.'); return; }
    obj.clone((clone) => {
      clone.set({ left:(obj.left || 0)+24, top:(obj.top || 0)+24, name:(obj.name || objectLabel(obj))+' copy' });
      if (clone.type === 'activeSelection') { clone.canvas = canvas; clone.forEachObject(o=>canvas.add(o)); clone.setCoords(); }
      else canvas.add(clone);
      canvas.setActiveObject(clone); canvas.requestRenderAll(); refreshLayers(); refreshProps(); scheduleHistory(); setStatus('Duplicated selection.');
    }, ['name','selectable','evented','fenixFilterState']);
  }
  document.getElementById('duplicateSelected').onclick = selectedClone;
  document.getElementById('groupSelected').onclick = () => {
    const obj=activeObj(); if(!obj || obj.type!=='activeSelection'){setStatus('Select multiple objects to group.');return;}
    const group=obj.toGroup(); group.name='Group'; canvas.setActiveObject(group); canvas.requestRenderAll(); refreshLayers(); refreshProps(); scheduleHistory(); setStatus('Grouped selection.');
  };
  document.getElementById('ungroupSelected').onclick = () => {
    const obj=activeObj(); if(!obj || obj.type!=='group'){setStatus('Select a group to ungroup.');return;}
    const selection=obj.toActiveSelection(); canvas.setActiveObject(selection); canvas.requestRenderAll(); refreshLayers(); refreshProps(); scheduleHistory(); setStatus('Ungrouped selection.');
  };
  function modifyActive(fn, message){ const obj=activeObj(); if(!obj){setStatus('Nothing selected.');return;} fn(obj); obj.setCoords(); canvas.requestRenderAll(); refreshLayers(); refreshProps(); scheduleHistory(); setStatus(message); }
  document.getElementById('rotateLeft').onclick=()=>modifyActive(o=>o.rotate((o.angle||0)-90),'Rotated left.');
  document.getElementById('rotateRight').onclick=()=>modifyActive(o=>o.rotate((o.angle||0)+90),'Rotated right.');
  document.getElementById('flipH').onclick=()=>modifyActive(o=>o.set('flipX',!o.flipX),'Flipped horizontally.');
  document.getElementById('flipV').onclick=()=>modifyActive(o=>o.set('flipY',!o.flipY),'Flipped vertically.');
  document.getElementById('alignH').onclick=()=>modifyActive(o=>o.setPositionByOrigin(new fabric.Point(canvas.getWidth()/2,o.getCenterPoint().y),'center','center'),'Centred horizontally.');
  document.getElementById('alignV').onclick=()=>modifyActive(o=>o.setPositionByOrigin(new fabric.Point(o.getCenterPoint().x,canvas.getHeight()/2),'center','center'),'Centred vertically.');
  document.getElementById('layerFront').onclick=()=>modifyActive(o=>canvas.bringToFront(o),'Moved to front.');
  document.getElementById('layerBack').onclick=()=>modifyActive(o=>canvas.sendToBack(o),'Moved to back.');

  function applyImageFilters(obj=activeObj(), record=true) {
    if (!obj || obj.type !== 'image') return;
    const state = Object.assign({brightness:0,contrast:0,saturation:0,blur:0,grayscale:false,sepia:false}, obj.fenixFilterState || {});
    if (obj === activeObj()) {
      state.brightness=Number(brightness.value)||0; state.contrast=Number(contrast.value)||0; state.saturation=Number(saturation.value)||0; state.blur=Number(imageBlur.value)||0; state.grayscale=grayscale.checked; state.sepia=sepia.checked;
    }
    const F=fabric.Image.filters, filters=[];
    if(state.brightness) filters.push(new F.Brightness({brightness:state.brightness/100}));
    if(state.contrast) filters.push(new F.Contrast({contrast:state.contrast/100}));
    if(state.saturation) filters.push(new F.Saturation({saturation:state.saturation/100}));
    if(state.blur && F.Blur) filters.push(new F.Blur({blur:state.blur/100}));
    if(state.grayscale) filters.push(new F.Grayscale());
    if(state.sepia) filters.push(new F.Sepia());
    obj.filters=filters; obj.fenixFilterState=state; obj.applyFilters(); obj.dirty=true; canvas.requestRenderAll();
    brightnessRead.textContent=state.brightness; contrastRead.textContent=state.contrast; saturationRead.textContent=state.saturation; imageBlurRead.textContent=state.blur;
    if(record) scheduleHistory();
  }
  [brightness,contrast,saturation,imageBlur].forEach(el=>el.addEventListener('input',()=>applyImageFilters()));
  [grayscale,sepia].forEach(el=>el.addEventListener('change',()=>applyImageFilters()));
  document.getElementById('resetFilters').onclick=()=>{ brightness.value=contrast.value=saturation.value=imageBlur.value=0; grayscale.checked=sepia.checked=false; applyImageFilters(); refreshProps(); setStatus('Image adjustments reset.'); };

  function setViewZoom(next) {
    viewZoom=Math.max(.1,Math.min(4,Number(next)||1));
    const w=Math.round(canvas.getWidth()*viewZoom), h=Math.round(canvas.getHeight()*viewZoom);
    [canvas.lowerCanvasEl,canvas.upperCanvasEl,canvas.wrapperEl].forEach(el=>{ if(el){el.style.width=`${w}px`;el.style.height=`${h}px`;} });
    canvas.calcOffset(); zoomValue.textContent=`${Math.round(viewZoom*100)}%`;
  }
  function fitCanvasToView(){ const z=Math.min((canvasWrap.clientWidth-48)/canvas.getWidth(),(canvasWrap.clientHeight-48)/canvas.getHeight(),1); setViewZoom(Math.max(.1,z)); canvasWrap.scrollTo({left:0,top:0}); }
  document.getElementById('zoomOut').onclick=()=>setViewZoom(viewZoom-.1);
  document.getElementById('zoomIn').onclick=()=>setViewZoom(viewZoom+.1);
  document.getElementById('zoomFit').onclick=fitCanvasToView; zoomValue.onclick=fitCanvasToView;
  document.getElementById('checkerToggle').onclick=(e)=>{canvasWrap.classList.toggle('checkerboard');e.currentTarget.classList.toggle('active');};
  canvasWrap.addEventListener('wheel',(e)=>{if(!e.ctrlKey)return;e.preventDefault();setViewZoom(viewZoom+(e.deltaY<0?.1:-.1));},{passive:false});
  window.addEventListener('resize',()=>{ if(viewZoom<1) fitCanvasToView(); });

  const canvasPreset=document.getElementById('canvasPreset'), canvasBg=document.getElementById('canvasBg'), canvasTransparent=document.getElementById('canvasTransparent');
  canvasPreset.onchange=()=>{if(!canvasPreset.value)return;const [w,h]=canvasPreset.value.split('x').map(Number);cw.value=w;ch.value=h;document.getElementById('applyCanvasSize').click();};
  function applyCanvasBackground(record=true){ canvas.setBackgroundColor(canvasTransparent.checked?null:canvasBg.value,()=>canvas.requestRenderAll()); if(record)scheduleHistory(); }
  canvasBg.addEventListener('input',()=>{canvasTransparent.checked=false;applyCanvasBackground();}); canvasTransparent.addEventListener('change',()=>applyCanvasBackground());

  function saveProjectFile(){
    const payload={format:'fenix-image-project',version:1,width:canvas.getWidth(),height:canvas.getHeight(),backgroundColor:canvas.backgroundColor||null,canvas:canvas.toJSON(['name','selectable','evented','fenixFilterState'])};
    const blob=new Blob([JSON.stringify(payload,null,2)],{type:'application/json'});const url=URL.createObjectURL(blob);downloadUrl(url,`fenix_image_project_${canvas.getWidth()}x${canvas.getHeight()}.feniximg.json`);setTimeout(()=>URL.revokeObjectURL(url),1000);setStatus('Project saved.');
  }
  document.getElementById('saveProject').onclick=saveProjectFile;
  document.getElementById('openProject').onclick=()=>document.getElementById('projectInput').click();
  document.getElementById('projectInput').onchange=(e)=>{const file=e.target.files?.[0];e.target.value='';if(!file)return;const reader=new FileReader();reader.onload=()=>{try{const p=JSON.parse(reader.result);if(p.format!=='fenix-image-project'||!p.canvas)throw new Error('Not a Fenix Image Studio project');historyLock=true;canvas.setWidth(Number(p.width)||1200);canvas.setHeight(Number(p.height)||800);canvas.backgroundColor=p.backgroundColor||null;canvas.loadFromJSON(p.canvas,()=>{historyLock=false;canvas.renderAll();updateCanvasSizeChip();canvasTransparent.checked=!p.backgroundColor;if(p.backgroundColor)canvasBg.value=p.backgroundColor;refreshLayers();refreshProps();fitCanvasToView();resetHistory();setStatus(`Opened ${file.name}.`);});}catch(err){historyLock=false;alert(err.message||'Could not open project.');setStatus('Project open failed.');}};reader.readAsText(file);};
  document.getElementById('newProject').onclick=()=>{if(canvas.getObjects().length&&!confirm('Clear the current project and start a new one?'))return;historyLock=true;canvas.clear();canvas.setWidth(1200);canvas.setHeight(800);canvas.backgroundColor=null;canvasTransparent.checked=true;historyLock=false;updateCanvasSizeChip();fitCanvasToView();refreshLayers();refreshProps();resetHistory();setStatus('New project.');};

  // ESC cancels in-progress line, otherwise deselect
  window.addEventListener('keydown', (e) => {
    if (e.key === 'Escape' && mode === 'pen' && linePreview) {
      cancelLinePreview();
      setStatus('Line cancelled.');
      e.preventDefault();
      return;
    }
  });

  // Keyboard shortcuts
  function typingTarget(el){return el&&(el.matches?.('input,textarea,select')||el.isContentEditable);}
  window.addEventListener('keydown',(e)=>{
    if(typingTarget(e.target))return;
    const mod=e.ctrlKey||e.metaKey,k=e.key.toLowerCase();
    if(mod&&k==='s'){e.preventDefault();saveProjectFile();return;}
    if(mod&&k==='o'){e.preventDefault();document.getElementById('openProject').click();return;}
    if(mod&&k==='d'){e.preventDefault();selectedClone();return;}
    if(mod&&k==='g'&&!e.shiftKey){e.preventDefault();document.getElementById('groupSelected').click();return;}
    if(mod&&k==='g'&&e.shiftKey){e.preventDefault();document.getElementById('ungroupSelected').click();return;}
    if(mod&&k==='z'&&!e.shiftKey){e.preventDefault();undo();return;}
    if(mod&&(k==='y'||(k==='z'&&e.shiftKey))){e.preventDefault();redo();return;}
    if(e.key==='Delete'){document.getElementById('deleteSelected').click();return;}
    if(e.key==='Escape'){document.getElementById('clearSelection').click();return;}
    if(k==='v')setMode('select'); if(k==='t')setMode('text'); if(k==='e')setMode('eraser'); if(k==='b')setMode('brush'); if(k==='p')setMode('pen'); if(k==='s')setMode('spray'); if(k==='m')setMode(mode==='magic'?'select':'magic'); if(k==='f')document.getElementById('fitView').click();
  });

  // Bounded project history, including canvas size/background and portable image data.
  let history=[]; let histIndex=-1; let historyLock=false; let historyTimer=null; const historyLimit=18;
  function snapshot(){return{width:canvas.getWidth(),height:canvas.getHeight(),backgroundColor:canvas.backgroundColor||null,json:canvas.toJSON(['name','selectable','evented','fenixFilterState'])};}
  function snapshotKey(s){return JSON.stringify(s);}
  function updateHistoryButtons(){undoBtn.disabled=histIndex<=0;redoBtn.disabled=histIndex>=history.length-1;}
  function pushHistory(){
    if(historyLock)return; const snap=snapshot(),key=snapshotKey(snap); if(history[histIndex]?.key===key){updateHistoryButtons();return;}
    history=history.slice(0,histIndex+1);history.push({key,snap});if(history.length>historyLimit)history.shift();histIndex=history.length-1;updateHistoryButtons();
  }
  function scheduleHistory(){clearTimeout(historyTimer);historyTimer=setTimeout(pushHistory,140);}
  function loadHistory(index){
    if(index<0||index>=history.length)return;historyLock=true;const s=history[index].snap;canvas.setWidth(s.width);canvas.setHeight(s.height);canvas.backgroundColor=s.backgroundColor||null;
    canvas.loadFromJSON(s.json,()=>{historyLock=false;canvas.renderAll();updateCanvasSizeChip();canvasTransparent.checked=!s.backgroundColor;if(s.backgroundColor)canvasBg.value=s.backgroundColor;refreshLayers();refreshProps();setViewZoom(viewZoom);updateHistoryButtons();});
  }
  function undo(){if(histIndex>0){histIndex--;loadHistory(histIndex);setStatus('Undo.');}}
  function redo(){if(histIndex<history.length-1){histIndex++;loadHistory(histIndex);setStatus('Redo.');}}
  function resetHistory(){history=[];histIndex=-1;pushHistory();}
  undoBtn.onclick=undo;redoBtn.onclick=redo;
  ['object:added','object:modified','object:removed','path:created','erasing:end'].forEach(ev=>canvas.on(ev,scheduleHistory));
  [opacity,shapeFill,shapeStroke,shapeStrokeW,textValue,fontFamily,fontSize,fillColor,strokeColor,strokeWidth,fxColor,fxBlur,fxOffX,fxOffY].forEach(el=>el?.addEventListener('change',scheduleHistory));

  // Init
  updateCanvasSizeChip();

  magicTolRead.textContent = `${magicTol.value}`;
  magicFeatherRead.textContent = `${magicFeather.value}`;
  brushSizeRead.textContent = `${brushSize.value} px`;
  brushSoftRead.textContent = `${brushSoft.value}`;
  eraserSizeRead.textContent = `${eraserSize.value} px`;

  setMode('select');
  refreshLayers();
  refreshProps();
  resetHistory();
  requestAnimationFrame(fitCanvasToView);
  window.FenixImageStudioReady = true;
})();
