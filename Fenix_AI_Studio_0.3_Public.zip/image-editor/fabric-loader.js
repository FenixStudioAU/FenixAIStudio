(() => {
  const boot = document.getElementById('bootScreen');
  const sources = [
    'https://cdn.jsdelivr.net/npm/fabric@5.3.0/dist/fabric.min.js',
    'https://cdnjs.cloudflare.com/ajax/libs/fabric.js/5.3.0/fabric.min.js'
  ];
  function startEditor(){
    const script=document.createElement('script');
    script.src='editor.js?v=140';
    script.onload=()=>{ setTimeout(()=>{ if(window.FenixImageStudioReady){ boot?.classList.add('ready'); setTimeout(()=>boot?.remove(),250); } else fail('The editor code loaded but did not finish starting. Check the browser console.'); },0); };
    script.onerror=()=>fail('The editor code could not be loaded.');
    document.body.appendChild(script);
  }
  function fail(message){
    if(!boot) return;
    boot.classList.add('error');
    boot.innerHTML='<div class="boot-mark">!</div><strong>Image editor failed to start</strong><span>'+message+'</span>';
  }
  function load(index){
    if(window.fabric){ startEditor(); return; }
    if(index>=sources.length){ fail('Fabric.js could not be loaded from either CDN. Check the internet connection or content blocker.'); return; }
    const script=document.createElement('script');
    script.src=sources[index];
    script.crossOrigin='anonymous';
    script.onload=()=>window.fabric ? startEditor() : load(index+1);
    script.onerror=()=>load(index+1);
    document.head.appendChild(script);
  }
  load(0);
})();
