"""Application configuration loader — portable across machines."""
from __future__ import annotations

import os
import shutil
from pathlib import Path
from typing import Any

import yaml

ROOT = Path(__file__).resolve().parent.parent
CONFIG_PATH = ROOT / "config.yaml"


def _load_yaml() -> dict[str, Any]:
    if CONFIG_PATH.exists():
        with open(CONFIG_PATH, "r", encoding="utf-8") as f:
            return yaml.safe_load(f) or {}
    return {}


CFG = _load_yaml()


def path_from_cfg(key: str, default: str) -> Path:
    rel = CFG.get("paths", {}).get(key, default)
    p = Path(rel)
    if not p.is_absolute():
        p = ROOT / p
    p.mkdir(parents=True, exist_ok=True)
    return p


def _refresh_path_env() -> None:
    """Merge Machine + User PATH into this process (Windows winget installs)."""
    if os.name != "nt":
        return
    try:
        import winreg

        parts: list[str] = []
        for root, sub in (
            (winreg.HKEY_LOCAL_MACHINE, r"SYSTEM\CurrentControlSet\Control\Session Manager\Environment"),
            (winreg.HKEY_CURRENT_USER, r"Environment"),
        ):
            try:
                with winreg.OpenKey(root, sub) as key:
                    val, _ = winreg.QueryValueEx(key, "Path")
                    if val:
                        parts.append(str(val))
            except OSError:
                pass
        if parts:
            merged = os.pathsep.join(parts)
            # Keep any process-only extras, then registry PATH
            current = os.environ.get("Path", "")
            os.environ["Path"] = merged + (os.pathsep + current if current else "")
    except Exception:
        pass


def _win_find_ffmpeg(name: str) -> str | None:
    """Locate ffmpeg/ffprobe even when the studio process was started before install."""
    _refresh_path_env()
    found = shutil.which(name)
    if found:
        return found

    # Common install locations (winget Gyan, chocolatey, scoop, manual)
    home = Path.home()
    local = Path(os.environ.get("LOCALAPPDATA", home / "AppData" / "Local"))
    candidates: list[Path] = []

    # winget Gyan.FFmpeg package layout
    winget_pkgs = local / "Microsoft" / "WinGet" / "Packages"
    if winget_pkgs.is_dir():
        for pkg in winget_pkgs.glob("Gyan.FFmpeg*"):
            for bin_dir in pkg.rglob("bin"):
                candidates.append(bin_dir / f"{name}.exe")

    candidates.extend(
        [
            Path(r"C:\ffmpeg\bin") / f"{name}.exe",
            Path(r"C:\ProgramData\chocolatey\bin") / f"{name}.exe",
            home / "scoop" / "shims" / f"{name}.exe",
            local / "Microsoft" / "WinGet" / "Links" / f"{name}.exe",
        ]
    )

    for c in candidates:
        if c.is_file():
            # Ensure parent is on PATH for child processes
            parent = str(c.parent)
            path_now = os.environ.get("Path", "")
            if parent.lower() not in path_now.lower():
                os.environ["Path"] = parent + os.pathsep + path_now
            return str(c)
    return None


def resolve_ffmpeg_binary(configured: str) -> str:
    """Resolve ffmpeg/ffprobe to an absolute path when possible."""
    name = (configured or "ffmpeg").strip() or "ffmpeg"
    p = Path(name)
    if p.is_file():
        return str(p)
    # Bare command name
    if os.name == "nt":
        hit = _win_find_ffmpeg(p.stem if p.suffix else name)
        if hit:
            return hit
    found = shutil.which(name)
    return found or name


def _discover_comfy_install() -> Path | None:
    """Optional discovery only — never force a hard-coded drive path as the truth."""
    candidates = [
        Path.home() / "ComfyUI",
        Path.home() / "Documents" / "ComfyUI",
        Path.home() / "ComfyUI_windows_portable" / "ComfyUI",
        Path(r"C:\ComfyUI_windows_portable\ComfyUI"),
        Path(r"D:\ComfyUI_windows_portable\ComfyUI"),
        Path(r"C:\ComfyUI"),
        Path(r"D:\ComfyUI\ComfyUI"),
    ]
    for c in candidates:
        if (c / "main.py").is_file() or (c / "models").is_dir():
            return c
    return None


def _discover_comfy_start(install: Path | None) -> Path | None:
    if not install:
        return None
    parent = install.parent
    for name in (
        "run_nvidia_gpu.bat",
        "run_nvidia_gpu_fast_fp16_accumulation.bat",
        "START-ComfyUI.bat",
        "start_comfyui.bat",
    ):
        for base in (parent, install):
            p = base / name
            if p.is_file():
                return p
    return None


def _comfy_install_from_cfg() -> Path:
    raw = (CFG.get("comfyui", {}) or {}).get("install_path") or ""
    raw = str(raw).strip()
    if raw:
        return Path(raw)
    found = _discover_comfy_install()
    # Empty placeholder until Settings / discovery finds a real install
    return found if found else (ROOT / ".comfyui_not_configured")


def _comfy_start_from_cfg(install: Path) -> Path:
    raw = (CFG.get("comfyui", {}) or {}).get("start_script") or ""
    raw = str(raw).strip()
    if raw:
        return Path(raw)
    found = _discover_comfy_start(install if install.exists() else None)
    return found if found else (install.parent / "run_nvidia_gpu.bat")


class Settings:
    host: str = CFG.get("app", {}).get("host", "127.0.0.1")
    port: int = int(CFG.get("app", {}).get("port", 7865))
    title: str = CFG.get("app", {}).get("title", "AI Music Video Studio")
    # Public release label (footer / about)
    version: str = str(CFG.get("app", {}).get("version", "Public-0.3"))
    # DEV ONLY menu / skins / beta toggles — must be false on public releases
    dev_build: bool = bool(CFG.get("app", {}).get("dev_build", False))

    comfy_url: str = CFG.get("comfyui", {}).get("base_url", "http://127.0.0.1:8188").rstrip("/")
    comfy_install: Path = _comfy_install_from_cfg()
    comfy_auto_start: bool = bool(CFG.get("comfyui", {}).get("auto_start", True))
    comfy_start_script: Path = _comfy_start_from_cfg(comfy_install)
    comfy_timeout: int = int(CFG.get("comfyui", {}).get("timeout_seconds", 600))

    projects_dir: Path = path_from_cfg("projects", "projects")
    logs_dir: Path = path_from_cfg("logs", "logs")
    workflows_dir: Path = path_from_cfg("workflows", "workflows")
    shared_refs_dir: Path = path_from_cfg("shared_references", "shared_references")
    cache_dir: Path = path_from_cfg("cache", "cache")

    ffmpeg: str = resolve_ffmpeg_binary(CFG.get("ffmpeg", {}).get("binary", "ffmpeg"))
    ffprobe: str = resolve_ffmpeg_binary(CFG.get("ffmpeg", {}).get("ffprobe", "ffprobe"))

    default_slot: float = float(CFG.get("defaults", {}).get("slot_duration_sec", 5.0))
    default_fps: int = int(CFG.get("defaults", {}).get("export_fps", 24))
    default_resolution: str = CFG.get("defaults", {}).get("export_resolution", "1280x720")
    default_aspect: str = CFG.get("defaults", {}).get("aspect_ratio", "16:9")
    default_image_model: str = CFG.get("defaults", {}).get("image_model", "flux2-klein-4b")
    default_video_preset: str = CFG.get("defaults", {}).get("video_preset", "minimax-h3-i2v")

    ollama_url: str = CFG.get("llm", {}).get("ollama_url", "http://127.0.0.1:11434").rstrip("/")
    llm_planner: str = CFG.get("llm", {}).get("planner_model", "planner-4b:latest")
    llm_writer: str = CFG.get("llm", {}).get("writer_model", "gemma4:12b")
    llm_editor: str = CFG.get("llm", {}).get("editor_model", "qwen2.5:7b")


settings = Settings()
