"""Chat helpers: PDF text extract + lightweight web search."""
from __future__ import annotations

import re
from pathlib import Path
from typing import Any

import httpx

from .logging_setup import log


def extract_pdf_text(path: Path, max_chars: int = 12000) -> str:
    """Best-effort PDF text. Uses pypdf if installed."""
    try:
        from pypdf import PdfReader
    except ImportError:
        try:
            from PyPDF2 import PdfReader  # type: ignore
        except ImportError:
            return "(PDF text extraction unavailable — install pypdf: pip install pypdf)"

    try:
        reader = PdfReader(str(path))
        parts: list[str] = []
        total = 0
        for i, page in enumerate(reader.pages):
            try:
                t = page.extract_text() or ""
            except Exception:
                t = ""
            if not t.strip():
                continue
            chunk = f"\n--- page {i + 1} ---\n{t.strip()}\n"
            parts.append(chunk)
            total += len(chunk)
            if total >= max_chars:
                break
        text = "".join(parts).strip()
        if len(text) > max_chars:
            text = text[: max_chars - 20] + "\n…[truncated]"
        return text or "(No extractable text in this PDF.)"
    except Exception as e:
        log.warning("PDF extract failed: %s", e)
        return f"(Could not read PDF: {e})"


async def web_search(query: str, limit: int = 5) -> list[dict[str, Any]]:
    """DuckDuckGo HTML results — no API key. Best-effort."""
    q = (query or "").strip()
    if not q:
        return []
    limit = max(1, min(int(limit or 5), 10))
    results: list[dict[str, Any]] = []

    # 1) Instant Answer API (often sparse but free)
    try:
        async with httpx.AsyncClient(timeout=12.0, follow_redirects=True) as c:
            r = await c.get(
                "https://api.duckduckgo.com/",
                params={"q": q, "format": "json", "no_html": "1", "skip_disambig": "1"},
            )
            if r.status_code == 200:
                data = r.json()
                abstract = (data.get("AbstractText") or "").strip()
                abstract_url = (data.get("AbstractURL") or "").strip()
                if abstract:
                    results.append(
                        {
                            "title": data.get("Heading") or "Summary",
                            "url": abstract_url,
                            "snippet": abstract[:500],
                        }
                    )
                for topic in (data.get("RelatedTopics") or [])[:limit]:
                    if not isinstance(topic, dict):
                        continue
                    if topic.get("Topics"):
                        continue
                    text = (topic.get("Text") or "").strip()
                    url = (topic.get("FirstURL") or "").strip()
                    if text:
                        results.append({"title": text[:80], "url": url, "snippet": text[:400]})
    except Exception as e:
        log.debug("DDG instant failed: %s", e)

    # 2) HTML search page
    if len(results) < limit:
        try:
            async with httpx.AsyncClient(
                timeout=15.0,
                follow_redirects=True,
                headers={"User-Agent": "Mozilla/5.0 (compatible; AMVS-Chat/1.0)"},
            ) as c:
                r = await c.post(
                    "https://html.duckduckgo.com/html/",
                    data={"q": q},
                )
                if r.status_code == 200:
                    html = r.text
                    # result blocks: class result__a + result__snippet
                    links = re.findall(
                        r'class="result__a"[^>]*href="([^"]+)"[^>]*>(.*?)</a>',
                        html,
                        flags=re.I | re.S,
                    )
                    snips = re.findall(
                        r'class="result__snippet"[^>]*>(.*?)</(?:a|td|div)',
                        html,
                        flags=re.I | re.S,
                    )
                    for i, (href, title_html) in enumerate(links[:limit]):
                        title = re.sub(r"<[^>]+>", "", title_html).strip()
                        snippet = ""
                        if i < len(snips):
                            snippet = re.sub(r"<[^>]+>", "", snips[i]).strip()
                        # unwrap ddg redirect
                        m = re.search(r"uddg=([^&]+)", href)
                        if m:
                            from urllib.parse import unquote

                            href = unquote(m.group(1))
                        if title or href:
                            results.append(
                                {"title": title or href, "url": href, "snippet": snippet[:400]}
                            )
        except Exception as e:
            log.warning("DDG html search failed: %s", e)

    # de-dupe by url
    seen: set[str] = set()
    out: list[dict[str, Any]] = []
    for item in results:
        u = item.get("url") or item.get("title") or ""
        if u in seen:
            continue
        seen.add(u)
        out.append(item)
        if len(out) >= limit:
            break
    return out


def format_search_context(results: list[dict[str, Any]], query: str) -> str:
    if not results:
        return f"Web search for “{query}” returned no results."
    lines = [f"Web search results for “{query}”:"]
    for i, r in enumerate(results, 1):
        lines.append(f"{i}. {r.get('title') or 'Result'}")
        if r.get("url"):
            lines.append(f"   {r['url']}")
        if r.get("snippet"):
            lines.append(f"   {r['snippet']}")
    return "\n".join(lines)
