"""ACE style LoRA training datasets + job records (Music Gen → Train tab)."""
from __future__ import annotations

import json
import secrets
import shutil
import time
from pathlib import Path
from typing import Any, Optional

from .config import ROOT, settings

TRAIN_ROOT = ROOT / "music_lora_train"
JOBS_FILE = TRAIN_ROOT / "jobs.json"


def _now() -> str:
    return time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())


def _new_id() -> str:
    return f"trn_{secrets.token_hex(5)}"


def ensure_root() -> Path:
    TRAIN_ROOT.mkdir(parents=True, exist_ok=True)
    (TRAIN_ROOT / "datasets").mkdir(parents=True, exist_ok=True)
    return TRAIN_ROOT


def _load_jobs() -> list[dict[str, Any]]:
    ensure_root()
    if not JOBS_FILE.exists():
        return []
    try:
        with open(JOBS_FILE, "r", encoding="utf-8") as f:
            data = json.load(f)
        return data if isinstance(data, list) else []
    except Exception:
        return []


def _save_jobs(jobs: list[dict[str, Any]]) -> None:
    ensure_root()
    with open(JOBS_FILE, "w", encoding="utf-8") as f:
        json.dump(jobs, f, indent=2, ensure_ascii=False)


def list_jobs() -> list[dict[str, Any]]:
    jobs = _load_jobs()
    jobs.sort(key=lambda j: j.get("updated_at") or j.get("created_at") or "", reverse=True)
    return jobs


def get_job(job_id: str) -> Optional[dict[str, Any]]:
    for j in _load_jobs():
        if j.get("id") == job_id:
            return j
    return None


def create_job(
    *,
    name: str,
    tags: str = "",
    epochs: int = 300,
    rank: int = 16,
    learning_rate: str = "1e-4",
) -> dict[str, Any]:
    ensure_root()
    jid = _new_id()
    ds = TRAIN_ROOT / "datasets" / jid
    (ds / "audio").mkdir(parents=True, exist_ok=True)
    job = {
        "id": jid,
        "name": (name or "My style").strip() or "My style",
        "tags": (tags or "").strip(),
        "epochs": max(50, min(2000, int(epochs or 300))),
        "rank": max(4, min(64, int(rank or 16))),
        "learning_rate": (learning_rate or "1e-4").strip(),
        "status": "draft",
        "message": "Add audio clips, then start training.",
        "progress": 0.0,
        "clips": [],
        "dataset_dir": str(ds.relative_to(ROOT)).replace("\\", "/"),
        "output_lora": "",
        "created_at": _now(),
        "updated_at": _now(),
        "error": "",
    }
    jobs = _load_jobs()
    jobs.insert(0, job)
    _save_jobs(jobs)
    return job


def patch_job(job_id: str, fields: dict[str, Any]) -> dict[str, Any]:
    jobs = _load_jobs()
    for i, j in enumerate(jobs):
        if j.get("id") != job_id:
            continue
        for k, v in fields.items():
            if v is not None and k not in ("id", "dataset_dir", "created_at"):
                j[k] = v
        j["updated_at"] = _now()
        jobs[i] = j
        _save_jobs(jobs)
        return j
    raise FileNotFoundError(job_id)


def dataset_dir(job_id: str) -> Path:
    return TRAIN_ROOT / "datasets" / job_id


def add_clip(job_id: str, filename: str, data: bytes) -> dict[str, Any]:
    job = get_job(job_id)
    if not job:
        raise FileNotFoundError(job_id)
    ds = dataset_dir(job_id)
    audio_dir = ds / "audio"
    audio_dir.mkdir(parents=True, exist_ok=True)
    safe = "".join(c if c.isalnum() or c in "._- " else "_" for c in filename).strip() or "clip.wav"
    if len(safe) > 120:
        safe = safe[-120:]
    # uniquify
    dest = audio_dir / safe
    n = 1
    while dest.exists():
        dest = audio_dir / f"{Path(safe).stem}_{n}{Path(safe).suffix}"
        n += 1
    dest.write_bytes(data)
    clips = list(job.get("clips") or [])
    clips.append(
        {
            "filename": dest.name,
            "path": str(dest.relative_to(ROOT)).replace("\\", "/"),
            "size_bytes": len(data),
        }
    )
    return patch_job(job_id, {"clips": clips, "message": f"{len(clips)} clip(s) ready"})


def clear_clips(job_id: str) -> dict[str, Any]:
    job = get_job(job_id)
    if not job:
        raise FileNotFoundError(job_id)
    audio_dir = dataset_dir(job_id) / "audio"
    if audio_dir.is_dir():
        for p in audio_dir.iterdir():
            if p.is_file():
                p.unlink(missing_ok=True)
    return patch_job(job_id, {"clips": [], "message": "Clips cleared"})


def write_dataset_meta(job: dict[str, Any]) -> Path:
    """Write dataset.json for trainers / future Comfy train nodes."""
    ds = dataset_dir(job["id"])
    meta = {
        "id": job["id"],
        "name": job.get("name"),
        "tags": job.get("tags"),
        "epochs": job.get("epochs"),
        "rank": job.get("rank"),
        "learning_rate": job.get("learning_rate"),
        "clips": job.get("clips") or [],
        "created_at": job.get("created_at"),
    }
    path = ds / "dataset.json"
    path.write_text(json.dumps(meta, indent=2, ensure_ascii=False), encoding="utf-8")
    # caption file per clip (tags as caption — ACE trainers often want this)
    caps = ds / "captions"
    caps.mkdir(exist_ok=True)
    tags = (job.get("tags") or job.get("name") or "music").strip()
    for c in job.get("clips") or []:
        stem = Path(c.get("filename") or "clip").stem
        (caps / f"{stem}.txt").write_text(tags, encoding="utf-8")
    return path


def safe_lora_filename(name: str, *, max_len: int = 80) -> str:
    """User-facing LoRA file name: keep spaces/hyphens, strip illegal Windows chars."""
    raw = (name or "style").strip() or "style"
    # remove path junk
    raw = raw.replace("\\", " ").replace("/", " ").replace("\0", "")
    illegal = '<>:"|?*'
    cleaned = "".join("_" if c in illegal else c for c in raw)
    cleaned = " ".join(cleaned.split())  # collapse whitespace
    cleaned = cleaned.strip(" .")
    if not cleaned:
        cleaned = "style"
    if len(cleaned) > max_len:
        cleaned = cleaned[:max_len].rstrip(" .")
    return cleaned


def suggested_output_name(job: dict[str, Any]) -> str:
    """Final LoRA path under models/loras — just the style name the user set."""
    base = safe_lora_filename(str(job.get("name") or "style"))
    return f"ace/{base}.safetensors"


def lora_output_path(rel_name: str) -> Path:
    """Absolute path under Comfy models/loras for a relative lora name."""
    rel = rel_name.replace("\\", "/").lstrip("/")
    return settings.comfy_install / "models" / "loras" / Path(rel)


def delete_job(job_id: str) -> bool:
    jobs = _load_jobs()
    found = False
    out = []
    for j in jobs:
        if j.get("id") == job_id:
            found = True
            ds = dataset_dir(job_id)
            if ds.exists():
                shutil.rmtree(ds, ignore_errors=True)
            continue
        out.append(j)
    if found:
        _save_jobs(out)
    return found
