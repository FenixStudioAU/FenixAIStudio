"""Central logging for jobs, FFmpeg, and app errors."""
from __future__ import annotations

import logging
from logging.handlers import RotatingFileHandler
from pathlib import Path

from .config import settings


def setup_logging() -> logging.Logger:
    settings.logs_dir.mkdir(parents=True, exist_ok=True)
    logger = logging.getLogger("amvs")
    if logger.handlers:
        return logger
    logger.setLevel(logging.DEBUG)

    fmt = logging.Formatter(
        "%(asctime)s [%(levelname)s] %(name)s: %(message)s",
        datefmt="%Y-%m-%d %H:%M:%S",
    )

    fh = RotatingFileHandler(
        settings.logs_dir / "app.log",
        maxBytes=5_000_000,
        backupCount=5,
        encoding="utf-8",
    )
    fh.setLevel(logging.DEBUG)
    fh.setFormatter(fmt)
    logger.addHandler(fh)

    ch = logging.StreamHandler()
    ch.setLevel(logging.INFO)
    ch.setFormatter(fmt)
    logger.addHandler(ch)

    # Dedicated channels
    for name in ("comfyui", "ffmpeg", "jobs"):
        sub = logging.getLogger(f"amvs.{name}")
        sub.setLevel(logging.DEBUG)
        sh = RotatingFileHandler(
            settings.logs_dir / f"{name}.log",
            maxBytes=5_000_000,
            backupCount=3,
            encoding="utf-8",
        )
        sh.setFormatter(fmt)
        sub.addHandler(sh)
        sub.propagate = True

    return logger


log = setup_logging()
