"""Standalone Image/Video Gen gallery (not tied to a timeline project)."""
from __future__ import annotations

import json
import shutil
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Optional
from uuid import uuid4

from .config import ROOT
from .logging_setup import log

STUDIO_DIR = ROOT / "studio_media"
META_PATH = STUDIO_DIR / "library.json"


def _now() -> str:
    return datetime.now(timezone.utc).isoformat()


def _ensure() -> None:
    STUDIO_DIR.mkdir(parents=True, exist_ok=True)
    (STUDIO_DIR / "images").mkdir(parents=True, exist_ok=True)
    (STUDIO_DIR / "videos").mkdir(parents=True, exist_ok=True)
    if not META_PATH.exists():
        META_PATH.write_text(json.dumps({"items": []}, indent=2), encoding="utf-8")


def _load() -> dict[str, Any]:
    _ensure()
    try:
        return json.loads(META_PATH.read_text(encoding="utf-8-sig"))
    except Exception:
        return {"items": []}


def _save(data: dict[str, Any]) -> None:
    _ensure()
    META_PATH.write_text(json.dumps(data, indent=2), encoding="utf-8")


def list_items(kind: str | None = None) -> list[dict[str, Any]]:
    items = list(_load().get("items") or [])
    if kind:
        k = kind.strip().lower()
        items = [i for i in items if (i.get("kind") or "").lower() == k]
    items.sort(key=lambda t: t.get("created_at") or "", reverse=True)
    return items


def import_image_file(
    source_path: Path,
    *,
    title: str = "",
    prompt: str = "",
) -> dict[str, Any]:
    """Copy an arbitrary still into the studio image gallery."""
    return add_item(
        kind="image",
        title=(title or source_path.name)[:80],
        prompt=prompt or "",
        source_path=source_path,
    )


def list_aggregated_images() -> list[dict[str, Any]]:
    """Studio stills + Character library + project shot stills (for gallery Images tab)."""
    from . import character_library, project_store

    out: list[dict[str, Any]] = []
    seen: set[str] = set()

    for it in list_items("image"):
        iid = str(it.get("id") or "")
        if not iid or iid in seen:
            continue
        seen.add(iid)
        row = dict(it)
        row["origin"] = "studio"
        row["media_url"] = f"/api/studio/items/{iid}/media"
        out.append(row)

    for c in character_library.list_characters():
        cid = str(c.get("id") or "")
        if not cid or not c.get("path"):
            continue
        key = f"char:{cid}"
        if key in seen:
            continue
        if not character_library.abs_image_path(c.get("path") or ""):
            continue
        seen.add(key)
        out.append(
            {
                "id": key,
                "kind": "image",
                "title": (c.get("name") or cid)[:80],
                "prompt": (c.get("description") or "").strip(),
                "origin": "character",
                "char_id": cid,
                "media_url": f"/api/characters/{cid}/image",
                "created_at": "",
            }
        )

    for meta in project_store.list_projects():
        pid = str(meta.get("id") or "")
        if not pid:
            continue
        try:
            proj = project_store.load_project(pid)
        except Exception:
            continue
        pname = (proj.name or pid)[:40]
        for shot in proj.timeline.shots or []:
            candidates: list[str] = []
            if shot.image_path:
                candidates.append(shot.image_path)
            for alt in shot.image_alternatives or []:
                if alt and alt not in candidates:
                    candidates.append(alt)
            for rel in candidates:
                key = f"proj:{pid}:{rel}"
                if key in seen:
                    continue
                abs_p = project_store.abs_path(pid, rel)
                if not abs_p or not abs_p.is_file():
                    continue
                seen.add(key)
                label = (shot.label or shot.id or "shot")[:24]
                out.append(
                    {
                        "id": key,
                        "kind": "image",
                        "title": f"{pname} · {label}",
                        "prompt": "",
                        "origin": "project",
                        "project_id": pid,
                        "rel": rel,
                        "media_url": f"/api/projects/{pid}/files/{rel}",
                        "created_at": getattr(proj, "updated_at", "") or "",
                    }
                )

    out.sort(key=lambda t: t.get("created_at") or "", reverse=True)
    return out


def get_item(item_id: str) -> Optional[dict[str, Any]]:
    for t in list_items():
        if t.get("id") == item_id:
            return t
    return None


def abs_media_path(rel: str) -> Optional[Path]:
    if not rel:
        return None
    p = STUDIO_DIR / rel
    return p if p.is_file() else None


def add_item(
    *,
    kind: str,
    title: str = "",
    prompt: str = "",
    negative_prompt: str = "",
    source_path: Path | None = None,
    duration_sec: float = 0,
    width: int = 0,
    height: int = 0,
    seed: int = -1,
    model: str = "",
    parent_id: str = "",
) -> dict[str, Any]:
    _ensure()
    kind = (kind or "image").strip().lower()
    if kind not in ("image", "video"):
        kind = "image"
    if not source_path or not source_path.is_file():
        raise ValueError("source_path missing")
    data = _load()
    iid = ("img_" if kind == "image" else "vid_") + uuid4().hex[:12]
    suffix = source_path.suffix or (".png" if kind == "image" else ".mp4")
    sub = "images" if kind == "image" else "videos"
    dest = STUDIO_DIR / sub / f"{iid}{suffix}"
    shutil.copy2(source_path, dest)
    rel = f"{sub}/{iid}{suffix}"
    item = {
        "id": iid,
        "kind": kind,
        "title": (title or "").strip() or (prompt[:48] if prompt else iid),
        "prompt": (prompt or "").strip(),
        "negative_prompt": (negative_prompt or "").strip(),
        "path": rel,
        "duration_sec": float(duration_sec or 0),
        "width": int(width or 0),
        "height": int(height or 0),
        "seed": int(seed if seed is not None else -1),
        "model": (model or "").strip(),
        "parent_id": (parent_id or "").strip(),
        "created_at": _now(),
    }
    items = data.get("items") or []
    items.append(item)
    data["items"] = items
    _save(data)
    log.info("Studio media saved: %s %s", kind, iid)
    return item


def delete_item(item_id: str) -> bool:
    data = _load()
    items = data.get("items") or []
    kept: list[dict[str, Any]] = []
    found = False
    for t in items:
        if t.get("id") == item_id:
            found = True
            p = abs_media_path(t.get("path") or "")
            if p and p.is_file():
                try:
                    p.unlink()
                except Exception:
                    pass
        else:
            kept.append(t)
    if found:
        data["items"] = kept
        _save(data)
    return found
