"""ACE style LoRA training via ComfyUI native TrainLoraNode + ACE audio encode.

Uses nodes already in modern Comfy (no FL-AceStep-Training pack required):
  UNETLoader + DualCLIPLoader + VAELoader
  LoadAudio → VAEEncodeAudio → latents
  TextEncodeAceStepAudio1.5 → conditioning
  TrainLoraNode → SaveLoRA
"""
from __future__ import annotations

import asyncio
import math
import random
import shutil
import time
import traceback
from pathlib import Path
from typing import Any, Optional

from . import music_pipeline
from . import music_train_store as store
from .comfyui_client import comfy
from .config import ROOT, settings
from .gen_activity import clear_activity, set_activity
from .logging_setup import log

_running: dict[str, asyncio.Task] = {}

# Native Comfy nodes we need for real ACE audio LoRA training
_REQUIRED_NODES = (
    "TrainLoraNode",
    "SaveLoRA",
    "LoadAudio",
    "VAEEncodeAudio",
    "TextEncodeAceStepAudio1.5",
    "UNETLoader",
    "DualCLIPLoader",
    "VAELoader",
)


async def detect_train_capability() -> dict[str, Any]:
    """Probe Comfy for native train + ACE encode nodes (not third-party packs)."""
    online = await comfy.is_online()
    if not online:
        return {
            "comfy_online": False,
            "train_nodes": [],
            "can_train": False,
            "mode": "none",
            "detail": "ComfyUI offline — start Comfy to train.",
            "hint": "Start ComfyUI with ACE-Step models installed, then refresh.",
        }
    try:
        info = await comfy.object_info()
    except Exception as e:
        return {
            "comfy_online": True,
            "train_nodes": [],
            "can_train": False,
            "mode": "none",
            "detail": f"Could not read Comfy nodes: {e}",
            "hint": "Update ComfyUI to a recent build that includes Train LoRA (model/training).",
        }

    names = set((info or {}).keys())
    present = [n for n in _REQUIRED_NODES if n in names]
    missing = [n for n in _REQUIRED_NODES if n not in names]
    can = not missing

    # ACE models
    ace_ok = False
    ace_detail = ""
    try:
        await music_pipeline.resolve_ace_models(prefer="turbo")
        ace_ok = True
    except Exception as e:
        ace_detail = str(e)

    can_train = can and ace_ok
    if can_train:
        prof = _train_vram_profile()
        detail = f"Ready — native Train LoRA + ACE Turbo. {prof['note']}"
        hint = (
            "Upload 2–6 clips. On 8GB we auto-trim to ~8s and use low rank. "
            "Full-song train needs 16GB+ VRAM."
        )
    elif missing:
        detail = f"Missing Comfy nodes: {', '.join(missing)}"
        hint = "Update ComfyUI (TrainLoraNode is in comfy_extras). Restart Comfy after update."
    else:
        detail = f"ACE models not ready: {ace_detail}"
        hint = "Install ACE-Step 1.5 turbo + VAE + text encoders into Comfy models/."

    return {
        "comfy_online": True,
        "train_nodes": present,
        "missing_nodes": missing,
        "can_train": can_train,
        "mode": "comfy_native" if can_train else "none",
        "ace_ready": ace_ok,
        "detail": detail,
        "hint": hint,
    }


async def start_training(job_id: str) -> dict[str, Any]:
    job = store.get_job(job_id)
    if not job:
        raise FileNotFoundError(job_id)
    clips = job.get("clips") or []
    if len(clips) < 2:
        raise ValueError("Add at least 2 audio clips (3–20 of the same vibe works best).")
    if job.get("status") == "running":
        return job

    store.write_dataset_meta(job)
    out_name = store.suggested_output_name(job)
    job = store.patch_job(
        job_id,
        {
            "status": "running",
            "message": "Starting ACE LoRA training in Comfy…",
            "progress": 0.05,
            "output_lora": out_name,
            "error": "",
        },
    )

    old = _running.pop(job_id, None)
    if old and not old.done():
        old.cancel()

    task = asyncio.create_task(_run_train_job(job_id))
    _running[job_id] = task
    return job


def _clip_abs(clip: dict[str, Any]) -> Path:
    rel = (clip.get("path") or "").replace("\\", "/")
    p = ROOT / rel if rel and not Path(rel).is_absolute() else Path(rel)
    if not p.is_file():
        # fallback: dataset audio folder
        raise FileNotFoundError(f"Clip missing on disk: {rel}")
    return p


def _parse_lr(s: str, default: float = 1e-4) -> float:
    try:
        v = float(str(s).strip().replace(",", ""))
        if v > 0:
            return min(1.0, max(1e-7, v))
    except (TypeError, ValueError):
        pass
    return default


def _comfy_lora_combo_name(path: Path) -> str:
    """Name as Comfy COMBO options list it (often Windows backslashes under loras/)."""
    root = settings.comfy_install / "models" / "loras"
    try:
        rel = path.resolve().relative_to(root.resolve())
        # Comfy object_info used ace\\file.safetensors
        return str(rel).replace("/", "\\")
    except Exception:
        return path.name


def _train_vram_profile() -> dict[str, Any]:
    """Pick train settings that fit the host GPU (8GB needs short clips)."""
    from .models_detect import get_vram_gb
    from . import app_settings_store

    vram = float(get_vram_gb() or 0)
    try:
        low_flag = bool(app_settings_store.load_user_settings().get("optimize_low_vram"))
    except Exception:
        low_flag = False
    # Official ACE train docs say 16GB+; on 8GB we must trim hard
    if low_flag or (0 < vram <= 10):
        return {
            "tier": "8gb",
            "max_clip_sec": 8.0,
            "rank_cap": 8,
            "steps_cap": 120,
            "steps_per_clip_cap": 40,
            "lora_dtype": "fp32",
            "training_dtype": "none",
            "checkpoint_depth": 3,
            "offloading": True,
            "note": (
                f"Low VRAM mode (~{vram:.0f}GB): clips trimmed to 8s, rank≤8, "
                "fewer steps. Full-song training needs ~16GB+."
            ),
        }
    if 0 < vram <= 14:
        return {
            "tier": "12gb",
            "max_clip_sec": 12.0,
            "rank_cap": 12,
            "steps_cap": 300,
            "steps_per_clip_cap": 80,
            "lora_dtype": "fp32",
            "training_dtype": "none",
            "checkpoint_depth": 2,
            "offloading": True,
            "note": f"Mid VRAM (~{vram:.0f}GB): clips trimmed to 12s.",
        }
    return {
        "tier": "high",
        "max_clip_sec": 20.0,
        "rank_cap": 32,
        "steps_cap": 800,
        "steps_per_clip_cap": 200,
        "lora_dtype": "fp32",
        "training_dtype": "none",
        "checkpoint_depth": 1,
        "offloading": True,
        "note": f"VRAM ~{vram:.0f}GB: clips trimmed to 20s.",
    }


def _single_clip_train_prompt(
    *,
    models: dict[str, str],
    audio_key: str,
    tags: str,
    seed: int,
    steps: int,
    lr: float,
    rank: int,
    existing_lora: str,
    save_prefix: str,
    max_clip_sec: float = 8.0,
    lora_dtype: str = "fp32",
    training_dtype: str = "none",
    checkpoint_depth: int = 3,
    offloading: bool = True,
) -> dict[str, Any]:
    """One TrainLoraNode graph — latents/positive are single [node, slot] links only.

    Audio is hard-trimmed before VAE encode so sequence length stays 8GB-safe.
    """
    dur = float(max(4.0, min(30.0, max_clip_sec)))
    return {
        "1": {
            "class_type": "UNETLoader",
            "inputs": {
                "unet_name": models["unet"],
                "weight_dtype": "default",
            },
        },
        "2": {
            "class_type": "DualCLIPLoader",
            "inputs": {
                "clip_name1": models["clip1"],
                "clip_name2": models["clip2"],
                "type": "ace",
                "device": "default",
            },
        },
        "3": {
            "class_type": "VAELoader",
            "inputs": {"vae_name": models["vae"]},
        },
        "10": {
            "class_type": "LoadAudio",
            "inputs": {"audio": audio_key},
        },
        # Critical for 8GB: full songs create huge latents → OOM on backward
        "10b": {
            "class_type": "TrimAudioDuration",
            "inputs": {
                "audio": ["10", 0],
                "start_index": 0.0,
                "duration": dur,
            },
        },
        "11": {
            "class_type": "VAEEncodeAudio",
            "inputs": {
                "audio": ["10b", 0],
                "vae": ["3", 0],
            },
        },
        "12": {
            "class_type": "TextEncodeAceStepAudio1.5",
            "inputs": {
                "clip": ["2", 0],
                "tags": tags,
                "lyrics": "",
                "seed": int(seed),
                "bpm": 120,
                "duration": float(dur),
                "timesignature": "4",
                "language": "en",
                "keyscale": "E minor",
                "generate_audio_codes": False,
                "cfg_scale": 2.0,
                "temperature": 0.85,
                "top_p": 0.9,
                "top_k": 0,
                "min_p": 0.0,
            },
        },
        "22": {
            "class_type": "TrainLoraNode",
            "inputs": {
                "model": ["1", 0],
                # API requires exactly [node_id, slot] — NOT a list of links
                "latents": ["11", 0],
                "positive": ["12", 0],
                "batch_size": 1,
                "grad_accumulation_steps": 1,
                "steps": int(steps),
                "learning_rate": float(lr),
                "rank": int(rank),
                "optimizer": "AdamW",
                "loss_function": "MSE",
                "seed": int(seed),
                "training_dtype": training_dtype,
                "lora_dtype": lora_dtype,
                "quantized_backward": False,
                "algorithm": "LoRA",
                "gradient_checkpointing": True,
                "checkpoint_depth": int(checkpoint_depth),
                "offloading": bool(offloading),
                "existing_lora": existing_lora or "[None]",
                "bucket_mode": False,
                "bypass_mode": False,
            },
        },
        "23": {
            "class_type": "SaveLoRA",
            "inputs": {
                "lora": ["22", 0],
                "prefix": save_prefix,
                "steps": int(steps),
            },
        },
    }


async def _build_and_run_train_workflow(job: dict[str, Any]) -> dict[str, Any]:
    """Upload clips; train sequentially (one clip per Comfy job), chain via existing_lora.

    TrainLoraNode API rejects multi-link latents/positive — each link must be
    exactly [node_id, slot_index]. So we train clip-by-clip and append.
    """
    models = await music_pipeline.resolve_ace_models(prefer="turbo")
    profile = _train_vram_profile()
    clips = list(job.get("clips") or [])
    tags = (job.get("tags") or job.get("name") or "music style").strip()
    rank = max(4, min(int(profile["rank_cap"]), int(job.get("rank") or 16)))
    epochs = max(50, min(2000, int(job.get("epochs") or 300)))
    # total budget split across clips — hard caps on low VRAM
    total_steps = max(24, min(int(profile["steps_cap"]), int(epochs * max(1, len(clips)) // 4)))
    steps_per = max(12, min(int(profile["steps_per_clip_cap"]), total_steps // max(1, len(clips))))
    lr = _parse_lr(job.get("learning_rate") or "1e-4", 1e-4)
    seed = random.randint(0, 2**31 - 1)
    # Final public name = exactly what the user typed (filesystem-safe)
    style_name = store.safe_lora_filename(str(job.get("name") or "style"))
    final_rel = f"ace/{style_name}.safetensors"
    # Temp SaveLoRA prefixes (must produce *_N_steps_* for Comfy existing_lora parse)
    job_tag = (job.get("id") or "job")[-8:]
    tmp_prefix_base = f"loras/ace/_tmp_train_{job_tag}"

    store.patch_job(
        job["id"],
        {
            "message": (
                f"Uploading {len(clips)} clip(s)… {profile['note']} "
                f"(trim {profile['max_clip_sec']:.0f}s · rank {rank} · {steps_per} steps/clip)"
            ),
            "progress": 0.08,
            "vram_profile": profile["tier"],
            "output_lora": final_rel,
        },
    )
    log.info("ACE train VRAM profile: %s final_name=%s", profile, final_rel)

    uploaded: list[str] = []
    sub = f"fenix_train/{job['id']}"
    for i, clip in enumerate(clips):
        src = _clip_abs(clip)
        up = await comfy.upload_audio(src, subfolder=sub)
        name = up.get("name") or up.get("filename") or src.name
        subfolder = (up.get("subfolder") or sub or "").replace("\\", "/")
        audio_key = f"{subfolder}/{name}".strip("/") if subfolder else name
        uploaded.append(audio_key)
        store.patch_job(
            job["id"],
            {
                "message": f"Uploaded clip {i + 1}/{len(clips)}…",
                "progress": 0.08 + 0.12 * ((i + 1) / max(1, len(clips))),
            },
        )

    existing = "[None]"
    started = time.time()
    last_found: Optional[Path] = None
    intermediates: list[Path] = []
    total_done_steps = 0
    timeout = max(float(settings.comfy_timeout), 3600.0)
    prompt_id = ""

    for i, audio_key in enumerate(uploaded):
        store.patch_job(
            job["id"],
            {
                "message": (
                    f"Training “{style_name}” clip {i + 1}/{len(uploaded)} "
                    f"({steps_per} steps · rank {rank} · {profile['max_clip_sec']:.0f}s trim"
                    f"{', continue' if existing != '[None]' else ''})…"
                ),
                "progress": 0.2 + 0.7 * (i / max(1, len(uploaded))),
                "train_steps": total_steps,
            },
        )
        set_activity(
            f"ACE LoRA train · {style_name} · {i + 1}/{len(uploaded)}",
            source="music",
            busy=True,
        )
        try:
            await comfy.free_memory(unload_models=True, free_memory=True)
            await asyncio.sleep(1.5)
        except Exception as e:
            log.warning("pre-train free_memory: %s", e)

        # Temp prefix only — final rename to user style name after all passes
        prefix = f"{tmp_prefix_base}_p{i + 1}"

        prompt = _single_clip_train_prompt(
            models=models,
            audio_key=audio_key,
            tags=tags,
            seed=seed + i,
            steps=steps_per,
            lr=lr,
            rank=rank,
            existing_lora=existing,
            save_prefix=prefix,
            max_clip_sec=float(profile["max_clip_sec"]),
            lora_dtype=str(profile["lora_dtype"]),
            training_dtype=str(profile["training_dtype"]),
            checkpoint_depth=int(profile["checkpoint_depth"]),
            offloading=bool(profile["offloading"]),
        )
        log.info(
            "ACE train pass %d/%d job=%s style=%s steps=%d existing=%s save=%s",
            i + 1,
            len(uploaded),
            job["id"],
            style_name,
            steps_per,
            existing,
            prefix,
        )
        pass_start = time.time()
        try:
            prompt_id = await comfy.queue_prompt(prompt)
            await comfy.wait_for_prompt(prompt_id, timeout=timeout)
        except Exception as e:
            err = str(e)
            if "out of memory" in err.lower() or "oom" in err.lower() or "exceed allowed memory" in err.lower():
                raise RuntimeError(
                    "Out of VRAM during ACE LoRA training.\n\n"
                    f"This machine profile: {profile['note']}\n\n"
                    "Tips for 8GB:\n"
                    "• Use 2–4 short clips (we auto-trim to ~8s)\n"
                    "• Rank 4–8 (UI rank is capped on low VRAM)\n"
                    "• Close other GPU apps; restart Comfy before train\n"
                    "• Official ACE train docs recommend 16GB+ for full songs\n\n"
                    f"Raw error: {err[:800]}"
                ) from e
            raise
        total_done_steps += steps_per

        needle = Path(prefix.replace("\\", "/")).name
        found = _search_trained_lora(pass_start - 10, needle=needle)
        if not found:
            found = _search_trained_lora(pass_start - 10, needle=job_tag)
        if not found:
            found = _search_trained_lora(pass_start - 10, needle="_tmp_train_")
        if not found:
            out_dir = settings.comfy_install / "output"
            raise RuntimeError(
                f"Train pass {i + 1}/{len(uploaded)} finished but no LoRA .safetensors was found.\n"
                f"SaveLoRA writes to: {out_dir}/loras/…\n"
                "Check that folder and Comfy logs for SaveLoRA."
            )

        # Intermediate installs MUST keep "_NN_steps_" in the filename for Comfy's
        # existing_lora step parser. Final public name is applied after the last pass.
        install_name = found.name
        if "_steps_" not in install_name:
            install_name = f"_tmp_train_{job_tag}_p{i + 1}_{steps_per}_steps_00001_.safetensors"
        installed, combo = _install_lora_for_comfy(found, install_name)
        intermediates.append(installed)
        # Also track Comfy output dump for cleanup
        intermediates.append(found)
        last_found = installed
        existing = combo
        log.info(
            "ACE train pass %d temp install %s (combo=%s)",
            i + 1,
            installed,
            existing,
        )

    # Final: copy last weights to the clean user-facing name
    if not last_found or not last_found.is_file():
        raise RuntimeError("Training finished but final LoRA weights are missing.")

    final_path, _ = _install_lora_for_comfy(last_found, f"{style_name}.safetensors")
    # Remove all intermediate temps (models + output), keep only final_path
    for p in intermediates:
        try:
            if p.resolve() != final_path.resolve():
                _delete_path_quiet(p)
        except Exception:
            _delete_path_quiet(p)
    _cleanup_train_intermediates(
        job_id=str(job.get("id") or ""),
        keep=final_path,
        output_needles=[job_tag, style_name.lower().replace(" ", "_"), "_tmp_train_"],
    )

    elapsed = time.time() - started
    result_path = f"ace/{style_name}.safetensors"
    try:
        result_path = str(
            final_path.relative_to(settings.comfy_install / "models" / "loras")
        ).replace("\\", "/")
    except Exception:
        pass

    return {
        "prompt_id": prompt_id,
        "elapsed_sec": elapsed,
        "output_lora": result_path,
        "steps": total_done_steps,
        "entry_ok": True,
        "passes": len(uploaded),
        "display_name": style_name,
    }


def _find_newest_lora(root: Path, newer_than: float, needle: str = "") -> Optional[Path]:
    """Find a newly written .safetensors under root (recursive)."""
    if not root.is_dir():
        return None
    needle_l = (needle or "").lower().replace("\\", "/")
    # Prefer filename stem match over full path
    if "/" in needle_l:
        needle_l = needle_l.split("/")[-1]
    scored: list[tuple[float, Path]] = []
    for p in root.rglob("*.safetensors"):
        try:
            st = p.stat()
            if st.st_mtime < newer_than:
                continue
            if st.st_size < 8_000:
                continue
            name = p.name.lower()
            rel = str(p).lower().replace("\\", "/")
            score = float(st.st_mtime)
            if needle_l:
                if needle_l in name or needle_l in rel:
                    score += 1e12  # hard prefer name match
                elif "trained" in name or "fenix" in name or "ace15_user" in name:
                    score += 1e9
                else:
                    # other new safetensors (minimax etc.) — low priority
                    score -= 1e6
            scored.append((score, p))
        except OSError:
            continue
    if not scored:
        return None
    scored.sort(key=lambda x: x[0], reverse=True)
    return scored[0][1]


def _install_lora_for_comfy(src: Path, dest_name: str) -> tuple[Path, str]:
    """Copy trained weights into models/loras/ace/ so Loaders + existing_lora COMBO see it.

    SaveLoRA writes under ComfyUI/output/ — not models/loras/.
    """
    dest_name = Path(dest_name).name
    if not dest_name.lower().endswith(".safetensors"):
        dest_name = dest_name + ".safetensors"
    dest = settings.comfy_install / "models" / "loras" / "ace" / dest_name
    dest.parent.mkdir(parents=True, exist_ok=True)
    if src.resolve() != dest.resolve():
        shutil.copy2(src, dest)
    combo = _comfy_lora_combo_name(dest)
    return dest, combo


def _delete_path_quiet(p: Optional[Path]) -> None:
    if not p:
        return
    try:
        if p.is_file():
            p.unlink(missing_ok=True)
    except Exception as e:
        log.warning("Could not delete %s: %s", p, e)


def _cleanup_train_intermediates(
    *,
    job_id: str,
    keep: Optional[Path],
    output_needles: list[str],
) -> None:
    """Remove ALL intermediate pass/tmp LoRAs after success — keep only the final user-named file."""
    keep_res = None
    try:
        keep_res = keep.resolve() if keep and keep.is_file() else None
    except Exception:
        keep_res = None

    roots = [
        settings.comfy_install / "models" / "loras" / "ace",
        settings.comfy_install / "models" / "loras",
        settings.comfy_install / "output" / "loras" / "ace",
        settings.comfy_install / "output" / "loras",
        settings.comfy_install / "output",
    ]
    jid = (job_id or "")[-8:].lower()
    needles_l = [n.lower() for n in (output_needles or []) if n]

    def _is_intermediate(name: str) -> bool:
        n = name.lower()
        # Temp train chain files
        if n.startswith("_tmp_train_") or "_tmp_train_" in n:
            return True
        if "_pass" in n or n.startswith("pass"):
            return True
        # Comfy SaveLoRA dumps: always *_NN_steps_* — never the final public name
        if "_steps_" in n:
            return True
        # Legacy auto-prefixed train names
        if n.startswith("ace15_user_"):
            return True
        # Job-id tagged temps
        if jid and jid in n and ("tmp" in n or "pass" in n or "_steps_" in n):
            return True
        # Needle match (job tag / style slug) only when clearly a dump, not a clean final
        for nl in needles_l:
            if nl and nl in n and ("_steps_" in n or "pass" in n or "_tmp_" in n or n.startswith("ace15_user_")):
                return True
        return False

    seen: set[str] = set()
    for root in roots:
        if not root.is_dir():
            continue
        for p in list(root.rglob("*.safetensors")):
            try:
                key = str(p.resolve())
            except Exception:
                key = str(p)
            if key in seen:
                continue
            seen.add(key)
            try:
                if keep_res and p.resolve() == keep_res:
                    continue
            except Exception:
                pass
            if _is_intermediate(p.name):
                _delete_path_quiet(p)
                log.info("Cleaned train intermediate: %s", p)


def _search_trained_lora(newer_than: float, needle: str = "") -> Optional[Path]:
    """SaveLoRA uses folder_paths.get_output_directory() → ComfyUI/output/…"""
    roots = [
        settings.comfy_install / "output",
        settings.comfy_install / "models" / "loras",
        settings.comfy_install / "models",
    ]
    best: Optional[Path] = None
    best_score = -1e30
    for root in roots:
        hit = _find_newest_lora(root, newer_than, needle=needle)
        if not hit:
            continue
        try:
            score = hit.stat().st_mtime
            # Prefer output/loras (where SaveLoRA actually writes)
            if "output" in str(hit).replace("\\", "/").lower():
                score += 1e8
            if needle and needle.lower() in hit.name.lower():
                score += 1e9
            if score > best_score:
                best_score = score
                best = hit
        except OSError:
            continue
    return best


async def _run_train_job(job_id: str) -> None:
    try:
        set_activity("ACE LoRA training…", source="music", busy=True)
        job = store.get_job(job_id)
        if not job:
            return
        store.write_dataset_meta(job)

        cap = await detect_train_capability()
        if not cap.get("comfy_online"):
            store.patch_job(
                job_id,
                {
                    "status": "error",
                    "message": "ComfyUI is offline.",
                    "error": "offline",
                    "progress": 0,
                },
            )
            clear_activity("Train failed")
            return

        if not cap.get("can_train"):
            store.patch_job(
                job_id,
                {
                    "status": "error",
                    "message": cap.get("detail") or "Training not available",
                    "error": "capability",
                    "progress": 0,
                    "hint": cap.get("hint") or "",
                },
            )
            clear_activity("Train failed")
            return

        result = await _build_and_run_train_workflow(job)
        out = result.get("output_lora") or job.get("output_lora") or ""
        display = result.get("display_name") or Path(str(out)).stem
        store.patch_job(
            job_id,
            {
                "status": "done",
                "message": (
                    f"Training complete — “{display}” "
                    f"({int(result.get('steps') or 0)} steps, "
                    f"{result.get('elapsed_sec', 0):.0f}s). "
                    f"Create → Style LoRA → Refresh — pick “{display}”."
                ),
                "progress": 1.0,
                "output_lora": out,
                "error": "",
            },
        )
        clear_activity("LoRA train done")
        log.info("ACE train job %s done -> %s", job_id, out)

    except asyncio.CancelledError:
        store.patch_job(job_id, {"status": "cancelled", "message": "Cancelled", "progress": 0})
        clear_activity("Train cancelled")
        raise
    except Exception as e:
        log.error("ACE train failed %s: %s\n%s", job_id, e, traceback.format_exc())
        msg = str(e)
        # Friendlier hint for common size / dtype issues
        if "size of tensor" in msg.lower() or "mismatch" in msg.lower():
            msg = (
                f"{msg}\n\nHint: Train uses ACE Turbo so the new LoRA matches Turbo. "
                "If this is a dtype/OOM issue, try fewer clips, lower rank (8), or shorter audio."
            )
        store.patch_job(
            job_id,
            {
                "status": "error",
                "message": msg[:2000],
                "error": msg[:500],
                "progress": 0,
            },
        )
        clear_activity("Train failed")
    finally:
        _running.pop(job_id, None)
