"""Unload Comfy models after idle period to free VRAM between sessions."""
from __future__ import annotations

import asyncio
import time
from typing import Optional

from .comfyui_client import comfy
from .logging_setup import log

# Seconds of no generation before unload
IDLE_UNLOAD_SEC = 15 * 60

_last_work_ts: float = time.time()
_idle_unloaded: bool = False
_task: Optional[asyncio.Task] = None


def note_comfy_work() -> None:
    """Call when a Comfy job starts or bulk starts."""
    global _last_work_ts, _idle_unloaded
    _last_work_ts = time.time()
    _idle_unloaded = False


def _has_running_jobs() -> bool:
    try:
        from .job_manager import job_manager

        for j in job_manager.jobs.values():
            if j.status in ("queued", "running"):
                return True
    except Exception:
        pass
    return False


async def _loop() -> None:
    global _idle_unloaded
    while True:
        try:
            await asyncio.sleep(30)
            if _idle_unloaded:
                continue
            if _has_running_jobs():
                note_comfy_work()
                continue
            idle_for = time.time() - _last_work_ts
            if idle_for < IDLE_UNLOAD_SEC:
                continue
            if not await comfy.is_online():
                continue
            log.info(
                "Comfy idle for %.0fs — unloading models to free VRAM",
                idle_for,
            )
            try:
                await comfy.free_memory(unload_models=True, free_memory=True)
                await asyncio.sleep(0.5)
                await comfy.free_memory(unload_models=True, free_memory=True)
            except Exception as e:
                log.warning("idle unload failed: %s", e)
            _idle_unloaded = True
        except asyncio.CancelledError:
            raise
        except Exception as e:
            log.warning("idle unload loop: %s", e)


def start_idle_watcher() -> None:
    global _task
    try:
        loop = asyncio.get_event_loop()
        if _task is None or _task.done():
            _task = loop.create_task(_loop())
            log.info("Comfy idle unload watcher started (%ds)", IDLE_UNLOAD_SEC)
    except Exception as e:
        log.warning("Could not start idle unload watcher: %s", e)
