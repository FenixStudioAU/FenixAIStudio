"""Local LoRA detection, HF search with architecture filtering, install."""
from __future__ import annotations

import re
import shutil
from pathlib import Path
from typing import Any, Optional

from .config import settings
from .logging_setup import log
from .models_detect import MODEL_CATALOG

# Hugging Face base model tags we map to architectures
ARCH_PATTERNS = {
    "flux2-klein": [
        r"flux\.?2",
        r"flux2",
        r"klein",
        r"flux\.2-klein",
        r"black-forest-labs/FLUX\.2",
    ],
    "flux1": [r"flux\.1", r"flux1", r"\bflux\b"],
    "sdxl": [r"sdxl", r"stable-diffusion-xl", r"sd_xl"],
    "sd15": [r"sd1\.5", r"sd15", r"stable-diffusion-v1", r"sd-v1"],
    "wan": [r"\bwan\b", r"wan2"],
    "minimax-h3": [r"minimax", r"hailuo"],
}


def lora_dir() -> Path:
    return settings.comfy_install / "models" / "loras"


def list_local_loras() -> list[dict[str, Any]]:
    root = lora_dir()
    root.mkdir(parents=True, exist_ok=True)
    items = []
    for p in sorted(root.rglob("*")):
        if p.suffix.lower() not in {".safetensors", ".pt", ".ckpt", ".bin"}:
            continue
        # Skip HF hub cache trees / junk placeholders
        rel = str(p.relative_to(root)).replace("\\", "/")
        if any(part.startswith(".") or part == "_hf_cache" for part in p.relative_to(root).parts):
            continue
        if p.name.startswith("put_") or p.stat().st_size < 1024:
            continue
        items.append(
            {
                "name": rel,
                "filename": p.name,
                "path": str(p),
                "size_bytes": p.stat().st_size,
                "size_mb": round(p.stat().st_size / (1024 * 1024), 1),
            }
        )
    return items


def architecture_for_model(model_id: str) -> str:
    meta = MODEL_CATALOG.get(model_id, {})
    return meta.get("architecture", model_id)


def is_lora_compatible(model_id: str, card: dict[str, Any]) -> tuple[bool, str]:
    """Heuristic compatibility check against HF model card / tags / id."""
    arch = architecture_for_model(model_id)
    meta = MODEL_CATALOG.get(model_id, {})
    good_tags = [t.lower() for t in meta.get("lora_base_tags", [])]
    bad_tags = [t.lower() for t in meta.get("incompatible_lora_tags", [])]

    blob_parts = [
        str(card.get("id", "")),
        str(card.get("modelId", "")),
        " ".join(card.get("tags") or []),
        str(card.get("pipeline_tag") or ""),
        str((card.get("cardData") or {}).get("base_model") or ""),
        str((card.get("cardData") or {}).get("tags") or ""),
        str(card.get("description") or "")[:500],
    ]
    blob = " ".join(blob_parts).lower()

    # Hard reject incompatible architectures
    for bad in bad_tags:
        if bad in blob and not any(g in blob for g in good_tags):
            # e.g. sdxl lora when searching flux
            if bad in ("sdxl", "sd1.5", "sd15", "pony", "illustrious") and arch.startswith("flux"):
                return False, f"incompatible tag '{bad}'"
            if bad in ("flux",) and arch in ("minimax-h3", "wan"):
                return False, f"incompatible tag '{bad}'"

    # Require positive signal for flux2-klein
    if arch == "flux2-klein":
        patterns = ARCH_PATTERNS["flux2-klein"] + ARCH_PATTERNS["flux1"]
        if any(re.search(p, blob) for p in patterns):
            # Prefer flux2; allow general flux with warning
            if any(re.search(p, blob) for p in ARCH_PATTERNS["flux2-klein"]):
                return True, "matches flux2/klein"
            return True, "matches flux (verify Klein/Flux.2 compatibility)"
        # Some LoRAs only tag "lora" + base model field
        base = str((card.get("cardData") or {}).get("base_model") or "").lower()
        if "flux" in base:
            return True, f"base_model={base}"
        return False, "no flux/flux2 signal"

    if arch == "minimax-h3":
        if any(re.search(p, blob) for p in ARCH_PATTERNS["minimax-h3"]):
            return True, "matches minimax"
        return False, "no minimax signal"

    # default: require any good tag
    if any(g in blob for g in good_tags):
        return True, "tag match"
    return False, "no architecture match"


def search_huggingface_loras(
    query: str,
    base_model: str = "flux2-klein-4b",
    limit: int = 20,
) -> list[dict[str, Any]]:
    """Search HF for LoRAs and filter by base model architecture."""
    try:
        from huggingface_hub import HfApi
    except ImportError as e:
        raise RuntimeError("huggingface_hub not installed") from e

    api = HfApi()
    # Search peft / lora models
    q = (query or "style").strip()
    arch = architecture_for_model(base_model)
    # Expand query with architecture hints
    if arch == "flux2-klein" and "flux" not in q.lower():
        search_q = f"{q} flux lora"
    else:
        search_q = f"{q} lora"

    results = []
    try:
        models = api.list_models(
            search=search_q,
            filter=["lora"],
            sort="downloads",
            direction=-1,
            limit=min(limit * 4, 80),
        )
    except Exception:
        # older hub API
        models = api.list_models(search=search_q, sort="downloads", direction=-1, limit=min(limit * 4, 80))

    for m in models:
        card = {
            "id": getattr(m, "id", None) or getattr(m, "modelId", ""),
            "tags": list(getattr(m, "tags", None) or []),
            "pipeline_tag": getattr(m, "pipeline_tag", None),
            "downloads": getattr(m, "downloads", 0),
            "likes": getattr(m, "likes", 0),
            "cardData": getattr(m, "cardData", None) or {},
        }
        # Skip if clearly not a lora
        tags = [t.lower() for t in card["tags"]]
        tid = card["id"].lower()
        if "lora" not in " ".join(tags) and "lora" not in tid and "lycoris" not in tid:
            # still allow if peft
            if "peft" not in tags:
                continue

        ok, reason = is_lora_compatible(base_model, card)
        if not ok:
            continue

        # Preview image from HF
        preview = f"https://huggingface.co/{card['id']}/resolve/main/thumbnail.png"
        results.append(
            {
                "id": card["id"],
                "name": card["id"].split("/")[-1],
                "creator": card["id"].split("/")[0] if "/" in card["id"] else "",
                "downloads": card["downloads"],
                "likes": card["likes"],
                "tags": card["tags"][:12],
                "license": _extract_license(card),
                "preview_url": preview,
                "compatibility": reason,
                "compatible": True,
                "base_model_requested": base_model,
                "url": f"https://huggingface.co/{card['id']}",
            }
        )
        if len(results) >= limit:
            break

    log.info("HF LoRA search q=%r base=%s -> %d compatible", query, base_model, len(results))
    return results


def _extract_license(card: dict[str, Any]) -> str:
    tags = card.get("tags") or []
    for t in tags:
        if str(t).startswith("license:"):
            return str(t).split(":", 1)[-1]
    cd = card.get("cardData") or {}
    if isinstance(cd, dict) and cd.get("license"):
        return str(cd["license"])
    return "unknown"


def download_lora(repo_id: str, filename: str | None = None) -> dict[str, Any]:
    """Download a LoRA from Hugging Face into ComfyUI loras folder."""
    from huggingface_hub import hf_hub_download, list_repo_files

    dest_root = lora_dir()
    dest_root.mkdir(parents=True, exist_ok=True)

    files = list_repo_files(repo_id)
    candidates = [
        f
        for f in files
        if f.lower().endswith((".safetensors", ".pt", ".ckpt"))
        and "lora" in f.lower()
        or f.lower().endswith(".safetensors")
    ]
    # Prefer safetensors in root
    safes = [f for f in files if f.lower().endswith(".safetensors")]
    pick = filename
    if not pick:
        # smallest reasonable > 1MB preference: first safetensors not in vae/unet folders
        ranked = sorted(
            safes,
            key=lambda x: (
                0 if "/" not in x else 1,
                0 if "lora" in x.lower() else 1,
                len(x),
            ),
        )
        if not ranked:
            raise RuntimeError(f"No .safetensors found in {repo_id}")
        pick = ranked[0]

    log.info("Downloading LoRA %s / %s", repo_id, pick)
    local = hf_hub_download(repo_id=repo_id, filename=pick, local_dir=str(dest_root / repo_id.replace("/", "__")))
    # Also copy flat name for easy ComfyUI selection
    src = Path(local)
    flat_name = f"{repo_id.replace('/', '__')}__{src.name}"
    flat_path = dest_root / flat_name
    if not flat_path.exists():
        shutil.copy2(src, flat_path)

    return {
        "name": flat_name,
        "path": str(flat_path),
        "repo_id": repo_id,
        "source_file": pick,
        "size_mb": round(flat_path.stat().st_size / (1024 * 1024), 1),
    }


def import_lora_file(source_path: str, name: str | None = None) -> dict[str, Any]:
    src = Path(source_path)
    if not src.is_file():
        raise FileNotFoundError(source_path)
    dest_root = lora_dir()
    dest_root.mkdir(parents=True, exist_ok=True)
    dest_name = name or src.name
    dest = dest_root / dest_name
    shutil.copy2(src, dest)
    return {"name": dest_name, "path": str(dest), "size_mb": round(dest.stat().st_size / (1024 * 1024), 1)}


async def refresh_comfyui_if_possible() -> dict[str, Any]:
    """ComfyUI picks up new LoRAs on next object_info / refresh; try manager API if present."""
    from .comfyui_client import comfy

    online = await comfy.is_online()
    if not online:
        return {"refreshed": False, "reason": "ComfyUI offline"}
    # Re-fetch loras list forces folder scan in many versions
    loras = await comfy.list_models("loras")
    return {"refreshed": True, "lora_count": len(loras)}
