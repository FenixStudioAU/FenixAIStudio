"""Assemble timeline into MP4 via FFmpeg (images, videos, titles, transitions, SRT)."""
from __future__ import annotations

import json
import shlex
import subprocess
import tempfile
from pathlib import Path
from typing import Any, Optional

from .config import settings
from .logging_setup import log
from .project_store import abs_path, project_dir
from .schemas import Project

ffmpeg_log = __import__("logging").getLogger("amvs.ffmpeg")


def _run(cmd: list[str], cwd: Path | None = None) -> None:
    ffmpeg_log.info("RUN: %s", " ".join(shlex.quote(c) for c in cmd))
    proc = subprocess.run(
        cmd,
        cwd=str(cwd) if cwd else None,
        capture_output=True,
        text=True,
        encoding="utf-8",
        errors="replace",
    )
    if proc.returncode != 0:
        ffmpeg_log.error("FFmpeg stderr: %s", proc.stderr[-4000:])
        raise RuntimeError(f"FFmpeg failed ({proc.returncode}): {proc.stderr[-1500:]}")
    if proc.stderr:
        ffmpeg_log.debug(proc.stderr[-2000:])


def parse_resolution(res: str) -> tuple[int, int]:
    w, h = res.lower().split("x")
    return int(w), int(h)


def _effect_filters(effects: list) -> list[str]:
    """Map VisualEffect list to ffmpeg filter fragments."""
    parts: list[str] = []
    for e in effects or []:
        enabled = getattr(e, "enabled", True) if not isinstance(e, dict) else e.get("enabled", True)
        if not enabled:
            continue
        et = getattr(e, "type", None) if not isinstance(e, dict) else e.get("type")
        strength = float(getattr(e, "strength", 0.5) if not isinstance(e, dict) else e.get("strength", 0.5))
        s = max(0.0, min(1.0, strength))
        if not et or et == "none":
            continue
        if et == "film_grain":
            # alls ~ 5..40
            n = int(5 + s * 35)
            parts.append(f"noise=alls={n}:allf=t")
        elif et == "glitch":
            # cheap glitch: horizontal rgb shift + slight noise
            sh = max(1, int(s * 8))
            parts.append(f"rgbashift=rh={sh}:bh=-{sh}")
            parts.append(f"noise=alls={int(3 + s * 12)}:allf=t")
        elif et == "hue_cycle":
            # animated hue over time
            parts.append(f"hue=h={s * 360}*t:s=1")
        elif et == "vignette":
            # angle  PI/4 .. PI/2-ish via strength
            parts.append(f"vignette=PI/{max(2.5, 5 - s * 2.5)}:mode=forward")
        elif et == "bw":
            parts.append("hue=s=0")
        elif et == "blur":
            r = max(1, int(s * 4))
            parts.append(f"boxblur={r}:{r}")
        elif et == "chromatic":
            sh = max(1, int(s * 6))
            parts.append(f"rgbashift=rh={sh}:bh=-{sh}")
        elif et == "sharpen":
            # unsharp amount 0.5..2.5
            a = 0.5 + s * 2.0
            parts.append(f"unsharp=5:5:{a:0.2f}:5:5:0.0")
    return parts


def _compose_vf(base_scale_pad: str, effects: list) -> str:
    bits = [base_scale_pad] + _effect_filters(effects) + ["format=yuv420p"]
    return ",".join(bits)


def _slot_frame_count(duration_sec: float, fps: int) -> int:
    """Integer frame count for a timeline slot (rounds to nearest frame)."""
    fps = max(1, int(fps))
    return max(1, int(round(float(duration_sec) * fps)))


def _exact_slot_duration(duration_sec: float, fps: int) -> tuple[int, float]:
    """Return (frame_count, duration_sec) snapped to whole frames at export fps."""
    n = _slot_frame_count(duration_sec, fps)
    return n, float(n) / float(max(1, int(fps)))


def _segment_vf(base_vf: str, fps: int, n_frames: int, exact_dur: float) -> str:
    """
    Force each segment to exactly n_frames at CFR fps.

    Use end_frame trim (not float duration) so boundaries stay frame-accurate.
    tpad only fills if the source is short — long MiniMax clips are just trimmed.
    """
    n_frames = max(1, int(n_frames))
    # Enough pad for a short source; unused when the clip already covers the slot.
    pad = max(exact_dur, 1.0) + 0.5
    return (
        f"{base_vf},"
        f"fps={fps},"
        f"setpts=PTS-STARTPTS,"
        f"tpad=stop_mode=clone:stop_duration={pad:.3f},"
        f"trim=end_frame={n_frames},"
        f"setpts=PTS-STARTPTS"
    )


def export_project(project: Project, progress_cb=None) -> Path:
    """Export finished music video MP4."""
    root = project_dir(project.id)
    export_dir = root / "exports"
    export_dir.mkdir(parents=True, exist_ok=True)

    # Default 16:9 master; only 720p / 1080p landscape for MVP export
    res = project.export.resolution or "1920x1080"
    if res not in ("1920x1080", "1280x720"):
        res = "1920x1080" if project.export.preset == "final" else "1280x720"
    w, h = parse_resolution(res)
    fps = int(project.export.fps or 24)
    crf = 28 if project.export.preset == "draft" else int(project.export.crf or 18)
    preset_x264 = "veryfast" if project.export.preset == "draft" else "medium"

    shots = sorted(project.timeline.shots, key=lambda s: s.start)
    if not shots:
        raise RuntimeError("No shots on timeline")

    work = root / "cache" / "export_work"
    if work.exists():
        import shutil

        shutil.rmtree(work)
    work.mkdir(parents=True, exist_ok=True)

    # Build per-shot video segments (silent, exact frame counts @ export fps).
    # Snapping each slot to whole frames prevents cumulative A/V drift vs the song.
    segment_files: list[Path] = []
    total_frames = 0
    for i, shot in enumerate(shots):
        if progress_cb:
            progress_cb({"stage": "segments", "index": i, "total": len(shots)})
        seg = work / f"seg_{i:04d}.mp4"
        n_frames, exact_dur = _exact_slot_duration(max(0.1, float(shot.duration)), fps)
        total_frames += n_frames
        vid = abs_path(project.id, shot.video_path or shot.draft_video_path)
        img = abs_path(project.id, shot.image_path)

        # Scale/pad only here — fps/trim/tpad applied in _segment_vf for video clips
        base_scale = (
            f"scale={w}:{h}:force_original_aspect_ratio=decrease,"
            f"pad={w}:{h}:(ow-iw)/2:(oh-ih)/2"
        )
        shot_fx = list(getattr(shot, "effects", None) or [])
        global_fx = list(getattr(project.export, "global_effects", None) or [])
        scale_fx = _compose_vf(base_scale, shot_fx + global_fx)

        if vid and vid.exists():
            vf = _segment_vf(scale_fx, fps, n_frames, exact_dur)
            _run(
                [
                    settings.ffmpeg,
                    "-y",
                    "-i",
                    str(vid),
                    "-vf",
                    vf,
                    "-an",
                    "-r",
                    str(fps),
                    "-frames:v",
                    str(n_frames),
                    "-c:v",
                    "libx264",
                    "-preset",
                    preset_x264,
                    "-crf",
                    str(crf),
                    "-pix_fmt",
                    "yuv420p",
                    "-g",
                    str(max(fps, 24)),  # shorter GOP → cleaner joins at hard cuts
                    "-bf",
                    "0",  # no B-frames across segment edges
                    str(seg),
                ]
            )
        elif img and img.exists():
            # Still → exactly n_frames at export fps
            vf = f"{scale_fx},fps={fps},setpts=PTS-STARTPTS"
            _run(
                [
                    settings.ffmpeg,
                    "-y",
                    "-loop",
                    "1",
                    "-framerate",
                    str(fps),
                    "-i",
                    str(img),
                    "-vf",
                    vf,
                    "-r",
                    str(fps),
                    "-frames:v",
                    str(n_frames),
                    "-c:v",
                    "libx264",
                    "-preset",
                    preset_x264,
                    "-crf",
                    str(crf),
                    "-pix_fmt",
                    "yuv420p",
                    "-g",
                    str(max(fps, 24)),
                    "-bf",
                    "0",
                    str(seg),
                ]
            )
        else:
            # Placeholder slate (no drawtext — avoids Windows fontconfig crashes)
            _run(
                [
                    settings.ffmpeg,
                    "-y",
                    "-f",
                    "lavfi",
                    "-i",
                    f"color=c=0x1a1a2e:s={w}x{h}:d={exact_dur:.6f}:r={fps}",
                    "-r",
                    str(fps),
                    "-frames:v",
                    str(n_frames),
                    "-c:v",
                    "libx264",
                    "-pix_fmt",
                    "yuv420p",
                    "-preset",
                    preset_x264,
                    "-crf",
                    str(crf),
                    "-g",
                    str(max(fps, 24)),
                    "-bf",
                    "0",
                    str(seg),
                ]
            )
        got = _probe_duration(seg)
        if abs(got - exact_dur) > (1.5 / float(fps)):
            log.warning(
                "export seg %d duration drift: want=%.4fs got=%.4fs (shot %s)",
                i,
                exact_dur,
                got,
                getattr(shot, "id", "?"),
            )
        segment_files.append(seg)
    log.info(
        "Export segments: %d shots, %d frames @ %dfps (%.3fs video)",
        len(segment_files),
        total_frames,
        fps,
        total_frames / float(fps),
    )

    # Apply simple transitions via xfade where requested
    if progress_cb:
        progress_cb({"stage": "transitions"})
    concat_path = _concat_with_transitions(segment_files, shots, work, fps, w, h, crf, preset_x264)

    # Titles overlay
    titled = work / "with_titles.mp4"
    if project.timeline.titles:
        if progress_cb:
            progress_cb({"stage": "titles"})
        _burn_titles(concat_path, titled, project, w, h, fps)
        video_path = titled
    else:
        video_path = concat_path

    # Mix main audio + optional unmuted clip audio
    audio_path = abs_path(project.id, project.audio.path)
    mixed = work / "with_audio.mp4"
    if progress_cb:
        progress_cb({"stage": "audio"})
    if audio_path and audio_path.exists():
        _mux_audio(video_path, audio_path, mixed, project, shots, work, crf, preset_x264)
        video_path = mixed

    # Subtitles
    out_name = f"{project.name.replace(' ', '_')}_{project.export.preset}.mp4"
    final_path = export_dir / out_name
    srt = abs_path(project.id, project.subtitles.srt_path) if project.subtitles.enabled else None
    if srt and srt.exists() and project.export.include_subtitles and project.subtitles.burn_in:
        if progress_cb:
            progress_cb({"stage": "subtitles"})
        # escape path for subtitles filter (Windows)
        srt_escaped = str(srt).replace("\\", "/").replace(":", "\\:")
        style = (
            f"FontSize={project.subtitles.font_size},"
            f"PrimaryColour=&H00FFFFFF,OutlineColour=&H00000000,BorderStyle=1"
        )
        _run(
            [
                settings.ffmpeg,
                "-y",
                "-i",
                str(video_path),
                "-vf",
                f"subtitles='{srt_escaped}':force_style='{style}'",
                "-c:a",
                "copy",
                "-c:v",
                "libx264",
                "-preset",
                preset_x264,
                "-crf",
                str(crf),
                str(final_path),
            ]
        )
    else:
        import shutil

        shutil.copy2(video_path, final_path)

    # Watermark only on the finished export (not on stills or per-shot clips)
    try:
        from .watermark import apply_video_watermark

        apply_video_watermark(final_path)
    except Exception as we:
        log.warning("export watermark: %s", we)

    if progress_cb:
        progress_cb({"stage": "done", "path": str(final_path)})
    log.info("Exported %s", final_path)
    return final_path


def _concat_with_transitions(
    segments: list[Path],
    shots: list,
    work: Path,
    fps: int,
    w: int,
    h: int,
    crf: int,
    preset: str,
) -> Path:
    """Concat demuxer for hard cuts; xfade chain for crossfades."""
    # If no soft transitions, simple concat
    soft = any(
        getattr(s, "transition_out", "hard_cut") in ("crossfade", "fade_black", "fade_white")
        and getattr(s, "transition_duration", 0) > 0
        for s in shots[:-1]
    )
    if not soft:
        # Re-encode (don't stream-copy): -c copy leaves a decoder hitch / micro-pause
        # at every segment boundary because each file starts a new GOP.
        lst = work / "concat.txt"
        lines = [f"file '{p.resolve().as_posix()}'" for p in segments]
        lst.write_text("\n".join(lines), encoding="utf-8")
        out = work / "concat.mp4"
        _run(
            [
                settings.ffmpeg,
                "-y",
                "-f",
                "concat",
                "-safe",
                "0",
                "-i",
                str(lst),
                "-fflags",
                "+genpts",
                "-r",
                str(fps),
                "-an",
                "-c:v",
                "libx264",
                "-preset",
                preset,
                "-crf",
                str(crf),
                "-pix_fmt",
                "yuv420p",
                "-g",
                str(max(int(fps) * 2, 48)),
                str(out),
            ]
        )
        return out

    # Build filter_complex xfade chain
    # For fade_black: fade out + fade in via color
    current = segments[0]
    for i in range(1, len(segments)):
        prev_shot = shots[i - 1]
        td = float(getattr(prev_shot, "transition_duration", 0) or 0)
        kind = getattr(prev_shot, "transition_out", "hard_cut")
        out = work / f"xfade_{i}.mp4"
        if kind == "crossfade" and td > 0:
            # offset = duration_so_far - td; approximate using probe
            d0 = _probe_duration(current)
            offset = max(0.0, d0 - td)
            _run(
                [
                    settings.ffmpeg,
                    "-y",
                    "-i",
                    str(current),
                    "-i",
                    str(segments[i]),
                    "-filter_complex",
                    f"[0:v][1:v]xfade=transition=fade:duration={td:.3f}:offset={offset:.3f},format=yuv420p[v]",
                    "-map",
                    "[v]",
                    "-an",
                    "-c:v",
                    "libx264",
                    "-preset",
                    preset,
                    "-crf",
                    str(crf),
                    str(out),
                ]
            )
            current = out
        else:
            # hard cut — re-encode so the join isn't a stream-copy hitch
            lst = work / f"c_{i}.txt"
            lst.write_text(
                f"file '{current.resolve().as_posix()}'\nfile '{segments[i].resolve().as_posix()}'\n",
                encoding="utf-8",
            )
            _run(
                [
                    settings.ffmpeg,
                    "-y",
                    "-f",
                    "concat",
                    "-safe",
                    "0",
                    "-i",
                    str(lst),
                    "-fflags",
                    "+genpts",
                    "-r",
                    str(fps),
                    "-an",
                    "-c:v",
                    "libx264",
                    "-preset",
                    preset,
                    "-crf",
                    str(crf),
                    "-pix_fmt",
                    "yuv420p",
                    str(out),
                ]
            )
            current = out
    return current


def _probe_duration(path: Path) -> float:
    proc = subprocess.run(
        [
            settings.ffprobe,
            "-v",
            "error",
            "-show_entries",
            "format=duration",
            "-of",
            "default=noprint_wrappers=1:nokey=1",
            str(path),
        ],
        capture_output=True,
        text=True,
    )
    try:
        return float(proc.stdout.strip())
    except Exception:
        return 0.0


def _burn_titles(video: Path, out: Path, project: Project, w: int, h: int, fps: int) -> None:
    # Build drawtext chain; use a known Windows font to avoid fontconfig crashes
    fontfile = _windows_font()
    filters = []
    for t in project.timeline.titles:
        text = t.text.replace("\\", "\\\\").replace(":", "\\:").replace("'", "\\'").replace("%", "\\%")
        fontsize = int(t.size)
        if t.position == "top":
            x, y = "(w-text_w)/2", "40"
        elif t.position == "bottom":
            x, y = "(w-text_w)/2", "h-80"
        else:
            x, y = f"(w-text_w)*{t.x}", f"(h-text_h)*{t.y}"
        start = float(t.start)
        end = start + float(t.duration)
        fi, fo = float(t.fade_in), float(t.fade_out)
        alpha = (
            f"if(lt(t,{start}),0,if(lt(t,{start+fi}),(t-{start})/{max(fi,0.001)},"
            f"if(lt(t,{end-fo}),1,if(lt(t,{end}),({end}-t)/{max(fo,0.001)},0))))"
        )
        font_opt = f"fontfile='{fontfile}':" if fontfile else ""
        filters.append(
            f"drawtext={font_opt}text='{text}':fontsize={fontsize}:fontcolor=white@{alpha}:"
            f"x={x}:y={y}:shadowcolor=black@0.6:shadowx=2:shadowy=2"
        )
    if not filters:
        import shutil

        shutil.copy2(video, out)
        return
    vf = ",".join(filters)
    _run(
        [
            settings.ffmpeg,
            "-y",
            "-i",
            str(video),
            "-vf",
            vf,
            "-c:a",
            "copy",
            "-c:v",
            "libx264",
            "-pix_fmt",
            "yuv420p",
            str(out),
        ]
    )


def _windows_font() -> str | None:
    candidates = [
        Path(r"C:\Windows\Fonts\arial.ttf"),
        Path(r"C:\Windows\Fonts\segoeui.ttf"),
        Path(r"C:\Windows\Fonts\calibri.ttf"),
    ]
    for p in candidates:
        if p.is_file():
            # FFmpeg on Windows wants forward slashes and escaped drive colon
            return str(p).replace("\\", "/").replace(":", "\\:")
    return None


def _mux_audio(
    video: Path,
    main_audio: Path,
    out: Path,
    project: Project,
    shots: list,
    work: Path,
    crf: int,
    preset: str,
) -> None:
    """Mux timeline video with the project song (unchanged) + optional clip audio.

    Never trim/pad/stretch/resample the song for timing — sync is fixed on the
    video side (exact frame-count segments). The master track is copied as-is.
    """
    filter_parts: list[str] = []
    # base: video + main audio (song left untouched)
    cmd = [settings.ffmpeg, "-y", "-i", str(video), "-i", str(main_audio)]
    idx = 2
    mix_labels = ["[1:a]"]
    for i, shot in enumerate(shots):
        if shot.video.mute_clip_audio:
            continue
        vid = abs_path(project.id, shot.video_path or shot.draft_video_path)
        if not vid or not vid.exists():
            continue
        cmd.extend(["-i", str(vid)])
        # delay clip audio to shot.start (only affects optional clip beds, not the song)
        delay_ms = int(float(shot.start) * 1000)
        filter_parts.append(
            f"[{idx}:a]aformat=sample_fmts=fltp:sample_rates=44100:channel_layouts=stereo,"
            f"volume=0.8,adelay={delay_ms}|{delay_ms}[a{i}]"
        )
        mix_labels.append(f"[a{i}]")
        idx += 1

    if len(mix_labels) == 1:
        # Song only — no audio filters, no -shortest (do not chop or stretch the track).
        # AAC remux for MP4 compatibility; timing/pitch unchanged.
        cmd.extend(
            [
                "-map",
                "0:v",
                "-map",
                "1:a",
                "-c:v",
                "copy",
                "-c:a",
                "aac",
                "-b:a",
                project.export.audio_bitrate or "192k",
                str(out),
            ]
        )
        _run(cmd)
        return

    # Song + optional clip audio. Format song for amix only (layout) — no trim/pad/tempo.
    n = len(mix_labels)
    filter_parts.insert(
        0,
        "[1:a]aformat=sample_fmts=fltp:sample_rates=44100:channel_layouts=stereo[maina]",
    )
    mix_labels[0] = "[maina]"
    filter_parts.append(
        "".join(mix_labels) + f"amix=inputs={n}:duration=longest:dropout_transition=2[aout]"
    )
    cmd.extend(
        [
            "-filter_complex",
            ";".join(filter_parts),
            "-map",
            "0:v",
            "-map",
            "[aout]",
            "-c:v",
            "copy",
            "-c:a",
            "aac",
            "-b:a",
            project.export.audio_bitrate or "192k",
            str(out),
        ]
    )
    _run(cmd)
