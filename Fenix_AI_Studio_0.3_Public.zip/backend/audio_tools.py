"""Audio import, waveform peaks, beat/energy analysis."""
from __future__ import annotations

import json
from pathlib import Path
from typing import Any

import numpy as np

from .logging_setup import log


def write_silent_wav(
    dest: Path,
    duration_sec: float,
    sample_rate: int = 44100,
    channels: int = 2,
) -> Path:
    """Write a silent WAV for LTX I2V-without-lip-sync (keeps AV graph valid)."""
    duration_sec = max(0.25, float(duration_sec or 1.0))
    dest.parent.mkdir(parents=True, exist_ok=True)
    n = max(1, int(duration_sec * sample_rate))
    try:
        import numpy as np
        import soundfile as sf

        data = np.zeros((n, max(1, int(channels))), dtype=np.float32)
        sf.write(str(dest), data, int(sample_rate))
        return dest
    except Exception as e:
        log.warning("soundfile silent wav failed (%s) — trying ffmpeg", e)
    from .config import resolve_ffmpeg_binary, settings as _settings
    import subprocess

    ffmpeg = resolve_ffmpeg_binary(_settings.ffmpeg) or "ffmpeg"
    cmd = [
        ffmpeg,
        "-y",
        "-f",
        "lavfi",
        "-i",
        f"anullsrc=r={sample_rate}:cl=stereo",
        "-t",
        f"{duration_sec:.3f}",
        "-acodec",
        "pcm_s16le",
        str(dest),
    ]
    subprocess.run(cmd, check=True, capture_output=True)
    if not dest.is_file() or dest.stat().st_size < 64:
        raise RuntimeError(f"ffmpeg silent wav failed for {dest}")
    return dest


def slice_audio_clip(
    src: Path,
    dest: Path,
    start_sec: float,
    duration_sec: float,
) -> Path:
    """Extract a mono/stereo PCM wav slice for Comfy LoadAudio (IA2V etc)."""
    start_sec = max(0.0, float(start_sec or 0.0))
    duration_sec = max(0.25, float(duration_sec or 1.0))
    dest.parent.mkdir(parents=True, exist_ok=True)
    try:
        import soundfile as sf

        info = sf.info(str(src))
        sr = int(info.samplerate)
        start_frame = int(start_sec * sr)
        n_frames = int(duration_sec * sr)
        with sf.SoundFile(str(src), "r") as f:
            f.seek(min(start_frame, max(0, len(f) - 1)))
            data = f.read(n_frames, dtype="float32")
        if getattr(data, "size", 0) == 0:
            raise RuntimeError("empty audio slice")
        sf.write(str(dest), data, sr)
        return dest
    except Exception as e:
        log.warning("soundfile slice failed (%s) — trying ffmpeg", e)
    from .config import resolve_ffmpeg_binary, settings as _settings

    ffmpeg = resolve_ffmpeg_binary(_settings.ffmpeg) or "ffmpeg"
    import subprocess

    cmd = [
        ffmpeg,
        "-y",
        "-ss",
        f"{start_sec:.3f}",
        "-t",
        f"{duration_sec:.3f}",
        "-i",
        str(src),
        "-acodec",
        "pcm_s16le",
        "-ar",
        "44100",
        str(dest),
    ]
    subprocess.run(cmd, check=True, capture_output=True)
    if not dest.is_file() or dest.stat().st_size < 64:
        raise RuntimeError(f"ffmpeg audio slice failed for {src}")
    return dest


def probe_duration(path: Path) -> dict[str, Any]:
    """Return duration and basic meta using soundfile / librosa."""
    try:
        import soundfile as sf

        info = sf.info(str(path))
        return {
            "duration": float(info.duration),
            "sample_rate": int(info.samplerate),
            "channels": int(info.channels),
        }
    except Exception as e:
        log.warning("soundfile probe failed: %s", e)
    try:
        import librosa

        y, sr = librosa.load(str(path), sr=None, mono=True)
        return {"duration": float(len(y) / sr), "sample_rate": int(sr), "channels": 1}
    except Exception as e:
        raise RuntimeError(f"Cannot read audio: {e}") from e


def build_waveform_peaks(path: Path, out_json: Path, peaks: int = 2000) -> Path:
    """Downsampled peak envelope for UI waveform."""
    import librosa

    y, sr = librosa.load(str(path), sr=22050, mono=True)
    if len(y) == 0:
        data = {"duration": 0, "sample_rate": sr, "peaks": []}
    else:
        chunk = max(1, len(y) // peaks)
        # peak amplitude per chunk
        n = len(y) // chunk
        arr = y[: n * chunk].reshape(n, chunk)
        peak = np.max(np.abs(arr), axis=1)
        peak = (peak / (peak.max() + 1e-9)).astype(float).tolist()
        data = {
            "duration": float(len(y) / sr),
            "sample_rate": int(sr),
            "peaks": peak,
        }
    out_json.parent.mkdir(parents=True, exist_ok=True)
    out_json.write_text(json.dumps(data), encoding="utf-8")
    return out_json


def analyze_audio(path: Path, out_json: Path) -> dict[str, Any]:
    """Beats, onset strength peaks, energy segments for suggested cuts."""
    import librosa

    y, sr = librosa.load(str(path), sr=22050, mono=True)
    duration = float(len(y) / sr)
    result: dict[str, Any] = {
        "duration": duration,
        "sample_rate": int(sr),
        "beats": [],
        "onsets": [],
        "energy_cuts": [],
        "sections": [],
    }
    try:
        tempo, beat_frames = librosa.beat.beat_track(y=y, sr=sr)
        beat_times = librosa.frames_to_time(beat_frames, sr=sr)
        result["tempo"] = float(np.atleast_1d(tempo)[0]) if np.size(tempo) else 0.0
        result["beats"] = [round(float(t), 3) for t in beat_times]
    except Exception as e:
        log.warning("beat_track failed: %s", e)
        result["tempo"] = 0.0

    try:
        onset_env = librosa.onset.onset_strength(y=y, sr=sr)
        onset_frames = librosa.onset.onset_detect(onset_envelope=onset_env, sr=sr, backtrack=True)
        onset_times = librosa.frames_to_time(onset_frames, sr=sr)
        result["onsets"] = [round(float(t), 3) for t in onset_times]
    except Exception as e:
        log.warning("onset detect failed: %s", e)

    # Energy-based cuts: large RMS jumps
    try:
        hop = 512
        rms = librosa.feature.rms(y=y, hop_length=hop)[0]
        times = librosa.frames_to_time(np.arange(len(rms)), sr=sr, hop_length=hop)
        # smooth
        win = 8
        kernel = np.ones(win) / win
        smooth = np.convolve(rms, kernel, mode="same")
        delta = np.diff(smooth, prepend=smooth[0])
        thr = np.percentile(np.abs(delta), 92)
        cuts = []
        last = -999.0
        for t, d in zip(times, delta):
            if abs(d) >= thr and (t - last) >= 1.5:
                cuts.append(round(float(t), 3))
                last = float(t)
        result["energy_cuts"] = cuts
    except Exception as e:
        log.warning("energy cuts failed: %s", e)

    # Simple sectioning by spectral contrast / chroma change every ~8-16s
    try:
        sections = _estimate_sections(y, sr, duration)
        result["sections"] = sections
    except Exception as e:
        log.warning("sections failed: %s", e)

    out_json.parent.mkdir(parents=True, exist_ok=True)
    out_json.write_text(json.dumps(result, indent=2), encoding="utf-8")
    return result


def _estimate_sections(y: np.ndarray, sr: int, duration: float) -> list[dict[str, Any]]:
    import librosa

    hop = 2048
    mfcc = librosa.feature.mfcc(y=y, sr=sr, n_mfcc=13, hop_length=hop)
    # self-similarity novelty
    mfcc_n = librosa.util.normalize(mfcc, axis=1)
    # downsample frames
    step = max(1, mfcc_n.shape[1] // 200)
    m = mfcc_n[:, ::step]
    # novelty from consecutive frame distance
    dists = np.linalg.norm(np.diff(m, axis=1), axis=0)
    if len(dists) == 0:
        return [{"start": 0.0, "end": duration, "label": "full"}]
    thr = np.percentile(dists, 85)
    bounds = [0.0]
    frame_times = librosa.frames_to_time(np.arange(0, mfcc_n.shape[1], step), sr=sr, hop_length=hop)
    last = 0.0
    for i, d in enumerate(dists):
        t = float(frame_times[min(i + 1, len(frame_times) - 1)])
        if d >= thr and (t - last) >= 6.0:
            bounds.append(round(t, 3))
            last = t
    bounds.append(round(duration, 3))
    # unique sorted
    bounds = sorted(set(bounds))
    labels = ["intro", "verse", "chorus", "bridge", "outro", "section"]
    sections = []
    for i in range(len(bounds) - 1):
        sections.append(
            {
                "start": bounds[i],
                "end": bounds[i + 1],
                "label": labels[min(i, len(labels) - 1)],
            }
        )
    return sections


def slots_from_analysis(
    analysis: dict[str, Any],
    mode: str = "beats",
    target_duration: float = 5.0,
    song_duration: float | None = None,
) -> list[dict[str, float]]:
    """Build shot start/duration list from analysis."""
    duration = float(song_duration or analysis.get("duration") or 0)
    if duration <= 0:
        return []

    if mode == "sections" and analysis.get("sections"):
        slots = []
        for sec in analysis["sections"]:
            s = float(sec["start"])
            e = float(sec["end"])
            # split long sections into target_duration chunks
            t = s
            while t < e - 0.05:
                d = min(target_duration, e - t)
                slots.append({"start": round(t, 3), "duration": round(d, 3)})
                t += d
        return slots

    cuts: list[float] = [0.0]
    if mode == "beats":
        # every N beats ~ target_duration
        beats = analysis.get("beats") or []
        if beats:
            # average beat interval
            if len(beats) > 1:
                ibi = float(np.median(np.diff(beats)))
                n = max(1, int(round(target_duration / max(ibi, 0.01))))
            else:
                n = 4
            for i, b in enumerate(beats):
                if i % n == 0:
                    cuts.append(float(b))
        cuts.extend(analysis.get("energy_cuts") or [])
    elif mode == "energy":
        cuts.extend(analysis.get("energy_cuts") or analysis.get("onsets") or [])
    else:
        # fixed handled elsewhere
        t = 0.0
        slots = []
        while t < duration - 0.05:
            d = min(target_duration, duration - t)
            slots.append({"start": round(t, 3), "duration": round(d, 3)})
            t += d
        return slots

    cuts = sorted(set(max(0.0, min(duration, c)) for c in cuts))
    if cuts[-1] < duration:
        cuts.append(duration)
    # merge cuts that are too close
    merged = [cuts[0]]
    for c in cuts[1:]:
        if c - merged[-1] >= max(1.0, target_duration * 0.4):
            merged.append(c)
    if merged[-1] < duration:
        merged.append(duration)

    slots = []
    for i in range(len(merged) - 1):
        s = merged[i]
        e = merged[i + 1]
        d = e - s
        if d < 0.5:
            continue
        # split very long gaps
        if d > target_duration * 2.2:
            t = s
            while t < e - 0.05:
                dd = min(target_duration, e - t)
                slots.append({"start": round(t, 3), "duration": round(dd, 3)})
                t += dd
        else:
            slots.append({"start": round(s, 3), "duration": round(d, 3)})
    return slots
