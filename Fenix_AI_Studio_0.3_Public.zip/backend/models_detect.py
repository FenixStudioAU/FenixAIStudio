"""Detect GPU VRAM and installed *Comfy-native* models only.

Wan2GP / *quanto* packs are excluded so the studio never offers models that
fail with stock Comfy loaders (meta tensor / wrong quant format).
"""
from __future__ import annotations

import re
import shutil
import subprocess
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Optional

from .comfyui_client import comfy
from .config import settings
from .logging_setup import log

# Only Comfy-native filenames. No *quanto* Wan2GP aliases.
MODEL_CATALOG: dict[str, dict[str, Any]] = {
    "flux2-klein-4b": {
        "label": "FLUX.2 Klein 4B (8GB and under)",
        "architecture": "flux2-klein",
        "role": "image",
        "min_vram_gb": 6,
        "recommended_vram_gb": 8,
        "files": {
            "diffusion_models": [
                "flux-2-klein-4b.safetensors",
                "flux-2-klein-4b-fp8.safetensors",
                "flux2-klein-4b.safetensors",
            ],
            "text_encoders": [
                "qwen_3_4b.safetensors",
                "qwen3_4b.safetensors",
                "qwen_3_4b_fp8mixed.safetensors",
                "qwen_3_4b_fp4_flux2.safetensors",
            ],
            "vae": ["flux2-vae.safetensors", "flux2_vae.safetensors"],
        },
        "clip_type": "flux2",
        "lora_base_tags": ["flux", "flux2", "flux.2", "klein", "flux2-klein"],
        "incompatible_lora_tags": ["sdxl", "sd1.5", "sd15", "pony", "illustrious", "wan", "hunyuan"],
        "download": {"comfy_org": "https://huggingface.co/Comfy-Org/flux2-klein-4B"},
    },
    "flux2-klein-9b": {
        "label": "FLUX.2 Klein 9B (default — better detail)",
        "architecture": "flux2-klein",
        "role": "image",
        "min_vram_gb": 8,
        "recommended_vram_gb": 12,
        "files": {
            "diffusion_models": [
                "flux-2-klein-9b-fp8.safetensors",
                "flux-2-klein-9b.safetensors",
                "flux2-klein-9b.safetensors",
                "flux-2-klein-base-9b-fp8.safetensors",
            ],
            "text_encoders": [
                "qwen_3_8b_fp8mixed.safetensors",
                "qwen_3_8b.safetensors",
                "qwen3_8b.safetensors",
                "qwen_3_8b_fp4mixed.safetensors",
                "qwen_3_4b.safetensors",
                "qwen3_4b.safetensors",
            ],
            "vae": ["flux2-vae.safetensors", "flux2_vae.safetensors"],
        },
        "clip_type": "flux2",
        "lora_base_tags": ["flux", "flux2", "flux.2", "klein", "flux2-klein"],
        "incompatible_lora_tags": ["sdxl", "sd1.5", "sd15", "pony", "illustrious", "wan", "hunyuan"],
        "download": {
            "unet": "https://huggingface.co/black-forest-labs/FLUX.2-klein-9b-fp8",
            "te_vae": "https://huggingface.co/Comfy-Org/flux2-klein-9B",
        },
    },
    "wan21-i2v-480p": {
        "label": "Wan 2.1 Image-to-Video 480p",
        "architecture": "wan21-i2v",
        "role": "video",
        "min_vram_gb": 8,
        "recommended_vram_gb": 12,
        "files": {
            "diffusion_models": [
                "wan2.1_i2v_480p_14B_fp8_scaled.safetensors",
                "wan2.1_i2v_480p_14B_fp8_e4m3fn.safetensors",
                "wan2.1_i2v_480p_14B_fp16.safetensors",
                "wan2.1_i2v_480p_14B_bf16.safetensors",
            ],
            "text_encoders": [
                "umt5_xxl_fp8_e4m3fn_scaled.safetensors",
                "umt5_xxl_fp16.safetensors",
            ],
            "vae": ["wan_2.1_vae.safetensors"],
            "clip_vision": ["clip_vision_h.safetensors"],
        },
        "clip_type": "wan",
        "lora_base_tags": ["wan", "wan2.1", "wan21"],
        "incompatible_lora_tags": ["flux", "sdxl", "minimax"],
        "download": {
            "comfy_org": "https://huggingface.co/Comfy-Org/Wan_2.1_ComfyUI_repackaged"
        },
    },
    "minimax-h3-i2v": {
        "label": "MiniMax H3 Image-to-Video",
        "architecture": "minimax-h3",
        "role": "video",
        "min_vram_gb": 8,
        "recommended_vram_gb": 12,
        "files": {
            "diffusion_models": ["minimax_h3_fl2va_pruned_int8_convrot.safetensors"],
            "text_encoders": ["qwen3vl_32b_minimax_h3_nvfp4_awq.safetensors"],
            "vae": [
                "minimax_h3_video_vae_fp16.safetensors",
                # Audio VAE is required for native stereo in CreateVideo (checked separately)
            ],
        },
        "clip_type": "minimax",
        "lora_base_tags": ["minimax", "hailuo"],
        "incompatible_lora_tags": ["flux", "sdxl", "sd1.5"],
        "download": {
            "comfy_org": "https://huggingface.co/Comfy-Org/MiniMax-H3",
            "docs": "https://docs.comfy.org/tutorials/video/minimax/minimax-h3",
        },
    },
    # Ref2VA = omni-reference / lip-sync trunk (separate weights from FL2VA I2V).
    # Not a separate timeline preset — used when MiniMax + Lip sync is checked.
    "minimax-h3-ref2va": {
        "label": "MiniMax H3 Ref2VA (lip sync)",
        "architecture": "minimax-h3-ref2va",
        "role": "video",
        "min_vram_gb": 8,
        "recommended_vram_gb": 12,
        "files": {
            "diffusion_models": [
                "minimax_h3_ref2va_pruned_int8_convrot.safetensors",
                "minimax_h3_ref2va_pruned_fp8_scaled.safetensors",
                "minimax_h3_ref2va_int8_convrot.safetensors",
            ],
            "text_encoders": ["qwen3vl_32b_minimax_h3_nvfp4_awq.safetensors"],
            "vae": ["minimax_h3_video_vae_fp16.safetensors"],
        },
        "clip_type": "minimax",
        "lora_base_tags": ["minimax", "hailuo", "ref2va"],
        "incompatible_lora_tags": ["flux", "sdxl", "sd1.5"],
        "download": {
            "diffusion": "https://huggingface.co/Comfy-Org/MiniMax-H3/blob/main/diffusion_models/minimax_h3_ref2va_pruned_int8_convrot.safetensors",
            "docs": "https://docs.comfy.org/tutorials/video/minimax/minimax-h3",
        },
    },
    "minimax-h3-i2v-turbo": {
        "label": "MiniMax H3 I2V + FastLoRA (4–8 step turbo, ≥12 GB VRAM)",
        "architecture": "minimax-h3",
        "role": "video",
        # FastLoRA thrash on 8 GB — only offer/recommend from 12 GB up
        "min_vram_gb": 12,
        "recommended_vram_gb": 16,
        "files": {
            "diffusion_models": ["minimax_h3_fl2va_pruned_int8_convrot.safetensors"],
            "text_encoders": ["qwen3vl_32b_minimax_h3_nvfp4_awq.safetensors"],
            "vae": ["minimax_h3_video_vae_fp16.safetensors"],
            "loras": [
                "minimax_h3_turbo_4step_ckpt850_pruned_comfyui.safetensors",
                "minimax_h3_turbo_4step_ckpt500_pruned_comfyui.safetensors",
                "minimax_h3_turbo_4step_pruned_comfyui.safetensors",
            ],
        },
        "clip_type": "minimax",
        "lora_base_tags": ["minimax", "hailuo", "turbo"],
        "incompatible_lora_tags": ["flux", "sdxl", "sd1.5"],
        "download": {
            "turbo_lora": "https://huggingface.co/drbaph/MiniMax-H3-Turbo-Lora-ComfyUI"
        },
    },
    "ace-step-1.5": {
        "label": "ACE-Step 1.5 Music (turbo)",
        "architecture": "ace-step-1.5",
        "role": "music",
        "min_vram_gb": 8,
        "recommended_vram_gb": 12,
        # TE pair is checked specially (needs BOTH 0.6b + 4b/1.7b)
        "files": {
            "diffusion_models": [
                "acestep_v1.5_turbo.safetensors",
                "acestep_v1.5.safetensors",
            ],
            "vae": ["ace_1.5_vae.safetensors", "ace_1.5_vae.safetensors"],
        },
        "clip_type": "ace",
        "lora_base_tags": ["ace", "ace-step", "acestep"],
        "incompatible_lora_tags": ["flux", "sdxl", "minimax"],
        "download": {
            "comfy_org": "https://huggingface.co/Comfy-Org/ace_step_1.5_ComfyUI_files",
            "docs": "https://docs.comfy.org/tutorials/audio/ace-step/ace-step-v1-5",
            "upstream": "https://huggingface.co/ACE-Step/Ace-Step1.5",
        },
    },
    "minimax-music-3": {
        "label": "MiniMax Music 3",
        "architecture": "minimax-music-3",
        "role": "music",
        "min_vram_gb": 12,
        "recommended_vram_gb": 16,
        "files": {
            "diffusion_models": [
                "minimax_music3_dit_fp16.safetensors",
                "minimax_music3_dit_int8_convrot.safetensors",
            ],
            "text_encoders": [
                "minimax_music3_text_encoder_pruned_int8_convrot.safetensors",
            ],
            "vae": ["minimax_music3_dav.safetensors"],
        },
        "clip_type": "minimax",
        "lora_base_tags": [],
        "incompatible_lora_tags": ["ace", "flux", "sdxl", "minimax_h3", "hailuo"],
        "download": {
            "comfy_org": "https://huggingface.co/Comfy-Org/MiniMax-Music-3",
            "docs": "https://docs.comfy.org/tutorials/audio/minimax/minimax-music-3",
            "upstream": "https://github.com/MiniMax-AI/MiniMax-Music3",
        },
    },
    "ltx23-ia2v": {
        "label": "LTX-2.3 Image+Audio to Video (lip sync)",
        "architecture": "ltx23-ia2v",
        "role": "video",
        "min_vram_gb": 12,
        "recommended_vram_gb": 16,
        "files": {
            "checkpoints": [
                "ltx-2.3-22b-dev-fp8.safetensors",
            ],
            "text_encoders": [
                "gemma_3_12B_it_fp4_mixed.safetensors",
            ],
            "loras": [
                "ltx_2.3_22b_distilled_1.1_lora_dynamic_fro09_avg_rank_111_bf16.safetensors",
            ],
            "latent_upscale_models": [
                "ltx-2.3-spatial-upscaler-x2-1.1.safetensors",
            ],
        },
        "clip_type": "ltxv",
        "lora_base_tags": ["ltx", "ltxv", "ltx2", "ltx-2", "ltx2.3"],
        "incompatible_lora_tags": ["flux", "sdxl", "sd1.5", "minimax", "wan"],
        "download": {
            "checkpoint": "https://huggingface.co/Lightricks/LTX-2.3-fp8/blob/main/ltx-2.3-22b-dev-fp8.safetensors",
            "distilled_ckpt_optional": "https://huggingface.co/Lightricks/LTX-2.3-fp8/blob/main/ltx-2.3-22b-distilled-fp8.safetensors",
            "distilled_lora": "https://huggingface.co/Comfy-Org/ltx-2.3/blob/main/split_files/loras/ltx_2.3_22b_distilled_1.1_lora_dynamic_fro09_avg_rank_111_bf16.safetensors",
            "text_encoder": "https://huggingface.co/Comfy-Org/ltx-2/blob/main/split_files/text_encoders/gemma_3_12B_it_fp4_mixed.safetensors",
            "upscaler": "https://huggingface.co/Lightricks/LTX-2.3/blob/main/ltx-2.3-spatial-upscaler-x2-1.1.safetensors",
            "gemma_lora": "https://huggingface.co/Comfy-Org/ltx-2/blob/main/split_files/loras/gemma-3-12b-it-abliterated_lora_rank64_bf16.safetensors",
            "docs": "https://docs.comfy.org/tutorials/video/ltx/ltx-2-3",
        },
    },
}

# Filename substrings that indicate Wan2GP / non-Comfy quants — never treat as ready
_REJECT_SUBSTRINGS = (
    "quanto",
    "mbf16_int8",
    "nvfp4_awq",  # ok for minimax TE which is official comfy — exception below
)


@dataclass
class ModelStatus:
    model_id: str
    label: str
    role: str
    available: bool
    missing: list[str] = field(default_factory=list)
    resolved_files: dict[str, str] = field(default_factory=dict)
    vram_ok: bool = True
    recommended: bool = False
    experimental: bool = False
    notes: str = ""


def _ffmpeg_available() -> bool:
    """True if configured ffmpeg binary resolves and runs."""
    from .config import resolve_ffmpeg_binary

    bin_path = resolve_ffmpeg_binary(settings.ffmpeg)
    # Keep settings in sync if we discovered an absolute path
    if bin_path and bin_path != settings.ffmpeg and Path(bin_path).is_file():
        settings.ffmpeg = bin_path
        probe = resolve_ffmpeg_binary("ffprobe")
        if probe and Path(probe).is_file():
            settings.ffprobe = probe
    if not bin_path:
        return False
    if Path(bin_path).is_file():
        return True
    return shutil.which(bin_path) is not None


def get_vram_gb() -> float:
    try:
        out = subprocess.check_output(
            ["nvidia-smi", "--query-gpu=memory.total", "--format=csv,noheader,nounits"],
            text=True,
            timeout=10,
        )
        line = out.strip().splitlines()[0].strip()
        return round(float(line) / 1024.0, 1) if float(line) > 256 else round(float(line), 1)
    except Exception as e:
        log.warning("nvidia-smi failed: %s", e)
    try:
        import torch

        if torch.cuda.is_available():
            return round(torch.cuda.get_device_properties(0).total_memory / (1024**3), 1)
    except Exception:
        pass
    return 0.0


def _basename(path_or_name: str) -> str:
    return path_or_name.replace("\\", "/").split("/")[-1]


def PathStem(name: str) -> str:
    return re.sub(r"[^a-z0-9]+", "", name.lower().rsplit(".", 1)[0])


def is_wan_only_junk(name: str, allow_minimax_awq: bool = False) -> bool:
    """True if this looks like a Wan2GP-only quant that stock Comfy cannot load."""
    n = name.lower().replace("\\", "/")
    if allow_minimax_awq and "minimax" in n and "nvfp4_awq" in n:
        return False
    if "minimax_h3" in n and n.endswith(".safetensors"):
        return False  # native minimax packages in ComfyUI models are fine
    if "quanto" in n:
        return True
    if "mbf16_int8" in n or "_int8_convrot" in n:
        # minimax pruned int8 is official comfy package
        if "minimax" in n:
            return False
        return True
    return False


def _match_file(
    available: list[str],
    candidates: list[str],
    *,
    allow_minimax_awq: bool = False,
) -> Optional[str]:
    """Exact / basename match only against allowlisted candidate names — no fuzzy quanto."""
    clean = [
        a
        for a in available
        if not is_wan_only_junk(a, allow_minimax_awq=allow_minimax_awq)
    ]
    lower_map = {a.lower(): a for a in clean}
    base_map = {_basename(a).lower(): a for a in clean}
    for c in candidates:
        cl = c.lower()
        # Reject if candidate itself is quanto junk (except catalog minimax)
        if is_wan_only_junk(c, allow_minimax_awq=allow_minimax_awq) and "minimax" not in cl:
            continue
        if cl in lower_map:
            return lower_map[cl]
        if cl in base_map:
            return base_map[cl]
        for a in clean:
            al = a.lower().replace("\\", "/")
            if al.endswith("/" + cl):
                return a
    # Strict stem equality on basename (not substring) to avoid false positives
    for c in candidates:
        stem = PathStem(c)
        for a in clean:
            if PathStem(_basename(a)) == stem:
                return a
    return None


async def inventory() -> dict[str, list[str]]:
    folders = [
        "checkpoints",
        "diffusion_models",
        "loras",
        "vae",
        "text_encoders",
        "clip",
        "clip_vision",
        "unet",
        "latent_upscale_models",
    ]
    result: dict[str, list[str]] = {}
    online = await comfy.is_online()
    if not online:
        models_root = settings.comfy_install / "models"
        for f in folders:
            p = models_root / f
            if p.is_dir():
                names: list[str] = []
                for x in p.rglob("*"):
                    if not x.is_file():
                        continue
                    if x.suffix.lower() not in {
                        ".safetensors",
                        ".ckpt",
                        ".pt",
                        ".pth",
                        ".gguf",
                        ".sft",
                        ".bin",
                    }:
                        continue
                    rel = str(x.relative_to(p)).replace("\\", "/")
                    if is_wan_only_junk(x.name, allow_minimax_awq=True):
                        continue
                    if "_hf_cache" in rel or any(part.startswith(".") for part in Path(rel).parts):
                        continue
                    if x.name.startswith("put_") or x.stat().st_size <= 1024:
                        continue
                    # Prefer relative path so subfolders (loras/ace/…) work in Comfy
                    names.append(rel)
                result[f] = sorted(set(names), key=str.lower)
            else:
                result[f] = []
        return result
    for f in folders:
        try:
            raw = await comfy.list_models(f)
            # Filter junk so API consumers only see loadable-ish names
            result[f] = [
                x
                for x in raw
                if not is_wan_only_junk(x, allow_minimax_awq=True)
            ]
        except Exception:
            result[f] = []
    return result


async def detect_models() -> dict[str, Any]:
    vram = get_vram_gb()
    inv = await inventory()
    online = await comfy.is_online()

    # Prefer 9B when installed; 4B is the ≤8GB fallback
    rec_image = ["flux2-klein-9b", "flux2-klein-4b"]

    statuses: list[ModelStatus] = []
    for mid, meta in MODEL_CATALOG.items():
        missing: list[str] = []
        resolved: dict[str, str] = {}
        allow_awq = mid.startswith("minimax")
        for folder, candidates in meta["files"].items():
            pool = inv.get(folder, []) + inv.get("unet", []) + inv.get("clip", [])
            hit = _match_file(pool, candidates, allow_minimax_awq=allow_awq)
            if hit:
                resolved[folder] = hit
            else:
                missing.append(f"{folder}: need {candidates[0]}")
        # ACE needs two text encoders (0.6b + 4b or 1.7b)
        if mid == "ace-step-1.5":
            te_pool = (inv.get("text_encoders") or []) + (inv.get("clip") or [])
            te06 = _match_file(te_pool, ["qwen_0.6b_ace15.safetensors", "qwen_0.6b_ace15"])
            te_lm = _match_file(
                te_pool,
                [
                    "qwen_4b_ace15.safetensors",
                    "qwen_1.7b_ace15.safetensors",
                    "qwen_4b_ace15",
                    "qwen_1.7b_ace15",
                ],
            )
            if te06:
                resolved["text_encoders_0.6b"] = te06
            else:
                missing.append("text_encoders: need qwen_0.6b_ace15.safetensors")
            if te_lm:
                resolved["text_encoders_lm"] = te_lm
            else:
                missing.append("text_encoders: need qwen_4b_ace15.safetensors (or 1.7b)")
        available = len(missing) == 0
        vram_ok = vram == 0 or vram >= meta.get("min_vram_gb", 0)
        notes = ""
        if not available and mid.startswith("flux2"):
            notes = (
                "Install Comfy-native FLUX.2 Klein into ComfyUI/models "
                "(Comfy-Org/flux2-klein-4B). Wan2GP quanto weights are not used."
            )
        if not available and mid.startswith("minimax") and "turbo" in mid:
            notes = (
                "Install MiniMax FastLoRA into ComfyUI/models/loras/ from "
                "drbaph/MiniMax-H3-Turbo-Lora-ComfyUI (pruned ComfyUI format). "
                "Requires ≥12 GB VRAM — disabled on smaller GPUs."
            )
        if mid.startswith("minimax") and "turbo" in mid and 0 < vram < 12:
            notes = (notes + " " if notes else "") + "Disabled under 12 GB VRAM (causes thrash)."
            vram_ok = False
        if mid == "ace-step-1.5" and not available:
            notes = (
                "Install ACE-Step 1.5 from Comfy-Org/ace_step_1.5_ComfyUI_files "
                "(diffusion_models + text_encoders + vae). See Help."
            )
        if mid == "minimax-music-3" and not available:
            notes = (
                "Install MiniMax Music 3 from Comfy-Org/MiniMax-Music-3 "
                "(diffusion_models + text_encoders + vae)."
            )
        if mid == "ltx23-ia2v" and not available:
            notes = (
                "Install LTX-2.3 IA2V models: ltx-2.3-22b-dev-fp8 checkpoint, "
                "gemma_3_12B_it_fp4_mixed text encoder, distilled 1.1 LoRA, "
                "and spatial upscaler x2. See Help / download links."
            )
        # Optional Gemma abliterated LoRA note when core LTX is present
        if mid == "ltx23-ia2v" and available:
            loras = inv.get("loras") or []
            has_gemma = any("abliterated" in x.lower() and "gemma" in x.lower() for x in loras)
            if not has_gemma:
                notes = (
                    (notes + " " if notes else "")
                    + "Optional: gemma-3-12b-it-abliterated LoRA improves prompt adherence."
                )
        # Audio VAE note for standard I2V
        if mid == "minimax-h3-i2v" and available:
            vaes = inv.get("vae") or []
            has_audio = any("audio" in v.lower() and "minimax" in v.lower() for v in vaes)
            if not has_audio:
                notes = (
                    (notes + " " if notes else "")
                    + "Install minimax_h3_audio_vae_fp32.safetensors for native clip audio."
                )
            # Lip sync uses FL2VA I2V + MiniMaxH3AddGuide(audio) — same FL2VA weights.
            # Audio VAE is required (noted above).
        if mid == "minimax-h3-ref2va" and not available:
            notes = (
                "Install MiniMax H3 Ref2VA for lip sync: "
                "minimax_h3_ref2va_pruned_int8_convrot.safetensors "
                "(~19.5 GB) into ComfyUI/models/diffusion_models/. "
                "Shares TE/VAE with standard MiniMax I2V."
            )
        rec = mid in rec_image
        if mid == "minimax-h3-i2v" and vram >= 8:
            rec = True
        # Turbo only recommended from 12 GB up
        if mid == "minimax-h3-i2v-turbo" and vram >= 12:
            rec = True
        if mid == "minimax-music-3" and available and vram >= 12:
            rec = True
        if mid == "ace-step-1.5" and vram >= 8:
            rec = True
        if mid == "wan21-i2v-480p" and available:
            if gpu_vendor() == "amd":
                rec = True
            elif not any(
                s.model_id.startswith("minimax-h3") and s.available and "ref2va" not in s.model_id
                for s in statuses
            ):
                rec = True
        if mid == "ltx23-ia2v" and available and vram >= 12:
            rec = True
        # 9B is the default recommendation whenever it is installed
        if mid == "flux2-klein-9b" and available:
            rec = True
        if mid == "flux2-klein-4b":
            # Recommend 4B mainly when 9B files are missing (≤8GB / fallback)
            nine_hit = _match_file(
                inv.get("diffusion_models") or [],
                MODEL_CATALOG["flux2-klein-9b"]["files"]["diffusion_models"],
            )
            rec = nine_hit is None
        if mid == "minimax-h3-ref2va":
            # Capability model — not a primary preset pick
            rec = False
        statuses.append(
            ModelStatus(
                model_id=mid,
                label=meta["label"],
                role=meta["role"],
                available=available,
                missing=missing,
                resolved_files=resolved,
                vram_ok=vram_ok,
                recommended=rec,
                experimental="turbo" in mid or mid == "minimax-h3-ref2va",
                notes=notes,
            )
        )

    loras = [
        {
            "name": n,
            "path": str(settings.comfy_install / "models" / "loras" / n),
            "enabled_default": False,
        }
        for n in inv.get("loras", [])
        if not is_wan_only_junk(n)
    ]

    # Count raw vs filtered for diagnostics
    raw_dm = 0
    try:
        if online:
            raw_dm = len(await comfy.list_models("diffusion_models"))
    except Exception:
        pass

    return {
        "comfyui_online": online,
        "comfyui_url": settings.comfy_url,
        "comfyui_path": str(settings.comfy_install),
        "vram_gb": vram,
        "gpu_name": _gpu_name(),
        "ffmpeg": _ffmpeg_available(),
        "inventory": inv,
        "models": [s.__dict__ for s in statuses],
        "recommended_image_models": rec_image,
        "recommended_video_presets": [
            m.model_id
            for m in statuses
            if m.role == "video" and m.available and m.recommended
        ] or [
            m.model_id for m in statuses if m.role == "video" and m.available
        ],
        "loras": loras,
        "catalog": {
            k: {
                "label": v["label"],
                "architecture": v["architecture"],
                "role": v["role"],
                "download": v.get("download", {}),
                "lora_base_tags": v.get("lora_base_tags", []),
                "incompatible_lora_tags": v.get("incompatible_lora_tags", []),
            }
            for k, v in MODEL_CATALOG.items()
        },
        "policy": {
            "exclude_wan2gp_quanto": True,
            "extra_model_paths": "Wan2GP ckpts not linked — ComfyUI/models only",
            "raw_diffusion_count": raw_dm,
            "filtered_diffusion_count": len(inv.get("diffusion_models", [])),
        },
    }


def _gpu_name() -> str:
    try:
        out = subprocess.check_output(
            ["nvidia-smi", "--query-gpu=name", "--format=csv,noheader"],
            text=True,
            timeout=10,
        )
        return out.strip().splitlines()[0].strip()
    except Exception:
        return "unknown"


def gpu_vendor() -> str:
    """Return 'nvidia' | 'amd' | 'unknown' for default generator picks."""
    name = (_gpu_name() or "").lower()
    if name and name != "unknown":
        if any(x in name for x in ("amd", "radeon", "rx ")):
            return "amd"
        if any(x in name for x in ("nvidia", "geforce", "rtx", "gtx", "quadro", "tesla")):
            return "nvidia"
        return "nvidia"  # nvidia-smi worked
    # No nvidia-smi → check Windows for AMD display adapter
    try:
        out = subprocess.check_output(
            [
                "powershell",
                "-NoProfile",
                "-Command",
                "(Get-CimInstance Win32_VideoController).Name -join ';'",
            ],
            text=True,
            timeout=15,
        ).lower()
        if any(x in out for x in ("amd", "radeon")):
            return "amd"
        if any(x in out for x in ("nvidia", "geforce", "rtx", "gtx")):
            return "nvidia"
    except Exception:
        pass
    return "unknown"


def resolve_model_files(model_id: str, inventory_map: dict[str, list[str]]) -> dict[str, str]:
    meta = MODEL_CATALOG.get(model_id)
    if not meta:
        return {}
    resolved: dict[str, str] = {}
    allow_awq = model_id.startswith("minimax")
    for folder, candidates in meta["files"].items():
        pool = (
            inventory_map.get(folder, [])
            + inventory_map.get("unet", [])
            + inventory_map.get("clip", [])
            + (inventory_map.get("loras", []) if folder == "loras" else [])
            + (
                inventory_map.get("latent_upscale_models", [])
                if folder == "latent_upscale_models"
                else []
            )
        )
        hit = _match_file(pool, candidates, allow_minimax_awq=allow_awq)
        if hit:
            resolved[folder] = hit
    return resolved
