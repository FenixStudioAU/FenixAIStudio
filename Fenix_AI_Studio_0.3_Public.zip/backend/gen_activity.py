"""Shared live activity text for long Comfy / studio jobs (polled by the UI)."""
from __future__ import annotations

import time
from typing import Any

_state: dict[str, Any] = {
    "source": "",
    "message": "Idle",
    "busy": False,
    "ts": 0.0,
}


def set_activity(message: str, *, source: str = "", busy: bool = True) -> None:
    _state["message"] = (message or "").strip() or "Working…"
    if source:
        _state["source"] = source
    _state["busy"] = bool(busy)
    _state["ts"] = time.time()


def clear_activity(message: str = "Idle") -> None:
    _state["message"] = message
    _state["source"] = ""
    _state["busy"] = False
    _state["ts"] = time.time()


def get_activity() -> dict[str, Any]:
    return dict(_state)
