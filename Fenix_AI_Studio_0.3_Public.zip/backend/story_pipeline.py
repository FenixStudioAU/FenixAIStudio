"""Multi-agent local LLM pipeline: planner → writer → editor for music-video scenes."""
from __future__ import annotations

import math
from typing import Any, Callable, Optional

from . import llm_client
from .logging_setup import log
from .persona import with_persona
from .schemas import ImageSettings, Project, Shot, StoryBrief, VideoSettings, new_id

# Style templates: optional prefix prepended to still prompts.
# "standard" = no look filter (default).
STYLE_TEMPLATES: dict[str, dict[str, str]] = {
    "standard": {
        "label": "Standard video",
        "prefix": "",
        "motion": (
            "subject moves naturally with the music, body language clear, "
            "environment reacts lightly, performance energy"
        ),
        "guidance": "No style filter — only the story/LLM prompt text.",
    },
    "cinematic_drama": {
        "label": "Cinematic drama",
        "prefix": (
            "Cinematic dramatic music video still, film grain, anamorphic bokeh, "
            "moody contrast, emotional lighting, 35mm film look"
        ),
        "motion": (
            "subject shifts weight and breathes, eyes track something off-frame, "
            "fabric and hair react to a light draft, rain or dust drifts through the light"
        ),
        "guidance": "Serious emotional stakes, grounded performances, movie-trailer framing.",
    },
    "clean_digital": {
        "label": "Clean digital / sharp",
        "prefix": (
            "Clean sharp digital music video still, crisp detail, modern grading, "
            "no film grain, no heavy texture overlays"
        ),
        "motion": "precise body moves, clean edges, modern pop performance energy",
        "guidance": "Polished contemporary look — avoid grain and vintage filters.",
    },
    "documentary": {
        "label": "Documentary / handheld",
        "prefix": (
            "Documentary music video still, natural available light, "
            "honest framing, slight handheld feel, real-world locations"
        ),
        "motion": "natural fidgeting, real reactions, ambient life in the background",
        "guidance": "Observational realism — not glossy music-video polish.",
    },
    "childrens": {
        "label": "Children's entertainment",
        "prefix": (
            "Bright cheerful children's music video still, soft friendly lighting, "
            "wholesome characters, playful props, safe colorful world"
        ),
        "motion": (
            "characters bounce and clap along, toys wiggle, balloons sway, "
            "bright smiles, playful little jumps, confetti or leaves flutter"
        ),
        "guidance": "Kid-safe, warm, simple readable actions, no horror or dark themes.",
    },
    "mtv": {
        "label": "MTV / pop",
        "prefix": (
            "High-energy MTV music video still, bold color grading, dynamic composition, "
            "fashion-forward, punchy contrast, iconic pop aesthetics"
        ),
        "motion": (
            "performer hits the beat with sharp head/shoulder moves, "
            "hair and jacket whip, crowd pulses behind, lights strobe across the face"
        ),
        "guidance": "Style-forward cuts, performance energy, bold looks, pop-culture cool.",
    },
    "grunge": {
        "label": "Grunge / 90s alt",
        "prefix": (
            "Grunge 90s music video still, desaturated teal-orange grime, handheld raw look, "
            "distressed textures, underground DIY energy"
        ),
        "motion": (
            "subject paces restlessly, kicks gravel, smoke curls, "
            "amp cables tremble, rain spatters the window"
        ),
        "guidance": "Raw, imperfect, angst, authenticity over polish.",
    },
    "rock_50s": {
        "label": "50s rock / rockabilly",
        "prefix": (
            "1950s rock and roll music video still, vintage Technicolor, chrome diners, "
            "leather jackets, classic cars, period costumes, warm nostalgic glow"
        ),
        "motion": (
            "couples jive and spin, skirts flare, chrome cars roll past, "
            "neon diner sign flickers"
        ),
        "guidance": "Period-accurate 1950s Americana, sock hop, drive-in.",
    },
    "bright_happy": {
        "label": "Bright happy",
        "prefix": (
            "Colorful bright happy energetic scene with saturated colors and a fun vibe, "
            "sun-kissed lighting, cheerful expressions, clean pop look"
        ),
        "motion": (
            "people laugh and high-five, hair tosses in sunlight, "
            "sparkling water or confetti flies"
        ),
        "guidance": "Joyful, high-key light, candy colors, feel-good energy.",
    },
    "night_neon": {
        "label": "Night neon / city",
        "prefix": (
            "Nighttime neon music video still, wet asphalt reflections, cyan-magenta neon, "
            "urban night atmosphere, cinematic low-key lighting"
        ),
        "motion": (
            "neon signs flicker, puddle reflections shimmer, "
            "subject walks through steam, cars streak past"
        ),
        "guidance": "After-dark city, neon, rain streets.",
    },
    "horror_ballad": {
        "label": "Dark ballad / soft horror",
        "prefix": (
            "Dark atmospheric music video still, fog, cold moonlight, uneasy beauty, "
            "subtle horror mood without gore"
        ),
        "motion": (
            "fog thickens, curtains lift in cold air, "
            "candle flames stutter, breath fogs in moonlight"
        ),
        "guidance": "Melancholy eerie beauty — not jump-scare gore.",
    },
    "animated": {
        "label": "Animated / cartoon",
        "prefix": (
            "Animated cartoon music video still, clean cel-shaded look, expressive faces, "
            "bold outlines, colorful stylized world, 2D animation aesthetic"
        ),
        "motion": (
            "characters bounce with squash-and-stretch, eyes blink big, "
            "hair and clothes flap"
        ),
        "guidance": "Readable cartoon staging, expressive poses.",
    },
    "anime": {
        "label": "Anime",
        "prefix": (
            "Anime music video still, clean line art, expressive eyes, "
            "vibrant cel color, Japanese animation aesthetic"
        ),
        "motion": "hair and ribbons sway, dramatic blinks, wind effects, pose accents on beat",
        "guidance": "Anime staging and emotion — not photoreal.",
    },
    "pixel_art": {
        "label": "Pixel art",
        "prefix": (
            "Pixel art music video still, crisp low-res retro pixels, limited color palette, "
            "16-bit game aesthetic, chunky sprites, no smooth gradients"
        ),
        "motion": "sprite-like frame steps, blinking pixel eyes, simple walk cycles",
        "guidance": "Intentionally pixelated — no photoreal skin or film grain.",
    },
    "voxel": {
        "label": "Voxel / blocky 3D",
        "prefix": (
            "Voxel art music video still, Minecraft-like blocky 3D, cubic characters, "
            "chunky volume pixels, soft ambient occlusion, toy-like diorama"
        ),
        "motion": "blocky limbs pivot, voxel dust puffs, cubes settle",
        "guidance": "Everything is cubes/voxels — no smooth organic meshes.",
    },
    "noir_50s": {
        "label": "50s noir B&W",
        "prefix": (
            "1950s film noir music video still, high-contrast black and white, "
            "venetian blind shadows, fedora silhouettes, rain-slick streets"
        ),
        "motion": "smoke curls through light, blinds cast moving bars, rain streaks glass",
        "guidance": "Monochrome noir drama — hard light, mystery.",
    },
    "scifi_trek_wars": {
        "label": "Sci-Fi (Trek / Wars)",
        "prefix": (
            "Epic sci-fi music video still, starship corridors and bridge glow, "
            "laser and plasma accents, distant nebulae, heroic costume design"
        ),
        "motion": "console lights blink, holograms flicker, stars drift past a viewport",
        "guidance": "Space-opera heroics — not grimdark cyberpunk.",
    },
    "cyberpunk": {
        "label": "Cyberpunk",
        "prefix": (
            "Cyberpunk music video still, rainy megacity, holographic ads, "
            "neon haze, techwear, chrome and concrete"
        ),
        "motion": "holo-ads flicker, rain sheets down, drones skim past, LED trim pulses",
        "guidance": "High-tech low-life night city.",
    },
    "western": {
        "label": "Western",
        "prefix": (
            "Western music video still, dusty frontier town, golden hour, "
            "wood porches, wide desert sky, period costume"
        ),
        "motion": "dust drifts, tumbleweed rolls, horse shifts weight, saloon doors sway",
        "guidance": "Classic western atmosphere.",
    },
    "hiphop_street": {
        "label": "Hip-hop / street",
        "prefix": (
            "Hip-hop music video still, urban street, bold fashion, "
            "graffiti wall, confident stance, golden-hour or night street light"
        ),
        "motion": "head nods on beat, crew sways, cars roll past, jacket moves",
        "guidance": "Street performance energy, fashion-forward.",
    },
    "metal_stage": {
        "label": "Metal / live stage",
        "prefix": (
            "Heavy metal concert music video still, stage lights, fog, "
            "crowd silhouettes, aggressive performance energy"
        ),
        "motion": "headbanging, hair whip, strobes flash, crowd arms up, mic stand shakes",
        "guidance": "Live metal show intensity.",
    },
    "acoustic_intimate": {
        "label": "Acoustic / intimate",
        "prefix": (
            "Intimate acoustic music video still, soft window light, "
            "close framing, warm quiet room, natural skin"
        ),
        "motion": "fingers on strings, subtle breathing, curtain stirs, soft eye movement",
        "guidance": "Quiet close-up performance — no heavy grain or neon.",
    },
    "watercolor": {
        "label": "Watercolor / painterly",
        "prefix": (
            "Watercolor music video still, soft painted edges, paper texture, "
            "gentle pigment blooms, illustration look"
        ),
        "motion": "pigment blooms softly, edges dissolve and reform, gentle wash motion",
        "guidance": "Painted illustration — not photoreal.",
    },
    "vhs_retro": {
        "label": "VHS / retro tape",
        "prefix": (
            "Retro VHS music video still, soft tracking noise, dated color, "
            "slight scanlines, 80s/90s home-video nostalgia"
        ),
        "motion": "slight tape wobble feel, tracking shimmer, period performance moves",
        "guidance": "Analog tape nostalgia — use only when this look is wanted.",
    },
    "fashion_editorial": {
        "label": "Fashion editorial",
        "prefix": (
            "High-fashion editorial music video still, striking pose, "
            "studio or runway light, designer wardrobe, magazine cover composition"
        ),
        "motion": "slow pose shift, fabric drape, wind on couture, confident walk",
        "guidance": "Fashion-forward staging and wardrobe.",
    },
    "fantasy_epic": {
        "label": "Fantasy epic",
        "prefix": (
            "Epic fantasy music video still, dramatic sky, cloaks and armor, "
            "mythic landscape, painterly light"
        ),
        "motion": "cloak billows, banners snap, embers drift, distant dragons or riders move",
        "guidance": "Mythic adventure scale.",
    },
    "uk_garage_club": {
        "label": "Club / UK garage night",
        "prefix": (
            "Club night music video still, strobes, lasers, packed dancefloor, "
            "sweaty energy, underground rave vibe"
        ),
        "motion": "crowd jumps on beat, lasers sweep, bass hits the chest, hands in the air",
        "guidance": "Dancefloor heat and lights.",
    },
    "custom": {
        "label": "Custom (type your own)",
        "prefix": "",
        "motion": (
            "subject shifts weight and breathes, fabric and hair react to air, "
            "subtle environmental motion that fits the custom look"
        ),
        "guidance": "Follow the user's custom style string closely for every still.",
    },
}

DEFAULT_MODELS = {
    # Only used when user has no saved story/chat model at all
    "planner": "qwen3.5:0.8b",
    "writer": "qwen3.5:0.8b",
    "editor": "qwen3.5:0.8b",
}

# Fallbacks if preferred model missing — prefer general instruct over coder packs
FALLBACKS = {
    "planner": [
        "qwen3.5:0.8b",
        "qwen3.5:2b",
        "qwen3.5:4b",
        "qwen2.5:3b",
        "qwen2.5:1.5b",
        "llama3.2:3b",
        "llama3.2:1b",
        "tinyllama",
        "gemma2:2b",
        "phi3:mini",
        "qwen3:4b",
        "qwen3:8b",
    ],
    "writer": [
        "qwen3.5:0.8b",
        "qwen3.5:2b",
        "qwen3.5:4b",
        "qwen2.5:3b",
        "qwen2.5:1.5b",
        "llama3.2:3b",
        "tinyllama",
        "gemma2:2b",
        "qwen3:4b",
        "qwen3:8b",
    ],
    "editor": [
        "qwen3.5:0.8b",
        "qwen3.5:2b",
        "qwen3.5:4b",
        "qwen2.5:3b",
        "qwen2.5:1.5b",
        "llama3.2:3b",
        "tinyllama",
        "qwen3:4b",
        "qwen3:8b",
    ],
}

# Hard cap for systems under 8 GB VRAM (or optimize_low_vram)
LOW_VRAM_MAX_B = 4.5


def list_style_templates() -> list[dict[str, str]]:
    return [{"id": k, "label": v["label"], "prefix": v["prefix"]} for k, v in STYLE_TEMPLATES.items()]


def resolve_style(style_id: str, style_prefix: str = "") -> dict[str, str]:
    """Resolve a style template; custom uses the user-typed prefix string.

    Default is ``standard`` (empty prefix — no look/feel injected into prompts).
    """
    sid = (style_id or "").strip() or "standard"
    custom_prefix = (style_prefix or "").strip()
    if sid == "custom":
        # Empty custom = no prefix (same as standard), never invent film grain
        prefix = custom_prefix
        base = STYLE_TEMPLATES["custom"]
        return {
            "label": "Custom",
            "prefix": prefix,
            "motion": base["motion"],
            "guidance": base["guidance"],
        }
    return dict(STYLE_TEMPLATES.get(sid) or STYLE_TEMPLATES["standard"])


def _model_param_b(name: str) -> float:
    """Best-effort parameter count in billions from Ollama model id (e.g. qwen2.5:3b → 3)."""
    import re

    n = (name or "").lower()
    # Prefer the last NNb tag (avoids matching year-like digits)
    m = re.search(r"(?:^|[:\-_./])(\d+(?:\.\d+)?)\s*b\b", n)
    if m:
        return float(m.group(1))
    if "mini" in n or "tiny" in n:
        return 1.5
    if "small" in n:
        return 3.0
    # Unknown size — treat as large so low-VRAM mode won't pick it unless nothing else
    return 99.0


def _score_model_for_json(name: str, *, prefer_small: bool = False) -> int:
    """Higher = better for structured story JSON. When prefer_small, smaller wins hard."""
    n = (name or "").lower()
    size = _model_param_b(n)
    score = 0
    if "instruct" in n or "coder" in n or "dolphin" in n:
        score += 40
    if "qwen2.5" in n:
        score += 35
    if "qwen2" in n and "qwen3" not in n:
        score += 20
    if "gemma" in n:
        score += 15
    if "mistral" in n or "llama" in n:
        score += 12
    # CoT models work with think=false but are slower; slight deprioritize
    if "qwen3.5" in n:
        score -= 15
    if "qwen3.6" in n:
        score -= 10
    if prefer_small:
        # Strongly prefer ≤4B; punish big models
        if size <= 4.5:
            score += int(50 - size * 5)
        elif size <= 8:
            score -= 20
        else:
            score -= 80
    else:
        # Mild preference for usable size, but not 14B+
        if size <= 4.5:
            score += 25
        elif size <= 8:
            score += 10
        elif size >= 12:
            score -= 40
    return score


def pick_model(
    role: str,
    preferred: str | None,
    available: set[str],
    *,
    max_param_b: float | None = None,
) -> str:
    """
    Choose an Ollama model.
    - If the user picked a model that is installed, use it EXACTLY — never swap it.
    - Only auto-pick when preferred is empty / missing from Ollama.
    """
    if not available:
        raise RuntimeError("No Ollama models available. Install/pull a model and ensure Ollama is running.")

    # Case-insensitive exact match map
    by_lower = {a.lower(): a for a in available}

    pref = (preferred or "").strip()
    if pref:
        # Exact (case-sensitive or insensitive) — ALWAYS honor user choice
        if pref in available:
            return pref
        if pref.lower() in by_lower:
            return by_lower[pref.lower()]
        # Only allow same-id tag variants when the exact string isn't installed
        # e.g. "qwen3.5:0.8b" vs rare alt spelling — still same size family only
        pref_base = pref.split(":")[0].lower()
        pref_size = _model_param_b(pref)
        same_base = [
            a
            for a in available
            if a.lower() == pref.lower()
            or a.lower().startswith(pref_base + ":")
            or a.lower().split(":")[0] == pref_base
        ]
        if same_base:
            same_base.sort(
                key=lambda a: (
                    abs(_model_param_b(a) - pref_size),
                    a,
                )
            )
            # Never jump to a much larger sibling when user asked for a tiny model
            for a in same_base:
                if abs(_model_param_b(a) - pref_size) <= 0.5:
                    return a
            if abs(_model_param_b(same_base[0]) - pref_size) <= 1.5:
                return same_base[0]
        log.warning(
            "Requested model %r for %s not installed; falling back. Available sample: %s",
            pref,
            role,
            list(available)[:8],
        )

    pool = set(available)
    if max_param_b is not None:
        small = {a for a in available if _model_param_b(a) <= max_param_b}
        if small:
            pool = small

    # Named fallbacks (small first) — only when user did not specify a model
    for c in FALLBACKS.get(role, []):
        if c in pool:
            return c
        base = c.split(":")[0].lower()
        want = _model_param_b(c)
        matches = [
            a
            for a in pool
            if a.lower().startswith(base + ":") or a.lower().split(":")[0] == base
        ]
        if not matches:
            continue
        matches.sort(key=lambda a: (abs(_model_param_b(a) - want), _model_param_b(a), a))
        pick = matches[0]
        if max_param_b is not None and _model_param_b(pick) > max_param_b:
            continue
        if want <= 4.5 and _model_param_b(pick) > 8:
            continue
        return pick

    prefer_small = max_param_b is not None
    return max(pool, key=lambda a: (_score_model_for_json(a, prefer_small=prefer_small), -_model_param_b(a)))


def resolve_max_param_b_for_host() -> float | None:
    """Under 8GB VRAM (or low-vram setting) → cap story models ~4B."""
    try:
        from . import app_settings_store
        from .models_detect import get_vram_gb

        low = bool(app_settings_store.load_user_settings().get("optimize_low_vram"))
        vram = float(get_vram_gb() or 0)
        if low or (0 < vram < 8):
            return LOW_VRAM_MAX_B
    except Exception:
        pass
    return None


# on_progress(message, progress_0_1, detail_snippet)
ProgressCb = Optional[Callable[..., None]]


async def run_story_pipeline(
    *,
    idea: str = "",
    lyrics: str = "",
    use_story: bool = True,
    use_lyrics: bool = True,
    style_id: str = "standard",
    style_prefix: str = "",
    character_names: list[str] | None = None,
    scene_count: int,
    slot_duration: float = 5.0,
    song_duration: float = 0.0,
    planner_model: str | None = None,
    writer_model: str | None = None,
    editor_model: str | None = None,
    on_progress: ProgressCb = None,
) -> dict[str, Any]:
    """
    Returns {
      "story_summary": str,
      "scenes": [{"index":1,"label":"...","image_prompt":"...","motion_prompt":"...","characters":[]}, ...],
      "models_used": {...},
      "style_id": str,
    }
    """
    if scene_count < 1:
        raise ValueError("scene_count must be >= 1")
    if scene_count > 120:
        scene_count = 120

    style = resolve_style(style_id, style_prefix)
    # character_names may be strings or {name, description} dicts
    char_lines: list[str] = []
    chars: list[str] = []
    for c in character_names or []:
        if isinstance(c, dict):
            n = (c.get("name") or "").strip()
            d = (c.get("description") or c.get("notes") or "").strip()
            if n:
                chars.append(n)
                char_lines.append(f"- {n}: {d}" if d else f"- {n}")
        else:
            n = str(c).strip()
            if n:
                chars.append(n)
                char_lines.append(f"- {n}")

    idea_clean = (idea or "").strip() if use_story else ""
    lyrics_clean = (lyrics or "").strip() if use_lyrics else ""
    story_bits = []
    if idea_clean:
        story_bits.append(f"STORY / IDEA (this is the VIDEO PREMISE — follow it):\n{idea_clean}")
    if lyrics_clean:
        # Lyrics inform mood/structure only. Putting full lyrics in context causes tiny
        # models to paste song lines into image_prompt (broken stills).
        story_bits.append(
            "LYRICS — MOOD / STRUCTURE ONLY.\n"
            "NEVER copy lyric lines into image_prompt or motion_prompt. "
            "image_prompt must describe a VISUAL scene (people, place, action, light), "
            "not song text.\n"
            f"(Lyrics excerpt for mood, truncated):\n{_lyrics_mood_excerpt(lyrics_clean)}"
        )
    if char_lines:
        story_bits.append(
            "CAST — exact names only; each person has ONE identity.\n"
            "Do not merge two people into one body. Do not write the same name twice in a prompt. "
            "Only include a person if they are actually in that shot. "
            "Keep roles consistent with the STORY / IDEA (who sings, who mixes, etc.).\n"
            + "\n".join(char_lines)
        )
    if not story_bits:
        raise ValueError("Provide a story idea and/or lyrics (enable at least one source).")
    source_text = "\n\n".join(story_bits)
    # Idea-only text for rebuilds (never dump lyrics into a still prompt)
    idea_for_rebuild = idea_clean or "music video story"

    models = await llm_client.list_ollama_models()
    avail = {m["id"] for m in models}
    if not avail:
        online = await llm_client.ollama_online()
        raise RuntimeError(
            "Ollama has no models listed."
            + (" Is Ollama running on :11434?" if not online else " Pull a model (e.g. gemma4:12b).")
        )

    max_b = resolve_max_param_b_for_host()
    # Caller should already pass saved settings; DEFAULT only if still empty
    planner = pick_model(
        "planner",
        (planner_model or "").strip() or DEFAULT_MODELS["planner"],
        avail,
        max_param_b=max_b,
    )
    writer = pick_model(
        "writer",
        (writer_model or "").strip() or DEFAULT_MODELS["writer"],
        avail,
        max_param_b=max_b,
    )
    editor = pick_model(
        "editor",
        (editor_model or "").strip() or DEFAULT_MODELS["editor"],
        avail,
        max_param_b=max_b,
    )
    models_used = {
        "planner": planner,
        "writer": writer,
        "editor": editor,
        "max_param_b": max_b,
        "vram_capped": max_b is not None,
    }
    log.info("Story pipeline models: %s (max_param_b=%s)", models_used, max_b)

    def prog(msg: str, p: float, detail: str = "") -> None:
        if on_progress:
            try:
                on_progress(msg, p, detail or "")
            except TypeError:
                on_progress(msg, p)
        log.info("story_pipeline: %s (%.0f%%)", msg, p * 100)

    # ----- 1) PLANNER: beat sheet matching exact scene count -----
    # Large scene counts (e.g. 58) blow the token budget if done in one shot,
    # especially on CoT models — chunk the beat sheet.
    prog(f"Planner ({planner}): outlining {scene_count} beats…", 0.05)
    cast_rule = (
        "CAST IS REQUIRED when listed: beats that show people must name them with the "
        "exact cast names (not 'a man', 'a woman', 'the singer'). Put those names in "
        "characters[] AND in the beat text. Do not leave characters[] empty when people "
        "are on screen. You may omit a cast member from a beat if they are truly off-screen — "
        "but most beats should feature at least one cast member. Never invent alternate names."
        if chars
        else "No named cast provided — describe people generically if needed."
    )
    planner_sys = with_persona(
        "You are a music-video director's assistant. Output ONLY valid JSON — no markdown. "
        "Plan a continuous music-video story arc that follows the user's STORY/IDEA exactly "
        "(same setting, same people, same activity). No filler, no repeated beats. "
        + cast_rule,
        chatty=False,
    )
    import json as _json

    plan_chunk = 16
    beats: list[Any] = []
    story_summary = ""
    for start in range(0, scene_count, plan_chunk):
        end = min(start + plan_chunk, scene_count)
        n_chunk = end - start
        prev_note = ""
        if beats:
            prev_note = (
                "Continue AFTER these previous beats (do not repeat them):\n"
                + _json.dumps(beats[-4:], ensure_ascii=False)
            )
        planner_user = f"""Create beats {start + 1}..{end} of a music video with TOTAL {scene_count} scenes.
Exactly {n_chunk} beats. Indices {start + 1} through {end}.
Each scene ~{slot_duration:.1f}s. Song length ~{song_duration or scene_count * slot_duration:.1f}s.
Visual style label only (do not ignore the story): {style['label']}

Cast available: {', '.join(chars) if chars else '(none)'}

PRIMARY DIRECTIVE — the story MUST be about this (do not invent a different premise):
{source_text}

{prev_note}

Return JSON:
{{
  "story_summary": "2-4 sentences retelling the user's idea as the video arc",
  "beats": [
    {{"index": {start + 1}, "label": "short title", "beat": "specific action in this story's setting", "characters": [], "lyric_hook": ""}}
  ]
}}
Length of beats MUST be {n_chunk}. Vary the actions; do not repeat the same beat.
"""
        plan_tokens = min(4096, max(1024, 140 * n_chunk + 500))
        prog(
            f"Planner ({planner}): writing beats {start + 1}–{end}…",
            0.05 + 0.25 * (start / max(1, scene_count)),
            f"Calling Ollama · {planner} · JSON beat sheet chunk",
        )
        plan_raw = await llm_client.chat(
            planner,
            [{"role": "system", "content": planner_sys}, {"role": "user", "content": planner_user}],
            temperature=0.55,
            num_predict=plan_tokens,
            format_json=True,
            timeout=600.0,
            retries=2,
            disable_thinking=True,
        )
        prog(
            f"Planner: got beats {start + 1}–{end}",
            0.05 + 0.28 * (end / scene_count),
            (plan_raw or "")[:900],
        )
        plan = llm_client.extract_json(plan_raw)
        chunk_beats = plan.get("beats") or plan.get("scenes") or []
        if not isinstance(chunk_beats, list):
            chunk_beats = []
        # Force indices into this chunk range
        fixed = []
        for i, b in enumerate(chunk_beats[:n_chunk]):
            if not isinstance(b, dict):
                b = {"beat": str(b)}
            b = dict(b)
            b["index"] = start + 1 + i
            fixed.append(b)
        while len(fixed) < n_chunk:
            idx = start + 1 + len(fixed)
            fixed.append(
                {
                    "index": idx,
                    "label": f"Beat {idx}",
                    "beat": "Continue the story arc naturally.",
                    "characters": [],
                    "lyric_hook": "",
                }
            )
        beats.extend(fixed)
        if plan.get("story_summary"):
            story_summary = str(plan["story_summary"]).strip()
        prog(
            f"Planner: beats {start + 1}–{end}…",
            0.05 + 0.28 * (end / scene_count),
        )

    beats = _normalize_beats(beats, scene_count, chars)
    story_summary = story_summary or "Music video following the provided story/lyrics."

    # ----- 2) WRITER: detailed image + motion prompts -----
    prog(f"Writer ({writer}): writing detailed scene prompts…", 0.35)
    writer_cast = (
        "CAST RULES (cast is provided): "
        "Every image_prompt that shows a person MUST use exact cast name(s) from the list — "
        "weave the name into the sentence (e.g. 'Bow leans on the desk…'). "
        "Forbidden anonymous stand-ins when cast covers the role: 'a man', 'a woman', "
        "'the girl', 'the singer', 'a couple' without names. "
        "characters[] must list every cast name that appears in image_prompt. "
        "Do not merge two cast members into one body. Keep story roles consistent."
        if chars
        else "No named cast — generic people OK."
    )
    writer_sys = with_persona(
        "You write production prompts for music-video shots. Output ONLY valid JSON. "
        "image_prompt = VISUAL still only: who is in frame, what they do, room/setting, light, framing. "
        "motion_prompt = physical action for I2V (hands, mouth, body, gear) — not song lyrics. "
        "HARD RULES: "
        "(1) NEVER paste song lyrics or chorus/verse text into image_prompt or motion_prompt. "
        "(2) NEVER start a prompt with a bare comma-separated name list; weave names into prose. "
        "(3) " + writer_cast + " "
        "(4) No camera-jargon-only motion (soft pan, gentle camera, subject shifts weight). "
        "(5) Stay in the story setting — not random fashion/lyric posters.",
        chatty=False,
    )
    import json as _json

    written: list[dict[str, Any]] = []
    chunk_size = 12
    for start in range(0, scene_count, chunk_size):
        chunk = beats[start : start + chunk_size]
        writer_user = f"""Expand these beats into production prompts for THIS story only.

STORY / IDEA (setting + who does what — follow exactly):
{idea_for_rebuild}

Context pack (lyrics are mood only — do not quote them):
{source_text}

Story summary: {story_summary}
Visual style look (secondary): {style['prefix']}
Cast: {', '.join(chars) if chars else 'none'}

Beats:
{_json.dumps(chunk, ensure_ascii=False)}

Return JSON with exactly {len(chunk)} scenes, same indices:
{{
  "scenes": [
    {{
      "index": <int>,
      "label": "short title",
      "image_prompt": "visual description of the room and people acting — NO lyric quotes",
      "motion_prompt": "physical action only — NO lyric quotes",
      "characters": ["names that appear once each in image_prompt"]
    }}
  ]
}}
"""
        write_tokens = min(6144, max(2048, 420 * len(chunk) + 600))
        prog(
            f"Writer ({writer}): prompts for scenes {start + 1}–{min(start + chunk_size, scene_count)}…",
            0.35 + 0.35 * (start / max(1, scene_count)),
            f"Calling Ollama · {writer}",
        )
        w_raw = await llm_client.chat(
            writer,
            [{"role": "system", "content": writer_sys}, {"role": "user", "content": writer_user}],
            temperature=0.7,
            num_predict=write_tokens,
            format_json=True,
            timeout=600.0,
            retries=2,
            disable_thinking=True,
        )
        prog(
            f"Writer: finished chunk {start + 1}–{min(start + chunk_size, scene_count)}",
            0.35 + 0.35 * (min(start + chunk_size, scene_count) / scene_count),
            (w_raw or "")[:900],
        )
        w_data = llm_client.extract_json(w_raw)
        sc = w_data.get("scenes") or w_data.get("beats") or []
        if isinstance(sc, list):
            written.extend(sc)
        prog(
            f"Writer: scenes {start + 1}–{min(start + chunk_size, scene_count)}…",
            0.35 + 0.35 * ((start + chunk_size) / scene_count),
        )

    written = _normalize_scenes(
        written,
        beats,
        style,
        chars,
        idea=idea_for_rebuild,
        lyrics=lyrics_clean,
    )

    # ----- 3) EDITOR: light QA (same model user chose) -----
    prog(f"Editor ({editor}): QA pass — completeness & no padding…", 0.8)
    editor_sys = with_persona(
        "You are a continuity editor. Output ONLY valid JSON. "
        "Fix empty, generic, or placeholder image_prompts and motion_prompts. "
        "Keep the user's story setting. "
        + (
            "When CAST is listed: every people-shot must keep exact cast names in image_prompt "
            "(no anonymous 'a man/a woman' replacements). characters[] must match names in the prompt. "
            if chars
            else ""
        )
        + "motion_prompt must be concrete action, not camera jargon. "
        "Do not prefix prompts with a bare comma-separated name list.",
        chatty=False,
    )
    editor_blob = _json.dumps(written, ensure_ascii=False)
    if len(editor_blob) > 28000:
        editor_blob = editor_blob[:28000]
    editor_user = f"""Review and fix this scene list for the story below.

STORY:
{source_text}

Summary: {story_summary}
Cast: {', '.join(chars) if chars else 'none'}
Required scene count: {scene_count}

Scenes:
{editor_blob}

Return JSON:
{{
  "story_summary": "...",
  "issues_fixed": ["..."],
  "scenes": [{{"index":1,"label":"...","image_prompt":"...","motion_prompt":"...","characters":[]}}]
}}
Exactly {scene_count} scenes.
"""
    try:
        edit_tokens = min(8192, max(2048, 300 * scene_count + 800))
        prog(f"Editor ({editor}): QA pass…", 0.82, f"Calling Ollama · {editor}")
        e_raw = await llm_client.chat(
            editor,
            [{"role": "system", "content": editor_sys}, {"role": "user", "content": editor_user}],
            temperature=0.35,
            num_predict=edit_tokens,
            format_json=True,
            timeout=600.0,
            retries=2,
            disable_thinking=True,
        )
        prog("Editor: review complete", 0.92, (e_raw or "")[:900])
        e_data = llm_client.extract_json(e_raw)
        final_scenes = e_data.get("scenes") or written
        if e_data.get("story_summary"):
            story_summary = str(e_data["story_summary"]).strip()
        issues = e_data.get("issues_fixed") or []
    except Exception as e:
        log.warning("Editor pass failed, using writer output: %s", e)
        final_scenes = written
        issues = [f"editor skipped: {e}"]

    final_scenes = _normalize_scenes(
        final_scenes,
        beats,
        style,
        chars,
        idea=idea_for_rebuild,
        lyrics=lyrics_clean,
    )
    # Optional style prefix only — never inject cast names or lyrics here
    for sc in final_scenes:
        ip = (sc.get("image_prompt") or "").strip()
        if _looks_like_lyrics(ip, lyrics_clean) or _is_junk_prompt(ip):
            beat_txt = next(
                (b.get("beat") for b in beats if int(b.get("index") or 0) == int(sc.get("index") or 0)),
                sc.get("label") or "scene",
            )
            ip = _visual_from_beat(style, str(beat_txt), idea_for_rebuild, chars)
            sc["image_prompt"] = ip
        elif (
            ip
            and (style.get("prefix") or "").strip()
            and style["prefix"].split(",")[0].lower() not in ip.lower()[:160]
        ):
            sc["image_prompt"] = f"{style['prefix']}. {ip}"
        mp = (sc.get("motion_prompt") or "").strip()
        if not mp or _is_junk_prompt(mp) or _looks_like_lyrics(mp, lyrics_clean):
            sc["motion_prompt"] = _motion_from_beat(
                sc.get("label") or "",
                next(
                    (b.get("beat") for b in beats if int(b.get("index") or 0) == int(sc.get("index") or 0)),
                    "",
                ),
                sc.get("image_prompt") or "",
            )
        # characters from final image prompt only
        sc["characters"] = _cast_names_in_text(sc.get("image_prompt") or "", chars)

    prog("Story pipeline complete", 1.0)
    return {
        "story_summary": story_summary,
        "scenes": final_scenes,
        "models_used": models_used,
        "style_id": style_id,
        "issues_fixed": issues if isinstance(issues, list) else [],
        "scene_count": len(final_scenes),
    }


def _normalize_beats(beats: list, n: int, chars: list[str]) -> list[dict[str, Any]]:
    cast = [str(c).strip() for c in (chars or []) if str(c).strip()]
    out = []
    for i in range(n):
        b = beats[i] if i < len(beats) and isinstance(beats[i], dict) else {}
        raw_chars = b.get("characters") if isinstance(b.get("characters"), list) else []
        scene_chars = [str(c).strip() for c in raw_chars if str(c).strip()]
        # Keep only names that exist in the project cast
        if cast:
            scene_chars = [c for c in scene_chars if any(_norm_name_key(c) == _norm_name_key(x) for x in cast)]
            # Map fuzzy matches back to canonical cast spelling
            canon = []
            for c in scene_chars:
                hit = next((x for x in cast if _norm_name_key(c) == _norm_name_key(x)), c)
                if hit not in canon:
                    canon.append(hit)
            scene_chars = canon
            # LLM often leaves characters[] empty — rotate cast so every beat has someone
            if not scene_chars and cast:
                scene_chars = [cast[i % len(cast)]]
                if len(cast) > 1 and (i % 2 == 0):
                    other = cast[(i + 1) % len(cast)]
                    if other not in scene_chars:
                        scene_chars.append(other)
            beat_txt = str(b.get("beat") or b.get("description") or f"Scene {i + 1} of the story")
            # If beat text also lacks names, weave them in for the writer
            if scene_chars and not _cast_names_in_text(beat_txt, cast):
                if len(scene_chars) == 1:
                    beat_txt = f"{scene_chars[0]}: {beat_txt}"
                else:
                    beat_txt = f"{scene_chars[0]} and {scene_chars[1]}: {beat_txt}"
        else:
            beat_txt = str(b.get("beat") or b.get("description") or f"Scene {i + 1} of the story")
        out.append(
            {
                "index": i + 1,
                "label": str(b.get("label") or f"Scene {i + 1}")[:80],
                "beat": beat_txt[:500],
                "characters": scene_chars,
                "lyric_hook": str(b.get("lyric_hook") or "")[:200],
            }
        )
    return out


def _name_mentioned(name: str, text: str) -> bool:
    import re

    n = (name or "").strip()
    if len(n) < 2 or not (text or "").strip():
        return False
    return bool(re.search(rf"(?i)(?<!\w){re.escape(n)}(?!\w)", text))


def _lyrics_mood_excerpt(lyrics: str, *, max_chars: int = 400) -> str:
    """Short lyric sample for mood only — not enough to paste whole songs into prompts."""
    lines = []
    for line in (lyrics or "").splitlines():
        s = line.strip()
        if not s or s.startswith("["):
            continue
        lines.append(s)
        if sum(len(x) for x in lines) > max_chars:
            break
    text = " / ".join(lines)
    if len(text) > max_chars:
        text = text[: max_chars - 1].rstrip() + "…"
    return text or "(instrumental / no lyric lines)"


def _looks_like_lyrics(text: str, lyrics: str) -> bool:
    """True if the prompt is mostly song words instead of a visual description."""
    import re

    t = (text or "").strip()
    if len(t) < 12:
        return False
    # Strip common style prefix for comparison
    t_cmp = re.sub(
        r"(?i)^cinematic[^.]{0,120}\.\s*",
        "",
        t,
    ).strip()
    ly = (lyrics or "").strip()
    if ly:
        for line in ly.splitlines():
            s = line.strip()
            if not s or s.startswith("[") or len(s) < 18:
                continue
            if s.lower() in t_cmp.lower() or s.lower()[:28] in t_cmp.lower():
                return True
    # Lyric-ish lines without visual nouns
    visual_hits = sum(
        1
        for w in (
            "studio",
            "booth",
            "mic",
            "mixer",
            "fader",
            "room",
            "light",
            "camera",
            "face",
            "hands",
            "glass",
            "desk",
            "headphones",
            "cable",
            "shadow",
            "neon",
            "standing",
            "sitting",
            "singing",
            "playing",
        )
        if w in t_cmp.lower()
    )
    if visual_hits == 0 and any(
        x in t_cmp.lower()
        for x in ("chorus", "verse", "rise from the flame", "no rules, no waiting", "turn the noise")
    ):
        return True
    return False


def _is_junk_prompt(text: str) -> bool:
    """Detect template echo / placeholder garbage from weak model outputs."""
    t = (text or "").strip().lower()
    if len(t) < 12:
        return True
    junk_markers = (
        "full visual prompt",
        "when present",
        "named subjects",
        "exactcastname",
        "what happens: named",
        "character names when",
        "environment motion",
        "<real visual",
        "<real physical",
        "image_prompt",
        "motion_prompt",
        "setup scene, introduce",
        "subject shifts weight",
        "soft camera",
        "gentle pan",
        "natural movement",
        "no lyric quotes",
        "visual description of the room",
        "physical action only",
    )
    if any(m in t for m in junk_markers):
        return True
    if re_match_bare_name_prefix(t):
        return True
    return False


def re_match_bare_name_prefix(text_lower: str) -> bool:
    import re

    return bool(re.match(r"^[a-z0-9_\-]+(?:\s*,\s*[a-z0-9_\-]+){0,5}\s*[—\-:]+\s*$", text_lower[:80]))


def _cast_names_in_text(text: str, cast: list[str]) -> list[str]:
    found = []
    for c in cast or []:
        n = str(c).strip()
        if n and _name_mentioned(n, text) and n not in found:
            found.append(n)
    return found


def _dedupe_name_spam(text: str, cast: list[str]) -> str:
    """If a cast name appears many times, keep first occurrence only (common tiny-model glitch)."""
    import re

    out = text or ""
    for name in sorted({(c or "").strip() for c in (cast or []) if (c or "").strip()}, key=len, reverse=True):
        if len(name) < 2:
            continue
        parts = re.split(rf"(?i)(?<!\w){re.escape(name)}(?!\w)", out)
        if len(parts) <= 2:
            continue
        # first hit keeps the name; later hits become empty
        rebuilt = parts[0]
        for i, p in enumerate(parts[1:]):
            if i == 0:
                rebuilt += name + p
            else:
                rebuilt += p
        out = rebuilt
    return out


def _visual_from_beat(
    style: dict[str, str], beat_txt: str, idea: str, chars: list[str]
) -> str:
    """Rebuild a visual still when the model dumped lyrics/junk — no lyric paste."""
    idea_s = (idea or "music video").strip()
    if len(idea_s) > 220:
        idea_s = idea_s[:220].rstrip() + "…"
    beat_s = (beat_txt or "story beat").strip()
    # If beat itself is lyrics, fall back to idea only
    if _looks_like_lyrics(beat_s, beat_s) and idea_s:
        beat_s = idea_s
    cast_bit = ""
    named = [str(c).strip() for c in (chars or []) if str(c).strip()]
    if named:
        if len(named) == 1:
            cast_bit = f"{named[0]} is clearly in frame. "
        else:
            cast_bit = f"{named[0]} and {named[1]} are clearly in frame. "
    prefix = (style.get("prefix") or "").strip()
    head = f"{prefix}. " if prefix else ""
    return (
        f"{head}{cast_bit}{beat_s}. "
        f"Setting and activity from the story: {idea_s}. "
        f"Clear faces, practical props, music-video framing, high detail."
    )


def _inject_cast_names(
    image_prompt: str,
    cast: list[str],
    preferred: list[str] | None = None,
) -> tuple[str, list[str]]:
    """Ensure at least one cast name appears in the still prompt when cast exists."""
    cast_names = [str(c).strip() for c in (cast or []) if str(c).strip()]
    if not cast_names:
        return image_prompt or "", []
    ip = (image_prompt or "").strip()
    already = _cast_names_in_text(ip, cast_names)
    if already:
        return ip, already
    pref = [p for p in (preferred or []) if p in cast_names]
    want = pref[:2] if pref else cast_names[: min(2, len(cast_names))]
    if not want:
        return ip, []
    if len(want) == 1:
        weave = f"{want[0]} is in frame"
    else:
        weave = f"{want[0]} and {want[1]} are in frame"
    ip = f"{weave}. {ip}" if ip else weave
    return ip, want


def _motion_from_beat(label: str, beat: str, image_prompt: str) -> str:
    """Concrete I2V motion when the model failed — never lyrics or camera jargon."""
    base = (beat or label or "").strip()
    if _looks_like_lyrics(base, base):
        base = ""
    if not base and image_prompt:
        # strip style prefix-ish start
        base = image_prompt.split(". ", 1)[-1][:160]
    if not base or _looks_like_lyrics(base, base):
        base = "people work the scene in the story setting"
    return (
        f"{base}. Hands, body, and face move with purpose; "
        f"equipment and room details react slightly; continuous natural action."
    )[:400]


def _normalize_scenes(
    scenes: list,
    beats: list[dict[str, Any]],
    style: dict[str, str],
    chars: list[str],
    *,
    idea: str = "",
    lyrics: str = "",
    source_text: str = "",  # compat unused
) -> list[dict[str, Any]]:
    by_idx = {}
    for s in scenes:
        if not isinstance(s, dict):
            continue
        try:
            idx = int(s.get("index") or 0)
        except (TypeError, ValueError):
            continue
        if idx >= 1:
            by_idx[idx] = s
    out = []
    for i, beat in enumerate(beats):
        idx = i + 1
        s = by_idx.get(idx) or {}
        beat_txt = str(beat.get("beat") or f"Scene {idx} of the story").strip()
        if _looks_like_lyrics(beat_txt, lyrics):
            beat_txt = (idea or "Continue the story in the established setting").strip()[:200]
        label = str(s.get("label") or beat.get("label") or f"Scene {idx}")[:80]
        ip = str(s.get("image_prompt") or s.get("prompt") or "").strip()
        mp = str(s.get("motion_prompt") or s.get("animation_prompt") or "").strip()

        beat_chars = []
        raw_bc = beat.get("characters") if isinstance(beat.get("characters"), list) else []
        for c in raw_bc:
            n = str(c).strip()
            if n:
                beat_chars.append(n)

        if _is_junk_prompt(ip) or _looks_like_lyrics(ip, lyrics) or len(ip) < 24:
            ip = _visual_from_beat(style, beat_txt, idea, beat_chars or chars)
        else:
            ip = _dedupe_name_spam(ip, chars)

        # Hard guarantee: if project has cast, the still prompt must name them
        ip, scene_chars = _inject_cast_names(ip, chars, preferred=beat_chars)

        if _is_junk_prompt(mp) or _looks_like_lyrics(mp, lyrics) or len(mp) < 12:
            mp = _motion_from_beat(label, beat_txt, ip)
        else:
            mp = _dedupe_name_spam(mp, chars)
        # Prefer named action when cast is known
        if scene_chars and not _cast_names_in_text(mp, chars):
            who = scene_chars[0]
            rest = (mp[0].lower() + mp[1:]) if mp else "moves with purpose."
            mp = f"{who} {rest}"

        out.append(
            {
                "index": idx,
                "label": label,
                "image_prompt": ip,
                "motion_prompt": mp[:400],
                "characters": scene_chars,
            }
        )
    return out


def _norm_name_key(s: str) -> str:
    import re

    return re.sub(r"[\s_\-]+", "", (s or "").strip().lower())


def _match_cast_ref_ids(proj: Project, character_names: list) -> list[str]:
    """Map names that appear for a scene → project reference IDs."""
    names = []
    for c in character_names or []:
        if isinstance(c, dict):
            n = (c.get("name") or "").strip()
        else:
            n = str(c or "").strip()
        if n:
            names.append(n)
    if not names:
        return []
    refs = list(getattr(proj, "references", None) or [])
    if not refs:
        return []
    ids: list[str] = []
    seen: set[str] = set()
    for name in names:
        nk = _norm_name_key(name)
        if len(nk) < 2:
            continue
        hit = None
        for r in refs:
            rn = (getattr(r, "name", None) or "").strip()
            rk = _norm_name_key(rn)
            if not rk:
                continue
            if rk == nk or (len(nk) >= 4 and (nk in rk or rk in nk)):
                hit = r
                break
        if hit and hit.id not in seen:
            seen.add(hit.id)
            ids.append(hit.id)
    return ids[:6]


def apply_scenes_to_project(
    proj: Project,
    scenes: list[dict[str, Any]],
    *,
    slot_duration: float,
    song_duration: float,
    story_summary: str = "",
    style_id: str = "",
    idea: str = "",
    lyrics: str = "",
    track_title: str = "",
    include_title_card: bool = False,
    preserve_media: bool = False,
) -> Project:
    """Replace timeline shots with LLM scenes covering the target duration.

    By default no forced title poster — every scene comes from the LLM story list.
    include_title_card=True is legacy (music title poster as shot 0).
    preserve_media=True keeps existing stills/videos on matching shot indices
    AND keeps each shot's video engine settings (preset_id, ltx_mode, lip_sync,
    quality, …). Only image/motion prompt text is replaced — never silently
    resets LTX → MiniMax (used when regenerating prompts only).
    """
    if song_duration <= 0:
        song_duration = max(slot_duration * max(len(scenes), 1), slot_duration)
    title = (track_title or proj.name or "Untitled Track").strip() or "Untitled Track"
    is_film = (getattr(proj, "kind", None) or "music").strip().lower() == "film"
    want_title = bool(include_title_card) and not is_film
    # Snapshot media from current body shots (skip title card) for optional keep
    old_body = [
        s
        for s in (getattr(proj.timeline, "shots", None) or [])
        if not (
            getattr(getattr(s, "image", None), "strict_named_characters_only", False)
        )
    ]

    title_dur = 0.0
    if want_title:
        title_dur = min(max(slot_duration, 3.0), max(3.0, song_duration * 0.08))
    body_duration = max(0.5, song_duration - title_dur)
    n = len(scenes) or max(1, int(math.ceil(body_duration / slot_duration)))
    t = 0.0
    shots: list[Shot] = []

    if want_title:
        title_prompt = (
            f'Animated music video title poster for the song "{title}", '
            f'bold cinematic typography clearly reading "{title}", '
            f"stylized poster composition, high contrast, music-video title card, "
            f"dramatic lighting, film grain, 16:9 frame"
        )
        title_motion = (
            f'slow push-in on the title "{title}", subtle particle glow, '
            "gentle parallax on poster layers, cinematic title-card animation"
        )
        shots.append(
            Shot(
                id=new_id("shot_"),
                start=0.0,
                duration=round(title_dur, 3),
                label=f"Title · {title}"[:80],
                image=ImageSettings(
                    positive_prompt=title_prompt,
                    negative_prompt=(
                        (proj.global_negative or "blurry, low quality, watermark")
                        + ", readable faces of specific people, photoreal portraits of cast"
                    ),
                    strict_named_characters_only=True,
                ),
                video=VideoSettings(
                    animation_prompt=title_motion,
                    duration_sec=round(title_dur, 3),
                ),
            )
        )
        t = title_dur

    for i, sc in enumerate(scenes):
        remaining = max(0.1, song_duration - t)
        if i == len(scenes) - 1:
            dur = remaining
        else:
            dur = min(slot_duration, remaining)
            ideal = body_duration / max(1, n)
            if abs(ideal - slot_duration) > 0.5:
                dur = min(ideal, remaining)
        dur = max(0.5, round(dur, 3))
        label = str(sc.get("label") or f"Scene {i + 1}")
        ip = str(sc.get("image_prompt") or "").strip()
        if not ip:
            if is_film:
                ip = (
                    f'Cinematic short-film still for "{title}", {label}, '
                    f"story beat opening, atmospheric, detailed, clear subjects"
                )
            else:
                ip = f'Cinematic music video still continuing "{title}", {label}, atmospheric, detailed'
        # Refs ONLY for cast names that appear inside the image_prompt (LLM wrote them).
        # Never inject names here; never attach refs from characters[] alone.
        cast_pool = [
            (getattr(r, "name", None) or "").strip()
            for r in (getattr(proj, "references", None) or [])
            if (getattr(r, "name", None) or "").strip()
            and (getattr(r, "category", None) or "character").strip().lower() == "character"
        ]
        named_in_prompt = _cast_names_in_text(ip, cast_pool)
        ref_ids = _match_cast_ref_ids(proj, named_in_prompt)
        mp = str(sc.get("motion_prompt") or "").strip()
        if _is_junk_prompt(mp):
            mp = _motion_from_beat(label, "", ip)
        # Stronger default anti-mutant negative when project has none
        neg = (proj.global_negative or "").strip() or (
            "blurry, low quality, watermark, text artifacts, "
            "mutated hands, extra fingers, fused faces, duplicate limbs, "
            "disfigured, poorly drawn face, bad anatomy, merged characters"
        )
        img = ImageSettings(
            positive_prompt=ip,
            negative_prompt=neg,
            reference_ids=ref_ids,
        )
        # Default video settings; when preserve_media, keep engine/quality from the old shot
        # so "Regenerate prompts" never silently resets LTX → MiniMax.
        vid_kwargs: dict[str, Any] = {
            "animation_prompt": mp,
            "duration_sec": dur,
        }
        if preserve_media and i < len(old_body):
            old_v = getattr(old_body[i], "video", None)
            if old_v is not None:
                for key in (
                    "preset_id",
                    "quality",
                    "ltx_mode",
                    "lip_sync",
                    "fps",
                    "motion_strength",
                    "camera_movement",
                    "seed",
                    "width",
                    "height",
                    "mute_clip_audio",
                    "audio_start_sec",
                ):
                    if hasattr(old_v, key):
                        vid_kwargs[key] = getattr(old_v, key)
        elif getattr(proj, "global_video_preset", None):
            vid_kwargs["preset_id"] = proj.global_video_preset
        vid = VideoSettings(**vid_kwargs)
        new_shot = Shot(
            id=new_id("shot_"),
            start=round(t, 3),
            duration=dur,
            label=label,
            image=img,
            video=vid,
        )
        if preserve_media and i < len(old_body):
            old = old_body[i]
            new_shot.id = old.id  # keep stable shot ids
            new_shot.image_path = getattr(old, "image_path", None) or None
            new_shot.thumbnail_path = getattr(old, "thumbnail_path", None) or None
            new_shot.image_alternatives = list(getattr(old, "image_alternatives", None) or [])
            if getattr(old, "image_status", None) is not None:
                new_shot.image_status = old.image_status
            new_shot.video_path = getattr(old, "video_path", None) or None
            new_shot.draft_video_path = getattr(old, "draft_video_path", None) or None
            new_shot.video_alternatives = list(getattr(old, "video_alternatives", None) or [])
            if getattr(old, "video_status", None) is not None:
                new_shot.video_status = old.video_status
            # Keep timing if user already laid out the edit
            if getattr(old, "duration", None):
                new_shot.duration = float(old.duration)
                dur = new_shot.duration
                if new_shot.video:
                    new_shot.video.duration_sec = dur
            if getattr(old, "start", None) is not None:
                new_shot.start = float(old.start)
        shots.append(new_shot)
        t += dur
        if t >= song_duration - 0.05:
            break
    if shots and t < song_duration - 0.1:
        shots[-1].duration = round(shots[-1].duration + (song_duration - t), 3)

    proj.timeline.shots = shots
    if not hasattr(proj, "story") or proj.story is None:
        proj.story = StoryBrief()
    proj.story.idea = idea or proj.story.idea
    proj.story.lyrics = lyrics or proj.story.lyrics
    proj.story.style_template = style_id or proj.story.style_template
    proj.story.summary = story_summary
    proj.story.slot_duration = slot_duration
    if story_summary:
        proj.notes = (proj.notes + "\n\n" if proj.notes else "") + f"[Story] {story_summary}"
    return proj
