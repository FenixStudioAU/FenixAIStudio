"""Optional output watermark for generated stills and video clips."""
from __future__ import annotations

import re
import shutil
import subprocess
import tempfile
from pathlib import Path
from typing import Any

from . import app_settings_store
from .config import settings
from .logging_setup import log


def _wm_settings() -> dict[str, Any]:
    u = app_settings_store.load_user_settings()
    enabled = u.get("watermark_enabled")
    if enabled is None:
        enabled = True
    text = (u.get("watermark_text") or "Made with Fenix AI Studio").strip()
    if not text:
        text = "Made with Fenix AI Studio"
    try:
        opacity = float(u.get("watermark_opacity") if u.get("watermark_opacity") is not None else 0.45)
    except (TypeError, ValueError):
        opacity = 0.45
    opacity = max(0.15, min(0.9, opacity))
    return {"enabled": bool(enabled), "text": text, "opacity": opacity}


def _windows_font() -> Path | None:
    windir = Path(r"C:\Windows\Fonts")
    for name in ("segoeui.ttf", "arial.ttf", "calibri.ttf", "tahoma.ttf"):
        p = windir / name
        if p.is_file():
            return p
    return None


def apply_image_watermark(path: Path) -> bool:
    """Burn tiny bottom-right text onto a still. Returns True if applied."""
    cfg = _wm_settings()
    if not cfg["enabled"] or not path.is_file():
        return False
    try:
        from PIL import Image, ImageDraw, ImageFont
    except Exception as e:
        log.warning("watermark image: PIL unavailable: %s", e)
        return False
    try:
        with Image.open(path) as im:
            im = im.convert("RGBA")
            overlay = Image.new("RGBA", im.size, (0, 0, 0, 0))
            draw = ImageDraw.Draw(overlay)
            w, h = im.size
            # Scale font with image size (tiny)
            size = max(10, min(18, int(min(w, h) * 0.022)))
            font = None
            fp = _windows_font()
            if fp:
                try:
                    font = ImageFont.truetype(str(fp), size)
                except Exception:
                    font = None
            if font is None:
                try:
                    font = ImageFont.load_default()
                except Exception:
                    font = None
            text = cfg["text"]
            # Measure
            if font is not None:
                bbox = draw.textbbox((0, 0), text, font=font)
            else:
                bbox = (0, 0, len(text) * 6, 10)
            tw, th = bbox[2] - bbox[0], bbox[3] - bbox[1]
            pad = max(6, size // 2)
            x = w - tw - pad
            y = h - th - pad
            alpha = int(255 * cfg["opacity"])
            # Soft shadow for readability
            shadow = (0, 0, 0, min(200, alpha + 40))
            fill = (255, 255, 255, alpha)
            if font is not None:
                draw.text((x + 1, y + 1), text, font=font, fill=shadow)
                draw.text((x, y), text, font=font, fill=fill)
            else:
                draw.text((x + 1, y + 1), text, fill=shadow)
                draw.text((x, y), text, fill=fill)
            out = Image.alpha_composite(im, overlay)
            # Preserve original format
            suf = path.suffix.lower()
            if suf in {".jpg", ".jpeg"}:
                out.convert("RGB").save(path, quality=92, optimize=True)
            else:
                out.save(path)
        log.info("Watermark applied to image %s", path.name)
        return True
    except Exception as e:
        log.warning("watermark image failed %s: %s", path, e)
        return False


def _escape_drawtext(s: str) -> str:
    # ffmpeg drawtext escapes
    s = s.replace("\\", "\\\\").replace(":", "\\:").replace("'", "\\'").replace("%", "\\%")
    s = re.sub(r"[\r\n]+", " ", s)
    return s


def apply_video_watermark(path: Path) -> bool:
    """Burn tiny bottom-right text onto a video via ffmpeg. Returns True if applied."""
    cfg = _wm_settings()
    if not cfg["enabled"] or not path.is_file():
        return False
    ff = settings.ffmpeg or "ffmpeg"
    if not ff:
        log.warning("watermark video: ffmpeg not configured")
        return False
    font = _windows_font()
    text = _escape_drawtext(cfg["text"])
    # fontsize ~2% of height, min 12 max 20 — drawtext uses fontsize in pixels
    opacity = cfg["opacity"]
    # fontcolor with alpha: white@0.45
    fontcolor = f"white@{opacity:.2f}"
    fontfile = ""
    if font:
        # Windows path for ffmpeg: C\:/Windows/Fonts/arial.ttf
        fp = str(font).replace("\\", "/").replace(":", "\\:")
        fontfile = f"fontfile='{fp}':"
    # x/y bottom-right with padding
    vf = (
        f"drawtext={fontfile}text='{text}':fontsize=h*0.028:fontcolor={fontcolor}:"
        f"x=w-tw-12:y=h-th-10:shadowcolor=black@{min(0.7, opacity + 0.2):.2f}:shadowx=1:shadowy=1"
    )
    tmp = path.with_suffix(path.suffix + ".wm.mp4")
    try:
        cmd = [
            ff,
            "-y",
            "-hide_banner",
            "-loglevel",
            "error",
            "-i",
            str(path),
            "-vf",
            vf,
            "-c:v",
            "libx264",
            "-preset",
            "veryfast",
            "-crf",
            "18",
            "-c:a",
            "copy",
            "-movflags",
            "+faststart",
            str(tmp),
        ]
        r = subprocess.run(cmd, capture_output=True, text=True, timeout=600)
        if r.returncode != 0 or not tmp.is_file() or tmp.stat().st_size < 500:
            # retry without audio copy (some clips have no audio stream)
            cmd2 = [
                ff,
                "-y",
                "-hide_banner",
                "-loglevel",
                "error",
                "-i",
                str(path),
                "-vf",
                vf,
                "-c:v",
                "libx264",
                "-preset",
                "veryfast",
                "-crf",
                "18",
                "-an",
                "-movflags",
                "+faststart",
                str(tmp),
            ]
            r2 = subprocess.run(cmd2, capture_output=True, text=True, timeout=600)
            if r2.returncode != 0 or not tmp.is_file():
                log.warning(
                    "watermark video ffmpeg failed: %s",
                    (r2.stderr or r.stderr or "")[:400],
                )
                tmp.unlink(missing_ok=True)
                return False
        shutil.move(str(tmp), str(path))
        log.info("Watermark applied to video %s", path.name)
        return True
    except Exception as e:
        log.warning("watermark video failed %s: %s", path, e)
        try:
            tmp.unlink(missing_ok=True)
        except Exception:
            pass
        return False
