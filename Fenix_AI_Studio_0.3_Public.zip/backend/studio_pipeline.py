"""Direct Image / Video generation for the home studio (no timeline project)."""
from __future__ import annotations

import asyncio
import shutil
import time
from pathlib import Path
from typing import Any, Optional
from uuid import uuid4

from .comfyui_client import comfy
from .config import settings
from .gen_activity import clear_activity, set_activity
from .logging_setup import log
from .schemas import ImageSettings, VideoSettings
from . import studio_store
from .workflow_engine import build_image_workflow, build_video_workflow

log_s = log


def _status(msg: str, on_status=None) -> None:
    set_activity(msg, source="studio", busy=True)
    if on_status:
        try:
            on_status(msg)
        except Exception:
            pass


def _scan_outputs(prefix: str, *, newer_than: float = 0.0, kinds: set[str] | None = None) -> list[Path]:
    out_root = settings.comfy_install / "output"
    if not out_root.is_dir():
        return []
    kinds = kinds or {".png", ".jpg", ".jpeg", ".webp", ".mp4", ".webm", ".gif", ".mov"}
    parts = [p for p in prefix.replace("\\", "/").split("/") if p]
    needle = parts[-1] if parts else prefix
    found: list[Path] = []
    for p in out_root.rglob("*"):
        if not p.is_file():
            continue
        if p.suffix.lower() not in kinds:
            continue
        rel = str(p.relative_to(out_root)).replace("\\", "/")
        if needle not in p.name and needle not in rel and not any(x in rel for x in parts[-2:]):
            continue
        try:
            if newer_than and p.stat().st_mtime < newer_than - 2:
                continue
            if p.stat().st_size < 512:
                continue
        except OSError:
            continue
        found.append(p)
    found.sort(key=lambda x: x.stat().st_mtime, reverse=True)
    return found


async def _import_history_file(
    hist: dict[str, Any],
    *,
    prefer_video: bool = False,
    dest: Path,
) -> Optional[Path]:
    outs = comfy.extract_output_images(hist)
    if prefer_video:
        ordered = [
            o
            for o in outs
            if o.get("kind") == "video"
            or str(o.get("filename", "")).lower().endswith((".mp4", ".webm", ".mov", ".mkv", ".gif"))
        ] or outs
    else:
        ordered = [
            o
            for o in outs
            if not str(o.get("filename", "")).lower().endswith((".mp4", ".webm", ".mov", ".mkv"))
        ] or outs
    for o in ordered:
        fn = o.get("filename") or ""
        if not fn:
            continue
        try:
            await comfy.download_view(
                fn, o.get("subfolder", "") or "", o.get("type", "output") or "output", dest
            )
            if dest.is_file() and dest.stat().st_size > 200:
                return dest
        except Exception as e:
            log_s.debug("studio download_view %s: %s", fn, e)
    # history may nest outputs under nodes
    for _nid, node_out in (hist.get("outputs") or {}).items():
        if not isinstance(node_out, dict):
            continue
        for key in ("images", "gifs", "videos", "audio"):
            for item in node_out.get(key) or []:
                if not isinstance(item, dict):
                    continue
                fn = item.get("filename") or ""
                if not fn:
                    continue
                try:
                    await comfy.download_view(
                        fn,
                        item.get("subfolder", "") or "",
                        item.get("type", "output") or "output",
                        dest,
                    )
                    if dest.is_file() and dest.stat().st_size > 200:
                        return dest
                except Exception:
                    pass
    return None


def _snap_dim(v: int, *, lo: int = 256, hi: int = 2048, step: int = 16) -> int:
    """Snap to nearest multiple of 16 so real 720p (1280×720) is preserved."""
    v = int(v or 0)
    v = max(lo, min(hi, v))
    snapped = int(round(v / step) * step)
    return max(lo, min(hi, snapped))


async def generate_studio_image(
    *,
    prompt: str,
    negative_prompt: str = "",
    width: int = 0,
    height: int = 0,
    seed: int = -1,
    steps: int = 20,
    model_id: str = "flux2-klein-4b",
    quality: str = "final",
    batch_count: int = 1,
    reference_paths: list[tuple[Path, str, str]] | None = None,
    on_status=None,
) -> list[dict[str, Any]]:
    """Generate one or more stills. Returns a list of studio gallery items.

    reference_paths: optional list of (abs_path, label, category).
    batch_count: queue N variations sequentially (1–100).
    """
    prompt = (prompt or "").strip()
    if not prompt:
        raise ValueError("Prompt is required")
    if not await comfy.is_online():
        raise RuntimeError("ComfyUI is offline")

    # Distilled Klein defaults to 4; allow up to 8 for "final" callers
    q = (quality or "final").strip().lower()
    if int(steps or 0) <= 0:
        steps = 4 if q == "draft" else 8
    steps = max(1, min(50, int(steps)))
    count = max(1, min(100, int(batch_count or 1)))
    try:
        from .model_prefs import resolve_image_model
        from .workflow_engine import resolve_flux_size

        model_id = await resolve_image_model(model_id or None)
        if int(width or 0) <= 0 or int(height or 0) <= 0:
            width, height = resolve_flux_size(quality=quality or "final")
    except Exception:
        model_id = model_id or "flux2-klein-4b"
        if int(width or 0) <= 0 or int(height or 0) <= 0:
            width, height = (1280, 720)
    width = _snap_dim(width or 1280)
    height = _snap_dim(height or 720)
    # Legacy: old UI snapped 720→704 (64px grid). Treat as real 720p.
    if width == 1280 and height == 704:
        height = 720
    if height == 1280 and width == 704:
        width = 720
    base_seed = int(seed if seed is not None else -1)
    run_id = "studio_" + uuid4().hex[:10]
    model_id = model_id or "flux2-klein-4b"

    try:
        ref_payload: list[dict[str, str]] = []
        for abs_p, label, category in (reference_paths or [])[:6]:
            if not abs_p or not Path(abs_p).is_file():
                continue
            _status(f"Uploading reference {label or abs_p.name}…", on_status)
            up = await comfy.upload_image(Path(abs_p), subfolder="studio/refs")
            name = up.get("name") or up.get("filename") or Path(abs_p).name
            sub = (up.get("subfolder") or "").replace("\\", "/")
            comfy_name = f"{sub}/{name}".strip("/") if sub else name
            ref_payload.append(
                {
                    "name": comfy_name,
                    "label": (label or Path(abs_p).stem)[:64],
                    "category": (category or "character")[:32],
                }
            )

        items: list[dict[str, Any]] = []
        # Distinct seed per variation. Passing seed=-1 each loop relied on
        # random.randint per build — still OK in theory, but Comfy/refs made
        # dupes easy to miss; explicit offsets guarantee different noise.
        import random as _random

        if base_seed < 0:
            batch_base = _random.randint(0, 2**32 - 1 - max(count, 1))
        else:
            batch_base = int(base_seed)

        def _commit_file(src: Path, *, use_seed: int, index: int, count_n: int) -> dict[str, Any]:
            title = prompt[:60] if count_n == 1 else f"{prompt[:50]} ({index + 1}/{count_n})"
            item = studio_store.add_item(
                kind="image",
                title=title,
                prompt=prompt,
                negative_prompt=negative_prompt or "",
                source_path=src,
                width=width,
                height=height,
                seed=use_seed,
                model=model_id,
            )
            return item

        for b in range(count):
            use_seed = int(batch_base + b) % (2**32)
            settings_img = ImageSettings(
                positive_prompt=prompt,
                negative_prompt=negative_prompt or "",
                seed=use_seed,
                width=width,
                height=height,
                model_id=model_id,
                steps=steps,
                batch_count=1,
            )
            # Keep prefix stable so disk salvage works after interrupt/stop
            prefix = f"studio/img/{run_id}_{b}" if count > 1 else f"studio/img/{run_id}"
            label_n = f"{b + 1}/{count}"
            _status(f"Building Flux workflow ({label_n}, seed={use_seed})…", on_status)
            # Do NOT call Comfy /free before every gen — that unloads models and forces
            # a full cold reload next run (felt "insanely slow" vs warm cache).
            wf = await build_image_workflow(
                settings_img,
                filename_prefix=prefix,
                reference_comfy_names=ref_payload or None,
            )
            started = time.time()
            _status(
                f"Queued image {label_n} ({width}×{height}, seed={use_seed}) — sampling…",
                on_status,
            )
            prompt_id = await comfy.queue_prompt(wf)
            hist: dict[str, Any] | None = None
            wait_err: Exception | None = None
            try:
                hist = await comfy.wait_for_prompt(
                    prompt_id, timeout=max(float(settings.comfy_timeout), 600.0)
                )
            except Exception as e:
                wait_err = e
                log_s.warning(
                    "Studio image wait failed (%s) — trying disk salvage for %s",
                    e,
                    prefix,
                )

            _status(f"Importing image {label_n}…", on_status)
            tmp = Path(settings.cache_dir) / "studio_tmp" / f"{run_id}_{b}.png"
            tmp.parent.mkdir(parents=True, exist_ok=True)
            got = None
            if hist:
                got = await _import_history_file(hist, prefer_video=False, dest=tmp)
            if not got:
                # Only match THIS variation's prefix — never the whole run_id
                # (that reused variation 1's PNG for later slots).
                disk = _scan_outputs(
                    prefix, newer_than=started, kinds={".png", ".jpg", ".jpeg", ".webp"}
                )
                if disk:
                    shutil.copy2(disk[0], tmp)
                    got = tmp
                    log_s.info("Salvaged studio image from disk: %s", disk[0].name)

            if not got or not tmp.is_file():
                if items:
                    # Partial batch: return what we already saved instead of total failure
                    msg = f"Stopped after {len(items)}/{count} — last variation missing"
                    _status(msg, on_status)
                    clear_activity(msg)
                    return items
                raise RuntimeError(
                    str(wait_err)
                    if wait_err
                    else (
                        f"Comfy finished variation {label_n} but no image file was found "
                        "(check ComfyUI/output/studio/)"
                    )
                )

            item = _commit_file(tmp, use_seed=use_seed, index=b, count_n=count)
            items.append(item)
            try:
                tmp.unlink(missing_ok=True)
            except Exception:
                pass

            if wait_err and not hist:
                # We salvaged a file after interrupt — keep going only if more requested
                log_s.info("Imported salvaged variation %s despite: %s", label_n, wait_err)

        msg = "Image ready" if count == 1 else f"{count} images ready"
        _status(msg, on_status)
        clear_activity(msg)
        return items
    except Exception:
        clear_activity("Image failed")
        raise


def _is_ltx_preset(preset: str) -> bool:
    p = (preset or "").lower()
    return p.startswith("ltx") or "ltx23" in p or ("ia2v" in p and "ltx" in p)


def _is_minimax_preset(preset: str) -> bool:
    p = (preset or "").lower()
    return p.startswith("minimax") or "minimax" in p


async def generate_studio_video(
    *,
    image_path: Path,
    animation_prompt: str = "",
    duration_sec: float = 5.0,
    seed: int = -1,
    parent_id: str = "",
    quality: str = "draft",
    video_preset: str = "",
    audio_path: Path | None = None,
    lip_sync: bool | None = None,
    on_status=None,
) -> dict[str, Any]:
    if not image_path or not Path(image_path).is_file():
        raise ValueError("Source image is required for I2V")
    if not await comfy.is_online():
        raise RuntimeError("ComfyUI is offline")

    image_path = Path(image_path)
    anim = (animation_prompt or "").strip() or (
        "subject breathes and shifts slightly, fabric and hair react to a light draft, "
        "environment details move naturally with the scene"
    )
    q = (quality or "draft").strip().lower()
    if q not in ("draft", "final"):
        q = "draft"
    try:
        from .model_prefs import resolve_video_preset

        preset = await resolve_video_preset((video_preset or "").strip() or None)
    except Exception:
        preset = (video_preset or "").strip() or "minimax-h3-i2v"

    is_ltx = _is_ltx_preset(preset)
    is_minimax = _is_minimax_preset(preset)
    has_audio = bool(audio_path and Path(audio_path).is_file())
    # Explicit flag wins; else LTX+audio or MiniMax+audio → lip sync
    if lip_sync is None:
        want_lip = bool(has_audio and (is_ltx or is_minimax))
    else:
        want_lip = bool(lip_sync)
    max_dur = 20.0 if is_ltx else 15.0
    dur = max(1.0, min(max_dur, float(duration_sec or 5.0)))

    if want_lip and (is_ltx or is_minimax):
        if not has_audio:
            eng = "LTX" if is_ltx else "MiniMax"
            raise ValueError(
                f"{eng} lip-sync needs an audio file. Upload a short clip (speech or music) "
                "in the Video panel, then generate again."
            )
        # Keep the user's prompt. Simple lines like "Man sings Woman Dances" work best —
        # do not inject mouth/jaw instructions (Ref2VA tags are added in workflow_engine).
        anim = (animation_prompt or "").strip() or (
            "man sings woman dances on a live stage, camera mostly steady"
        )

    # Studio: Draft/Final = resolution; map to ltx_mode only as a default pass choice
    # (Final→2-pass, Draft→1-pass) when the caller didn't set one.
    ltx_mode = "quality" if q == "final" else "fast" if is_ltx else ""

    settings_vid = VideoSettings(
        preset_id=preset,
        animation_prompt=anim,
        duration_sec=dur,
        seed=seed,
        quality=q,  # type: ignore[arg-type]
        ltx_mode=ltx_mode,
        mute_clip_audio=True,
        audio_start_sec=0.0,
        lip_sync=bool(want_lip and (is_ltx or is_minimax)),
    )
    run_id = "studio_" + uuid4().hex[:10]
    prefix = f"studio/vid/{run_id}"

    try:
        _status("Uploading source frame to Comfy…", on_status)
        up = await comfy.upload_image(image_path, subfolder="studio/i2v")
        name = up.get("name") or up.get("filename") or image_path.name
        sub = (up.get("subfolder") or "").replace("\\", "/")
        comfy_name = f"{sub}/{name}".strip("/") if sub else name

        audio_comfy_name = None
        if settings_vid.lip_sync and has_audio:
            eng = "LTX" if is_ltx else "MiniMax"
            _status(f"Uploading audio for {eng} lip-sync…", on_status)
            from .audio_tools import slice_audio_clip

            # Trim to clip duration so LoadAudio matches the shot length
            slice_path = Path(settings.cache_dir) / "studio_tmp" / f"{run_id}_audio.wav"
            slice_audio_clip(Path(audio_path), slice_path, 0.0, dur)
            aup = await comfy.upload_audio(slice_path, subfolder="studio/ia2v")
            aname = aup.get("name") or aup.get("filename") or slice_path.name
            asub = (aup.get("subfolder") or "").replace("\\", "/")
            audio_comfy_name = f"{asub}/{aname}".strip("/") if asub else aname

        if is_ltx:
            ltx_fast = q == "draft"
            label = f"LTX IA2V {'Fast' if ltx_fast else 'Quality'}"
        elif settings_vid.lip_sync and is_minimax:
            label = "MiniMax I2V + lip-sync"
        else:
            label = "I2V"
        _status(f"Building {label} workflow ({q})…", on_status)
        wf = await build_video_workflow(
            settings_vid,
            comfy_name,
            filename_prefix=prefix,
            audio_comfy_name=audio_comfy_name,
        )
        started = time.time()
        # LTX 2-stage can run longer than MiniMax on consumer GPUs
        try:
            from . import app_settings_store

            _mins = int(
                app_settings_store.load_user_settings().get("video_timeout_min") or 60
            )
        except Exception:
            _mins = 60
        _mins = max(10, min(240, _mins))
        wait_timeout = max(float(settings.comfy_timeout), float(_mins) * 60.0)
        _status(f"Queued {label} (~{dur:.0f}s, {q}) — loading models…", on_status)
        prompt_id = await comfy.queue_prompt(wf)
        _status("Loading video models / sampling frames…", on_status)
        hist = await comfy.wait_for_prompt(prompt_id, timeout=wait_timeout)
        _status("Decoding / importing video…", on_status)

        tmp = Path(settings.cache_dir) / "studio_tmp" / f"{run_id}.mp4"
        tmp.parent.mkdir(parents=True, exist_ok=True)
        got = await _import_history_file(hist, prefer_video=True, dest=tmp)
        if not got:
            disk = _scan_outputs(prefix, newer_than=started, kinds={".mp4", ".webm", ".mov", ".gif"})
            if disk:
                shutil.copy2(disk[0], tmp)
                got = tmp
        if not got or not tmp.is_file():
            raise RuntimeError(
                "Comfy finished but no video file was found (check ComfyUI/output/studio/)"
            )
        item = studio_store.add_item(
            kind="video",
            title=anim[:60],
            prompt=anim,
            source_path=tmp,
            duration_sec=dur,
            seed=seed,
            model=f"{preset}-{q}",
            parent_id=parent_id or "",
        )
        try:
            tmp.unlink(missing_ok=True)
        except Exception:
            pass
        _status("Video ready", on_status)
        clear_activity("Video ready")
        return item
    except Exception:
        clear_activity("Video failed")
        raise
