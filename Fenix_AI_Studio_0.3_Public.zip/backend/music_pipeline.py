"""ACE-Step 1.5 + MiniMax Music 3 text-to-audio via ComfyUI API workflows."""
from __future__ import annotations

import asyncio
import copy
import json
import math
import random
from pathlib import Path
from typing import Any, Optional

from .comfyui_client import comfy
from .config import settings
from .gen_activity import clear_activity, set_activity
from .logging_setup import log
from .models_detect import inventory
from .workflow_engine import _load_template, _set_input

log_m = log


def _music_status(msg: str, on_status=None) -> None:
    set_activity(msg, source="music", busy=True)
    if on_status:
        try:
            on_status(msg)
        except Exception:
            pass


def _pick(pool: list[str], needles: list[str]) -> Optional[str]:
    lower = {n.lower().replace("\\", "/").split("/")[-1]: n for n in pool}
    for nd in needles:
        if nd.lower() in lower:
            return lower[nd.lower()]
    for n in pool:
        bn = n.lower().replace("\\", "/").split("/")[-1]
        for nd in needles:
            if nd.lower() in bn:
                return n
    return None


def _probe_lora_file(path: Path) -> dict[str, Any]:
    """Read safetensors header only — detect PEFT vs Comfy-trained + which ACE UNET family.

    Important:
    - Community SFT LoRAs: keys like base_model.model.layers…, mostly in_dim 2048 only
    - Comfy TrainLoraNode (our Train tab): keys like diffusion_model.decoder…, mixed dims
      including 1024 — these match Turbo UNETLoader, NOT "SFT only"
    """
    import json
    import struct

    info: dict[str, Any] = {
        "path": str(path),
        "format": "unknown",
        "in_dim": None,
        "n_keys": 0,
        "base_hint": "unknown",  # turbo | sft | unknown
        "key_style": "unknown",  # peft_base | comfy_diffusion | other
    }
    try:
        with open(path, "rb") as f:
            n = struct.unpack("<Q", f.read(8))[0]
            if n <= 0 or n > 50_000_000:
                return info
            header = json.loads(f.read(n))
        tensors = {k: v for k, v in header.items() if k != "__metadata__"}
        info["n_keys"] = len(tensors)
        keys = list(tensors.keys())
        if any(k.startswith("diffusion_model.") for k in keys):
            info["key_style"] = "comfy_diffusion"
            info["format"] = "comfy"
        elif any(k.startswith("base_model.") or "lora_A" in k for k in keys):
            info["key_style"] = "peft_base"
            info["format"] = "peft" if any("lora_A" in k for k in keys) else "comfy"
        else:
            info["key_style"] = "other"

        in_dims: set[int] = set()
        sample_dim = None
        for k, v in tensors.items():
            shape = v.get("shape") or []
            if not isinstance(shape, list) or len(shape) != 2:
                continue
            a, b = int(shape[0]), int(shape[1])
            if not (
                "lora_A" in k
                or k.endswith("lora_A.weight")
                or "lora_down" in k
            ):
                continue
            if "lora_A" in k or k.endswith("lora_A.weight"):
                info["format"] = "peft"
            elif "lora_down" in k:
                info["format"] = "comfy"
            # rank is the small axis for down/A matrices
            dim = b if a <= b else a
            in_dims.add(dim)
            if sample_dim is None:
                sample_dim = dim
        info["in_dim"] = sample_dim
        info["in_dims"] = sorted(in_dims)

        # Classification (do NOT use first-tensor-only 2048 → SFT — Comfy turbo
        # train LoRAs also have 2048-wide layers next to 1024-wide ones).
        if info["key_style"] == "comfy_diffusion":
            # Trained / saved for Comfy UNETLoader path → Turbo (and generic ACE DiT)
            info["base_hint"] = "turbo"
        elif info["key_style"] == "peft_base":
            # HuggingFace PEFT adapters → almost always ACE SFT / Gradio base
            info["base_hint"] = "sft"
        elif 1024 in in_dims and 2048 not in in_dims:
            info["base_hint"] = "turbo"
        elif 2048 in in_dims and 1024 not in in_dims and len(in_dims) <= 3:
            info["base_hint"] = "sft"
        elif sample_dim in (1024, 768, 1536):
            info["base_hint"] = "turbo"
        elif sample_dim in (2048, 2560, 3072, 4096):
            info["base_hint"] = "sft"
    except Exception as e:
        info["error"] = str(e)
    return info


def _lora_abs_path(comfy_lora_name: str) -> Optional[Path]:
    """Map Comfy lora_name (may use \\) to disk under models/loras."""
    rel = (comfy_lora_name or "").strip().replace("\\", "/")
    if not rel:
        return None
    root = settings.comfy_install / "models" / "loras"
    cand = root / rel
    if cand.is_file():
        return cand
    bn = Path(rel).name
    hits = list(root.rglob(bn))
    return hits[0] if hits else None


async def resolve_ace_models(*, prefer: str = "turbo") -> dict[str, str]:
    """prefer: turbo | sft — which UNET family to pick when both exist."""
    inv = await inventory()
    dm = inv.get("diffusion_models") or []
    te = inv.get("text_encoders") or []
    vaes = inv.get("vae") or []
    prefer = (prefer or "turbo").strip().lower()
    if prefer == "sft":
        unet = _pick(
            dm,
            [
                "acestep_v1.5.safetensors",
                "acestep_v15_sft",
                "acestep-v15-sft",
                "ace_step_1.5",
                "acestep_v1.5_sft",
                # last resort turbo only if no SFT
                "acestep_v1.5_turbo.safetensors",
                "acestep",
            ],
        )
    else:
        unet = _pick(
            dm,
            [
                "acestep_v1.5_turbo.safetensors",
                "acestep_v1.5.safetensors",
                "ace_step",
                "acestep",
            ],
        )
    clip1 = _pick(te, ["qwen_0.6b_ace15.safetensors", "0.6b_ace", "qwen_0.6b"])
    clip2 = _pick(te, ["qwen_4b_ace15.safetensors", "4b_ace15", "qwen_4b_ace"])
    vae = _pick(vaes, ["ace_1.5_vae.safetensors", "ace_1.5_vae", "ace15_vae", "ace_vae"])
    missing = []
    if not unet:
        missing.append("diffusion_models/acestep_v1.5_turbo.safetensors")
    if not clip1 or not clip2:
        missing.append("text_encoders/qwen_0.6b_ace15 + qwen_4b_ace15")
    if not vae:
        missing.append("vae/ace_1.5_vae.safetensors")
    if missing:
        raise RuntimeError(
            "ACE-Step 1.5 models missing in ComfyUI: " + "; ".join(missing)
        )
    kind = "turbo" if "turbo" in (unet or "").lower() else "sft"
    return {"unet": unet, "clip1": clip1, "clip2": clip2, "vae": vae, "unet_kind": kind}


def _norm_lora_key(name: str) -> str:
    """Normalize for comparison only (not for Comfy API)."""
    return (name or "").strip().replace("\\", "/").lower()


def _is_video_or_non_music_lora(name: str) -> bool:
    """MiniMax / video turbo LoRAs live in models/loras but are not ACE music styles."""
    n = _norm_lora_key(name)
    bn = n.split("/")[-1]
    needles = (
        "minimax",
        "hailuo",
        "h3_turbo",
        "h3-turbo",
        "i2v",
        "video_turbo",
        "fastlora",
        "4step",
        "ckpt500",
        "ckpt850",
        "flux",
        "sdxl",
        "sd1.5",
        "sd15",
    )
    return any(k in n or k in bn for k in needles)


def _resolve_lora_name(lora_name: str, inv: dict[str, list[str]]) -> Optional[str]:
    """Match user pick to the EXACT string Comfy lists for lora_name.

    Comfy on Windows often uses backslashes (ace\\foo.safetensors). Forward-slash
    paths fail validation even when the file exists.
    """
    name = (lora_name or "").strip()
    if not name:
        return None
    pool = [str(n) for n in (inv.get("loras") or [])]
    if not pool:
        return name
    key = _norm_lora_key(name)
    # Exact (after norm) → return Comfy's original spelling
    for n in pool:
        if _norm_lora_key(n) == key:
            return n
    bn = key.split("/")[-1]
    for n in pool:
        if _norm_lora_key(n).split("/")[-1] == bn:
            return n
    for n in pool:
        nk = _norm_lora_key(n)
        if bn in nk or key in nk:
            return n
    return name


async def list_ace_loras() -> list[dict[str, Any]]:
    """LoRAs for ACE Music Gen — excludes MiniMax/video turbo LoRAs.

    Probes each file: community ACE LoRAs are almost always trained on SFT (in_dim 2048).
    Turbo UNET is ~1024 — mismatched LoRAs spam tensor-size errors and sound bad.
    """
    inv = await inventory()
    models = None
    try:
        models = await resolve_ace_models(prefer="turbo")
    except Exception:
        models = None
    unet_kind = (models or {}).get("unet_kind") or "turbo"
    has_sft = False
    try:
        dm = inv.get("diffusion_models") or []
        has_sft = any(
            "turbo" not in str(x).lower()
            and ("acestep" in str(x).lower() or "ace_step" in str(x).lower() or "ace-step" in str(x).lower())
            for x in dm
        )
        # stricter: explicit non-turbo ace unet
        has_sft = bool(
            _pick(
                dm,
                [
                    "acestep_v1.5.safetensors",
                    "acestep_v15_sft",
                    "acestep-v15-sft",
                    "acestep_v1.5_sft",
                ],
            )
        )
    except Exception:
        pass

    out: list[dict[str, Any]] = []
    for n in inv.get("loras") or []:
        raw = str(n)
        if _is_video_or_non_music_lora(raw):
            continue
        rel = raw.replace("\\", "/")
        bn = rel.split("/")[-1]
        # Hide junk / train temps / intermediate pass dumps (never show to user)
        bl = bn.lower()
        if bn.startswith("_") or bn.startswith("."):
            continue
        if bl.startswith("_tmp_train_") or "_pass" in bl:
            continue
        # Comfy SaveLoRA intermediate dumps: ..._20_steps_00001_.safetensors
        if "_steps_" in bl:
            continue
        # Legacy auto-prefixed train names (replaced by user style name)
        if bl.startswith("ace15_user_"):
            continue
        likely = any(
            k in rel.lower()
            for k in (
                "ace",
                "acestep",
                "ace-step",
                "ace_step",
                "metal",
                "rock",
                "music",
                "fenix",
            )
        )
        # User-trained styles live under ace/ with the name they typed
        if rel.lower().startswith("ace/") or "fenix" in bl:
            likely = True
        probe: dict[str, Any] = {}
        ap = _lora_abs_path(raw)
        if ap:
            probe = _probe_lora_file(ap)
        # Comfy TrainLoraNode / Fenix train outputs → Turbo UNETLoader
        if probe.get("key_style") == "comfy_diffusion":
            probe["base_hint"] = "turbo"
        if "fenix" in bl or probe.get("key_style") == "comfy_diffusion":
            if "ace" in rel.lower() or "fenix" in bl:
                probe["base_hint"] = "turbo"
        base_hint = probe.get("base_hint") or "unknown"
        # Compatible if dims match installed UNET, or SFT LoRA + SFT model present
        if base_hint == "turbo":
            ok = True  # works with turbo; SFT optional
            needs = "turbo"
        elif base_hint == "sft":
            ok = has_sft  # needs SFT unet — turbo will tensor-mismatch
            needs = "sft"
        else:
            ok = True
            needs = "unknown"
        badge = ""
        if base_hint == "sft":
            badge = "SFT only" if not has_sft else "SFT"
        elif base_hint == "turbo" and probe.get("key_style") == "comfy_diffusion":
            badge = ""  # user-named Fenix trains — show clean name only
        elif base_hint == "turbo":
            badge = "Turbo"
        # Display: exact file stem (user names keep spaces/hyphens as typed)
        label = bn.replace(".safetensors", "")
        if "_" in label and " " not in label:
            label = label.replace("_", " ")
        if badge:
            label = f"{label} [{badge}]"
        if not ok:
            label = f"⚠ {label}"
        out.append(
            {
                "name": raw,
                "filename": bn,
                "label": label,
                "likely_ace": likely,
                "format": probe.get("format"),
                "in_dim": probe.get("in_dim"),
                "base_hint": base_hint,
                "needs_unet": needs,
                "compatible": ok,
                "has_sft_model": has_sft,
                "current_unet": unet_kind,
                "key_style": probe.get("key_style"),
            }
        )
    out.sort(
        key=lambda x: (
            0 if x.get("compatible") else 1,
            0 if x["likely_ace"] else 1,
            x["filename"].lower(),
        )
    )
    return out


async def build_ace_workflow(
    *,
    tags: str,
    lyrics: str,
    duration_sec: float = 30.0,
    bpm: int = 120,
    seed: int = -1,
    keyscale: str = "E minor",
    language: str = "en",
    timesignature: str = "4",
    steps: int = 8,
    generate_audio_codes: bool = False,
    cfg_scale: float = 2.0,
    temperature: float = 0.85,
    top_p: float = 0.9,
    top_k: int = 0,
    min_p: float = 0.0,
    filename_prefix: str = "audio/fenix",
    lora_name: str = "",
    lora_strength: float = 0.75,
    reference_audio: str = "",
) -> dict[str, Any]:
    inv = await inventory()
    strength = max(0.0, min(2.0, float(lora_strength if lora_strength is not None else 0.75)))
    resolved_lora = _resolve_lora_name(lora_name, inv) if (lora_name or "").strip() else None

    # Community ACE LoRAs are almost always trained on SFT (in_dim 2048).
    # Turbo UNET (~1024) → massive "tensor a/b must match" spam and useless audio.
    prefer = "turbo"
    lora_probe: dict[str, Any] = {}
    if resolved_lora and strength > 0.001:
        ap = _lora_abs_path(resolved_lora)
        if ap:
            lora_probe = _probe_lora_file(ap)
        # User / Fenix Train-tab LoRAs (diffusion_model.* keys) always use Turbo
        bn = Path(str(resolved_lora).replace("\\", "/")).name.lower()
        if (
            "ace15_user" in bn
            or "fenix" in bn
            or lora_probe.get("key_style") == "comfy_diffusion"
        ):
            lora_probe["base_hint"] = "turbo"
            prefer = "turbo"
        elif lora_probe.get("base_hint") == "sft":
            prefer = "sft"

    models = await resolve_ace_models(prefer=prefer)
    if resolved_lora and strength > 0.001 and lora_probe.get("base_hint") == "sft":
        if models.get("unet_kind") == "turbo":
            raise RuntimeError(
                "This ACE style LoRA is a community SFT adapter (base_model.* keys), "
                "not a Fenix/Turbo train. Loading it on Turbo causes tensor size errors.\n\n"
                "Fix: pick a LoRA marked [Turbo / Fenix train], leave Style LoRA on None, "
                "or install ACE SFT UNET for true SFT LoRAs.\n\n"
                f"LoRA: {resolved_lora} (key_style={lora_probe.get('key_style')}, "
                f"in_dim={lora_probe.get('in_dim')})"
            )
        # SFT needs more steps than turbo's 8
        if int(steps or 8) <= 12:
            steps = 30
            log_m.info("ACE SFT + LoRA: bumping steps to %s", steps)

    prompt = copy.deepcopy(_load_template("ace_step15_t2a.json"))
    if seed is None or seed < 0:
        seed = random.randint(0, 2**32 - 1)
    # Comfy ACE uses math.ceil(duration); keep integer seconds for latent + encode
    duration_sec = float(math.ceil(max(10.0, min(240.0, float(duration_sec or 30)))))
    bpm = max(40, min(220, int(bpm or 120)))
    steps = max(4, min(50, int(steps or 8)))
    # Hard bool — Comfy node default is True (LLM, duration*5 tokens on the 4B).
    # That is the usual “GPU pegged forever” path; only enable when user opts in.
    # Official tip: turn codes OFF when using a reference audio timbre.
    ref_name = (reference_audio or "").strip().replace("\\", "/")
    if "/" in ref_name:
        # LoadAudio wants the name relative to input/ (with subfolder if any)
        pass
    use_audio_codes = bool(generate_audio_codes) and not bool(ref_name)

    _set_input(prompt, "1", "unet_name", models["unet"])
    _set_input(prompt, "1", "weight_dtype", "default")
    _set_input(prompt, "2", "clip_name1", models["clip1"])
    _set_input(prompt, "2", "clip_name2", models["clip2"])
    _set_input(prompt, "2", "type", "ace")
    _set_input(prompt, "2", "device", "default")
    _set_input(prompt, "3", "vae_name", models["vae"])
    _set_input(prompt, "4", "tags", (tags or "").strip())
    _set_input(prompt, "4", "lyrics", lyrics or "")
    _set_input(prompt, "4", "seed", int(seed))
    _set_input(prompt, "4", "bpm", int(bpm))
    _set_input(prompt, "4", "duration", float(duration_sec))
    _set_input(prompt, "4", "timesignature", str(timesignature or "4"))
    _set_input(prompt, "4", "language", language or "en")
    _set_input(prompt, "4", "keyscale", keyscale or "E minor")
    _set_input(prompt, "4", "generate_audio_codes", use_audio_codes)
    _set_input(prompt, "4", "cfg_scale", float(cfg_scale if cfg_scale is not None else 2.0))
    _set_input(prompt, "4", "temperature", float(temperature if temperature is not None else 0.85))
    _set_input(prompt, "4", "top_p", float(top_p if top_p is not None else 0.9))
    _set_input(prompt, "4", "top_k", int(top_k if top_k is not None else 0))
    _set_input(prompt, "4", "min_p", float(min_p if min_p is not None else 0.0))
    # Latent length must match encode duration (this is what makes long tracks heavy)
    _set_input(prompt, "6", "seconds", float(duration_sec))
    _set_input(prompt, "6", "batch_size", 1)

    # Optional ACE style LoRA: UNET → LoraLoaderModelOnly → ModelSampling → KSampler
    model_src: list[Any] = ["1", 0]
    if resolved_lora and strength > 0.001:
        prompt["11"] = {
            "class_type": "LoraLoaderModelOnly",
            "inputs": {
                "model": ["1", 0],
                "lora_name": resolved_lora,
                "strength_model": float(strength),
            },
        }
        model_src = ["11", 0]
        log_m.info("ACE LoRA: %s @ strength=%.3f", resolved_lora, strength)
    else:
        if (lora_name or "").strip():
            log_m.warning("ACE LoRA requested but not applied (name=%r strength=%s)", lora_name, strength)

    # Optional timbre reference: LoadAudio → VAEEncodeAudio → ReferenceTimbreAudio
    positive_src: list[Any] = ["4", 0]
    if ref_name:
        # LoadAudio expects the filename as listed under Comfy input/ (subfolder/name)
        prompt["12"] = {
            "class_type": "LoadAudio",
            "inputs": {"audio": ref_name},
        }
        prompt["13"] = {
            "class_type": "VAEEncodeAudio",
            "inputs": {"audio": ["12", 0], "vae": ["3", 0]},
        }
        prompt["14"] = {
            "class_type": "ReferenceTimbreAudio",
            "inputs": {
                "conditioning": ["4", 0],
                "latent": ["13", 0],
            },
        }
        positive_src = ["14", 0]
        log_m.info("ACE reference timbre audio: %s (audio codes forced off)", ref_name)

    _set_input(prompt, "7", "model", model_src)
    _set_input(prompt, "7", "shift", 3.0)
    _set_input(prompt, "8", "model", ["7", 0])
    _set_input(prompt, "8", "seed", int(seed))
    _set_input(prompt, "8", "steps", int(steps))
    _set_input(prompt, "8", "cfg", 1.0)
    _set_input(prompt, "8", "sampler_name", "euler")
    _set_input(prompt, "8", "scheduler", "simple")
    _set_input(prompt, "8", "positive", positive_src)
    _set_input(prompt, "8", "denoise", 1.0)
    # Tiled VAE decode: full-buffer decode OOMs / thrash after 8/8 on long tracks
    # when TE (~9GB) + DiT (~4.5GB) are still staged ("0 models unloaded").
    # Smaller tiles for longer songs keep peak VRAM down.
    if duration_sec >= 90:
        tile_size, overlap = 256, 32
    elif duration_sec >= 45:
        tile_size, overlap = 384, 48
    else:
        tile_size, overlap = 512, 64
    if prompt.get("9", {}).get("class_type") == "VAEDecodeAudioTiled":
        _set_input(prompt, "9", "tile_size", int(tile_size))
        _set_input(prompt, "9", "overlap", int(overlap))
    _set_input(prompt, "10", "filename_prefix", filename_prefix)
    _set_input(prompt, "10", "quality", "V0")

    te = prompt["4"]["inputs"]
    log_m.info(
        "ACE-Step payload unet=%s clip1=%s clip2=%s vae=%s lora=%s@%.2f | "
        "tags_len=%d lyrics_len=%d duration=%.0fs bpm=%d seed=%s steps=%d "
        "audio_codes=%s (if True, LLM runs ~%d tokens BEFORE 8/8)",
        models["unet"],
        models["clip1"],
        models["clip2"],
        models["vae"],
        resolved_lora or "(none)",
        strength if resolved_lora else 0.0,
        len(tags or ""),
        len(lyrics or ""),
        duration_sec,
        bpm,
        seed,
        steps,
        use_audio_codes,
        int(duration_sec) * 5 if use_audio_codes else 0,
    )
    log_m.info(
        "ACE-Step TextEncode inputs: %s",
        {k: (v if k not in ("tags", "lyrics") else f"<{len(str(v))} chars>") for k, v in te.items()},
    )
    # Dump exact API prompt so it can be Load'd in Comfy for A/B
    try:
        dump_dir = Path(settings.cache_dir) / "music_tmp"
        dump_dir.mkdir(parents=True, exist_ok=True)
        dump_path = dump_dir / "last_ace_prompt.json"
        dump_path.write_text(json.dumps(prompt, indent=2), encoding="utf-8")
        log_m.info("ACE-Step API prompt dumped to %s", dump_path)
    except Exception as e:
        log_m.debug("ACE prompt dump failed: %s", e)
    return prompt


def extract_audio_outputs(history_entry: dict[str, Any]) -> list[dict[str, str]]:
    """Pull audio file refs from Comfy history (SaveAudio / SaveAudioMP3)."""
    found: list[dict[str, str]] = []

    def _add(item: dict) -> None:
        fn = str(item.get("filename") or "")
        if not fn:
            return
        found.append(
            {
                "filename": fn,
                "subfolder": item.get("subfolder", "") or "",
                "type": item.get("type", "output") or "output",
                "kind": "audio",
            }
        )

    for _nid, node_out in (history_entry.get("outputs") or {}).items():
        if not isinstance(node_out, dict):
            continue
        for key in ("audio", "audios", "flac", "mp3", "wav"):
            for item in node_out.get(key) or []:
                if isinstance(item, dict):
                    _add(item)
        for item in node_out.get("images") or []:
            if isinstance(item, dict):
                fn = str(item.get("filename") or "")
                if fn.lower().endswith((".mp3", ".flac", ".wav", ".ogg", ".opus")):
                    _add(item)
        # UI payload from SaveAudio helpers
        ui = node_out.get("ui") if isinstance(node_out.get("ui"), dict) else {}
        for key in ("audio", "images"):
            for item in ui.get(key) or []:
                if isinstance(item, dict):
                    fn = str(item.get("filename") or "")
                    if not fn or fn.lower().endswith((".mp3", ".flac", ".wav", ".ogg", ".opus", ".webm")):
                        if fn:
                            _add(item)
    return found


def _scan_comfy_audio(filename_prefix: str, *, newer_than: float = 0.0) -> list[Path]:
    """Find audio files written under Comfy output for this prefix."""
    out_root = settings.comfy_install / "output"
    if not out_root.is_dir():
        return []
    prefix = filename_prefix.replace("\\", "/").split("/")[-1]
    # Also match subfolder path pieces (amvs/music/trk_xxx)
    parts = [p for p in filename_prefix.replace("\\", "/").split("/") if p]
    candidates: list[Path] = []
    for p in out_root.rglob("*"):
        if not p.is_file():
            continue
        if p.suffix.lower() not in {".mp3", ".flac", ".wav", ".ogg", ".opus"}:
            continue
        name = p.name
        rel = str(p.relative_to(out_root)).replace("\\", "/")
        if prefix and prefix not in name and prefix not in rel:
            # match last path segment of prefix
            if not any(part in name or part in rel for part in parts[-2:]):
                continue
        try:
            if newer_than and p.stat().st_mtime < newer_than - 2:
                continue
            # Ignore empty / still-writing files
            if p.stat().st_size < 2048:
                continue
        except OSError:
            continue
        candidates.append(p)
    candidates.sort(key=lambda x: x.stat().st_mtime, reverse=True)
    return candidates


async def run_ace_generation(
    *,
    tags: str,
    lyrics: str,
    duration_sec: float,
    bpm: int,
    seed: int,
    keyscale: str,
    language: str,
    steps: int,
    filename_prefix: str,
    generate_audio_codes: bool = False,
    timesignature: str = "4",
    cfg_scale: float = 2.0,
    temperature: float = 0.85,
    top_p: float = 0.9,
    top_k: int = 0,
    min_p: float = 0.0,
    lora_name: str = "",
    lora_strength: float = 0.75,
    reference_audio: str = "",
    on_status=None,
    timeout_sec: float | None = None,
) -> Path:
    """
    Queue ACE-Step and wait until audio exists.

    After KSampler hits N/N, Comfy still runs VAEDecodeAudio + SaveAudio — that can
    peg the GPU for a long time on long tracks. We therefore:
      - use a long timeout (default 45 min for music)
      - also watch the Comfy output folder so we succeed as soon as the file lands
        even if history JSON is slow/odd
    """
    import time

    try:
        _music_status("Building ACE-Step workflow…", on_status)
        prompt = await build_ace_workflow(
            tags=tags,
            lyrics=lyrics,
            duration_sec=duration_sec,
            bpm=bpm,
            seed=seed,
            keyscale=keyscale,
            language=language,
            timesignature=timesignature or "4",
            steps=8,  # fixed turbo steps — not user-configurable
            generate_audio_codes=generate_audio_codes,
            cfg_scale=cfg_scale,
            temperature=temperature,
            top_p=top_p,
            top_k=top_k,
            min_p=min_p,
            filename_prefix=filename_prefix,
            lora_name=lora_name or "",
            lora_strength=lora_strength,
            reference_audio=reference_audio or "",
        )
        if (lora_name or "").strip():
            _music_status(f"ACE style LoRA: {lora_name}…", on_status)
        # Free hard before queue. Long tracks need headroom for post-8/8 audio VAE
        dur_guess = float(duration_sec or 30)
        # No automatic /free here — unloading forces multi‑GB cold reloads and
        # made gens "insanely slow". Use EMERGENCY STOP only when you want a hard clear.
        started = time.time()
        codes_on = bool(prompt.get("4", {}).get("inputs", {}).get("generate_audio_codes"))
        dur = prompt.get("6", {}).get("inputs", {}).get("seconds", duration_sec)
        tile = prompt.get("9", {}).get("inputs", {}).get("tile_size")
        if codes_on:
            _music_status(
                f"Queued ACE ({dur:.0f}s, audio-codes ON ≈{int(dur)*5} LLM tokens — heavy)…",
                on_status,
            )
        else:
            _music_status(
                f"Queued ACE ({dur:.0f}s, codes OFF, tiled VAE tile={tile})…",
                on_status,
            )
        prompt_id = await comfy.queue_prompt(prompt)
        _music_status(
            "Loading ACE models / sampling (then audio decode after 8/8)…",
            on_status,
        )
    except Exception:
        clear_activity("Music failed")
        raise

    # Music is slow: encode + sample + audio VAE decode for full song length
    timeout = float(timeout_sec or max(float(settings.comfy_timeout), 1800.0))
    deadline = time.monotonic() + timeout
    last_status = 0.0
    hist_entry: dict[str, Any] | None = None

    while time.monotonic() < deadline:
        # 1) Disk win: SaveAudio already wrote the file
        disk = _scan_comfy_audio(filename_prefix, newer_than=started)
        if disk:
            # Prefer a file that hasn't grown in 1.5s (write finished)
            p = disk[0]
            try:
                s1 = p.stat().st_size
                await asyncio.sleep(1.2)
                s2 = p.stat().st_size
                if s2 >= s1 and s2 > 4096:
                    log_m.info("ACE audio found on disk: %s (%s bytes)", p, s2)
                    _music_status("Track ready — importing…", on_status)
                    clear_activity("Track ready")
                    return p
            except OSError:
                pass

        # 2) History win
        try:
            hist = await comfy.get_history(prompt_id)
            entry = comfy._history_entry(hist, prompt_id)
            if entry:
                err = comfy._entry_failed(entry)
                if err:
                    raise RuntimeError(f"ComfyUI execution error: {err}")
                outs = extract_audio_outputs(entry)
                if outs or comfy._entry_succeeded(entry):
                    hist_entry = entry
                    if outs:
                        break
                    # Succeeded but no audio keys yet — keep scanning disk a bit
        except RuntimeError:
            raise
        except Exception as e:
            log_m.debug("ACE history poll: %s", e)

        # 3) Left queue without us noticing?
        try:
            q = await comfy.get_queue()
            running = q.get("queue_running") or []
            pending = q.get("queue_pending") or []
            in_q = any(
                isinstance(item, (list, tuple)) and len(item) > 1 and item[1] == prompt_id
                for item in list(running) + list(pending)
            )
            if not in_q:
                disk = _scan_comfy_audio(filename_prefix, newer_than=started)
                if disk:
                    if on_status:
                        on_status("Track ready — importing…")
                    return disk[0]
                if hist_entry and extract_audio_outputs(hist_entry):
                    break
        except Exception:
            pass

        now = time.monotonic()
        if on_status and now - last_status > 8:
            elapsed = int(time.time() - started)
            _music_status(
                f"Still working ({elapsed}s) — past 8/8 is audio VAE decode "
                f"(slower cards may delay here)…",
                on_status,
            )
            last_status = now
        await asyncio.sleep(1.0)

    if hist_entry:
        outs = extract_audio_outputs(hist_entry)
        if outs:
            o = outs[0]
            dest = Path(settings.cache_dir) / "music_tmp" / o["filename"]
            dest.parent.mkdir(parents=True, exist_ok=True)
            await comfy.download_view(
                o["filename"], o.get("subfolder", ""), o.get("type", "output"), dest
            )
            clear_activity("Track ready")
            return dest

    disk = _scan_comfy_audio(filename_prefix, newer_than=started)
    if disk:
        clear_activity("Track ready")
        return disk[0]

    clear_activity("Music timed out")
    raise TimeoutError(
        f"ACE-Step timed out after {timeout:.0f}s (prompt {prompt_id}). "
        "If Comfy already finished, check ComfyUI/output for the mp3 and we can import it next time."
    )


# ---------- MiniMax Music 3 ----------

MINIMAX_MUSIC_MAX_SEC = 300.0
MINIMAX_MUSIC_CFG = 1.7
MINIMAX_MUSIC_STEPS = 30
MINIMAX_MUSIC_TOP_K = 50
MINIMAX_MUSIC_TILE = 1536
MINIMAX_MUSIC_OVERLAP = 64


def _low_vram_on() -> bool:
    try:
        from . import app_settings_store

        return bool(app_settings_store.load_user_settings().get("optimize_low_vram"))
    except Exception:
        return False


def _minimax_prefer_int8(duration_sec: float) -> bool:
    """Prefer int8 DiT under Low VRAM or for long songs (VRAM peaks hard past ~2 min)."""
    if _low_vram_on():
        return True
    return float(duration_sec or 0) >= 120.0


def _minimax_tile_for_duration(duration_sec: float) -> tuple[int, int]:
    """Smaller decode tiles for longer songs — 1536 at 3min can OOM on 8–16GB cards."""
    d = float(duration_sec or 0)
    if d >= 180:
        return 512, 64
    if d >= 120:
        return 768, 64
    if d >= 90:
        return 1024, 64
    return MINIMAX_MUSIC_TILE, MINIMAX_MUSIC_OVERLAP


async def resolve_minimax_music_models(*, prefer_int8: bool | None = None) -> dict[str, str]:
    """Resolve MiniMax Music 3 DiT + text encoder + DAV from Comfy inventory."""
    inv = await inventory()
    dm = inv.get("diffusion_models") or []
    te = inv.get("text_encoders") or []
    vaes = inv.get("vae") or []
    use_int8 = _low_vram_on() if prefer_int8 is None else bool(prefer_int8)
    if use_int8:
        unet = _pick(
            dm,
            [
                "minimax_music3_dit_int8_convrot.safetensors",
                "minimax_music3_dit_fp16.safetensors",
                "minimax_music3_dit",
            ],
        )
    else:
        unet = _pick(
            dm,
            [
                "minimax_music3_dit_fp16.safetensors",
                "minimax_music3_dit_int8_convrot.safetensors",
                "minimax_music3_dit",
            ],
        )
    clip = _pick(
        te,
        [
            "minimax_music3_text_encoder_pruned_int8_convrot.safetensors",
            "minimax_music3_text_encoder",
        ],
    )
    vae = _pick(vaes, ["minimax_music3_dav.safetensors", "minimax_music3_dav"])
    missing = []
    if not unet:
        missing.append("diffusion_models/minimax_music3_dit_fp16.safetensors")
    if not clip:
        missing.append(
            "text_encoders/minimax_music3_text_encoder_pruned_int8_convrot.safetensors"
        )
    if not vae:
        missing.append("vae/minimax_music3_dav.safetensors")
    if missing:
        raise RuntimeError(
            "MiniMax Music 3 models missing in ComfyUI: " + "; ".join(missing)
        )
    return {"unet": unet, "clip": clip, "vae": vae}


async def build_minimax_music_workflow(
    *,
    caption: str,
    lyrics: str,
    duration_sec: float,
    seed: int,
    filename_prefix: str,
) -> dict[str, Any]:
    # Cap at 300s (node allows ~360); keep a small floor so empty latents are valid
    duration_sec = float(max(5.0, min(MINIMAX_MUSIC_MAX_SEC, float(duration_sec or 120))))
    prefer_int8 = _minimax_prefer_int8(duration_sec)
    models = await resolve_minimax_music_models(prefer_int8=prefer_int8)
    prompt = copy.deepcopy(_load_template("minimax_music3_t2a.json"))
    if seed is None or seed < 0:
        seed = random.randint(0, 2**32 - 1)
    caption_s = (caption or "").strip()
    lyrics_s = lyrics if lyrics is not None else ""
    tile_size, overlap = _minimax_tile_for_duration(duration_sec)
    # Slightly fewer denoise steps on long tracks — AR encode is the real cost;
    # fewer DiT steps cuts peak VRAM/time without a hard duration cap.
    if duration_sec >= 180:
        steps = 20
    elif duration_sec >= 120:
        steps = 24
    else:
        steps = int(MINIMAX_MUSIC_STEPS)

    _set_input(prompt, "1", "unet_name", models["unet"])
    _set_input(prompt, "1", "weight_dtype", "default")
    _set_input(prompt, "2", "clip_name", models["clip"])
    _set_input(prompt, "2", "type", "minimax")
    _set_input(prompt, "2", "device", "default")
    _set_input(prompt, "3", "vae_name", models["vae"])
    _set_input(prompt, "4", "caption", caption_s)
    _set_input(prompt, "4", "lyrics", str(lyrics_s))
    _set_input(prompt, "4", "seed", int(seed))
    _set_input(prompt, "4", "max_duration", float(duration_sec))
    _set_input(prompt, "4", "cfg_scale", float(MINIMAX_MUSIC_CFG))
    _set_input(prompt, "4", "top_k", int(MINIMAX_MUSIC_TOP_K))
    # seconds linked from encode output in template — keep batch_size only
    _set_input(prompt, "6", "batch_size", 1)
    _set_input(prompt, "7", "seed", int(seed))
    _set_input(prompt, "7", "steps", int(steps))
    _set_input(prompt, "7", "cfg", float(MINIMAX_MUSIC_CFG))
    _set_input(prompt, "7", "sampler_name", "euler")
    _set_input(prompt, "7", "scheduler", "simple")
    _set_input(prompt, "7", "denoise", 1.0)
    if prompt.get("8", {}).get("class_type") == "VAEDecodeAudioTiled":
        _set_input(prompt, "8", "tile_size", int(tile_size))
        _set_input(prompt, "8", "overlap", int(overlap))
    _set_input(prompt, "9", "filename_prefix", filename_prefix)
    _set_input(prompt, "9", "quality", "V0")

    log_m.info(
        "MiniMax Music3 payload unet=%s clip=%s vae=%s | caption_len=%d lyrics_len=%d "
        "max_duration=%.0fs seed=%s steps=%d cfg=%.1f tiled=%dx%d prefer_int8=%s",
        models["unet"],
        models["clip"],
        models["vae"],
        len(caption_s),
        len(str(lyrics_s)),
        duration_sec,
        seed,
        steps,
        MINIMAX_MUSIC_CFG,
        tile_size,
        overlap,
        prefer_int8,
    )
    try:
        dump_dir = Path(settings.cache_dir) / "music_tmp"
        dump_dir.mkdir(parents=True, exist_ok=True)
        dump_path = dump_dir / "last_minimax_music_prompt.json"
        dump_path.write_text(json.dumps(prompt, indent=2), encoding="utf-8")
        log_m.info("MiniMax Music3 API prompt dumped to %s", dump_path)
    except Exception as e:
        log_m.debug("MiniMax prompt dump failed: %s", e)
    return prompt


async def run_minimax_generation(
    *,
    caption: str,
    lyrics: str,
    duration_sec: float,
    seed: int,
    filename_prefix: str,
    on_status=None,
    timeout_sec: float | None = None,
) -> Path:
    """Queue MiniMax Music 3 and wait until audio exists (same poll pattern as ACE)."""
    import time

    try:
        _music_status("Building MiniMax Music 3 workflow…", on_status)
        prompt = await build_minimax_music_workflow(
            caption=caption,
            lyrics=lyrics,
            duration_sec=duration_sec,
            seed=seed,
            filename_prefix=filename_prefix,
        )
        started = time.time()
        dur = float(prompt.get("4", {}).get("inputs", {}).get("max_duration", duration_sec) or 0)
        # Long AR encode + DiT is VRAM-hungry; clear leftover Flux/video weights first
        if dur >= 90:
            _music_status("Freeing VRAM before long MiniMax Music job…", on_status)
            try:
                await comfy.free_memory(unload_models=True, free_memory=True)
                await asyncio.sleep(1.0)
            except Exception as fe:
                log_m.warning("pre-MiniMax free_memory: %s", fe)
        tile = prompt.get("8", {}).get("inputs", {}).get("tile_size")
        unet = prompt.get("1", {}).get("inputs", {}).get("unet_name", "")
        _music_status(
            f"Queued MiniMax Music 3 ({dur:.0f}s max, tile={tile}, "
            f"{'int8' if 'int8' in str(unet).lower() else 'fp16'} — long songs are slow)…",
            on_status,
        )
        prompt_id = await comfy.queue_prompt(prompt)
        _music_status(
            "MiniMax Music 3: text/AR encode first (slow on long tracks), then sample + decode…",
            on_status,
        )
    except Exception:
        clear_activity("Music failed")
        raise

    timeout = float(timeout_sec or max(float(settings.comfy_timeout), 2700.0))
    deadline = time.monotonic() + timeout
    last_status = 0.0
    hist_entry: dict[str, Any] | None = None

    while time.monotonic() < deadline:
        disk = _scan_comfy_audio(filename_prefix, newer_than=started)
        if disk:
            p = disk[0]
            try:
                s1 = p.stat().st_size
                await asyncio.sleep(1.2)
                s2 = p.stat().st_size
                if s2 >= s1 and s2 > 4096:
                    log_m.info("MiniMax Music3 audio on disk: %s (%s bytes)", p, s2)
                    _music_status("Track ready — importing…", on_status)
                    clear_activity("Track ready")
                    return p
            except OSError:
                pass

        try:
            hist = await comfy.get_history(prompt_id)
            entry = comfy._history_entry(hist, prompt_id)
            if entry:
                err = comfy._entry_failed(entry)
                if err:
                    raise RuntimeError(f"ComfyUI execution error: {err}")
                outs = extract_audio_outputs(entry)
                if outs or comfy._entry_succeeded(entry):
                    hist_entry = entry
                    if outs:
                        break
        except RuntimeError:
            raise
        except Exception as e:
            log_m.debug("MiniMax Music3 history poll: %s", e)

        try:
            q = await comfy.get_queue()
            running = q.get("queue_running") or []
            pending = q.get("queue_pending") or []
            in_q = any(
                isinstance(item, (list, tuple)) and len(item) > 1 and item[1] == prompt_id
                for item in list(running) + list(pending)
            )
            if not in_q:
                disk = _scan_comfy_audio(filename_prefix, newer_than=started)
                if disk:
                    if on_status:
                        on_status("Track ready — importing…")
                    clear_activity("Track ready")
                    return disk[0]
                if hist_entry and extract_audio_outputs(hist_entry):
                    break
        except Exception:
            pass

        now = time.monotonic()
        if on_status and now - last_status > 8:
            elapsed = int(time.time() - started)
            _music_status(
                f"Still working ({elapsed}s) — MiniMax Music 3 is slow; "
                f"sampling then tiled VAE decode…",
                on_status,
            )
            last_status = now
        await asyncio.sleep(1.0)

    if hist_entry:
        outs = extract_audio_outputs(hist_entry)
        if outs:
            o = outs[0]
            dest = Path(settings.cache_dir) / "music_tmp" / o["filename"]
            dest.parent.mkdir(parents=True, exist_ok=True)
            await comfy.download_view(
                o["filename"], o.get("subfolder", ""), o.get("type", "output"), dest
            )
            clear_activity("Track ready")
            return dest

    disk = _scan_comfy_audio(filename_prefix, newer_than=started)
    if disk:
        clear_activity("Track ready")
        return disk[0]

    clear_activity("Music timed out")
    raise TimeoutError(
        f"MiniMax Music 3 timed out after {timeout:.0f}s (prompt {prompt_id}). "
        "If Comfy already finished, check ComfyUI/output for the mp3."
    )
