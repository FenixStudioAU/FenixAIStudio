"""FastAPI application — AI Music Video Studio."""
from __future__ import annotations

import asyncio
import json
import math
import shutil
import subprocess
import traceback
from pathlib import Path
from typing import Any, Optional

from fastapi import BackgroundTasks, FastAPI, File, Form, HTTPException, UploadFile
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse, JSONResponse, StreamingResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel, Field

from . import (
    amv_pipeline,
    app_settings_store,
    audio_tools,
    character_library,
    chat_service,
    chat_tools,
    coder_store,
    export_ffmpeg,
    llm_client,
    lora_manager,
    models_detect,
    music_pipeline,
    music_store,
    music_train,
    music_train_store,
    project_store,
    story_pipeline,
    studio_pipeline,
    studio_store,
    system_stats,
)
from .comfyui_client import comfy
from .config import ROOT, settings
from .gen_activity import clear_activity, get_activity, set_activity
from .job_manager import job_manager
from .logging_setup import log
from .schemas import (
    AmvPrepareRequest,
    ApplyQualityRequest,
    AutoSlotsRequest,
    BulkGenerateRequest,
    ChatMediaRequest,
    ChatRequest,
    ChatSearchRequest,
    CoderProjectCreate,
    CoderProjectPatch,
    CoderVersionCreate,
    GenerateImageRequest,
    GenerateVideoRequest,
    GenStatus,
    StudioImageRequest,
    StudioVideoRequest,
    ImageSettings,
    ImportLoraRequest,
    LoraSearchRequest,
    MusicGenerateRequest,
    MusicTrainCreate,
    Project,
    ProjectCloneRequest,
    ProjectCreate,
    ReferenceItem,
    Shot,
    StoryGenerateRequest,
    UserSettingsUpdate,
    VideoSettings,
    new_id,
)
from .workflow_engine import list_video_presets

app = FastAPI(title=settings.title, version="0.3.0")
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

FRONTEND = ROOT / "frontend"


@app.on_event("startup")
async def startup() -> None:
    settings.projects_dir.mkdir(parents=True, exist_ok=True)
    settings.logs_dir.mkdir(parents=True, exist_ok=True)
    settings.workflows_dir.mkdir(parents=True, exist_ok=True)
    app_settings_store.apply_user_settings()
    # Ensure workflow templates are visible (config may remap path)
    job_manager.start()
    from . import comfy_idle

    comfy_idle.start_idle_watcher()
    online = await comfy.is_online()
    log.info(
        "Startup — ComfyUI online=%s url=%s version=%s",
        online,
        settings.comfy_url,
        settings.version,
    )
    if not online and settings.comfy_auto_start and settings.comfy_start_script.exists():
        log.info("Attempting to start ComfyUI via %s", settings.comfy_start_script)
        try:
            subprocess.Popen(
                ["cmd", "/c", "start", "ComfyUI", str(settings.comfy_start_script)],
                cwd=str(settings.comfy_install),
                shell=False,
            )
        except Exception as e:
            log.warning("Could not auto-start ComfyUI: %s", e)


@app.on_event("shutdown")
async def shutdown() -> None:
    await comfy.close()


# ---------- System ----------


@app.get("/api/health")
async def health() -> dict[str, Any]:
    from .models_detect import _ffmpeg_available

    return {
        "ok": True,
        "version": settings.version,
        "comfyui": await comfy.is_online(),
        "ffmpeg": _ffmpeg_available(),
        "ffmpeg_path": settings.ffmpeg,
    }


@app.get("/api/system")
async def system_info() -> dict[str, Any]:
    info = await models_detect.detect_models()
    info["app"] = {
        "title": settings.title,
        "port": settings.port,
        "version": settings.version,
        "dev_build": bool(settings.dev_build),
    }
    try:
        from .models_detect import gpu_vendor

        info["gpu_vendor"] = gpu_vendor()
    except Exception:
        info["gpu_vendor"] = "unknown"
    # Mark which video presets are actually installed
    try:
        from .workflow_engine import list_video_presets_installed

        info["video_presets"] = await list_video_presets_installed()
    except Exception:
        pass
    info["defaults"] = {
        "slot_duration": settings.default_slot,
        "fps": settings.default_fps,
        "resolution": settings.default_resolution,
        "aspect_ratio": settings.default_aspect,
        "image_model": settings.default_image_model,
        "video_preset": settings.default_video_preset,
    }
    ollama_ok = await llm_client.ollama_online()
    info["ollama"] = {
        "online": ollama_ok,
        "url": settings.ollama_url,
        "models": await llm_client.list_ollama_models() if ollama_ok else [],
        "defaults": {
            "planner": settings.llm_planner,
            "writer": settings.llm_writer,
            "editor": settings.llm_editor,
        },
    }
    info["style_templates"] = story_pipeline.list_style_templates()
    return info


@app.post("/api/comfyui/interrupt")
async def interrupt_comfy() -> dict[str, str]:
    await comfy.interrupt()
    return {"status": "ok"}


@app.get("/api/system/host-stats")
async def api_host_stats() -> dict[str, Any]:
    return system_stats.host_stats()


@app.get("/api/activity")
async def api_activity() -> dict[str, Any]:
    """
    Lightweight 'what is the studio doing right now?' for the top-bar indicator.
    Combines local jobs + ComfyUI queue (+ Ollama reachability).
    """
    active_jobs = [
        j
        for j in job_manager.jobs.values()
        if j.status in ("queued", "running")
    ]
    # Prefer most recently created active job
    active_jobs.sort(key=lambda j: j.created_at, reverse=True)

    comfy_online = False
    comfy_running = 0
    comfy_pending = 0
    comfy_detail = ""
    try:
        comfy_online = await asyncio.wait_for(comfy.is_online(), timeout=2.5)
        if comfy_online:
            q = await asyncio.wait_for(comfy.get_queue(), timeout=3.0)
            running = q.get("queue_running") or []
            pending = q.get("queue_pending") or []
            comfy_running = len(running)
            comfy_pending = len(pending)
            if running:
                # entry shape: [number, prompt_id, prompt, extra_data, outputs_to_execute]
                try:
                    entry = running[0]
                    pid = entry[1] if isinstance(entry, (list, tuple)) and len(entry) > 1 else "?"
                    comfy_detail = f"prompt {str(pid)[:8]}"
                except Exception:
                    comfy_detail = "queue busy"
    except Exception:
        comfy_online = False

    ollama_online = False
    try:
        ollama_online = await asyncio.wait_for(llm_client.ollama_online(), timeout=2.0)
    except Exception:
        ollama_online = False

    # Derive human label (priority: our jobs → comfy queue → idle)
    state = "idle"
    label = "Idle"
    detail = ""
    color = "idle"

    job = active_jobs[0] if active_jobs else None
    if job:
        kind = (job.kind or "").lower()
        msg = (job.message or "").strip()
        pct = int(round(float(job.progress or 0) * 100))
        if kind == "video":
            state = "gen_video"
            label = "Generating video"
            color = "busy-video"
        elif kind == "image":
            state = "gen_image"
            label = "Generating image"
            color = "busy-image"
        else:
            state = "job"
            label = f"Job: {kind or 'work'}"
            color = "busy"
        detail = msg or f"{job.status}"
        if pct > 0:
            detail = f"{detail} · {pct}%".strip(" ·")
        # Early phase often means model load in Comfy
        if job.status == "queued":
            label = f"Queued {kind}" if kind else "Queued"
            color = "wait"
        elif msg and any(
            x in msg.lower()
            for x in ("waiting for comfy", "loading", "model", "starting", "queueing", "queue")
        ):
            if kind == "video":
                label = "Comfy: loading / video"
            elif kind == "image":
                label = "Comfy: loading / image"
            else:
                label = "Comfy: loading model"
            color = "comfy"
    elif comfy_running > 0:
        state = "comfy"
        label = "ComfyUI working"
        detail = comfy_detail or f"{comfy_running} running"
        if comfy_pending:
            detail += f" · {comfy_pending} pending"
        color = "comfy"
    elif comfy_pending > 0:
        state = "comfy_queue"
        label = "ComfyUI queue"
        detail = f"{comfy_pending} pending"
        color = "wait"
    elif not comfy_online:
        state = "comfy_offline"
        label = "Comfy offline"
        color = "warn"
        detail = "start ComfyUI"
    else:
        state = "idle"
        label = "Idle"
        color = "idle"
        detail = "ready" if ollama_online else "Ollama offline"

    return {
        "state": state,
        "label": label,
        "detail": detail,
        "color": color,
        "comfy_online": comfy_online,
        "comfy_running": comfy_running,
        "comfy_pending": comfy_pending,
        "ollama_online": ollama_online,
        "jobs_active": len(active_jobs),
        "job": (
            {
                "id": job.id,
                "kind": job.kind,
                "status": job.status,
                "progress": job.progress,
                "message": job.message,
            }
            if job
            else None
        ),
    }


@app.get("/api/settings")
async def api_get_settings() -> dict[str, Any]:
    data = app_settings_store.load_user_settings()
    data["comfy_url_live"] = settings.comfy_url
    data["ollama_url_live"] = settings.ollama_url
    return data


@app.put("/api/settings")
async def api_put_settings(body: UserSettingsUpdate) -> dict[str, Any]:
    patch = body.model_dump(exclude_none=True)
    return app_settings_store.save_user_settings(patch)


# ---------- Character library (shared gallery) ----------


@app.get("/api/characters")
async def api_list_characters() -> list[dict[str, Any]]:
    return character_library.list_characters()


@app.post("/api/characters")
async def api_add_character(
    name: str = Form(...),
    category: str = Form("character"),
    description: str = Form(""),
    file: UploadFile | None = File(None),
) -> dict[str, Any]:
    raw = await file.read() if file else None
    suffix = Path(file.filename or "x.jpg").suffix if file else ".jpg"
    return character_library.add_character(
        name=name,
        category=category,
        description=description,
        image_bytes=raw,
        image_suffix=suffix or ".jpg",
    )


@app.put("/api/characters/{char_id}")
async def api_update_character(
    char_id: str,
    name: Optional[str] = Form(None),
    category: Optional[str] = Form(None),
    description: Optional[str] = Form(None),
    file: UploadFile | None = File(None),
) -> dict[str, Any]:
    patch: dict[str, Any] = {}
    if name is not None:
        patch["name"] = name
    if category is not None:
        patch["category"] = category
    if description is not None:
        patch["description"] = description
    if file:
        patch["image_bytes"] = await file.read()
        patch["image_suffix"] = Path(file.filename or "x.jpg").suffix or ".jpg"
    try:
        return character_library.update_character(char_id, patch)
    except FileNotFoundError:
        raise HTTPException(404, "Character not found")


@app.delete("/api/characters/{char_id}")
async def api_delete_character(char_id: str) -> dict[str, str]:
    character_library.delete_character(char_id)
    return {"status": "deleted"}


@app.get("/api/characters/{char_id}/image")
async def api_character_image(char_id: str):
    c = character_library.get_character(char_id)
    if not c or not c.get("path"):
        raise HTTPException(404, "No image")
    p = character_library.abs_image_path(c["path"])
    if not p:
        raise HTTPException(404, "File missing")
    return FileResponse(p)


@app.post("/api/projects/{project_id}/references/from-library/{char_id}")
async def api_import_char_to_project(project_id: str, char_id: str) -> Project:
    try:
        character_library.import_to_project(project_id, char_id)
    except FileNotFoundError as e:
        raise HTTPException(404, str(e))
    return project_store.load_project(project_id)


# ---------- Projects ----------


@app.get("/api/projects")
async def api_list_projects() -> list[dict[str, Any]]:
    return project_store.list_projects()


@app.post("/api/projects")
async def api_create_project(body: ProjectCreate) -> Project:
    return project_store.create_project(
        body.name,
        kind=body.kind or "music",
        notes=body.notes or "",
    )


@app.get("/api/projects/{project_id}")
async def api_get_project(project_id: str) -> Project:
    try:
        return project_store.load_project(project_id)
    except FileNotFoundError:
        raise HTTPException(404, "Project not found")


@app.put("/api/projects/{project_id}")
async def api_save_project(project_id: str, project: Project) -> Project:
    if project.id != project_id:
        project.id = project_id
    return project_store.save_project(project)


@app.delete("/api/projects/{project_id}")
async def api_delete_project(project_id: str) -> dict[str, str]:
    project_store.delete_project(project_id)
    return {"status": "deleted"}


@app.post("/api/projects/{project_id}/clone")
async def api_clone_project(
    project_id: str, body: ProjectCloneRequest | None = None
) -> Project:
    """Duplicate a project (shots, audio, images, videos, refs) under a new id."""
    try:
        name = ((body.name if body else "") or "").strip()
        return project_store.clone_project(project_id, new_name=name or None)
    except FileNotFoundError:
        raise HTTPException(404, "Project not found")
    except Exception as e:
        log.error("Clone project failed: %s", e)
        raise HTTPException(500, str(e))


@app.get("/api/projects/{project_id}/files/{file_path:path}")
async def api_project_file(project_id: str, file_path: str):
    root = project_store.project_dir(project_id).resolve()
    target = (root / file_path).resolve()
    if not str(target).startswith(str(root)):
        raise HTTPException(400, "Invalid path")
    if not target.is_file():
        raise HTTPException(404, "File not found")
    # Stills/thumbs are overwritten in place sometimes — never let the browser
    # keep a decoded bitmap of the previous generation.
    return FileResponse(
        target,
        headers={"Cache-Control": "no-store, max-age=0", "Pragma": "no-cache"},
    )


# ---------- Audio ----------


@app.post("/api/projects/{project_id}/audio")
async def api_upload_audio(project_id: str, file: UploadFile = File(...)) -> Project:
    try:
        proj = project_store.load_project(project_id)
    except FileNotFoundError:
        raise HTTPException(404, "Project not found")

    suffix = Path(file.filename or "audio.mp3").suffix.lower() or ".mp3"
    if suffix not in {".mp3", ".wav", ".flac", ".ogg", ".m4a", ".aac", ".wma"}:
        raise HTTPException(400, f"Unsupported audio type: {suffix}")

    dest = project_store.project_dir(project_id) / "audio" / f"main{suffix}"
    dest.parent.mkdir(parents=True, exist_ok=True)
    data = await file.read()
    dest.write_bytes(data)

    meta = audio_tools.probe_duration(dest)
    wf = project_store.project_dir(project_id) / "cache" / "waveform.json"
    audio_tools.build_waveform_peaks(dest, wf)

    proj.audio.path = project_store.rel_to_project(project_id, dest)
    proj.audio.filename = file.filename
    proj.audio.duration = meta["duration"]
    proj.audio.sample_rate = meta.get("sample_rate", 0)
    proj.audio.channels = meta.get("channels", 0)
    proj.audio.waveform_path = project_store.rel_to_project(project_id, wf)

    if not proj.timeline.shots:
        project_store.ensure_default_slots(proj, settings.default_slot)

    return project_store.save_project(proj)


@app.post("/api/projects/{project_id}/audio/analyze")
async def api_analyze_audio(project_id: str) -> dict[str, Any]:
    proj = project_store.load_project(project_id)
    audio = project_store.abs_path(project_id, proj.audio.path)
    if not audio or not audio.exists():
        raise HTTPException(400, "No audio uploaded")
    out = project_store.project_dir(project_id) / "cache" / "analysis.json"
    result = audio_tools.analyze_audio(audio, out)
    proj.audio.analysis_path = project_store.rel_to_project(project_id, out)
    project_store.save_project(proj)
    return result


@app.post("/api/projects/{project_id}/amv/prepare")
async def api_amv_prepare(project_id: str, body: AmvPrepareRequest) -> Project:
    """Advanced Music Video: analyze track, plan ~20s LTX lip-sync shots, write timeline."""
    if not await llm_client.ollama_online():
        raise HTTPException(
            503,
            "Ollama is offline. Start Ollama so the performance planner can write shot prompts.",
        )
    try:
        cast = [
            {"name": c.name, "role": c.role}
            for c in (body.cast_roles or [])
            if (c.name or "").strip()
        ]
        return await amv_pipeline.run_amv_prepare(
            project_id,
            concept=body.concept or "",
            lyrics=body.lyrics or "",
            window_sec=float(body.window_sec or 20.0),
            slot_mode=(body.slot_mode or "fixed"),
            video_engine=(body.video_engine or "ltx23-ia2v"),
            ltx_mode=(body.ltx_mode or "fast"),
            quality=body.quality or "draft",
            cast_roles=cast,
            environment_name=body.environment_name or "",
            seamless=bool(body.seamless),
            llm_model=body.llm_model or "",
        )
    except HTTPException:
        raise
    except Exception as e:
        log.error("AMV prepare failed: %s\n%s", e, traceback.format_exc())
        raise HTTPException(500, str(e))


@app.post("/api/projects/{project_id}/timeline/auto-slots")
async def api_auto_slots(project_id: str, body: AutoSlotsRequest) -> Project:
    proj = project_store.load_project(project_id)
    slot_dur = body.duration or settings.default_slot
    if body.mode == "fixed":
        project_store.rebuild_slots_fixed(proj, slot_dur)
        return project_store.save_project(proj)

    analysis_path = project_store.abs_path(project_id, proj.audio.analysis_path)
    if not analysis_path or not analysis_path.exists():
        audio = project_store.abs_path(project_id, proj.audio.path)
        if not audio:
            raise HTTPException(400, "No audio")
        analysis_path = project_store.project_dir(project_id) / "cache" / "analysis.json"
        audio_tools.analyze_audio(audio, analysis_path)
        proj.audio.analysis_path = project_store.rel_to_project(project_id, analysis_path)

    analysis = json.loads(analysis_path.read_text(encoding="utf-8"))
    slots = audio_tools.slots_from_analysis(
        analysis, mode=body.mode, target_duration=slot_dur, song_duration=proj.audio.duration
    )
    shots = []
    for i, s in enumerate(slots, 1):
        shots.append(Shot(start=s["start"], duration=s["duration"], label=f"Shot {i}"))
    proj.timeline.shots = shots
    return project_store.save_project(proj)


# ---------- Shot media ----------


@app.post("/api/projects/{project_id}/shots/{shot_id}/upload-image")
async def api_upload_shot_image(
    project_id: str, shot_id: str, file: UploadFile = File(...)
) -> Project:
    proj = project_store.load_project(project_id)
    shot = next((s for s in proj.timeline.shots if s.id == shot_id), None)
    if not shot:
        raise HTTPException(404, "Shot not found")
    suffix = Path(file.filename or "image.png").suffix.lower() or ".png"
    dest = project_store.project_dir(project_id) / "images" / "uploaded" / f"{shot_id}{suffix}"
    dest.parent.mkdir(parents=True, exist_ok=True)
    dest.write_bytes(await file.read())
    rel = project_store.rel_to_project(project_id, dest)
    shot.image_path = rel
    shot.image_status = GenStatus.uploaded
    # New still replaces animation
    shot.video_path = None
    shot.draft_video_path = None
    shot.video_alternatives = []
    shot.video_status = GenStatus.empty
    # thumb
    try:
        from PIL import Image

        thumb = project_store.project_dir(project_id) / "thumbnails" / f"{shot_id}.jpg"
        thumb.parent.mkdir(parents=True, exist_ok=True)
        with Image.open(dest) as im:
            im = im.convert("RGB")
            im.thumbnail((320, 180))
            im.save(thumb, "JPEG", quality=85)
        shot.thumbnail_path = project_store.rel_to_project(project_id, thumb)
    except Exception as e:
        log.warning("thumb failed: %s", e)
    return project_store.save_project(proj, merge_media=False)


@app.post("/api/projects/{project_id}/shots/{shot_id}/from-studio/{item_id}")
async def api_shot_from_studio(project_id: str, shot_id: str, item_id: str) -> Project:
    """Attach a studio gallery still/video to a timeline shot."""
    import shutil

    item = studio_store.get_item(item_id)
    if not item:
        raise HTTPException(404, "Gallery item not found")
    src = studio_store.abs_media_path(item.get("path") or "")
    if not src or not src.is_file():
        raise HTTPException(404, "Gallery file missing")
    proj = project_store.load_project(project_id)
    shot = next((s for s in proj.timeline.shots if s.id == shot_id), None)
    if not shot:
        raise HTTPException(404, "Shot not found")
    kind = (item.get("kind") or "image").lower()
    suffix = src.suffix.lower() or (".png" if kind == "image" else ".mp4")
    if kind == "video":
        from datetime import datetime, timezone

        # Unique name so browser/timeline cache can't stick to a previous gallery file
        ts = datetime.now(timezone.utc).strftime("%Y%m%d_%H%M%S")
        dest = (
            project_store.project_dir(project_id)
            / "videos"
            / "final"
            / f"{shot_id}_gallery_{ts}{suffix}"
        )
        dest.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(src, dest)
        rel = project_store.rel_to_project(project_id, dest)
        shot.video_path = rel
        shot.draft_video_path = None
        shot.video_status = GenStatus.final
        shot.last_error = None
    else:
        dest = (
            project_store.project_dir(project_id)
            / "images"
            / "uploaded"
            / f"{shot_id}_gallery{suffix}"
        )
        dest.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(src, dest)
        rel = project_store.rel_to_project(project_id, dest)
        shot.image_path = rel
        shot.image_status = GenStatus.uploaded
        shot.video_path = None
        shot.draft_video_path = None
        shot.video_alternatives = []
        shot.video_status = GenStatus.empty
        try:
            from PIL import Image

            thumb = project_store.project_dir(project_id) / "thumbnails" / f"{shot_id}.jpg"
            thumb.parent.mkdir(parents=True, exist_ok=True)
            with Image.open(dest) as im:
                im = im.convert("RGB")
                im.thumbnail((320, 180))
                im.save(thumb, "JPEG", quality=85)
            shot.thumbnail_path = project_store.rel_to_project(project_id, thumb)
        except Exception as e:
            log.warning("gallery thumb failed: %s", e)
    return project_store.save_project(proj, merge_media=False)


@app.post("/api/projects/{project_id}/shots/{shot_id}/upload-video")
async def api_upload_shot_video(
    project_id: str, shot_id: str, file: UploadFile = File(...)
) -> Project:
    """Attach an existing video file to a timeline shot (skip AI animation)."""
    proj = project_store.load_project(project_id)
    shot = next((s for s in proj.timeline.shots if s.id == shot_id), None)
    if not shot:
        raise HTTPException(404, "Shot not found")
    suffix = Path(file.filename or "clip.mp4").suffix.lower() or ".mp4"
    if suffix not in {".mp4", ".webm", ".mov", ".mkv", ".avi", ".gif"}:
        raise HTTPException(400, f"Unsupported video type: {suffix}")
    dest = project_store.project_dir(project_id) / "videos" / "final" / f"{shot_id}_upload{suffix}"
    dest.parent.mkdir(parents=True, exist_ok=True)
    dest.write_bytes(await file.read())
    rel = project_store.rel_to_project(project_id, dest)
    shot.video_path = rel
    shot.video_status = GenStatus.final
    shot.last_error = None
    # Optional still thumb via ffmpeg
    try:
        thumb = project_store.project_dir(project_id) / "thumbnails" / f"{shot_id}.jpg"
        thumb.parent.mkdir(parents=True, exist_ok=True)
        subprocess.run(
            [
                settings.ffmpeg,
                "-y",
                "-i",
                str(dest),
                "-ss",
                "0",
                "-vframes",
                "1",
                "-q:v",
                "3",
                str(thumb),
            ],
            capture_output=True,
            timeout=30,
        )
        if thumb.exists():
            shot.thumbnail_path = project_store.rel_to_project(project_id, thumb)
            if not shot.image_path:
                # copy frame as image so animate-from-image still has a still
                img_dest = project_store.project_dir(project_id) / "images" / "uploaded" / f"{shot_id}_frame.jpg"
                img_dest.parent.mkdir(parents=True, exist_ok=True)
                img_dest.write_bytes(thumb.read_bytes())
                shot.image_path = project_store.rel_to_project(project_id, img_dest)
                shot.image_status = GenStatus.uploaded
    except Exception as e:
        log.warning("video thumb failed: %s", e)
    return project_store.save_project(proj)


@app.post("/api/projects/{project_id}/shots/{shot_id}/upload-media")
async def api_upload_shot_media(
    project_id: str, shot_id: str, file: UploadFile = File(...)
) -> Project:
    """Auto-route image or video upload based on file type."""
    name = (file.filename or "").lower()
    ct = (file.content_type or "").lower()
    video_ext = (".mp4", ".webm", ".mov", ".mkv", ".avi", ".gif")
    if ct.startswith("video/") or name.endswith(video_ext):
        return await api_upload_shot_video(project_id, shot_id, file)
    return await api_upload_shot_image(project_id, shot_id, file)


@app.post("/api/projects/{project_id}/generate/image")
async def api_gen_image(project_id: str, body: GenerateImageRequest) -> dict[str, Any]:
    if not await comfy.is_online():
        raise HTTPException(503, "ComfyUI is offline. Start ComfyUI and retry.")
    proj = project_store.load_project(project_id)
    shot = next((s for s in proj.timeline.shots if s.id == body.shot_id), None)
    if not shot:
        raise HTTPException(404, "Shot not found")
    settings_img = body.settings or shot.image
    # Persist prompt/settings immediately so switching shots / reloads keep them
    shot.image = settings_img
    shot.image_status = GenStatus.queued
    # Regenerating the still invalidates the old animation immediately
    shot.video_path = None
    shot.draft_video_path = None
    shot.video_alternatives = []
    shot.video_status = GenStatus.empty
    project_store.save_project(proj, merge_media=False)
    job = await job_manager.enqueue_image(project_id, body.shot_id, settings_img)
    return {"job_id": job.id, "status": job.status}


@app.post("/api/projects/{project_id}/generate/video")
async def api_gen_video(project_id: str, body: GenerateVideoRequest) -> dict[str, Any]:
    if not await comfy.is_online():
        raise HTTPException(503, "ComfyUI is offline. Start ComfyUI and retry.")
    proj = project_store.load_project(project_id)
    shot = next((s for s in proj.timeline.shots if s.id == body.shot_id), None)
    if not shot:
        raise HTTPException(404, "Shot not found")
    settings_vid = body.settings or shot.video
    # Timeline length is authoritative; never let default duration_sec=5 override a longer shot
    timeline_dur = float(shot.duration or 0)
    if timeline_dur > 0:
        settings_vid.duration_sec = timeline_dur
    elif not settings_vid.duration_sec or settings_vid.duration_sec <= 0:
        settings_vid.duration_sec = 5.0
    # LTX ~20s; MiniMax/Wan ~15s
    preset_l = (getattr(settings_vid, "preset_id", None) or "").lower()
    is_ltx = preset_l.startswith("ltx") or "ltx23" in preset_l
    max_clip = 20.0 if is_ltx else 15.0
    if settings_vid.duration_sec > max_clip:
        settings_vid.duration_sec = max_clip
    # Fallback: use image prompt when motion prompt empty
    if not (settings_vid.animation_prompt or "").strip():
        ip = (shot.image.positive_prompt if shot.image else "") or ""
        if ip.strip():
            settings_vid.animation_prompt = ip.strip()
    shot.video = settings_vid
    shot.video_status = GenStatus.queued
    project_store.save_project(proj)
    job = await job_manager.enqueue_video(project_id, body.shot_id, settings_vid)
    return {
        "job_id": job.id,
        "status": job.status,
        "duration_sec": settings_vid.duration_sec,
    }


@app.post("/api/projects/{project_id}/generate/bulk-images")
async def api_bulk_images(project_id: str, body: BulkGenerateRequest | None = None) -> dict[str, Any]:
    """Queue image gen for every shot that has a prompt and (optionally) no image yet."""
    if not await comfy.is_online():
        raise HTTPException(503, "ComfyUI is offline. Start ComfyUI and retry.")
    # Free VRAM before a bulk run so Flux/MiniMax start from a clean load
    from . import comfy_idle

    comfy_idle.note_comfy_work()
    try:
        await comfy.free_memory(unload_models=True, free_memory=True)
        await asyncio.sleep(0.6)
        await comfy.free_memory(unload_models=True, free_memory=True)
    except Exception as e:
        log.warning("bulk-images pre-free: %s", e)
    body = body or BulkGenerateRequest()
    proj = project_store.load_project(project_id)
    job_ids: list[str] = []
    skipped = 0
    id_filter = set(body.shot_ids or [])
    for shot in proj.timeline.shots:
        if id_filter and shot.id not in id_filter:
            continue
        prompt = (shot.image.positive_prompt if shot.image else "") or ""
        if not prompt.strip():
            skipped += 1
            continue
        if body.only_missing and shot.image_path:
            skipped += 1
            continue
        shot.image_status = GenStatus.queued
        if not body.only_missing or not shot.image_path:
            # clear video if re-gen image
            if shot.image_path and not body.only_missing:
                pass
            if not shot.image_path:
                pass
        # When generating new image onto empty, or force: clear video when replacing
        if shot.image_path and not body.only_missing:
            shot.video_path = None
            shot.draft_video_path = None
            shot.video_status = GenStatus.empty
        job = await job_manager.enqueue_image(project_id, shot.id, shot.image)
        job_ids.append(job.id)
    project_store.save_project(proj)
    return {"queued": len(job_ids), "skipped": skipped, "job_ids": job_ids}


@app.post("/api/projects/{project_id}/generate/bulk-videos")
async def api_bulk_videos(project_id: str, body: BulkGenerateRequest | None = None) -> dict[str, Any]:
    """Queue video gen for shots that have an image + (motion or image) prompt.

    only_missing behaviour:
    - quality draft: skip if any video already exists
    - quality final: skip only if status is already final (drafts get re-queued)
    - only_missing false: regenerate everything with an image
    """
    if not await comfy.is_online():
        raise HTTPException(503, "ComfyUI is offline. Start ComfyUI and retry.")
    from . import comfy_idle

    comfy_idle.note_comfy_work()
    try:
        await comfy.free_memory(unload_models=True, free_memory=True)
        await asyncio.sleep(0.6)
        await comfy.free_memory(unload_models=True, free_memory=True)
    except Exception as e:
        log.warning("bulk-videos pre-free: %s", e)
    body = body or BulkGenerateRequest()
    proj = project_store.load_project(project_id)
    job_ids: list[str] = []
    skipped = 0
    id_filter = set(body.shot_ids or [])
    want_quality = body.quality  # may be None → use each shot's quality
    for shot in proj.timeline.shots:
        if id_filter and shot.id not in id_filter:
            continue
        if not shot.image_path:
            skipped += 1
            continue
        target_q = want_quality or (shot.video.quality if shot.video else "draft") or "draft"
        has_vid = bool(shot.video_path or shot.draft_video_path)
        status = shot.video_status
        status_val = status.value if hasattr(status, "value") else str(status or "")
        is_final = status_val == GenStatus.final.value or status_val == "final"
        is_draft_vid = has_vid and not is_final

        if body.only_missing and has_vid:
            # Final bulk upgrades drafts; pure draft bulk leaves existing clips alone
            if target_q == "final" and is_draft_vid:
                pass  # re-queue draft → final
            elif target_q == "final" and is_final:
                skipped += 1
                continue
            else:
                # target draft (or unknown) and video already exists
                skipped += 1
                continue

        anim = (shot.video.animation_prompt if shot.video else "") or ""
        img_p = (shot.image.positive_prompt if shot.image else "") or ""
        if not anim.strip() and not img_p.strip():
            skipped += 1
            continue
        if not anim.strip() and img_p.strip():
            shot.video.animation_prompt = img_p.strip()
        shot.video.quality = target_q  # type: ignore[assignment]
        # Never silently change engine. Quality-only bulk. If preset was wiped
        # (e.g. old prompt-regen bug), restore from project global when set.
        cur_preset = (getattr(shot.video, "preset_id", None) or "").strip()
        global_preset = (getattr(proj, "global_video_preset", None) or "").strip()
        if (not cur_preset or cur_preset.lower() in ("auto", "default", "none")) and global_preset:
            shot.video.preset_id = global_preset
            log.info(
                "bulk-videos shot %s: empty preset → using project global %s",
                shot.id,
                global_preset,
            )
        shot.video_status = GenStatus.queued
        job = await job_manager.enqueue_video(project_id, shot.id, shot.video)
        job_ids.append(job.id)
    project_store.save_project(proj)
    return {
        "queued": len(job_ids),
        "skipped": skipped,
        "job_ids": job_ids,
        "quality": want_quality,
    }


@app.post("/api/projects/{project_id}/apply-video-quality")
async def api_apply_video_quality(project_id: str, body: ApplyQualityRequest) -> Project:
    """Set draft/final quality on every shot (or selected) at once."""
    proj = project_store.load_project(project_id)
    id_filter = set(body.shot_ids or [])
    for shot in proj.timeline.shots:
        if id_filter and shot.id not in id_filter:
            continue
        shot.video.quality = body.quality
    proj.export.default_video_quality = body.quality
    return project_store.save_project(proj)


@app.get("/api/projects/{project_id}/export/clips-zip")
async def api_export_clips_zip(project_id: str):
    """Zip all generated/uploaded shot videos for bulk download."""
    import io
    import zipfile
    from datetime import datetime
    from fastapi.responses import StreamingResponse

    proj = project_store.load_project(project_id)
    buf = io.BytesIO()
    count = 0
    with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as zf:
        for i, shot in enumerate(sorted(proj.timeline.shots, key=lambda s: s.start)):
            rel = shot.video_path or shot.draft_video_path
            if not rel:
                continue
            p = project_store.abs_path(project_id, rel)
            if not p or not p.is_file():
                continue
            label = (shot.label or f"shot_{i+1:02d}").replace("/", "-").replace("\\", "-")
            safe = "".join(c if c.isalnum() or c in "-_ ." else "_" for c in label)[:60]
            arc = f"{i+1:02d}_{safe}{p.suffix}"
            zf.write(p, arcname=arc)
            count += 1
    if count == 0:
        raise HTTPException(404, "No video clips on any shot yet")
    buf.seek(0)
    name = f"{proj.name.replace(' ', '_')}_clips_{datetime.now().strftime('%Y%m%d_%H%M')}.zip"
    return StreamingResponse(
        buf,
        media_type="application/zip",
        headers={"Content-Disposition": f'attachment; filename="{name}"'},
    )


@app.get("/api/llm/models")
async def api_llm_models() -> dict[str, Any]:
    online = await llm_client.ollama_online()
    user = app_settings_store.load_user_settings()
    from .models_detect import get_vram_gb

    vram = float(get_vram_gb() or 0)
    low = bool(user.get("optimize_low_vram")) or (0 < vram < 8)
    max_b = story_pipeline.LOW_VRAM_MAX_B if low else None
    # Saved story models win. Fall back to chat model, then built-in small defaults.
    chat = (user.get("chat_model") or "").strip()
    def_planner = (
        (user.get("story_planner_model") or "").strip()
        or chat
        or story_pipeline.DEFAULT_MODELS["planner"]
    )
    def_writer = (
        (user.get("story_writer_model") or "").strip()
        or chat
        or story_pipeline.DEFAULT_MODELS["writer"]
    )
    def_editor = (
        (user.get("story_editor_model") or "").strip()
        or chat
        or story_pipeline.DEFAULT_MODELS["editor"]
    )
    return {
        "online": online,
        "url": settings.ollama_url,
        "models": await llm_client.list_ollama_models() if online else [],
        "vram_gb": vram,
        "force_small_models": low,
        "max_param_b": max_b,
        "defaults": {
            "planner": def_planner,
            "writer": def_writer,
            "editor": def_editor,
            "chat": chat,
            "story_planner": def_planner,
            "story_writer": def_writer,
            "story_editor": def_editor,
            "coder_designer": user.get("coder_designer_model") or "",
            "coder": user.get("coder_model") or "",
            "coder_repair": user.get("coder_repair_model") or "",
        },
        "styles": story_pipeline.list_style_templates(),
    }


@app.post("/api/chat")
async def api_chat(body: ChatRequest) -> dict[str, Any]:
    """Standalone chat / coder turn. History is stored in the browser, not here."""
    if not await llm_client.ollama_online():
        raise HTTPException(503, "Ollama is offline. Start Ollama and pull a model.")
    user = app_settings_store.load_user_settings()
    model = (body.model or "").strip()
    if not model:
        if (body.mode or "chat").lower() == "coder":
            stage = (body.stage or "designer").lower()
            if stage == "repair":
                model = user.get("coder_repair_model") or user.get("coder_model") or ""
            elif stage == "coder":
                model = user.get("coder_model") or ""
            else:
                model = user.get("coder_designer_model") or user.get("chat_model") or ""
        else:
            model = user.get("chat_model") or ""
    if not model:
        models = await llm_client.list_ollama_models()
        if not models:
            raise HTTPException(400, "No Ollama models available. Pull a model first.")
        model = models[0]["id"]
    try:
        msgs = [m.model_dump() for m in body.messages]
        # Inject attachment / web-search context as a synthetic user note before the last message
        extra_bits: list[str] = []
        if body.attachment_context:
            extra_bits.append(body.attachment_context.strip())
        search_block = ""
        if body.enable_web_search and (body.web_search_query or "").strip():
            hits = await chat_tools.web_search(body.web_search_query.strip(), limit=5)
            search_block = chat_tools.format_search_context(hits, body.web_search_query.strip())
            extra_bits.append(search_block)
        if extra_bits and msgs:
            # Prepend context to the latest user message so the model sees it this turn
            for i in range(len(msgs) - 1, -1, -1):
                if msgs[i].get("role") == "user":
                    msgs[i]["content"] = (
                        "[Context for this turn]\n"
                        + "\n\n".join(extra_bits)
                        + "\n\n[User message]\n"
                        + (msgs[i].get("content") or "")
                    )
                    break
        result = await chat_service.chat_reply(
            mode=body.mode or "chat",
            stage=body.stage or "chat",
            model=model,
            messages=msgs,
            temperature=body.temperature,
            num_predict=body.num_predict,
        )
        if search_block:
            result["web_search"] = search_block
        return result
    except Exception as e:
        log.exception("chat failed")
        raise HTTPException(500, str(e)) from e


CHAT_PROJECT_NAME = "Chat Media (studio)"


def _ensure_chat_project() -> Project:
    """Hidden project used only for chat-triggered Comfy generations.

    IMPORTANT: list_projects() hides this name from the home grid, so we must
    scan the projects folder directly. Otherwise every upload/gen creates a
    brand-new project and attached images cannot be found on the next call.
    """
    import json as _json

    root = settings.projects_dir
    best_id: str | None = None
    best_mtime = -1.0
    if root.is_dir():
        for p in root.iterdir():
            if not p.is_dir():
                continue
            jp = p / "project.json"
            if not jp.is_file():
                continue
            try:
                data = _json.loads(jp.read_text(encoding="utf-8"))
            except Exception:
                continue
            if (data.get("name") or "") != CHAT_PROJECT_NAME:
                continue
            try:
                mtime = jp.stat().st_mtime
            except OSError:
                mtime = 0.0
            if mtime >= best_mtime:
                best_mtime = mtime
                best_id = str(data.get("id") or p.name)
    if best_id:
        try:
            return project_store.load_project(best_id)
        except Exception as e:
            log.warning("Chat media project %s unreadable: %s", best_id, e)
    return project_store.create_project(CHAT_PROJECT_NAME)


def _resolve_chat_source_image(proj: Project, source_rel: str) -> tuple[str, Path]:
    """Return (relative_path_under_proj, absolute Path) for an attached still.

    Recover if the file was saved under an older Chat Media project id
    (from the list_projects hide bug) by locating the basename and copying it in.
    """
    rel = (source_rel or "").strip().replace("\\", "/")
    if not rel:
        raise HTTPException(400, "No source image path")
    ap = project_store.abs_path(proj.id, rel)
    if ap and ap.is_file():
        return rel, ap

    name = Path(rel).name
    # Search any Chat Media (studio) project's uploaded folder
    root = settings.projects_dir
    found: Path | None = None
    if root.is_dir():
        for p in root.iterdir():
            if not p.is_dir():
                continue
            jp = p / "project.json"
            if not jp.is_file():
                continue
            try:
                data = __import__("json").loads(jp.read_text(encoding="utf-8"))
            except Exception:
                continue
            if (data.get("name") or "") != CHAT_PROJECT_NAME:
                continue
            for cand in (
                p / "images" / "uploaded" / name,
                p / rel,
            ):
                if cand.is_file():
                    found = cand
                    break
            if found:
                break
            # basename scan under images/
            img_root = p / "images"
            if img_root.is_dir():
                for hit in img_root.rglob(name):
                    if hit.is_file():
                        found = hit
                        break
            if found:
                break

    if not found:
        raise HTTPException(400, f"Source image not found: {rel}")

    # Copy into current chat project so future jobs stay stable
    dest = project_store.project_dir(proj.id) / "images" / "uploaded" / name
    dest.parent.mkdir(parents=True, exist_ok=True)
    if found.resolve() != dest.resolve():
        try:
            shutil.copy2(found, dest)
        except Exception as e:
            log.warning("Could not copy recovered attachment: %s", e)
            # still use original if readable
            return rel, found
    new_rel = project_store.rel_to_project(proj.id, dest)
    return new_rel, dest


@app.post("/api/chat/upload")
async def api_chat_upload(file: UploadFile = File(...)) -> dict[str, Any]:
    """Upload an image or PDF for chat / Comfy reuse."""
    proj = _ensure_chat_project()
    raw_name = file.filename or "upload.bin"
    suffix = Path(raw_name).suffix.lower() or ".bin"
    data = await file.read()
    if not data:
        raise HTTPException(400, "Empty file")

    att_id = new_id("att_")
    is_pdf = suffix == ".pdf" or (file.content_type or "").lower() == "application/pdf"
    is_image = suffix in {".png", ".jpg", ".jpeg", ".webp", ".gif", ".bmp"} or (
        file.content_type or ""
    ).startswith("image/")

    if is_pdf:
        dest = project_store.project_dir(proj.id) / "cache" / "chat_attachments" / f"{att_id}.pdf"
        dest.parent.mkdir(parents=True, exist_ok=True)
        dest.write_bytes(data)
        text = chat_tools.extract_pdf_text(dest)
        rel = project_store.rel_to_project(proj.id, dest)
        return {
            "id": att_id,
            "kind": "pdf",
            "filename": raw_name,
            "path": rel,
            "project_id": proj.id,
            "text": text,
            "url": f"/api/projects/{proj.id}/files/{rel}",
            "size": len(data),
        }

    if not is_image:
        # store as generic attachment (text-ish) for context
        dest = project_store.project_dir(proj.id) / "cache" / "chat_attachments" / f"{att_id}{suffix}"
        dest.parent.mkdir(parents=True, exist_ok=True)
        dest.write_bytes(data)
        rel = project_store.rel_to_project(proj.id, dest)
        text = ""
        try:
            text = data.decode("utf-8", errors="replace")[:8000]
        except Exception:
            text = "(binary attachment)"
        return {
            "id": att_id,
            "kind": "file",
            "filename": raw_name,
            "path": rel,
            "project_id": proj.id,
            "text": text,
            "url": f"/api/projects/{proj.id}/files/{rel}",
            "size": len(data),
        }

    # Image → store under uploaded images so video jobs can use it
    dest = project_store.project_dir(proj.id) / "images" / "uploaded" / f"{att_id}{suffix}"
    dest.parent.mkdir(parents=True, exist_ok=True)
    dest.write_bytes(data)
    rel = project_store.rel_to_project(proj.id, dest)
    return {
        "id": att_id,
        "kind": "image",
        "filename": raw_name,
        "path": rel,
        "project_id": proj.id,
        "url": f"/api/projects/{proj.id}/files/{rel}",
        "size": len(data),
    }


@app.post("/api/chat/search")
async def api_chat_search(body: ChatSearchRequest) -> dict[str, Any]:
    q = (body.query or "").strip()
    if not q:
        raise HTTPException(400, "query required")
    results = await chat_tools.web_search(q, limit=body.limit or 5)
    return {
        "query": q,
        "results": results,
        "context": chat_tools.format_search_context(results, q),
    }


# ---------- Code Companion workspace (Coder mode) ----------


@app.get("/api/coder/projects")
async def api_coder_list_projects() -> dict[str, Any]:
    return {
        "projects": coder_store.list_projects(),
        "active_id": coder_store.get_active_project_id(),
    }


@app.post("/api/coder/projects")
async def api_coder_create_project(body: CoderProjectCreate | None = None) -> dict[str, Any]:
    name = (body.name if body else "") or ""
    switch = True if body is None else bool(body.switch)
    proj = coder_store.create_project(name, switch=switch)
    return {"project": proj, "active_id": coder_store.get_active_project_id()}


@app.post("/api/coder/projects/{project_id}/activate")
async def api_coder_activate_project(project_id: str) -> dict[str, Any]:
    try:
        coder_store.set_active_project_id(project_id)
    except FileNotFoundError as e:
        raise HTTPException(404, str(e)) from e
    return {"project": coder_store.load_project(project_id), "active_id": project_id}


@app.post("/api/coder/projects/{project_id}/rename")
async def api_coder_rename_project(project_id: str, body: CoderProjectCreate) -> dict[str, Any]:
    try:
        return coder_store.rename_project(project_id, body.name or "")
    except FileNotFoundError as e:
        raise HTTPException(404, str(e)) from e
    except ValueError as e:
        raise HTTPException(400, str(e)) from e


@app.delete("/api/coder/projects/{project_id}")
async def api_coder_delete_project(project_id: str) -> dict[str, Any]:
    try:
        return coder_store.delete_project(project_id)
    except FileNotFoundError as e:
        raise HTTPException(404, str(e)) from e
    except ValueError as e:
        raise HTTPException(400, str(e)) from e


@app.get("/api/coder/project")
async def api_coder_get_project(project_id: str | None = None) -> dict[str, Any]:
    return coder_store.load_project(project_id)


@app.put("/api/coder/project")
async def api_coder_put_project(body: CoderProjectPatch) -> dict[str, Any]:
    fields = body.model_dump(exclude_unset=True)
    pid = fields.pop("project_id", None) or fields.pop("id", None)
    return coder_store.patch_project(fields, project_id=pid)


@app.post("/api/coder/versions")
async def api_coder_add_version(body: CoderVersionCreate) -> dict[str, Any]:
    if not (body.raw_response or "").strip():
        raise HTTPException(400, "raw_response required")
    return coder_store.add_version(
        prompt=body.prompt or "",
        raw_response=body.raw_response,
        kind=body.kind or "build",
        inspector_report=body.inspector_report or "",
        model=body.model or "",
        project_id=body.project_id,
    )


@app.get("/api/coder/versions/{version_id}")
async def api_coder_version_detail(version_id: str, project_id: str | None = None) -> dict[str, Any]:
    detail = coder_store.get_version_detail(version_id, project_id=project_id)
    if not detail:
        raise HTTPException(404, "version not found")
    return detail


@app.get("/api/coder/versions/{version_id}/html")
async def api_coder_version_html(version_id: str, project_id: str | None = None):
    html = coder_store.get_version_html(version_id, project_id=project_id)
    if html is None:
        raise HTTPException(404, "version not found")
    from fastapi.responses import HTMLResponse

    return HTMLResponse(content=html, media_type="text/html")


@app.post("/api/coder/versions/{version_id}/accept")
async def api_coder_accept_version(version_id: str, project_id: str | None = None) -> dict[str, Any]:
    try:
        return coder_store.accept_version(version_id, project_id=project_id)
    except FileNotFoundError as e:
        raise HTTPException(404, str(e)) from e


@app.delete("/api/coder/versions/{version_id}")
async def api_coder_delete_version(version_id: str, project_id: str | None = None) -> dict[str, Any]:
    return coder_store.delete_version(version_id, project_id=project_id)


@app.get("/api/coder/baseline")
async def api_coder_baseline(project_id: str | None = None) -> dict[str, Any]:
    html = coder_store.baseline_html(project_id)
    proj = coder_store.load_project(project_id)
    return {
        "html": html,
        "accepted_version_id": proj.get("accepted_version_id"),
        "active_version_id": proj.get("active_version_id"),
        "project_id": proj.get("id"),
    }


@app.post("/api/chat/media")
async def api_chat_media(body: ChatMediaRequest) -> dict[str, Any]:
    """Generate image or video from chat without opening the timeline editor."""
    if not await comfy.is_online():
        raise HTTPException(503, "ComfyUI is offline. Start ComfyUI and retry.")
    kind = (body.kind or "image").lower()
    prompt = (body.prompt or body.image_prompt or body.motion_prompt or "").strip()
    # Video can reuse an existing image with a short motion prompt
    if kind == "video" and not prompt:
        prompt = (
            "subject breathes and shifts slightly, fabric and hair react to a light draft, "
            "environment details move with the scene"
        )
    if kind == "image" and not prompt:
        raise HTTPException(400, "prompt is required for image generation")

    # Optional LLM enhance of motion / image prompt
    if body.enhance_prompt and prompt:
        user = app_settings_store.load_user_settings()
        model = user.get("chat_model") or settings.llm_writer
        try:
            if await llm_client.ollama_online() and model:
                if kind == "video":
                    sys_enhance = (
                        "You enhance short image-to-video motion prompts. "
                        "Describe WHAT HAPPENS in the shot: subject actions, expressions, "
                        "and environment dynamics (wind, rain, cloth, traffic). "
                        "Do NOT write empty camera jargon like 'soft camera movement', "
                        "'gentle pan', 'natural movement', or 'subtle cinematic motion' alone. "
                        "Return only the improved prompt, no quotes or commentary."
                    )
                else:
                    sys_enhance = (
                        "You enhance short still-image prompts for Flux. "
                        "Return only the improved prompt, no quotes or commentary."
                    )
                prompt = await llm_client.chat(
                    model,
                    [
                        {"role": "system", "content": sys_enhance},
                        {"role": "user", "content": prompt},
                    ],
                    temperature=0.6,
                    num_predict=400,
                    timeout=120.0,
                )
        except Exception as e:
            log.warning("prompt enhance skipped: %s", e)

    proj = _ensure_chat_project()

    # Resolve existing still to reuse
    source_rel: str | None = (body.source_image_rel or "").strip() or None
    if body.source_shot_id:
        prev = next((s for s in (proj.timeline.shots or []) if s.id == body.source_shot_id), None)
        if prev and prev.image_path:
            source_rel = prev.image_path

    shot = Shot(
        label=f"Chat {kind}",
        start=0.0,
        duration=float(body.duration_sec or 5.0),
        image=ImageSettings(
            positive_prompt=prompt if kind == "image" else (body.image_prompt or ""),
            negative_prompt=body.negative or "",
            width=int(body.width or 1024),
            height=int(body.height or 576),
            model_id=settings.default_image_model,
        ),
        video=VideoSettings(
            animation_prompt=(body.motion_prompt or body.prompt or prompt) if kind == "video" else "",
            duration_sec=float(body.duration_sec or 5.0),
            preset_id=body.video_preset or "minimax-h3-i2v-turbo",
            width=int(body.width or 768),
            height=int(body.height or 432),
            quality="draft",
        ),
    )
    if source_rel and kind == "video":
        try:
            fixed_rel, _ap = _resolve_chat_source_image(proj, source_rel)
        except HTTPException:
            raise
        except Exception as e:
            raise HTTPException(400, f"Source image not found: {source_rel} ({e})") from e
        shot.image_path = fixed_rel
        shot.image_status = GenStatus.uploaded

    # Keep last few chat generations only
    proj.timeline.shots = (proj.timeline.shots or [])[-8:]
    proj.timeline.shots.append(shot)
    project_store.save_project(proj, merge_media=False)

    if kind == "image":
        shot.image_status = GenStatus.queued
        project_store.save_project(proj, merge_media=False)
        job = await job_manager.enqueue_image(proj.id, shot.id, shot.image)
        return {
            "job_id": job.id,
            "project_id": proj.id,
            "shot_id": shot.id,
            "kind": "image",
            "status": job.status,
            "message": "Queued image generation in ComfyUI…",
        }

    # video with existing still — animate only
    if shot.image_path:
        shot.video_status = GenStatus.queued
        project_store.save_project(proj, merge_media=False)
        job = await job_manager.enqueue_video(proj.id, shot.id, shot.video)
        return {
            "job_id": job.id,
            "project_id": proj.id,
            "shot_id": shot.id,
            "kind": "video",
            "status": job.status,
            "message": "Queued video from your image (no new still)…",
            "reused_image": True,
            "image_path": shot.image_path,
        }

    # no source image — generate still first
    still = (body.image_prompt or prompt).strip()
    if not still:
        raise HTTPException(400, "Need an attached image, or image_prompt, to make a video.")
    shot.image.positive_prompt = still
    shot.image_status = GenStatus.queued
    project_store.save_project(proj, merge_media=False)
    img_job = await job_manager.enqueue_image(proj.id, shot.id, shot.image)
    return {
        "job_id": img_job.id,
        "project_id": proj.id,
        "shot_id": shot.id,
        "kind": "video",
        "needs_image_first": True,
        "status": img_job.status,
        "message": "Step 1/2: generating still image, then will animate…",
        "pending_video": True,
    }


@app.post("/api/chat/media/{project_id}/shots/{shot_id}/continue-video")
async def api_chat_continue_video(project_id: str, shot_id: str) -> dict[str, Any]:
    """After chat image job finishes, queue video for the same shot."""
    if not await comfy.is_online():
        raise HTTPException(503, "ComfyUI is offline.")
    proj = project_store.load_project(project_id)
    shot = next((s for s in proj.timeline.shots if s.id == shot_id), None)
    if not shot:
        raise HTTPException(404, "Shot not found")
    if not shot.image_path:
        raise HTTPException(400, "Image not ready yet")
    shot.video_status = GenStatus.queued
    project_store.save_project(proj, merge_media=False)
    job = await job_manager.enqueue_video(project_id, shot_id, shot.video)
    return {
        "job_id": job.id,
        "project_id": project_id,
        "shot_id": shot_id,
        "kind": "video",
        "status": job.status,
        "message": "Step 2/2: animating image to video…",
    }


@app.post("/api/projects/{project_id}/story/generate")
async def api_story_generate(project_id: str, body: StoryGenerateRequest):
    """
    Multi-agent LLM: planner → writer → editor.
    Streams NDJSON progress events so the UI can show activity / model snippets.
    Final event: {"type":"done", ...} or {"type":"error","error":"..."}.
    """
    if not await llm_client.ollama_online():
        raise HTTPException(503, "Ollama is offline. Start Ollama and ensure models are pulled.")

    try:
        proj_pre = project_store.load_project(project_id)
        if (body.idea or "").strip():
            proj_pre.story.idea = body.idea
        if (body.lyrics or "").strip():
            proj_pre.story.lyrics = body.lyrics
        proj_pre.story.use_story = body.use_story
        proj_pre.story.use_lyrics = body.use_lyrics
        if body.style_id:
            proj_pre.story.style_template = body.style_id
        if body.slot_duration:
            proj_pre.story.slot_duration = float(body.slot_duration)
        project_store.save_project(proj_pre)
    except Exception as e:
        log.warning("pre-generate story save failed: %s", e)

    proj = project_store.load_project(project_id)
    song_dur = float(proj.audio.duration or 0)
    slot = float(body.slot_duration or settings.default_slot or 5.0)
    if song_dur <= 0:
        if not body.scene_count:
            raise HTTPException(400, "Upload audio first (or pass scene_count).")
        song_dur = body.scene_count * slot
    scene_count = body.scene_count
    if not scene_count:
        scene_count = max(1, int(math.ceil(song_dur / slot)))
    chars: list[Any] = list(body.character_names or [])
    if not chars:
        # Only explicit cast-category refs — never treat location/style as cast,
        # and never invent cast from an empty selection.
        chars = [
            {
                "name": r.name.strip(),
                "description": (getattr(r, "description", None) or r.notes or "").strip(),
            }
            for r in (proj.references or [])
            if (r.name or "").strip()
            and (getattr(r, "category", None) or "character").strip().lower() == "character"
        ]

    track_title = (
        (proj.name or "").strip()
        or (Path(proj.audio.filename or "").stem if proj.audio and proj.audio.filename else "")
        or "Untitled Track"
    )
    # Strip common file noise
    for suffix in (" (2)", " (1)", "_"):
        if track_title.endswith(suffix):
            track_title = track_title[: -len(suffix)].strip()

    queue: asyncio.Queue = asyncio.Queue()

    def on_prog(msg: str, p: float, detail: str = "") -> None:
        try:
            queue.put_nowait(
                {
                    "type": "status",
                    "message": msg,
                    "progress": float(p or 0),
                    "detail": (detail or "")[:1200],
                }
            )
        except Exception:
            pass

    async def worker() -> None:
        try:
            # Story runs on Ollama. If Comfy still holds Flux/MiniMax/ACE in VRAM
            # (e.g. 22GB vs ~12GB idle), the LLM crawls or swaps. Unload first.
            on_prog("Freeing GPU for story (unload Comfy models)…", 0.02)
            try:
                if await comfy.is_online():
                    await comfy.free_memory(unload_models=True, free_memory=True)
                    await asyncio.sleep(1.0)
                    await comfy.free_memory(unload_models=True, free_memory=True)
                    await asyncio.sleep(0.5)
            except Exception as free_err:
                log.warning("pre-story free_memory: %s", free_err)

            # Model priority: request body → user Settings story models → chat model → defaults
            user_s = app_settings_store.load_user_settings()
            chat_m = (user_s.get("chat_model") or "").strip()
            planner_m = (
                (body.planner_model or "").strip()
                or (user_s.get("story_planner_model") or "").strip()
                or chat_m
                or None
            )
            writer_m = (
                (body.writer_model or "").strip()
                or (user_s.get("story_writer_model") or "").strip()
                or chat_m
                or None
            )
            editor_m = (
                (body.editor_model or "").strip()
                or (user_s.get("story_editor_model") or "").strip()
                or chat_m
                or None
            )
            log.info(
                "Story models resolved planner=%s writer=%s editor=%s (body p/w/e=%s/%s/%s)",
                planner_m,
                writer_m,
                editor_m,
                body.planner_model,
                body.writer_model,
                body.editor_model,
            )
            result = await story_pipeline.run_story_pipeline(
                idea=body.idea,
                lyrics=body.lyrics,
                use_story=body.use_story,
                use_lyrics=body.use_lyrics,
                style_id=body.style_id or "standard",
                style_prefix=getattr(body, "style_prefix", "") or "",
                character_names=chars,
                scene_count=int(scene_count),
                slot_duration=slot,
                song_duration=song_dur,
                planner_model=planner_m,
                writer_model=writer_m,
                editor_model=editor_m,
                on_progress=on_prog,
            )
            proj2 = project_store.load_project(project_id)
            # Title poster only for music projects — film/story uses full LLM scene list
            is_film = (getattr(proj2, "kind", None) or "music").strip().lower() == "film"
            proj2 = story_pipeline.apply_scenes_to_project(
                proj2,
                result["scenes"],
                slot_duration=slot,
                song_duration=float(proj2.audio.duration or song_dur),
                story_summary=result.get("story_summary") or "",
                style_id=result.get("style_id") or body.style_id,
                idea=body.idea,
                lyrics=body.lyrics,
                track_title=track_title,
                # No forced title poster — LLM fills all scenes from the story
                include_title_card=False,
                preserve_media=bool(getattr(body, "preserve_media", False)),
            )
            proj2.story.use_story = body.use_story
            proj2.story.use_lyrics = body.use_lyrics
            proj2.story.planner_model = (result.get("models_used") or {}).get("planner", "")
            proj2.story.writer_model = (result.get("models_used") or {}).get("writer", "")
            proj2.story.editor_model = (result.get("models_used") or {}).get("editor", "")
            # Bind refs from names that appear in each shot's prompt (and drop dead IDs).
            from .job_manager import _name_in_prompt_exact, _names_equivalent

            refs_list = [r for r in proj2.references if (r.name or "").strip()]
            valid = {r.id for r in refs_list}
            for shot in proj2.timeline.shots:
                if not shot.image:
                    continue
                no_char_refs = bool(getattr(shot.image, "strict_named_characters_only", False))
                if no_char_refs:
                    keep = []
                    for rid in shot.image.reference_ids or []:
                        r = next((x for x in refs_list if x.id == rid), None)
                        if not r:
                            continue
                        cat = (getattr(r, "category", None) or "character").strip().lower()
                        if cat in ("location", "environment", "style"):
                            keep.append(rid)
                    shot.image.reference_ids = keep[:6]
                    continue
                prompt = shot.image.positive_prompt or ""
                ids = []
                for r in sorted(refs_list, key=lambda x: len((x.name or "").strip()), reverse=True):
                    name = (r.name or "").strip()
                    if not name:
                        continue
                    if _name_in_prompt_exact(name, prompt) or any(
                        _names_equivalent(name, tok)
                        for tok in prompt.replace(",", " ").replace(".", " ").split()
                        if len(tok) >= 3
                    ):
                        if r.id not in ids:
                            ids.append(r.id)
                # Prefer name-in-prompt match; keep valid pre-set chips only if still named
                if ids:
                    shot.image.reference_ids = ids[:6]
                else:
                    shot.image.reference_ids = [
                        i for i in (shot.image.reference_ids or []) if i in valid
                    ][:6]
            project_store.save_project(proj2, merge_media=False)
            await queue.put(
                {
                    "type": "done",
                    "project": proj2.model_dump(),
                    "story_summary": result.get("story_summary"),
                    "scene_count": len(proj2.timeline.shots),
                    "models_used": result.get("models_used"),
                    "issues_fixed": result.get("issues_fixed") or [],
                    "message": "Complete",
                    "progress": 1.0,
                }
            )
        except Exception as e:
            log.error("Story generate failed: %s\n%s", e, traceback.format_exc())
            await queue.put({"type": "error", "error": str(e), "message": str(e), "progress": 0})
        finally:
            await queue.put(None)

    async def event_stream():
        task = asyncio.create_task(worker())
        yield json.dumps({"type": "status", "message": "Starting story pipeline…", "progress": 0.01, "detail": ""}) + "\n"
        while True:
            item = await queue.get()
            if item is None:
                break
            yield json.dumps(item, default=str) + "\n"
        await task

    return StreamingResponse(event_stream(), media_type="application/x-ndjson")


@app.delete("/api/projects/{project_id}/shots/{shot_id}/video")
async def api_clear_shot_video(project_id: str, shot_id: str) -> Project:
    """Detach video from a shot (keeps the still image)."""
    proj = project_store.load_project(project_id)
    shot = next((s for s in proj.timeline.shots if s.id == shot_id), None)
    if not shot:
        raise HTTPException(404, "Shot not found")
    shot.video_path = None
    shot.draft_video_path = None
    shot.video_alternatives = []
    shot.video_status = GenStatus.empty
    shot.last_error = None
    return project_store.save_project(proj, merge_media=False)


@app.delete("/api/projects/{project_id}/shots/{shot_id}/image")
async def api_clear_shot_image(project_id: str, shot_id: str) -> Project:
    """Detach still image (and video) from a shot."""
    proj = project_store.load_project(project_id)
    shot = next((s for s in proj.timeline.shots if s.id == shot_id), None)
    if not shot:
        raise HTTPException(404, "Shot not found")
    shot.image_path = None
    shot.image_alternatives = []
    shot.thumbnail_path = None
    shot.image_status = GenStatus.empty
    shot.video_path = None
    shot.draft_video_path = None
    shot.video_alternatives = []
    shot.video_status = GenStatus.empty
    shot.last_error = None
    return project_store.save_project(proj, merge_media=False)


@app.get("/api/jobs")
async def api_jobs(project_id: Optional[str] = None) -> list[dict[str, Any]]:
    return job_manager.list_jobs(project_id)


@app.get("/api/jobs/{job_id}")
async def api_job(job_id: str) -> dict[str, Any]:
    j = job_manager.get(job_id)
    if not j:
        raise HTTPException(404, "Job not found")
    return j.__dict__


@app.post("/api/jobs/{job_id}/cancel")
async def api_cancel_job(job_id: str) -> dict[str, str]:
    job_manager.cancel(job_id)
    return {"status": "cancelled"}


# ---------- References ----------


@app.post("/api/projects/{project_id}/references")
async def api_add_reference(
    project_id: str,
    file: UploadFile = File(...),
    name: str = Form(""),
    category: str = Form("other"),
    notes: str = Form(""),
    description: str = Form(""),
    save_to_library: str = Form("1"),
) -> Project:
    """Add a project reference image. By default also copies characters into the shared Character Manager."""
    proj = project_store.load_project(project_id)
    suffix = Path(file.filename or "ref.png").suffix.lower() or ".png"
    rid = new_id("ref_")
    dest = project_store.project_dir(project_id) / "references" / f"{rid}{suffix}"
    dest.parent.mkdir(parents=True, exist_ok=True)
    raw = await file.read()
    dest.write_bytes(raw)
    desc = (description or notes or "").strip()
    ref_name = (name or file.filename or rid).strip()
    cat = (category or "other").strip().lower() or "other"
    item = ReferenceItem(
        id=rid,
        name=ref_name,
        category=cat,  # type: ignore
        path=project_store.rel_to_project(project_id, dest),
        notes=notes or desc,
        description=desc,
    )
    proj.references.append(item)
    # Persist to shared character library so Character Manager stays in sync
    want_lib = str(save_to_library or "1").strip().lower() not in ("0", "false", "no", "off")
    if want_lib and cat in ("character", "location", "style", "clothing", "object", "other"):
        try:
            # Skip if same name already in library
            existing = [
                c
                for c in character_library.list_characters()
                if (c.get("name") or "").strip().lower() == ref_name.lower()
            ]
            if not existing:
                character_library.add_character(
                    name=ref_name,
                    category=cat if cat in ("character", "location", "style", "other") else "character",
                    description=desc,
                    image_bytes=raw,
                    image_suffix=suffix,
                )
        except Exception as e:
            log.warning("save ref to character library failed: %s", e)
    return project_store.save_project(proj)


@app.patch("/api/projects/{project_id}/references/{ref_id}")
async def api_patch_reference(
    project_id: str,
    ref_id: str,
    name: Optional[str] = Form(None),
    category: Optional[str] = Form(None),
    description: Optional[str] = Form(None),
    notes: Optional[str] = Form(None),
) -> Project:
    proj = project_store.load_project(project_id)
    for r in proj.references:
        if r.id != ref_id:
            continue
        if name is not None:
            r.name = name
        if category is not None:
            r.category = category  # type: ignore
        if description is not None:
            r.description = description
        if notes is not None:
            r.notes = notes
        break
    else:
        raise HTTPException(404, "Reference not found")
    return project_store.save_project(proj)


@app.delete("/api/projects/{project_id}/references/{ref_id}")
async def api_del_reference(project_id: str, ref_id: str) -> Project:
    proj = project_store.load_project(project_id)
    removed = next((r for r in proj.references if r.id == ref_id), None)
    # Delete image file on disk
    if removed and removed.path:
        try:
            p = project_store.project_dir(project_id) / removed.path
            if p.is_file():
                p.unlink(missing_ok=True)
        except Exception:
            pass
    proj.references = [r for r in proj.references if r.id != ref_id]
    # Scrub dead IDs from every shot so gen never reuses a deleted cast member
    for shot in proj.timeline.shots or []:
        if shot.image and shot.image.reference_ids:
            shot.image.reference_ids = [i for i in shot.image.reference_ids if i != ref_id]
    return project_store.save_project(proj)


# ---------- LoRA ----------


@app.get("/api/loras")
async def api_local_loras() -> list[dict[str, Any]]:
    return lora_manager.list_local_loras()


@app.post("/api/loras/search")
async def api_search_loras(body: LoraSearchRequest) -> list[dict[str, Any]]:
    try:
        return lora_manager.search_huggingface_loras(body.query, body.base_model, body.limit)
    except Exception as e:
        log.error("LoRA search failed: %s", e)
        raise HTTPException(500, str(e))


@app.post("/api/loras/download")
async def api_download_lora(repo_id: str = Form(...), filename: str = Form(None)) -> dict[str, Any]:
    try:
        result = lora_manager.download_lora(repo_id, filename or None)
        refresh = await lora_manager.refresh_comfyui_if_possible()
        result["comfyui"] = refresh
        return result
    except Exception as e:
        raise HTTPException(500, str(e))


@app.post("/api/loras/import")
async def api_import_lora(body: ImportLoraRequest) -> dict[str, Any]:
    try:
        result = lora_manager.import_lora_file(body.source_path, body.name)
        refresh = await lora_manager.refresh_comfyui_if_possible()
        result["comfyui"] = refresh
        return result
    except Exception as e:
        raise HTTPException(500, str(e))


@app.post("/api/loras/upload")
async def api_upload_lora(file: UploadFile = File(...)) -> dict[str, Any]:
    """Upload a LoRA file from the browser into ComfyUI/models/loras."""
    dest_root = lora_manager.lora_dir()
    dest_root.mkdir(parents=True, exist_ok=True)
    name = Path(file.filename or "lora.safetensors").name
    dest = dest_root / name
    dest.write_bytes(await file.read())
    refresh = await lora_manager.refresh_comfyui_if_possible()
    return {
        "name": name,
        "path": str(dest),
        "size_mb": round(dest.stat().st_size / (1024 * 1024), 1),
        "comfyui": refresh,
    }


@app.post("/api/loras/refresh")
async def api_refresh_loras() -> dict[str, Any]:
    return await lora_manager.refresh_comfyui_if_possible()


# ---------- Subtitles ----------


@app.post("/api/projects/{project_id}/subtitles")
async def api_upload_srt(project_id: str, file: UploadFile = File(...)) -> Project:
    proj = project_store.load_project(project_id)
    dest = project_store.project_dir(project_id) / "subtitles" / "captions.srt"
    dest.parent.mkdir(parents=True, exist_ok=True)
    dest.write_bytes(await file.read())
    proj.subtitles.enabled = True
    proj.subtitles.srt_path = project_store.rel_to_project(project_id, dest)
    return project_store.save_project(proj)


# ---------- Export ----------


@app.post("/api/projects/{project_id}/export")
async def api_export(project_id: str, background_tasks: BackgroundTasks) -> dict[str, Any]:
    proj = project_store.load_project(project_id)
    try:
        path = export_ffmpeg.export_project(proj)
        rel = project_store.rel_to_project(project_id, path)
        return {"status": "done", "path": rel, "url": f"/api/projects/{project_id}/files/{rel}"}
    except Exception as e:
        log.error("Export failed: %s\n%s", e, traceback.format_exc())
        raise HTTPException(500, str(e))


# ---------- Music generation (ACE-Step 1.5) ----------


@app.get("/api/music/defaults")
async def api_music_defaults() -> dict[str, Any]:
    return {
        "tags": music_store.DEFAULT_TAGS,
        "caption": music_store.DEFAULT_MINIMAX_CAPTION,
        "lyrics": music_store.DEFAULT_LYRICS,
        "duration_sec": 30,
        "bpm": 120,
        "keyscale": "E minor",
        "language": "en",
        "steps": 8,
        "generate_audio_codes": False,
        "lora_strength": 0.75,
        "engine": "ace",
        "engines": {
            "ace": {"label": "ACE-Step", "max_duration_sec": 240, "style_field": "tags"},
            "minimax": {
                "label": "MiniMax Music 3",
                "max_duration_sec": 300,
                "style_field": "caption",
            },
        },
    }


@app.get("/api/music/loras")
async def api_music_loras() -> dict[str, Any]:
    """List ComfyUI loras suitable for ACE Music Gen style selection."""
    try:
        loras = await music_pipeline.list_ace_loras()
    except Exception as e:
        log.warning("list ACE loras failed: %s", e)
        loras = []
    return {"loras": loras}


@app.post("/api/music/upload-reference")
async def api_music_upload_reference(file: UploadFile = File(...)) -> dict[str, Any]:
    """Upload a short ACE timbre-reference clip into ComfyUI/input/fenix_ref/."""
    if not await comfy.is_online():
        raise HTTPException(503, "ComfyUI is offline.")
    raw_name = (file.filename or "reference.mp3").strip() or "reference.mp3"
    suffix = Path(raw_name).suffix.lower() or ".mp3"
    if suffix not in {".mp3", ".wav", ".flac", ".ogg", ".opus", ".m4a", ".aac"}:
        raise HTTPException(400, "Reference audio must be mp3/wav/flac/ogg/opus/m4a.")
    tmp = Path(settings.cache_dir) / "music_tmp" / f"ref_{new_id('aud')}{suffix}"
    tmp.parent.mkdir(parents=True, exist_ok=True)
    try:
        data = await file.read()
        if not data or len(data) < 256:
            raise HTTPException(400, "Reference file is empty or too small.")
        tmp.write_bytes(data)
        uploaded = await comfy.upload_audio(tmp, subfolder="fenix_ref", overwrite=True)
        name = str(uploaded.get("name") or tmp.name)
        sub = str(uploaded.get("subfolder") or "fenix_ref").strip().strip("/\\")
        # LoadAudio expects "subfolder/filename" when nested under input/
        comfy_name = f"{sub}/{name}" if sub else name
        comfy_name = comfy_name.replace("\\", "/")
        return {
            "name": comfy_name,
            "filename": name,
            "subfolder": sub,
            "bytes": len(data),
        }
    except HTTPException:
        raise
    except Exception as e:
        log.error("music reference upload failed: %s", e)
        raise HTTPException(500, str(e)) from e
    finally:
        try:
            tmp.unlink(missing_ok=True)
        except Exception:
            pass


@app.get("/api/music/status")
async def api_music_status() -> dict[str, Any]:
    online = await comfy.is_online()
    ace_ok = False
    minimax_ok = False
    ace_detail = ""
    minimax_detail = ""
    lora_count = 0
    if online:
        try:
            await music_pipeline.resolve_ace_models()
            ace_ok = True
            ace_detail = "ACE-Step 1.5 models ready"
            try:
                lora_count = len(await music_pipeline.list_ace_loras())
            except Exception:
                pass
        except Exception as e:
            ace_detail = str(e)
        try:
            await music_pipeline.resolve_minimax_music_models()
            minimax_ok = True
            minimax_detail = "MiniMax Music 3 models ready"
        except Exception as e:
            minimax_detail = str(e)
        detail = "; ".join(x for x in (ace_detail, minimax_detail) if x)
    else:
        detail = "ComfyUI offline"
        ace_detail = detail
        minimax_detail = detail
    return {
        "comfy_online": online,
        "ace_ready": ace_ok,
        "minimax_ready": minimax_ok,
        "detail": detail,
        "ace_detail": ace_detail,
        "minimax_detail": minimax_detail,
        "lora_count": lora_count,
    }


@app.get("/api/music/tracks")
async def api_music_tracks() -> list[dict[str, Any]]:
    return music_store.list_tracks()


@app.get("/api/music/tracks/{track_id}")
async def api_music_track(track_id: str) -> dict[str, Any]:
    t = music_store.get_track(track_id)
    if not t:
        raise HTTPException(404, "Track not found")
    return t


@app.get("/api/music/tracks/{track_id}/audio")
async def api_music_track_audio(track_id: str):
    t = music_store.get_track(track_id)
    if not t:
        raise HTTPException(404, "Track not found")
    p = music_store.abs_audio_path(t.get("path") or "")
    if not p:
        raise HTTPException(404, "Audio file missing")
    return FileResponse(p, filename=p.name)


@app.delete("/api/music/tracks/{track_id}")
async def api_music_delete(track_id: str) -> dict[str, str]:
    if not music_store.delete_track(track_id):
        raise HTTPException(404, "Track not found")
    return {"status": "deleted"}


@app.patch("/api/music/tracks/{track_id}")
async def api_music_rename(track_id: str, body: dict[str, Any]) -> dict[str, Any]:
    """Rename a library track (display title only)."""
    title = (body or {}).get("title")
    if title is None or not str(title).strip():
        raise HTTPException(400, "Provide a non-empty title")
    try:
        t = music_store.rename_track(track_id, str(title))
    except ValueError as e:
        raise HTTPException(400, str(e)) from e
    if not t:
        raise HTTPException(404, "Track not found")
    return t


@app.post("/api/music/generate")
async def api_music_generate(body: MusicGenerateRequest) -> dict[str, Any]:
    """Run ACE-Step 1.5 or MiniMax Music 3 in ComfyUI; optionally save to the library."""
    if not await comfy.is_online():
        raise HTTPException(503, "ComfyUI is offline. Start ComfyUI with music models installed.")

    engine = (body.engine or "ace").strip().lower()
    if engine not in ("ace", "minimax"):
        raise HTTPException(400, "engine must be 'ace' or 'minimax'")

    title = (body.title or "Untitled Track").strip() or "Untitled Track"
    # Use client lyrics as-is when provided (empty = instrumental); demo only if omitted
    lyrics = body.lyrics if body.lyrics is not None else music_store.DEFAULT_LYRICS
    lyrics = str(lyrics or "")
    prefix = f"audio/fenix_{new_id('trk')}"
    lora_name = ""
    tags = ""
    caption = ""
    # Resolve seed here so we can save/return the exact value used (-1 → random)
    import random as _random

    try:
        used_seed = int(body.seed) if body.seed is not None else -1
    except (TypeError, ValueError):
        used_seed = -1
    if used_seed < 0:
        used_seed = _random.randint(0, 2**32 - 1)

    try:
        if engine == "minimax":
            try:
                await music_pipeline.resolve_minimax_music_models()
            except Exception as e:
                raise HTTPException(400, str(e)) from e
            caption = (body.caption or "").strip() or music_store.DEFAULT_MINIMAX_CAPTION
            tags = (body.tags or "").strip()  # kept for library display if sent
            audio_path = await music_pipeline.run_minimax_generation(
                caption=caption,
                lyrics=lyrics,
                duration_sec=body.duration_sec,
                seed=used_seed,
                filename_prefix=prefix,
                timeout_sec=45 * 60,
            )
        else:
            try:
                await music_pipeline.resolve_ace_models()
            except Exception as e:
                raise HTTPException(400, str(e)) from e
            tags = (body.tags or music_store.DEFAULT_TAGS).strip()
            codes = body.generate_audio_codes is True
            lora_name = (body.lora_name or "").strip()
            lora_strength = float(
                body.lora_strength if body.lora_strength is not None else 0.75
            )
            ref_audio = (getattr(body, "reference_audio", None) or "").strip()
            audio_path = await music_pipeline.run_ace_generation(
                tags=tags,
                lyrics=lyrics,
                duration_sec=body.duration_sec,
                bpm=body.bpm,
                seed=used_seed,
                keyscale=body.keyscale,
                language=body.language,
                timesignature=body.timesignature or "4",
                steps=body.steps,
                filename_prefix=prefix,
                generate_audio_codes=codes,
                cfg_scale=float(getattr(body, "cfg_scale", 2.0) or 2.0),
                temperature=float(getattr(body, "temperature", 0.85) or 0.85),
                top_p=float(getattr(body, "top_p", 0.9) or 0.9),
                top_k=int(getattr(body, "top_k", 0) or 0),
                min_p=float(getattr(body, "min_p", 0.0) or 0.0),
                lora_name=lora_name,
                lora_strength=lora_strength,
                reference_audio=ref_audio,
                timeout_sec=45 * 60,
            )
    except HTTPException:
        raise
    except Exception as e:
        log.error("Music generate failed: %s\n%s", e, traceback.format_exc())
        raise HTTPException(500, str(e))

    track = None
    if body.save:
        track = music_store.add_track(
            title=title,
            tags=tags or caption,
            caption=caption,
            lyrics=lyrics,
            duration_sec=float(body.duration_sec or 0),
            bpm=int(body.bpm or 120),
            keyscale=body.keyscale or "E minor",
            source_path=audio_path,
            engine=engine,
            seed=used_seed,
        )
    return {
        "status": "done",
        "engine": engine,
        "seed": used_seed,
        "track": track,
        "temp_path": str(audio_path),
        "audio_url": f"/api/music/tracks/{track['id']}/audio" if track else None,
        "lora_name": lora_name or None,
    }


# ---------- ACE style LoRA training (Music Gen → Train tab) ----------


@app.get("/api/music/train/capability")
async def api_music_train_capability() -> dict[str, Any]:
    return await music_train.detect_train_capability()


@app.get("/api/music/train/jobs")
async def api_music_train_jobs() -> dict[str, Any]:
    return {"jobs": music_train_store.list_jobs()}


@app.post("/api/music/train/jobs")
async def api_music_train_create(body: MusicTrainCreate) -> dict[str, Any]:
    job = music_train_store.create_job(
        name=body.name,
        tags=body.tags,
        epochs=body.epochs,
        rank=body.rank,
        learning_rate=body.learning_rate,
    )
    return {"job": job}


@app.get("/api/music/train/jobs/{job_id}")
async def api_music_train_get(job_id: str) -> dict[str, Any]:
    job = music_train_store.get_job(job_id)
    if not job:
        raise HTTPException(404, "Train job not found")
    return job


@app.post("/api/music/train/jobs/{job_id}/clips")
async def api_music_train_add_clip(job_id: str, file: UploadFile = File(...)) -> dict[str, Any]:
    if not music_train_store.get_job(job_id):
        raise HTTPException(404, "Train job not found")
    data = await file.read()
    if len(data) < 1024:
        raise HTTPException(400, "File too small")
    if len(data) > 80 * 1024 * 1024:
        raise HTTPException(400, "Clip too large (max 80MB each)")
    try:
        job = music_train_store.add_clip(job_id, file.filename or "clip.mp3", data)
    except FileNotFoundError:
        raise HTTPException(404, "Train job not found")
    return {"job": job}


@app.post("/api/music/train/jobs/{job_id}/clear-clips")
async def api_music_train_clear(job_id: str) -> dict[str, Any]:
    try:
        job = music_train_store.clear_clips(job_id)
    except FileNotFoundError:
        raise HTTPException(404, "Train job not found")
    return {"job": job}


@app.post("/api/music/train/jobs/{job_id}/start")
async def api_music_train_start(job_id: str, body: MusicTrainCreate | None = None) -> dict[str, Any]:
    if not music_train_store.get_job(job_id):
        raise HTTPException(404, "Train job not found")
    if body is not None:
        try:
            music_train_store.patch_job(
                job_id,
                {
                    "name": body.name,
                    "tags": body.tags,
                    "epochs": body.epochs,
                    "rank": body.rank,
                    "learning_rate": body.learning_rate,
                },
            )
        except FileNotFoundError:
            raise HTTPException(404, "Train job not found")
    try:
        job = await music_train.start_training(job_id)
    except FileNotFoundError:
        raise HTTPException(404, "Train job not found")
    except ValueError as e:
        raise HTTPException(400, str(e))
    return {"job": job}


@app.delete("/api/music/train/jobs/{job_id}")
async def api_music_train_delete(job_id: str) -> dict[str, str]:
    if not music_train_store.delete_job(job_id):
        raise HTTPException(404, "Train job not found")
    return {"status": "deleted"}


# ---------- Live activity + emergency stop ----------

@app.get("/api/gen-activity")
async def api_gen_activity() -> dict[str, Any]:
    return get_activity()


class EmergencyStopRequest(BaseModel):
    reason: str = Field(default="", max_length=500)


@app.post("/api/emergency-stop")
async def api_emergency_stop(body: EmergencyStopRequest | None = None) -> dict[str, Any]:
    """Interrupt Comfy, clear its queue, cancel studio jobs, free VRAM."""
    reason = ((body.reason if body else "") or "").strip()
    if reason:
        log.warning("EMERGENCY STOP — reason: %s", reason[:500])
    else:
        log.warning("EMERGENCY STOP — (no reason given)")
    set_activity(
        "EMERGENCY STOP — interrupting…" + (f" ({reason[:60]})" if reason else ""),
        source="emergency",
        busy=True,
    )
    errors: list[str] = []
    cancelled = 0
    # 1) Flag Fenix jobs cancelled first so wait loops abort (no timeout-retry)
    try:
        cancelled = job_manager.cancel_all()
    except Exception as e:
        errors.append(f"jobs: {e}")
    # 2) Stop running Comfy work + wipe pending queue
    try:
        await comfy.emergency_halt()
    except Exception as e:
        errors.append(f"comfy halt: {e}")
        try:
            await comfy.interrupt()
        except Exception as e2:
            errors.append(f"comfy interrupt: {e2}")
    try:
        await asyncio.sleep(0.4)
        await comfy.free_memory(unload_models=True, free_memory=True)
        await asyncio.sleep(0.6)
        await comfy.free_memory(unload_models=True, free_memory=True)
    except Exception as e:
        errors.append(f"free: {e}")
    clear_activity("Emergency stop complete — VRAM cleared")
    log.info(
        "EMERGENCY STOP complete — cancelled_jobs=%s reason=%r errors=%s",
        cancelled,
        reason or None,
        errors or None,
    )
    return {
        "status": "stopped",
        "cancelled_jobs": cancelled,
        "reason": reason or None,
        "errors": errors,
        "note": (
            "Comfy interrupted, queue cleared, VRAM free requested. "
            "In-flight Ollama chat may finish its current token batch."
        ),
    }


# ---------- Image / Video Gen studio (home) ----------

@app.get("/api/studio/status")
async def api_studio_status() -> dict[str, Any]:
    online = await comfy.is_online()
    detail = "ComfyUI ready" if online else "ComfyUI offline"
    return {"comfy_online": online, "detail": detail, "activity": get_activity()}


@app.get("/api/studio/items")
async def api_studio_items(kind: str | None = None) -> list[dict[str, Any]]:
    return studio_store.list_items(kind=kind)


@app.get("/api/studio/items/{item_id}")
async def api_studio_item(item_id: str) -> dict[str, Any]:
    t = studio_store.get_item(item_id)
    if not t:
        raise HTTPException(404, "Item not found")
    return t


@app.get("/api/studio/items/{item_id}/media")
async def api_studio_item_media(item_id: str):
    t = studio_store.get_item(item_id)
    if not t:
        raise HTTPException(404, "Item not found")
    p = studio_store.abs_media_path(t.get("path") or "")
    if not p:
        raise HTTPException(404, "Media file missing")
    return FileResponse(p)


@app.delete("/api/studio/items/{item_id}")
async def api_studio_delete(item_id: str) -> dict[str, str]:
    if not studio_store.delete_item(item_id):
        raise HTTPException(404, "Item not found")
    return {"status": "deleted"}


@app.get("/api/studio/gallery-images")
async def api_studio_gallery_images() -> list[dict[str, Any]]:
    """Aggregated stills: studio + characters + all project shot images."""
    return studio_store.list_aggregated_images()


def _resolve_studio_source_image(source_id: str) -> tuple[Path, str, dict[str, Any]]:
    """Resolve studio / char: / proj: id → (abs_path, title, studio_item_or_meta)."""
    sid = (source_id or "").strip()
    if not sid:
        raise HTTPException(400, "No source image selected.")

    if sid.startswith("char:"):
        cid = sid.split(":", 1)[1]
        ch = character_library.get_character(cid)
        if not ch:
            raise HTTPException(404, "Character not found")
        img = character_library.abs_image_path(ch.get("path") or "")
        if not img:
            raise HTTPException(404, "Character image missing")
        item = studio_store.import_image_file(
            img, title=(ch.get("name") or cid)[:60], prompt=ch.get("description") or ""
        )
        path = studio_store.abs_media_path(item.get("path") or "")
        if not path:
            raise HTTPException(500, "Failed to import character into studio gallery")
        return path, item.get("title") or cid, item

    if sid.startswith("proj:"):
        # proj:{project_id}:{rel/path}
        rest = sid[len("proj:") :]
        if ":" not in rest:
            raise HTTPException(400, "Invalid project image id")
        pid, rel = rest.split(":", 1)
        abs_p = project_store.abs_path(pid, rel)
        if not abs_p or not abs_p.is_file():
            raise HTTPException(404, "Project image missing")
        try:
            pname = project_store.load_project(pid).name
        except Exception:
            pname = pid
        item = studio_store.import_image_file(
            abs_p, title=f"{pname} · {Path(rel).name}"[:60]
        )
        path = studio_store.abs_media_path(item.get("path") or "")
        if not path:
            raise HTTPException(500, "Failed to import project image into studio gallery")
        return path, item.get("title") or rel, item

    src = studio_store.get_item(sid)
    if not src or (src.get("kind") or "") != "image":
        raise HTTPException(400, "Pick an image from the Images gallery tab.")
    img = studio_store.abs_media_path(src.get("path") or "")
    if not img:
        raise HTTPException(400, "Source image file missing from gallery.")
    return img, src.get("title") or sid, src


@app.post("/api/studio/generate/image")
async def api_studio_generate_image(
    prompt: str = Form(""),
    negative_prompt: str = Form(""),
    width: int = Form(0),
    height: int = Form(0),
    seed: int = Form(-1),
    steps: int = Form(0),
    model_id: str = Form("flux2-klein-4b"),
    quality: str = Form("final"),
    batch_count: int = Form(1),
    ref_char_ids: str = Form(""),
    ref_files: list[UploadFile] = File(default=[]),
) -> dict[str, Any]:
    """Studio stills. Optional character refs + uploaded reference images (Flux multi-ref).

    batch_count: queue 1–100 variations sequentially (same prompt/size/refs).
    """
    if not await comfy.is_online():
        raise HTTPException(503, "ComfyUI is offline.")
    if not (prompt or "").strip():
        raise HTTPException(400, "Prompt is required")
    # FastAPI may hand a single UploadFile when only one file is posted
    files_in: list[UploadFile] = []
    if isinstance(ref_files, list):
        files_in = [f for f in ref_files if f is not None]
    elif ref_files is not None:
        files_in = [ref_files]
    ref_paths: list[tuple[Path, str, str]] = []
    tmp_files: list[Path] = []
    try:
        for cid in [x.strip() for x in (ref_char_ids or "").split(",") if x.strip()]:
            ch = character_library.get_character(cid)
            if not ch:
                continue
            img = character_library.abs_image_path(ch.get("path") or "")
            if img:
                ref_paths.append((img, ch.get("name") or cid, ch.get("category") or "character"))
        for uf in files_in:
            if not uf or not (getattr(uf, "filename", None) or "").strip():
                continue
            raw = await uf.read()
            if len(raw) < 64:
                continue
            ext = Path(uf.filename or "ref.png").suffix.lower() or ".png"
            if ext not in {".png", ".jpg", ".jpeg", ".webp", ".bmp"}:
                ext = ".png"
            tmp = Path(settings.cache_dir) / "studio_tmp" / f"ref_{new_id('ref')}{ext}"
            tmp.parent.mkdir(parents=True, exist_ok=True)
            tmp.write_bytes(raw)
            tmp_files.append(tmp)
            ref_paths.append((tmp, Path(uf.filename or "ref").stem[:40], "character"))
        items = await studio_pipeline.generate_studio_image(
            prompt=prompt,
            negative_prompt=negative_prompt or "",
            width=width,
            height=height,
            seed=seed,
            steps=steps,
            model_id=model_id or "flux2-klein-4b",
            quality=quality or "final",
            batch_count=batch_count,
            reference_paths=ref_paths,
        )
    except HTTPException:
        raise
    except Exception as e:
        log.error("Studio image failed: %s\n%s", e, traceback.format_exc())
        raise HTTPException(500, str(e))
    finally:
        for t in tmp_files:
            try:
                t.unlink(missing_ok=True)
            except Exception:
                pass
    if not items:
        raise HTTPException(500, "No images were produced")
    last = items[-1]
    return {
        "status": "done",
        "item": last,
        "items": items,
        "media_url": f"/api/studio/items/{last['id']}/media",
    }


@app.post("/api/studio/generate/video")
async def api_studio_generate_video(
    source_item_id: str = Form(""),
    animation_prompt: str = Form(""),
    duration_sec: float = Form(5.0),
    seed: int = Form(-1),
    quality: str = Form("draft"),
    video_preset: str = Form(""),
    audio: UploadFile | None = File(None),
) -> dict[str, Any]:
    """Gallery / character / project still → video. Multipart for optional LTX audio."""
    if not await comfy.is_online():
        raise HTTPException(503, "ComfyUI is offline.")
    img, _title, src = _resolve_studio_source_image(source_item_id or "")
    audio_tmp: Path | None = None
    try:
        if audio and (audio.filename or "").strip():
            raw_a = await audio.read()
            if len(raw_a) >= 64:
                ext = Path(audio.filename or "clip.wav").suffix.lower() or ".wav"
                if ext not in {".wav", ".mp3", ".flac", ".ogg", ".m4a", ".aac"}:
                    ext = ".wav"
                audio_tmp = Path(settings.cache_dir) / "studio_tmp" / f"audio_{new_id('aud')}{ext}"
                audio_tmp.parent.mkdir(parents=True, exist_ok=True)
                audio_tmp.write_bytes(raw_a)
        item = await studio_pipeline.generate_studio_video(
            image_path=img,
            animation_prompt=animation_prompt or src.get("prompt") or "",
            duration_sec=duration_sec,
            seed=seed,
            parent_id=src.get("id") or "",
            quality=quality or "draft",
            video_preset=video_preset or "",
            audio_path=audio_tmp,
        )
    except Exception as e:
        log.error("Studio video failed: %s\n%s", e, traceback.format_exc())
        raise HTTPException(500, str(e))
    finally:
        if audio_tmp:
            try:
                audio_tmp.unlink(missing_ok=True)
            except Exception:
                pass
    return {
        "status": "done",
        "item": item,
        "media_url": f"/api/studio/items/{item['id']}/media",
    }


@app.post("/api/studio/generate/video-upload")
async def api_studio_generate_video_upload(
    file: UploadFile = File(...),
    animation_prompt: str = Form(""),
    duration_sec: float = Form(5.0),
    seed: int = Form(-1),
    quality: str = Form("draft"),
    video_preset: str = Form(""),
    audio: UploadFile | None = File(None),
) -> dict[str, Any]:
    if not await comfy.is_online():
        raise HTTPException(503, "ComfyUI is offline.")
    raw = await file.read()
    if len(raw) < 200:
        raise HTTPException(400, "Empty or invalid image upload")
    # Keep original suffix — writing JPEG bytes as .png broke some LoadImage paths
    ext = Path(file.filename or "frame.png").suffix.lower() or ".png"
    if ext not in {".png", ".jpg", ".jpeg", ".webp", ".bmp"}:
        ext = ".png"
    tmp = Path(settings.cache_dir) / "studio_tmp" / f"upload_{new_id('up')}{ext}"
    tmp.parent.mkdir(parents=True, exist_ok=True)
    tmp.write_bytes(raw)
    audio_tmp: Path | None = None
    # Also keep in gallery as source still
    try:
        src_item = studio_store.add_item(
            kind="image",
            title=(file.filename or "upload")[:60],
            prompt=animation_prompt or "",
            source_path=tmp,
        )
        parent_id = src_item.get("id") or ""
        img_path = studio_store.abs_media_path(src_item.get("path") or "") or tmp
    except Exception as e:
        log.warning("studio upload gallery import failed: %s", e)
        parent_id = ""
        img_path = tmp
    try:
        if audio and (audio.filename or "").strip():
            raw_a = await audio.read()
            if len(raw_a) >= 64:
                ext = Path(audio.filename or "clip.wav").suffix.lower() or ".wav"
                if ext not in {".wav", ".mp3", ".flac", ".ogg", ".m4a", ".aac"}:
                    ext = ".wav"
                audio_tmp = Path(settings.cache_dir) / "studio_tmp" / f"audio_{new_id('aud')}{ext}"
                audio_tmp.parent.mkdir(parents=True, exist_ok=True)
                audio_tmp.write_bytes(raw_a)
        item = await studio_pipeline.generate_studio_video(
            image_path=img_path,
            animation_prompt=animation_prompt or "",
            duration_sec=duration_sec,
            seed=seed,
            parent_id=parent_id,
            quality=quality or "draft",
            video_preset=video_preset or "",
            audio_path=audio_tmp,
        )
    except Exception as e:
        log.error("Studio video-upload failed: %s\n%s", e, traceback.format_exc())
        raise HTTPException(500, str(e))
    finally:
        try:
            tmp.unlink(missing_ok=True)
        except Exception:
            pass
        if audio_tmp:
            try:
                audio_tmp.unlink(missing_ok=True)
            except Exception:
                pass
    return {
        "status": "done",
        "item": item,
        "media_url": f"/api/studio/items/{item['id']}/media",
        "source_item_id": parent_id or None,
    }


# ---------- Static assets ----------

CHAT_AVATAR_DIR = ROOT / "backend" / "chatavatar"
if CHAT_AVATAR_DIR.exists():
    app.mount(
        "/chatavatar",
        StaticFiles(directory=str(CHAT_AVATAR_DIR)),
        name="chatavatar",
    )

DAW_DIR = ROOT / "daw"
if DAW_DIR.exists():
    app.mount(
        "/daw",
        StaticFiles(directory=str(DAW_DIR), html=True),
        name="daw",
    )

IMAGE_EDITOR_DIR = ROOT / "image-editor"
if IMAGE_EDITOR_DIR.exists():
    app.mount(
        "/image-editor",
        StaticFiles(directory=str(IMAGE_EDITOR_DIR), html=True),
        name="image-editor",
    )

if FRONTEND.exists():
    app.mount("/", StaticFiles(directory=str(FRONTEND), html=True), name="frontend")


def run() -> None:
    import uvicorn

    uvicorn.run(
        "backend.main:app",
        host=settings.host,
        port=settings.port,
        reload=False,
        log_level="info",
    )


if __name__ == "__main__":
    run()
