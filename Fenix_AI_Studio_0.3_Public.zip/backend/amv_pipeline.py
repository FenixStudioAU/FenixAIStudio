"""Advanced Music Video planner: multi-character performance story → timeline.

Cast + story + optional environment → ~20s LTX lip-sync shots.
"""
from __future__ import annotations

import json
import re
from pathlib import Path
from typing import Any, Callable, Optional

from . import audio_tools, llm_client, project_store
from .app_settings_store import load_user_settings
from .config import settings
from .logging_setup import log
from .schemas import (
    GenStatus,
    ImageSettings,
    Project,
    Shot,
    VideoSettings,
    new_id,
)

ProgressCb = Optional[Callable[[str, float], None]]

# Preferred AMV planner when the user has created it locally (optional — not required).
# If missing, fall back to Settings story/chat models like every other wizard.
AMV_OLLAMA_MODEL = "fenix-amv-gemma4-e4b-heretic"
_AMV_MODEL_PREFER = (
    "fenix-amv-gemma4-e4b-heretic",
    "gemma-4-e4b-it-heretic",
    "gemma4-e4b-it-heretic",
    "gemma-4-e4b",
    "gemma4-e4b",
)


def _progress(cb: ProgressCb, msg: str, p: float) -> None:
    if cb:
        try:
            cb(msg, p)
        except Exception:
            pass
    log.info("amv_pipeline: %s (%.0f%%)", msg, p * 100)


def _fixed_slots(duration: float, window_sec: float = 20.0) -> list[dict[str, float]]:
    """Equal windows of window_sec; only the last shot may be shorter (ends with track)."""
    duration = max(0.5, float(duration or 0))
    window_sec = max(5.0, min(20.0, float(window_sec or 20.0)))
    slots: list[dict[str, float]] = []
    t = 0.0
    while t < duration - 0.001:
        d = min(window_sec, duration - t)
        slots.append({"start": round(t, 3), "duration": round(d, 3)})
        t += d
    return _ensure_contiguous(slots, duration)


def _ensure_contiguous(
    slots: list[dict[str, float]],
    duration: float,
    *,
    min_sec: float = 1.0,
    max_sec: float = 20.0,
) -> list[dict[str, float]]:
    """Force end-to-end coverage: no gaps, no overlaps, span [0, duration].

    Slots shorter than min_sec are merged into neighbors (never dropped as crumbs
    that used to leave timeline holes — or, with energy_cuts, 1–3s spam).
    """
    duration = max(0.5, float(duration or 0))
    min_sec = max(0.5, float(min_sec or 1.0))
    max_sec = max(min_sec, float(max_sec or 20.0))
    if not slots:
        return [{"start": 0.0, "duration": round(duration, 3)}]
    # Rebuild from sorted starts, snap each end to next start
    ordered = sorted(slots, key=lambda s: float(s.get("start") or 0))
    cuts = [0.0]
    for s in ordered:
        st = float(s.get("start") or 0)
        if st > cuts[-1] + 0.001:
            cuts.append(st)
        en = st + float(s.get("duration") or 0)
        if en > cuts[-1] + 0.001:
            cuts.append(en)
    if cuts[-1] < duration - 0.001:
        cuts.append(duration)
    # unique sorted, clamped
    cuts = sorted({max(0.0, min(duration, round(c, 3))) for c in cuts})
    if cuts[0] > 0:
        cuts.insert(0, 0.0)
    if cuts[-1] < duration:
        cuts.append(round(duration, 3))
    out: list[dict[str, float]] = []
    for i in range(len(cuts) - 1):
        a, b = cuts[i], cuts[i + 1]
        if b - a < 0.05:
            continue
        out.append({"start": round(a, 3), "duration": round(b - a, 3)})
    if not out:
        return [{"start": 0.0, "duration": round(duration, 3)}]
    # Merge short slots into neighbors until each is >= min_sec (or can't without
    # exceeding max_sec). Prefer absorb into previous.
    merged: list[dict[str, float]] = []
    i = 0
    while i < len(out):
        s = dict(out[i])
        while s["duration"] < min_sec - 0.001:
            if merged and merged[-1]["duration"] + s["duration"] <= max_sec + 0.001:
                merged[-1]["duration"] = round(
                    merged[-1]["duration"] + s["duration"], 3
                )
                s = None
                break
            if i + 1 < len(out):
                nxt = out[i + 1]
                combined = round(s["duration"] + nxt["duration"], 3)
                if combined <= max_sec + 0.001:
                    s = {"start": s["start"], "duration": combined}
                    i += 1
                    continue
            break  # can't merge further without blowing the cap
        if s is not None:
            merged.append(s)
        i += 1
    out = merged or out
    # Fix float drift on last end
    last_end = out[-1]["start"] + out[-1]["duration"]
    if abs(last_end - duration) > 0.01:
        out[-1]["duration"] = round(duration - out[-1]["start"], 3)
    return out


def _section_slots_no_gaps(
    analysis: dict[str, Any],
    duration: float,
    window_sec: float = 20.0,
) -> list[dict[str, float]]:
    """
    Use song *section* boundaries as cut points (verse/chorus/bridge…), cover
    0→duration with no gaps. Long spans split at window_sec.

    Do NOT use energy_cuts — those are dense beat/transient markers and produce
    ridiculous 1–3s crumbs. Short sections are merged up to ~half the window
    (min 8s) so clips stay usable for LTX/MiniMax.
    """
    duration = max(0.5, float(duration or 0))
    window_sec = max(5.0, min(20.0, float(window_sec or 20.0)))
    min_sec = max(8.0, min(window_sec, round(window_sec * 0.5, 1)))
    cuts = {0.0, round(duration, 3)}
    for sec in analysis.get("sections") or []:
        try:
            cuts.add(round(float(sec["start"]), 3))
            cuts.add(round(float(sec["end"]), 3))
        except Exception:
            continue
    # Intentionally ignore energy_cuts / beat grids here.
    cuts_l = sorted(c for c in cuts if 0.0 <= c <= duration + 0.001)
    if not cuts_l:
        return _fixed_slots(duration, window_sec)
    if cuts_l[-1] < duration:
        cuts_l.append(round(duration, 3))
    if cuts_l[0] > 0:
        cuts_l.insert(0, 0.0)

    raw: list[dict[str, float]] = []
    for i in range(len(cuts_l) - 1):
        a, b = cuts_l[i], cuts_l[i + 1]
        if b <= a:
            continue
        t = a
        while t < b - 0.001:
            d = min(window_sec, b - t)
            raw.append({"start": round(t, 3), "duration": round(d, 3)})
            t += d
    return _ensure_contiguous(raw, duration, min_sec=min_sec, max_sec=window_sec)


def _slots_from_project(
    proj: Project,
    window_sec: float = 20.0,
    slot_mode: str = "fixed",
) -> list[dict[str, float]]:
    dur = float(getattr(proj.audio, "duration", 0) or 0)
    mode = (slot_mode or "fixed").strip().lower()
    if mode not in ("fixed", "sections"):
        mode = "fixed"

    if mode == "fixed":
        return _fixed_slots(dur, window_sec)

    analysis: dict[str, Any] = {}
    if getattr(proj.audio, "analysis_path", None):
        analysis_path = project_store.abs_path(proj.id, proj.audio.analysis_path)
        if analysis_path and Path(analysis_path).is_file():
            try:
                analysis = json.loads(Path(analysis_path).read_text(encoding="utf-8"))
            except Exception:
                analysis = {}
    if analysis:
        return _section_slots_no_gaps(
            analysis,
            duration=dur or float(analysis.get("duration") or 0),
            window_sec=window_sec,
        )
    return _fixed_slots(dur, window_sec)


def _match_installed(cand: str, ids: list[str], ids_l: list[str]) -> str | None:
    """Return installed Ollama id matching cand, or None. Skip E2B heretic lookalikes."""
    cl = (cand or "").strip().lower()
    if not cl:
        return None
    if "e2b" in cl and "e4b" not in cl:
        return None
    for i, low in enumerate(ids_l):
        if not low:
            continue
        if "e2b" in low and "e4b" not in low:
            continue
        if cl == low or cl in low or low in cl:
            return ids[i]
    return None


async def resolve_amv_llm_model(explicit: str | None = None) -> str:
    """Pick an Ollama model for AMV planning.

    Order:
      1) explicit request override
      2) preferred Gemma E4B heretic **only if installed**
      3) settings: amv_planner_model → story_planner_model → chat_model
      4) any installed Ollama model

    Never hard-requires the custom heretic model (users can't pull it like a
    normal ollama model). Never mentions third-party apps in errors.
    """
    if (explicit or "").strip():
        return explicit.strip()

    us = load_user_settings()
    models = await llm_client.list_ollama_models()
    ids = [(m.get("id") or m.get("name") or "").strip() for m in models]
    ids = [i for i in ids if i]
    ids_l = [i.lower() for i in ids]
    if not ids:
        online = await llm_client.ollama_online()
        raise RuntimeError(
            "Advanced Music Video needs an Ollama model.\n\n"
            + (
                "Ollama has no models listed — pull one (e.g. whatever you use for Story), "
                "or set Story Planner / Chat model in Settings."
                if online
                else "Ollama looks offline. Start Ollama, then retry."
            )
        )

    # 1) Preferred custom AMV model — only when actually present
    for cand in (AMV_OLLAMA_MODEL, *_AMV_MODEL_PREFER):
        hit = _match_installed(cand, ids, ids_l)
        if hit:
            log.info("AMV planner using preferred model %s", hit)
            return hit

    # 2) User settings (same stack as story / chat)
    for key in ("amv_planner_model", "story_planner_model", "chat_model"):
        cand = (us.get(key) or "").strip()
        if not cand:
            continue
        hit = _match_installed(cand, ids, ids_l)
        if hit:
            log.info("AMV planner using settings %s → %s", key, hit)
            return hit
        # Exact name even if fuzzy miss (user typed a valid tag)
        if cand in ids:
            log.info("AMV planner using settings %s → %s", key, cand)
            return cand

    # 3) Anything installed
    log.info("AMV planner falling back to installed model %s", ids[0])
    return ids[0]


def _repair_shots_json(raw: str, expect: int) -> list[dict[str, Any]]:
    """Best-effort parse of truncated / slightly broken shot JSON."""
    data = None
    try:
        data = llm_client.extract_json(raw)
    except Exception:
        data = None
    if isinstance(data, dict) and isinstance(data.get("shots"), list):
        return [x for x in data["shots"] if isinstance(x, dict)]
    if isinstance(data, list):
        return [x for x in data if isinstance(x, dict)]

    # Pull individual shot objects even if the array is broken
    found: list[dict[str, Any]] = []
    for m in re.finditer(r"\{[^{}]*\"animation_prompt\"[^{}]*\}", raw or "", flags=re.I | re.S):
        try:
            obj = json.loads(m.group(0))
            if isinstance(obj, dict) and (obj.get("animation_prompt") or obj.get("label")):
                found.append(obj)
        except Exception:
            continue
    if found:
        return found[:expect]

    # Looser: label + animation_prompt pairs (order preserved)
    labels = re.findall(r'"label"\s*:\s*"((?:\\.|[^"\\])*)"', raw or "")
    anims = re.findall(r'"animation_prompt"\s*:\s*"((?:\\.|[^"\\])*)"', raw or "")
    imgs = re.findall(r'"image_prompt"\s*:\s*"((?:\\.|[^"\\])*)"', raw or "")
    n = max(len(labels), len(anims), 0)
    if n and anims:
        out = []
        for i in range(min(n, expect)):
            out.append(
                {
                    "label": labels[i] if i < len(labels) else f"Shot {i + 1}",
                    "animation_prompt": anims[i] if i < len(anims) else "",
                    "image_prompt": imgs[i] if i < len(imgs) else "",
                }
            )
        return out
    return []


def _fallback_shot(i: int, cast: list[dict[str, str]], concept: str) -> dict[str, Any]:
    singer = next((c for c in cast if (c.get("role") or "").lower() in ("singer", "lead", "vocalist")), None)
    if not singer and cast:
        singer = cast[0]
    singer_name = (singer or {}).get("name") or "the performer"
    others = [c["name"] for c in cast if c.get("name") and c.get("name") != singer_name]
    # Visual roles for I2V — LTX does not know character names
    anim = (
        f"man sings and performs a live rock song on stage"
        if singer
        else "performers move with the music on a live stage"
    )
    if others:
        anim = "man sings woman dances on a live stage environment"
    anim += ". Camera slowly circles the performers showing the crowd"
    return {
        "label": f"Shot {i + 1}",
        "featured": ([singer_name] + others[:2]) if singer_name else others[:3],
        "singer": singer_name,
        "has_vocals": True,
        "animation_prompt": anim,
        "image_prompt": (
            f"{singer_name} performing live, {concept or 'concert'}, clear face visible"
        ),
    }


async def _plan_batch(
    *,
    batch_slots: list[dict[str, float]],
    batch_offset: int,
    total: int,
    concept: str,
    lyrics: str,
    cast: list[dict[str, str]],
    environment: str,
    model: str,
) -> list[dict[str, Any]]:
    cast_lines = []
    for c in cast:
        role = (c.get("role") or "performer").strip()
        cast_lines.append(f"- {c.get('name') or 'Performer'} ({role})")
    cast_block = "\n".join(cast_lines) or "- Performer (singer)"
    singer_default = next(
        (c.get("name") for c in cast if (c.get("role") or "").lower() in ("singer", "lead", "vocalist")),
        (cast[0].get("name") if cast else "the performer"),
    )
    lines = []
    for j, s in enumerate(batch_slots):
        i = batch_offset + j + 1
        lines.append(f"{i}. start={s['start']:.2f}s duration={s['duration']:.2f}s")

    lyrics_snip = (lyrics or "").strip()
    if len(lyrics_snip) > 1800:
        lyrics_snip = lyrics_snip[:1800] + "…"

    system = (
        "You are a music-video director planner. Return ONLY valid JSON. "
        "Build a coherent multi-character performance (concert, club, stage, etc.) "
        "where the same people stay consistent across shots.\n"
        "animation_prompt rules (critical):\n"
        "- Describe the SCENE and CAMERA in plain visual language "
        "(who does what, environment, camera move). "
        "Example style: \"Man dances and sings a rock song on a live stage environment. "
        "Camera circles the performer as he performs showing the crowd.\"\n"
        "- Do NOT name characters in animation_prompt (video models ignore names; "
        "use man/woman/singer/dancer/guitarist). Names belong in featured/singer/image_prompt only.\n"
        "- Do NOT write mouth/jaw/lip-sync instructions. Audio handles that.\n"
        "- Keep animation_prompt to 1-2 short sentences.\n"
        "has_vocals: true when someone is singing in this window, false for instrumental/"
        "dance-only/breakdown. singer: name when singing, else \"\".\n"
        "image_prompt: still start frame; names OK there for image gen refs.\n"
        "Do NOT dump full lyrics into any prompt."
    )
    user = (
        f"Story / concept:\n{(concept or 'live music performance').strip()}\n\n"
        f"Cast:\n{cast_block}\n"
        f"Default lead singer if shot has vocals but does not specify: {singer_default}\n"
        f"Environment: {(environment or 'performance stage / venue').strip()}\n"
        f"Lyrics context (optional, do not quote long lines):\n{lyrics_snip or '(none)'}\n\n"
        f"Plan shots {batch_offset + 1}-{batch_offset + len(batch_slots)} of {total}:\n"
        + "\n".join(lines)
        + "\n\n"
        'Return JSON: {"shots":[{"i":1,"label":"Verse","featured":["Bob","Jane"],'
        '"singer":"Bob","has_vocals":true,'
        '"animation_prompt":"Man sings woman dances on a live stage. Camera slowly pushes in.",'
        '"image_prompt":"..."}]}\n'
        f"Exactly {len(batch_slots)} shots, same order."
    )
    raw = await llm_client.chat(
        model,
        [
            {"role": "system", "content": system},
            {"role": "user", "content": user},
        ],
        temperature=0.45,
        num_predict=min(6144, 800 + 450 * len(batch_slots)),
        format_json=True,
        timeout=360.0,
        retries=3,
    )
    planned = _repair_shots_json(raw or "", len(batch_slots))
    out: list[dict[str, Any]] = []
    for j in range(len(batch_slots)):
        item = planned[j] if j < len(planned) else {}
        if not item or not (item.get("animation_prompt") or "").strip():
            out.append(_fallback_shot(batch_offset + j, cast, concept))
            continue
        featured = item.get("featured") or item.get("characters") or []
        if isinstance(featured, str):
            featured = [featured]
        if not isinstance(featured, list):
            featured = []
        featured = [str(x).strip() for x in featured if str(x).strip()]
        has_vocals = item.get("has_vocals")
        if has_vocals is None:
            # Infer from singer field / prompt words if model omitted the flag
            raw_singer = str(item.get("singer") or "").strip()
            anim_l = str(item.get("animation_prompt") or "").lower()
            has_vocals = bool(raw_singer) or any(
                k in anim_l for k in ("sing", "rap", "vocal", "chorus", "verse")
            )
        else:
            has_vocals = bool(has_vocals)
        singer = str(item.get("singer") or "").strip()
        if has_vocals and not singer:
            singer = str(singer_default or "").strip()
        if not has_vocals:
            singer = ""
        if not featured and singer:
            featured = [singer]
        out.append(
            {
                "label": str(item.get("label") or f"Shot {batch_offset + j + 1}")[:80],
                "featured": featured,
                "singer": singer,
                "has_vocals": has_vocals,
                "animation_prompt": str(item.get("animation_prompt") or "").strip(),
                "image_prompt": str(item.get("image_prompt") or "").strip(),
            }
        )
    return out


async def _plan_prompts(
    *,
    slots: list[dict[str, float]],
    concept: str,
    lyrics: str,
    cast: list[dict[str, str]],
    environment: str,
    model: str,
    on_progress: ProgressCb = None,
) -> list[dict[str, Any]]:
    """Plan all windows in small batches to avoid truncated JSON on small GPUs."""
    batch_size = 4
    all_planned: list[dict[str, Any]] = []
    total = len(slots)
    for start in range(0, total, batch_size):
        batch = slots[start : start + batch_size]
        _progress(
            on_progress,
            f"Planning shots {start + 1}–{start + len(batch)} of {total}…",
            0.35 + 0.4 * (start / max(1, total)),
        )
        try:
            part = await _plan_batch(
                batch_slots=batch,
                batch_offset=start,
                total=total,
                concept=concept,
                lyrics=lyrics,
                cast=cast,
                environment=environment,
                model=model,
            )
        except Exception as e:
            log.warning("AMV batch plan failed (%s) — using fallbacks", e)
            part = [_fallback_shot(start + j, cast, concept) for j in range(len(batch))]
        all_planned.extend(part)
    return all_planned


def _ref_by_name(proj: Project, name: str):
    want = (name or "").strip().lower()
    if not want:
        return None
    for r in proj.references or []:
        if (r.name or "").strip().lower() == want:
            return r
    # partial
    for r in proj.references or []:
        n = (r.name or "").strip().lower()
        if want in n or n in want:
            return r
    return None


def _build_cast(proj: Project, cast_roles: list[dict[str, str]] | None) -> list[dict[str, str]]:
    """Merge explicit roles with project references."""
    by_name: dict[str, dict[str, str]] = {}
    for r in proj.references or []:
        if (r.category or "") == "location":
            continue
        name = (r.name or "").strip()
        if not name:
            continue
        by_name[name.lower()] = {"name": name, "role": "performer", "ref_id": r.id}
    for c in cast_roles or []:
        name = (c.get("name") or "").strip()
        if not name:
            continue
        role = (c.get("role") or "performer").strip() or "performer"
        key = name.lower()
        if key in by_name:
            by_name[key]["role"] = role
        else:
            by_name[key] = {"name": name, "role": role, "ref_id": ""}
    cast = list(by_name.values())
    # Ensure at least one singer
    if cast and not any((c.get("role") or "").lower() in ("singer", "lead", "vocalist") for c in cast):
        cast[0]["role"] = "singer"
    return cast


async def run_amv_prepare(
    project_id: str,
    *,
    concept: str = "",
    lyrics: str = "",
    window_sec: float = 20.0,
    slot_mode: str = "fixed",
    video_engine: str = "ltx23-ia2v",
    ltx_mode: str = "fast",
    quality: str = "draft",
    cast_roles: list[dict[str, str]] | None = None,
    environment_name: str = "",
    seamless: bool = False,
    llm_model: str = "",
    on_progress: ProgressCb = None,
) -> Project:
    """Analyze track, plan multi-character performance shots, write timeline."""
    proj = project_store.load_project(project_id)
    if not getattr(proj.audio, "path", None):
        raise RuntimeError("Upload a music track first.")
    audio_abs = project_store.abs_path(proj.id, proj.audio.path)
    if not audio_abs or not Path(audio_abs).is_file():
        raise RuntimeError("Project audio file missing.")

    _progress(on_progress, "Analyzing audio…", 0.1)
    cache = project_store.project_dir(proj.id) / "cache"
    cache.mkdir(parents=True, exist_ok=True)
    analysis_path = cache / "analysis.json"
    if not analysis_path.is_file():
        audio_tools.analyze_audio(Path(audio_abs), analysis_path)
        proj.audio.analysis_path = project_store.rel_to_project(proj.id, analysis_path)
        try:
            meta = json.loads(analysis_path.read_text(encoding="utf-8"))
            if meta.get("duration"):
                proj.audio.duration = float(meta["duration"])
        except Exception:
            pass
        project_store.save_project(proj)

    slots = _slots_from_project(proj, window_sec=window_sec, slot_mode=slot_mode)
    if not slots:
        raise RuntimeError("Could not build time windows from the track.")
    # Hard guarantee: contiguous coverage of the whole track
    slots = _ensure_contiguous(slots, float(getattr(proj.audio, "duration", 0) or 0))

    cast = _build_cast(proj, cast_roles)
    env_name = (environment_name or "").strip()
    env_ref = None
    for r in proj.references or []:
        if (r.category or "") == "location":
            if not env_name or (r.name or "").strip().lower() == env_name.lower():
                env_ref = r
                env_name = env_name or (r.name or "venue")
                break

    model = await resolve_amv_llm_model(llm_model)
    _progress(on_progress, f"Using planner model {model}", 0.25)

    planned = await _plan_prompts(
        slots=slots,
        concept=concept,
        lyrics=lyrics,
        cast=cast,
        environment=env_name or "performance stage",
        model=model,
        on_progress=on_progress,
    )

    _progress(on_progress, "Writing timeline…", 0.8)
    q = "draft" if (quality or "").strip().lower() == "draft" else "final"
    pass_mode = (ltx_mode or "fast").strip().lower()
    if pass_mode not in ("fast", "quality"):
        pass_mode = "fast"
    eng = (video_engine or "ltx23-ia2v").strip().lower()
    if eng in ("minimax", "minimax-h3", "minimax-h3-i2v", "minimax-h3-i2v-turbo"):
        video_preset = "minimax-h3-i2v"
        is_ltx_eng = False
    else:
        video_preset = "ltx23-ia2v"
        is_ltx_eng = True
    # MiniMax clips cap ~15s; rebuild slots if the wizard still had a 20s window
    if not is_ltx_eng and float(window_sec or 0) > 15.0:
        window_sec = 15.0
        slots = _slots_from_project(proj, window_sec=window_sec, slot_mode=slot_mode)
    name_to_ref = {c["name"].lower(): c for c in cast if c.get("name")}
    new_shots: list[Shot] = []

    for i, slot in enumerate(slots):
        meta = planned[i] if i < len(planned) else _fallback_shot(i, cast, concept)
        sid = new_id("shot_")
        featured = meta.get("featured") or []
        singer = (meta.get("singer") or "").strip()
        has_vocals = bool(meta.get("has_vocals", bool(singer)))
        # Primary still = singer if present, else first featured, else first cast
        primary_name = singer or (featured[0] if featured else (cast[0]["name"] if cast else ""))
        ref_ids: list[str] = []
        for nm in featured or ([primary_name] if primary_name else []):
            c = name_to_ref.get(str(nm).lower()) or {}
            rid = c.get("ref_id") or ""
            if not rid:
                rr = _ref_by_name(proj, str(nm))
                rid = rr.id if rr else ""
            if rid and rid not in ref_ids:
                ref_ids.append(rid)
        # Always include location ref if we have one
        if env_ref and env_ref.id not in ref_ids:
            ref_ids.append(env_ref.id)

        img_prompt = (meta.get("image_prompt") or "").strip()
        if not img_prompt:
            who = ", ".join(featured) if featured else (primary_name or "performers")
            img_prompt = f"{who} on stage, {concept or 'live performance'}, clear faces"

        anim = (meta.get("animation_prompt") or "").strip()
        # No start images yet — user Bulk-generates stills from image_prompt + refs,
        # then generates video. Do not copy character photos onto the timeline.
        shot = Shot(
            id=sid,
            start=float(slot["start"]),
            duration=float(slot["duration"]),
            label=str(meta.get("label") or f"Shot {i + 1}"),
            image=ImageSettings(
                positive_prompt=img_prompt,
                model_id=proj.global_image_model or "flux2-klein-9b",
                reference_ids=ref_ids,
            ),
            video=VideoSettings(
                preset_id=video_preset,
                animation_prompt=anim,
                duration_sec=float(slot["duration"]),
                fps=24,
                quality=q,  # type: ignore[arg-type]
                ltx_mode=pass_mode if is_ltx_eng else "",
                # Vocals windows get lip_sync; MiniMax uses Ref2VA when true
                lip_sync=has_vocals,
                mute_clip_audio=True,
            ),
            image_path=None,
            image_status=GenStatus.empty,
            video_status=GenStatus.empty,
        )
        new_shots.append(shot)

    proj.timeline.shots = new_shots
    proj.global_video_preset = video_preset
    if concept:
        proj.story.idea = concept
    if lyrics:
        proj.story.lyrics = lyrics
        proj.story.use_lyrics = True
    # Persist AMV flags in notes for later seamless wiring
    flags = []
    if seamless:
        flags.append("amv_seamless:1")
    flags.append(f"amv_planner:{model}")
    note = (proj.notes or "").strip()
    for f in flags:
        key = f.split(":", 1)[0]
        note = re.sub(rf"\[{re.escape(key)}:[^\]]*\]", "", note)
        note = (note + f" [{f}]").strip()
    proj.notes = note
    project_store.save_project(proj)
    _progress(on_progress, f"Ready — {len(new_shots)} shots ({model})", 1.0)
    return proj
