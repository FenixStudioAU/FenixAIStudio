"""Resolve which image / video generator to use from Settings + install state."""
from __future__ import annotations

from typing import Any, Optional

from . import app_settings_store
from .logging_setup import log
from .models_detect import MODEL_CATALOG, detect_models, gpu_vendor


async def _availability_map() -> dict[str, bool]:
    info = await detect_models()
    out: dict[str, bool] = {}
    for m in info.get("models") or []:
        if isinstance(m, dict):
            mid = m.get("model_id")
            if mid:
                out[str(mid)] = bool(m.get("available"))
        else:
            mid = getattr(m, "model_id", None)
            if mid:
                out[str(mid)] = bool(getattr(m, "available", False))
    return out


def _installed(mid: str, avail: dict[str, bool]) -> bool:
    if not mid:
        return False
    if mid in avail:
        return bool(avail[mid])
    # fuzzy: prefix match for turbo etc.
    return any(k.startswith(mid) and v for k, v in avail.items())


async def resolve_image_model(explicit: str | None = None) -> str:
    """
    Priority:
      - If explicit is set (standalone Image Gen picker) → that first
      - Else Settings preferred image model
      - Else legacy dev 9b toggle → Flux 4b
    Timeline jobs should call with explicit=None so Settings always wins.
    """
    avail = await _availability_map()
    us = app_settings_store.load_user_settings()
    candidates: list[str] = []
    explicit = (explicit or "").strip()
    if explicit and explicit.lower() not in ("auto", "default", "none"):
        candidates.append(explicit)
    pref = (us.get("preferred_image_model") or "").strip()
    if pref:
        candidates.append(pref)
    if us.get("dev_prefer_flux_9b"):
        candidates.append("flux2-klein-9b")
    # Default: 9B when installed, else 4B (≤8GB / fallback)
    candidates.append("flux2-klein-9b")
    candidates.append("flux2-klein-4b")
    for mid in candidates:
        if mid in MODEL_CATALOG and MODEL_CATALOG[mid].get("role") == "image":
            if _installed(mid, avail):
                log.info(
                    "Image model resolved to %s (explicit=%r pref=%r)",
                    mid,
                    explicit or None,
                    pref or None,
                )
                return mid
    for mid in ("flux2-klein-9b", "flux2-klein-4b"):
        if _installed(mid, avail):
            return mid
    for mid, meta in MODEL_CATALOG.items():
        if meta.get("role") == "image" and _installed(mid, avail):
            return mid
    return "flux2-klein-9b"


async def resolve_video_preset(explicit: str | None = None) -> str:
    """
    Priority:
      - If explicit is set (shot inspector / studio picker / AMV) → that wins.
        Never silently fall back to Settings/Wan when the user picked LTX.
      - Else Settings preferred video model
      - Else AMD → Wan, NVIDIA → MiniMax, then whatever is installed
    """
    avail = await _availability_map()
    us = app_settings_store.load_user_settings()
    explicit = (explicit or "").strip()
    # Ignore empty / placeholder
    if explicit and explicit.lower() not in ("auto", "default", "none"):
        meta = MODEL_CATALOG.get(explicit) or {}
        if meta.get("role") == "video":
            if _installed(explicit, avail):
                log.info(
                    "Video preset resolved to %s (explicit=%r)",
                    explicit,
                    explicit,
                )
                return explicit
            # Detection can flicker after Comfy restarts; still honor the selection
            # so we don't swap LTX → Wan/MiniMax behind the user's back.
            log.warning(
                "Video preset %s selected but not detected as installed — "
                "honoring selection (workflow will error if files are truly missing)",
                explicit,
            )
            return explicit
        log.warning("Unknown video preset %r — falling back to prefs", explicit)

    candidates: list[str] = []
    pref = (us.get("preferred_video_preset") or "").strip()
    # Migrate old Fun InP preference → real I2V
    if pref in ("wan21-fun-inp-1.3b", "wan", "wan21"):
        pref = "wan21-i2v-480p"
    if pref:
        candidates.append(pref)
    vendor = gpu_vendor()
    if vendor == "amd":
        candidates.extend(["wan21-i2v-480p", "minimax-h3-i2v"])
    else:
        candidates.extend(["minimax-h3-i2v", "wan21-i2v-480p"])
    candidates.append("minimax-h3-i2v-turbo")

    for mid in candidates:
        if mid in MODEL_CATALOG and MODEL_CATALOG[mid].get("role") == "video":
            if _installed(mid, avail):
                log.info(
                    "Video preset resolved to %s (explicit=%r pref=%r vendor=%s)",
                    mid,
                    None,
                    pref or None,
                    vendor,
                )
                return mid
    for mid, meta in MODEL_CATALOG.items():
        if meta.get("role") == "video" and _installed(mid, avail):
            return mid
    return "minimax-h3-i2v"
