"""Host CPU / RAM / GPU usage for the UI status bar."""
from __future__ import annotations

from typing import Any


def host_stats() -> dict[str, Any]:
    out: dict[str, Any] = {
        "cpu_percent": None,
        "ram_percent": None,
        "ram_used_gb": None,
        "ram_total_gb": None,
        "gpu_name": None,
        "gpu_util_percent": None,
        "gpu_mem_used_gb": None,
        "gpu_mem_total_gb": None,
        "gpu_mem_percent": None,
    }
    try:
        import psutil

        out["cpu_percent"] = round(psutil.cpu_percent(interval=0.15), 1)
        vm = psutil.virtual_memory()
        out["ram_percent"] = round(vm.percent, 1)
        out["ram_used_gb"] = round(vm.used / (1024**3), 2)
        out["ram_total_gb"] = round(vm.total / (1024**3), 2)
    except Exception:
        pass

    # NVIDIA via pynvml or nvidia-smi
    try:
        import pynvml

        pynvml.nvmlInit()
        h = pynvml.nvmlDeviceGetHandleByIndex(0)
        name = pynvml.nvmlDeviceGetName(h)
        if isinstance(name, bytes):
            name = name.decode("utf-8", errors="replace")
        out["gpu_name"] = name
        util = pynvml.nvmlDeviceGetUtilizationRates(h)
        out["gpu_util_percent"] = float(util.gpu)
        mem = pynvml.nvmlDeviceGetMemoryInfo(h)
        out["gpu_mem_used_gb"] = round(mem.used / (1024**3), 2)
        out["gpu_mem_total_gb"] = round(mem.total / (1024**3), 2)
        out["gpu_mem_percent"] = round(100.0 * mem.used / max(1, mem.total), 1)
        pynvml.nvmlShutdown()
        return out
    except Exception:
        pass

    try:
        import subprocess

        r = subprocess.run(
            [
                "nvidia-smi",
                "--query-gpu=name,utilization.gpu,memory.used,memory.total",
                "--format=csv,noheader,nounits",
            ],
            capture_output=True,
            text=True,
            timeout=3,
        )
        if r.returncode == 0 and r.stdout.strip():
            line = r.stdout.strip().splitlines()[0]
            parts = [p.strip() for p in line.split(",")]
            if len(parts) >= 4:
                out["gpu_name"] = parts[0]
                out["gpu_util_percent"] = float(parts[1])
                used_mb = float(parts[2])
                total_mb = float(parts[3])
                out["gpu_mem_used_gb"] = round(used_mb / 1024, 2)
                out["gpu_mem_total_gb"] = round(total_mb / 1024, 2)
                out["gpu_mem_percent"] = round(100.0 * used_mb / max(1, total_mb), 1)
    except Exception:
        pass
    return out
