"""Local LLM client — Ollama (primary)."""
from __future__ import annotations

import asyncio
import json
import re
from typing import Any, Optional

import httpx

from .config import settings
from .logging_setup import log


def _base(base: str | None = None) -> str:
    return (base or settings.ollama_url or "http://127.0.0.1:11434").rstrip("/")


async def ollama_online(base: str | None = None) -> bool:
    url = _base(base)
    try:
        async with httpx.AsyncClient(timeout=3.0) as c:
            r = await c.get(f"{url}/api/tags")
            return r.status_code == 200
    except Exception:
        return False


async def list_ollama_models(base: str | None = None) -> list[dict[str, Any]]:
    url = _base(base)
    try:
        async with httpx.AsyncClient(timeout=8.0) as c:
            r = await c.get(f"{url}/api/tags")
            r.raise_for_status()
            models = r.json().get("models") or []
            out = []
            for m in models:
                name = m.get("name") or m.get("model") or ""
                if not name:
                    continue
                size = m.get("size") or 0
                out.append(
                    {
                        "id": name,
                        "name": name,
                        "size_gb": round(size / (1024**3), 2) if size else 0,
                        "family": (m.get("details") or {}).get("family") or "",
                        "parameter_size": (m.get("details") or {}).get("parameter_size") or "",
                    }
                )
            out.sort(key=lambda x: x["name"].lower())
            return out
    except Exception as e:
        log.warning("list_ollama_models failed: %s", e)
        return []


def _is_thinking_model(model: str) -> bool:
    m = (model or "").lower()
    # qwen3 / qwen3.5 often default to chain-of-thought and empty "content"
    return any(x in m for x in ("qwen3", "qwen3.5", "deepseek-r1", "reasoning", "think"))


def _extract_message_text(data: dict[str, Any]) -> str:
    """Pull assistant text from Ollama /api/chat payloads."""
    msg = data.get("message") or {}
    if not isinstance(msg, dict):
        msg = {}

    content = (msg.get("content") or "").strip()
    if content:
        return content

    # Thinking models fill this while leaving content empty
    thinking = (msg.get("thinking") or data.get("thinking") or "").strip()
    if thinking:
        return thinking

    response = (data.get("response") or "").strip()
    if response:
        return response

    return ""


async def chat(
    model: str,
    messages: list[dict[str, str]],
    *,
    temperature: float = 0.7,
    num_predict: int = 4096,
    format_json: bool = False,
    base: str | None = None,
    timeout: float = 300.0,
    retries: int = 3,
    disable_thinking: bool | None = None,
) -> str:
    """Chat via Ollama /api/chat. Returns assistant text.

    qwen3.5-class models put tokens in message.thinking and leave content empty
    unless think=false. For JSON / story jobs we force think off and also accept
    thinking text as a fallback. Retries empty replies (cold load / length cut).
    """
    url = _base(base)
    if disable_thinking is None:
        # Default: kill thinking for JSON, and for known CoT models always
        disable_thinking = format_json or _is_thinking_model(model)

    # Thinking burns the token budget; give structured jobs more room
    if format_json and num_predict < 2048:
        num_predict = 2048

    last_err: Exception | None = None
    attempts = max(1, int(retries))

    for attempt in range(attempts):
        payload: dict[str, Any] = {
            "model": model,
            "messages": messages,
            "stream": False,
            "options": {
                "temperature": temperature,
                "num_predict": num_predict,
            },
        }
        if format_json:
            payload["format"] = "json"

        # Ollama think flag (0.9+). Try true path first; fall back if rejected.
        use_think_flag = disable_thinking
        if use_think_flag:
            payload["think"] = False

        try:
            async with httpx.AsyncClient(timeout=timeout) as c:
                r = await c.post(f"{url}/api/chat", json=payload)

                if r.status_code >= 400 and "think" in payload:
                    # Older Ollama: unknown field
                    log.warning(
                        "Ollama rejected payload with think (status %s); retrying without flag",
                        r.status_code,
                    )
                    payload.pop("think", None)
                    r = await c.post(f"{url}/api/chat", json=payload)

                if r.status_code >= 400:
                    raise RuntimeError(
                        f"Ollama chat failed ({r.status_code}): {r.text[:500]}"
                    )

                data = r.json()
                content = _extract_message_text(data)
                done_reason = data.get("done_reason") or ""
                msg = data.get("message") or {}

                if not content:
                    log.warning(
                        "Ollama empty model=%s attempt=%s done_reason=%s msg_keys=%s eval=%s",
                        model,
                        attempt + 1,
                        done_reason,
                        list(msg.keys()) if isinstance(msg, dict) else type(msg).__name__,
                        data.get("eval_count"),
                    )
                    # If we hit length while thinking, bump tokens and force think off harder
                    if done_reason == "length" and attempt + 1 < attempts:
                        num_predict = min(int(num_predict * 1.5) + 512, 16384)
                        disable_thinking = True
                    raise RuntimeError(
                        "Ollama returned empty response "
                        f"(model={model}, reason={done_reason or 'unknown'}, "
                        f"attempt {attempt + 1}/{attempts}). "
                        "Thinking models often need 'think=false' — retrying…"
                    )

                # Truncated thinking-only garbage for JSON — retry with more tokens
                if format_json and done_reason == "length":
                    try:
                        extract_json(content)
                    except Exception:
                        if attempt + 1 < attempts:
                            num_predict = min(int(num_predict * 1.5) + 1024, 16384)
                            disable_thinking = True
                            raise RuntimeError(
                                f"JSON output truncated (length) — raising num_predict to {num_predict}"
                            )

                return content
        except Exception as e:
            last_err = e
            log.warning("llm chat attempt %s/%s failed: %s", attempt + 1, attempts, e)
            if attempt + 1 < attempts:
                await asyncio.sleep(1.5 * (attempt + 1))
                continue
            break

    assert last_err is not None
    raise last_err


def extract_json(text: str) -> Any:
    """Parse JSON from model output, tolerating markdown fences."""
    t = text.strip()
    # Strip leftover thinking prose before first { or [
    if not t.startswith(("{", "[")):
        for opener in ("{", "["):
            i = t.find(opener)
            if i >= 0:
                t = t[i:]
                break
    if t.startswith("```"):
        t = re.sub(r"^```(?:json)?\s*", "", t)
        t = re.sub(r"\s*```$", "", t)
    try:
        return json.loads(t)
    except json.JSONDecodeError:
        for opener, closer in (("{", "}"), ("[", "]")):
            i = t.find(opener)
            if i < 0:
                continue
            depth = 0
            for j in range(i, len(t)):
                if t[j] == opener:
                    depth += 1
                elif t[j] == closer:
                    depth -= 1
                    if depth == 0:
                        try:
                            return json.loads(t[i : j + 1])
                        except json.JSONDecodeError:
                            break
        raise RuntimeError(f"Could not parse JSON from model output:\n{text[:800]}")
