"""Shared character / reference gallery (reuse across projects)."""
from __future__ import annotations

import json
import shutil
from pathlib import Path
from typing import Any, Optional
from uuid import uuid4

from .config import settings
from .logging_setup import log

LIB_DIR = settings.shared_refs_dir
META_PATH = LIB_DIR / "library.json"


def _ensure() -> None:
    LIB_DIR.mkdir(parents=True, exist_ok=True)
    (LIB_DIR / "images").mkdir(parents=True, exist_ok=True)
    if not META_PATH.exists():
        META_PATH.write_text(json.dumps({"characters": []}, indent=2), encoding="utf-8")


def _load() -> dict[str, Any]:
    _ensure()
    try:
        return json.loads(META_PATH.read_text(encoding="utf-8"))
    except Exception:
        return {"characters": []}


def _save(data: dict[str, Any]) -> None:
    _ensure()
    META_PATH.write_text(json.dumps(data, indent=2), encoding="utf-8")


def list_characters() -> list[dict[str, Any]]:
    return list(_load().get("characters") or [])


def get_character(cid: str) -> Optional[dict[str, Any]]:
    for c in list_characters():
        if c.get("id") == cid:
            return c
    return None


def add_character(
    *,
    name: str,
    category: str = "character",
    description: str = "",
    image_bytes: bytes | None = None,
    image_suffix: str = ".jpg",
    tags: list[str] | None = None,
) -> dict[str, Any]:
    _ensure()
    data = _load()
    cid = "char_" + uuid4().hex[:12]
    rel = ""
    if image_bytes:
        suffix = image_suffix if image_suffix.startswith(".") else f".{image_suffix}"
        dest = LIB_DIR / "images" / f"{cid}{suffix}"
        dest.write_bytes(image_bytes)
        rel = f"images/{cid}{suffix}"
    item = {
        "id": cid,
        "name": (name or "Unnamed").strip(),
        "category": category or "character",
        "description": (description or "").strip(),
        "path": rel,
        "tags": tags or [],
    }
    chars = data.get("characters") or []
    chars.append(item)
    data["characters"] = chars
    _save(data)
    log.info("Character library + %s", item["name"])
    return item


def update_character(cid: str, patch: dict[str, Any]) -> dict[str, Any]:
    data = _load()
    chars = data.get("characters") or []
    for i, c in enumerate(chars):
        if c.get("id") != cid:
            continue
        for k in ("name", "category", "description", "tags"):
            if k in patch and patch[k] is not None:
                c[k] = patch[k]
        if patch.get("image_bytes"):
            suffix = patch.get("image_suffix") or ".jpg"
            if not str(suffix).startswith("."):
                suffix = f".{suffix}"
            # remove old
            if c.get("path"):
                old = LIB_DIR / c["path"]
                if old.is_file():
                    old.unlink(missing_ok=True)
            dest = LIB_DIR / "images" / f"{cid}{suffix}"
            dest.write_bytes(patch["image_bytes"])
            c["path"] = f"images/{cid}{suffix}"
        chars[i] = c
        data["characters"] = chars
        _save(data)
        return c
    raise FileNotFoundError(f"Character {cid} not found")


def delete_character(cid: str) -> None:
    data = _load()
    chars = data.get("characters") or []
    kept = []
    for c in chars:
        if c.get("id") == cid:
            if c.get("path"):
                p = LIB_DIR / c["path"]
                if p.is_file():
                    p.unlink(missing_ok=True)
            continue
        kept.append(c)
    data["characters"] = kept
    _save(data)


def abs_image_path(rel: str) -> Optional[Path]:
    if not rel:
        return None
    p = LIB_DIR / rel
    return p if p.is_file() else None


def import_to_project(project_id: str, char_id: str) -> dict[str, Any]:
    """Copy a gallery character into a project's references list."""
    from . import project_store
    from .schemas import ReferenceItem

    char = get_character(char_id)
    if not char:
        raise FileNotFoundError("Character not found")
    proj = project_store.load_project(project_id)
    src = abs_image_path(char.get("path") or "")
    rid = "ref_" + uuid4().hex[:12]
    rel = ""
    if src and src.is_file():
        dest = project_store.project_dir(project_id) / "references" / f"{rid}{src.suffix}"
        dest.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(src, dest)
        rel = project_store.rel_to_project(project_id, dest)
    item = ReferenceItem(
        id=rid,
        name=char.get("name") or "Character",
        category=char.get("category") or "character",  # type: ignore
        path=rel,
        notes=char.get("description") or "",
        tags=list(char.get("tags") or []),
        description=char.get("description") or "",
    )
    # Same name already on project → replace image/notes so a re-import after
    # deleting/updating the gallery character does not keep the old face.
    existing = [r for r in proj.references if (r.name or "").lower() == item.name.lower()]
    if existing:
        old = existing[0]
        # Drop old image file if path changes
        if old.path and old.path != rel:
            try:
                old_abs = project_store.project_dir(project_id) / old.path
                if old_abs.is_file():
                    old_abs.unlink(missing_ok=True)
            except Exception:
                pass
        if rel:
            old.path = rel
        old.notes = item.notes or old.notes
        old.description = item.description or old.description
        old.category = item.category  # type: ignore
        if getattr(item, "tags", None) is not None:
            try:
                old.tags = list(item.tags)  # type: ignore[attr-defined]
            except Exception:
                pass
        project_store.save_project(proj)
        return old.model_dump()
    proj.references.append(item)
    project_store.save_project(proj)
    return item.model_dump()
