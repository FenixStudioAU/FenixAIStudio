"""Pydantic models for project JSON and API payloads."""
from __future__ import annotations

from enum import Enum
from typing import Any, Literal, Optional
from uuid import uuid4

from pydantic import BaseModel, Field


def new_id(prefix: str = "") -> str:
    u = uuid4().hex[:12]
    return f"{prefix}{u}" if prefix else u


class GenStatus(str, Enum):
    empty = "empty"
    queued = "queued"
    running = "running"
    ready = "ready"
    error = "error"
    uploaded = "uploaded"
    draft = "draft"
    final = "final"


class LoraWeight(BaseModel):
    name: str
    strength_model: float = 1.0
    strength_clip: float = 1.0
    enabled: bool = True


class ImageSettings(BaseModel):
    positive_prompt: str = ""
    negative_prompt: str = ""
    seed: int = -1
    width: int = 1280
    height: int = 720
    aspect_ratio: str = "16:9"
    model_id: str = "flux2-klein-9b"
    # Flux.2 Klein distilled is trained for ~4 steps; more steps can look worse
    steps: int = 4
    cfg: float = 1.0
    loras: list[LoraWeight] = Field(default_factory=list)
    reference_ids: list[str] = Field(default_factory=list)
    # Refs uploaded from the shot inspector "Add still…" (max 2 tracked here)
    shot_extra_ref_ids: list[str] = Field(default_factory=list)
    batch_count: int = 1
    # When true: do NOT attach character reference images for this shot
    # (title screens / transitions). Generic people in the prompt are still fine.
    # Field name kept for project JSON compatibility.
    strict_named_characters_only: bool = False


class VideoSettings(BaseModel):
    preset_id: str = "minimax-h3-i2v"
    animation_prompt: str = ""
    duration_sec: float = 5.0
    fps: int = 24
    motion_strength: float = 1.0
    camera_movement: str = "none"
    seed: int = -1
    # 0 = auto (engine picks from quality / VRAM). MiniMax defaults used to be 1280x720.
    width: int = 0
    height: int = 0
    quality: Literal["draft", "final"] = "draft"
    mute_clip_audio: bool = True
    # LTX IA2V: seconds into source track (0 when job_manager pre-slices the clip)
    audio_start_sec: float = 0.0
    # LTX only: "fast"=1-pass, "quality"=2-pass. Independent of Draft/Final resolution.
    # Empty = derive from quality for older shots (draft→fast, final→quality).
    ltx_mode: str = ""
    # LTX: vocals expected in this window (UI). Project audio is still fed when present.
    lip_sync: bool = False


class TitleClip(BaseModel):
    id: str = Field(default_factory=lambda: new_id("title_"))
    text: str = ""
    font: str = "Arial"
    size: int = 48
    color: str = "#FFFFFF"
    position: str = "center"  # center|top|bottom|custom
    x: float = 0.5
    y: float = 0.5
    start: float = 0.0
    duration: float = 3.0
    fade_in: float = 0.3
    fade_out: float = 0.3
    as_title_card: bool = False
    track: int = 0


class EffectClip(BaseModel):
    id: str = Field(default_factory=lambda: new_id("fx_"))
    effect: str = "hard_cut"  # hard_cut|crossfade|fade_black|fade_white|zoom|blur|grain|bw|vignette|color
    start: float = 0.0
    duration: float = 0.5
    strength: float = 1.0
    params: dict[str, Any] = Field(default_factory=dict)


class VisualEffect(BaseModel):
    """Simple per-shot or global visual effect for export pipeline."""
    id: str = Field(default_factory=lambda: new_id("vfx_"))
    type: Literal[
        "none",
        "film_grain",
        "glitch",
        "hue_cycle",
        "vignette",
        "bw",
        "blur",
        "chromatic",
        "sharpen",
    ] = "none"
    enabled: bool = True
    strength: float = 0.5  # 0..1


class Shot(BaseModel):
    id: str = Field(default_factory=lambda: new_id("shot_"))
    start: float = 0.0
    duration: float = 5.0
    label: str = ""
    image: ImageSettings = Field(default_factory=ImageSettings)
    video: VideoSettings = Field(default_factory=VideoSettings)
    # Relative paths under project folder
    image_path: Optional[str] = None
    image_alternatives: list[str] = Field(default_factory=list)
    video_path: Optional[str] = None
    draft_video_path: Optional[str] = None
    video_alternatives: list[str] = Field(default_factory=list)
    thumbnail_path: Optional[str] = None
    image_status: GenStatus = GenStatus.empty
    video_status: GenStatus = GenStatus.empty
    last_error: Optional[str] = None
    transition_out: str = "hard_cut"
    transition_duration: float = 0.0
    effects: list[VisualEffect] = Field(default_factory=list)


class ReferenceItem(BaseModel):
    id: str = Field(default_factory=lambda: new_id("ref_"))
    name: str = ""
    category: Literal["character", "object", "clothing", "location", "style", "other"] = "other"
    path: str = ""
    notes: str = ""
    description: str = ""  # optional bio / look notes for LLM consistency
    tags: list[str] = Field(default_factory=list)


class SubtitleTrack(BaseModel):
    enabled: bool = False
    srt_path: Optional[str] = None
    burn_in: bool = True
    font_size: int = 24
    color: str = "#FFFFFF"
    outline_color: str = "#000000"
    position: str = "bottom"


class ExportSettings(BaseModel):
    preset: Literal["draft", "final"] = "final"
    resolution: str = "1280x720"
    fps: int = 24
    aspect_ratio: str = "16:9"
    codec: str = "libx264"
    crf: int = 18
    audio_bitrate: str = "192k"
    include_subtitles: bool = True
    global_effects: list[VisualEffect] = Field(default_factory=list)
    default_video_quality: Literal["draft", "final"] = "draft"


class AudioMeta(BaseModel):
    path: Optional[str] = None
    filename: Optional[str] = None
    duration: float = 0.0
    sample_rate: int = 0
    channels: int = 0
    waveform_path: Optional[str] = None
    analysis_path: Optional[str] = None


class Timeline(BaseModel):
    zoom: float = 40.0  # pixels per second
    snap: bool = True
    snap_grid_sec: float = 0.25
    playhead: float = 0.0
    shots: list[Shot] = Field(default_factory=list)
    titles: list[TitleClip] = Field(default_factory=list)
    effects: list[EffectClip] = Field(default_factory=list)


class StoryBrief(BaseModel):
    """Inputs / outputs from the AI story wizard (optional on older projects)."""
    idea: str = ""
    lyrics: str = ""
    style_template: str = "standard"
    use_story: bool = True
    use_lyrics: bool = True
    summary: str = ""
    slot_duration: float = 5.0
    planner_model: str = ""
    writer_model: str = ""
    editor_model: str = ""


class Project(BaseModel):
    version: int = 1
    id: str = Field(default_factory=lambda: new_id("proj_"))
    name: str = "Untitled Music Video"
    # music = song-driven; film = short film / non-music cinematic
    kind: str = "music"
    created_at: str = ""
    updated_at: str = ""
    audio: AudioMeta = Field(default_factory=AudioMeta)
    timeline: Timeline = Field(default_factory=Timeline)
    references: list[ReferenceItem] = Field(default_factory=list)
    subtitles: SubtitleTrack = Field(default_factory=SubtitleTrack)
    export: ExportSettings = Field(default_factory=ExportSettings)
    global_image_model: str = "flux2-klein-9b"
    global_video_preset: str = "minimax-h3-i2v"
    global_negative: str = (
        "blurry, low quality, watermark, text artifacts, "
        "mutated hands, extra fingers, fused faces, duplicate limbs, "
        "disfigured, bad anatomy, merged characters"
    )
    notes: str = ""
    story: StoryBrief = Field(default_factory=StoryBrief)


class ProjectCreate(BaseModel):
    name: str = "Untitled Music Video"
    kind: str = "music"  # music | film
    notes: str = ""


class ProjectCloneRequest(BaseModel):
    """Optional rename on clone. Empty name → \"{original} (copy)\"."""
    name: str = ""


class StoryGenerateRequest(BaseModel):
    idea: str = ""
    lyrics: str = ""
    use_story: bool = True
    use_lyrics: bool = True
    style_id: str = "standard"
    # Used when style_id is "custom" — becomes the style line on every still
    style_prefix: str = ""
    slot_duration: float = 5.0
    scene_count: Optional[int] = None  # auto from audio duration / slot
    character_names: list[Any] = Field(default_factory=list)  # str or {name, description}
    planner_model: Optional[str] = None
    writer_model: Optional[str] = None
    editor_model: Optional[str] = None
    # When true: rewrite prompts but keep existing stills/videos on each shot
    preserve_media: bool = False


class BulkGenerateRequest(BaseModel):
    """Optional filters for bulk queue."""
    only_missing: bool = True
    shot_ids: list[str] = Field(default_factory=list)
    quality: Optional[Literal["draft", "final"]] = None  # apply to all queued / or all shots


class ApplyQualityRequest(BaseModel):
    quality: Literal["draft", "final"] = "draft"
    shot_ids: list[str] = Field(default_factory=list)  # empty = all shots


class UserSettingsUpdate(BaseModel):
    comfy_url: Optional[str] = None
    ollama_url: Optional[str] = None
    comfy_install_path: Optional[str] = None
    comfy_start_script: Optional[str] = None
    studio_port: Optional[int] = None
    chat_model: Optional[str] = None
    coder_designer_model: Optional[str] = None
    coder_model: Optional[str] = None
    coder_repair_model: Optional[str] = None
    story_planner_model: Optional[str] = None
    story_writer_model: Optional[str] = None
    story_editor_model: Optional[str] = None
    optimize_low_vram: Optional[bool] = None
    # Minutes; Studio video job wait before timeout (MiniMax/LTX can be slow on 8GB)
    video_timeout_min: Optional[int] = None
    onboarding_complete: Optional[bool] = None
    watermark_enabled: Optional[bool] = None
    watermark_text: Optional[str] = None
    watermark_opacity: Optional[float] = None
    preferred_image_model: Optional[str] = None
    preferred_video_preset: Optional[str] = None
    dev_skin: Optional[str] = None
    dev_show_beta: Optional[bool] = None
    dev_prefer_flux_9b: Optional[bool] = None
    dev_extra_anti_mutant: Optional[bool] = None


class MusicGenerateRequest(BaseModel):
    title: str = "Untitled Track"
    # ace = ACE-Step tags style; minimax = MiniMax Music 3 caption style
    engine: Literal["ace", "minimax"] = "ace"
    tags: str = ""
    # MiniMax Music 3 structured caption (Global Metadata / Vocal / Arrangement)
    caption: str = ""
    lyrics: str = ""
    duration_sec: float = 30.0
    bpm: int = 120
    seed: int = -1
    keyscale: str = "E minor"
    language: str = "en"
    timesignature: str = "4"
    steps: int = 8
    # Comfy node defaults this True — that runs a 4B LLM for duration*5 tokens
    # BEFORE sampling and is the usual GPU-peg culprit. Studio defaults off.
    generate_audio_codes: bool = False
    # ACE TextEncode advanced (LM sampling when audio codes on)
    cfg_scale: float = 2.0
    temperature: float = 0.85
    top_p: float = 0.9
    top_k: int = 0
    min_p: float = 0.0
    # Optional ACE style LoRA (ComfyUI/models/loras/ relative name)
    lora_name: str = ""
    lora_strength: float = 0.75
    # Comfy input/ filename from /api/music/upload-reference (timbre guide)
    reference_audio: str = ""
    save: bool = True


class MusicTrainCreate(BaseModel):
    name: str = "My style"
    tags: str = ""
    epochs: int = 300
    rank: int = 16
    learning_rate: str = "1e-4"


class StudioImageRequest(BaseModel):
    prompt: str = ""
    negative_prompt: str = ""
    width: int = 0  # 0 = derive from quality + low VRAM
    height: int = 0
    seed: int = -1
    steps: int = 0  # 0 = auto (Klein distilled: draft 4 / final 8)
    model_id: str = "flux2-klein-9b"
    quality: str = "final"  # draft | final — same tiers as timeline


class StudioVideoRequest(BaseModel):
    """I2V from a gallery image id (or use multipart upload endpoint)."""
    source_item_id: str = ""
    animation_prompt: str = ""
    duration_sec: float = 5.0
    seed: int = -1
    quality: str = "draft"  # draft | final — same as timeline video gen
    video_preset: str = ""  # optional override; empty → Settings preferred / auto
    # LTX IA2V: optional path already saved under cache/ (multipart endpoints preferred)
    audio_path: str = ""


class AmvCastRole(BaseModel):
    name: str = ""
    role: str = "performer"  # singer | guitarist | drummer | dancer | performer | ...


class AmvPrepareRequest(BaseModel):
    """Advanced Music Video: build lip-sync performance shots on the timeline."""
    concept: str = ""
    lyrics: str = ""
    window_sec: float = 20.0
    # fixed = equal windows (only last may be shorter); sections = structure cuts, no gaps
    slot_mode: str = "fixed"
    # Video engine: LTX IA2V or MiniMax (Ref2VA when lip_sync)
    video_engine: str = "ltx23-ia2v"  # ltx23-ia2v | minimax-h3-i2v
    # 1-pass vs 2-pass only (LTX) — does NOT change resolution
    ltx_mode: str = "fast"  # fast=1-pass | quality=2-pass
    # Timeline Draft/Final resolution (Under 8GB setting also affects size)
    quality: str = "draft"  # draft | final
    cast_roles: list[AmvCastRole] = Field(default_factory=list)
    environment_name: str = ""
    seamless: bool = False
    llm_model: str = ""  # optional override; else prefer Gemma E4B heretic if installed, else Settings


class ChatMessage(BaseModel):
    role: str = "user"
    content: str = ""


class ChatRequest(BaseModel):
    mode: str = "chat"  # chat | coder
    stage: str = "chat"  # chat | designer | coder | repair
    model: Optional[str] = None
    messages: list[ChatMessage] = Field(default_factory=list)
    temperature: Optional[float] = None
    num_predict: int = 4096
    # Optional attachment context injected by the client (ids/names + extracted text)
    attachment_context: Optional[str] = None
    enable_web_search: bool = False
    web_search_query: Optional[str] = None


class ChatMediaRequest(BaseModel):
    kind: str = "image"  # image | video
    prompt: str = ""
    negative: str = ""
    image_prompt: Optional[str] = None
    motion_prompt: Optional[str] = None
    width: int = 1024
    height: int = 576
    duration_sec: float = 5.0
    video_preset: str = "minimax-h3-i2v-turbo"
    # Reuse an existing still instead of generating a new one
    source_shot_id: Optional[str] = None
    source_image_rel: Optional[str] = None  # relative path under chat project
    enhance_prompt: bool = False  # LLM-enhance motion/image prompt first


class ChatSearchRequest(BaseModel):
    query: str = ""
    limit: int = 5


class CoderProjectPatch(BaseModel):
    name: Optional[str] = None
    designer_messages: Optional[list[dict[str, Any]]] = None
    build_prompt: Optional[str] = None
    repair_prompt: Optional[str] = None
    accepted_version_id: Optional[str] = None
    active_version_id: Optional[str] = None
    project_id: Optional[str] = None


class CoderProjectCreate(BaseModel):
    name: str = ""
    switch: bool = True


class CoderVersionCreate(BaseModel):
    prompt: str = ""
    raw_response: str = ""
    kind: str = "build"  # build | repair
    inspector_report: str = ""
    model: str = ""
    project_id: Optional[str] = None


class ProjectUpdate(BaseModel):
    project: Project


class GenerateImageRequest(BaseModel):
    shot_id: str
    settings: Optional[ImageSettings] = None


class GenerateVideoRequest(BaseModel):
    shot_id: str
    settings: Optional[VideoSettings] = None


class AutoSlotsRequest(BaseModel):
    duration: Optional[float] = None
    mode: Literal["fixed", "beats", "sections", "energy"] = "fixed"


class LoraSearchRequest(BaseModel):
    query: str = ""
    base_model: str = "flux2-klein-4b"
    limit: int = 20


class ImportLoraRequest(BaseModel):
    source_path: str
    name: Optional[str] = None
