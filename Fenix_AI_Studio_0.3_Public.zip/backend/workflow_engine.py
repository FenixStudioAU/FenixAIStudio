"""Load ComfyUI API workflow templates and inject parameters."""
from __future__ import annotations

import copy
import json
import random
from pathlib import Path
from typing import Any, Optional

from .config import settings
from .logging_setup import log
from .models_detect import MODEL_CATALOG, inventory, resolve_model_files
from .schemas import ImageSettings, LoraWeight, VideoSettings


def _load_template(name: str) -> dict[str, Any]:
    path = settings.workflows_dir / name
    if not path.exists():
        raise FileNotFoundError(f"Workflow template missing: {path}")
    with open(path, "r", encoding="utf-8") as f:
        return json.load(f)


def _set_input(prompt: dict, node_id: str, key: str, value: Any) -> None:
    if node_id not in prompt:
        raise KeyError(f"Node {node_id} not in workflow")
    prompt[node_id].setdefault("inputs", {})[key] = value


def _random_seed(seed: int) -> int:
    if seed is None or seed < 0:
        return random.randint(0, 2**32 - 1)
    return int(seed)


def resolve_flux_size(
    *,
    quality: str = "final",
    low_vram: bool | None = None,
) -> tuple[int, int]:
    """
    Flux still sizes (16:9):
      Normal: draft 960×544, final 1280×720
      Low VRAM: draft 768×432, final 960×544
    """
    if low_vram is None:
        try:
            from . import app_settings_store

            low_vram = bool(app_settings_store.load_user_settings().get("optimize_low_vram"))
        except Exception:
            low_vram = False
    is_draft = (quality or "final").strip().lower() == "draft"
    if low_vram:
        w, h = (768, 432) if is_draft else (960, 544)
    else:
        w, h = (960, 544) if is_draft else (1280, 720)
    # Align to 16px so 720p stays 1280×720 (32px floor was turning 720→704)
    return max(16, int(round(w / 16) * 16)), max(16, int(round(h / 16) * 16))


async def build_image_workflow(
    settings_img: ImageSettings,
    filename_prefix: str = "amvs/image",
    image_name: str | None = None,
    reference_comfy_names: list[str] | None = None,
) -> dict[str, Any]:
    inv = await inventory()
    model_id = settings_img.model_id or "flux2-klein-4b"
    resolved = resolve_model_files(model_id, inv)
    meta = MODEL_CATALOG.get(model_id, MODEL_CATALOG["flux2-klein-4b"])

    # Never fall back to Wan2GP *quanto* names — they crash Comfy (meta tensor).
    def _is_bad(n: str) -> bool:
        nl = n.lower()
        return "quanto" in nl or "mbf16_int8" in nl

    if "diffusion_models" not in resolved:
        want_9 = "9b" in (model_id or "").lower()
        for name in inv.get("diffusion_models", []):
            if _is_bad(name):
                continue
            nl = name.lower()
            if want_9 and "klein" in nl and "9b" in nl:
                resolved["diffusion_models"] = name
                break
            if (not want_9) and "flux" in nl and "klein" in nl and "4b" in nl:
                resolved["diffusion_models"] = name
                break
        if "diffusion_models" not in resolved:
            for name in inv.get("diffusion_models", []):
                if _is_bad(name):
                    continue
                if "flux-2-klein" in name.lower() or "flux2-klein" in name.lower():
                    resolved["diffusion_models"] = name
                    break
    if "vae" not in resolved:
        for name in inv.get("vae", []):
            if _is_bad(name):
                continue
            bn = name.replace("\\", "/").split("/")[-1].lower()
            if bn in ("flux2-vae.safetensors", "flux2_vae.safetensors"):
                resolved["vae"] = name
                break
    if "text_encoders" not in resolved:
        for name in inv.get("text_encoders", []) + inv.get("clip", []):
            if _is_bad(name):
                continue
            bn = name.replace("\\", "/").split("/")[-1].lower()
            if "qwen_3_4b" in bn or "qwen3_4b" in bn:
                resolved["text_encoders"] = name
                break
            if "qwen_3_8b" in bn or "qwen3_8b" in bn:
                resolved["text_encoders"] = name
                break

    missing = [k for k in ("diffusion_models", "text_encoders", "vae") if k not in resolved]
    if missing:
        raise RuntimeError(
            f"Image model '{model_id}' is not fully installed (Comfy-native weights only). "
            f"Missing: {missing}. "
            f"Download from https://huggingface.co/Comfy-Org/flux2-klein-4B into "
            f"ComfyUI/models/diffusion_models, text_encoders, vae. "
            f"Wan2GP quanto files are ignored on purpose."
        )
    for k, v in resolved.items():
        if _is_bad(v):
            raise RuntimeError(
                f"Refusing to load Wan2GP/quanto weight for {k}: {v}. "
                f"Install Comfy-native FLUX.2 Klein 4B instead."
            )

    use_lora = any(l.enabled and l.name for l in settings_img.loras)
    template_name = "flux2_klein_t2i_lora.json" if use_lora else "flux2_klein_t2i.json"
    prompt = copy.deepcopy(_load_template(template_name))

    # Normalize reference list: strings or {name, label, category}
    refs: list[dict[str, str]] = []
    for r in reference_comfy_names or []:
        if isinstance(r, str) and r.strip():
            refs.append({"name": r.strip(), "label": "", "category": ""})
        elif isinstance(r, dict) and r.get("name"):
            refs.append(
                {
                    "name": str(r["name"]),
                    "label": str(r.get("label") or ""),
                    "category": str(r.get("category") or ""),
                }
            )
    refs = refs[:6]  # Flux.2 can take multiple; keep GPU-friendly

    seed = _random_seed(settings_img.seed)
    pos_text = settings_img.positive_prompt or "cinematic still, high detail"
    neg_text = settings_img.negative_prompt or ""
    # No-character-refs mode: never force cast likeness via character ref images.
    # Generic people in the text prompt ("a man on the beach") remain allowed.
    if getattr(settings_img, "strict_named_characters_only", False):
        refs = [
            r
            for r in refs
            if (r.get("category") or "character").strip().lower()
            in ("location", "environment", "style")
        ]
    if refs:
        # Flux.2 multi-ref: image N is <Name> links the reference photo to that
        # person named in the scene prompt. Names in the creative prompt are required;
        # these lines tell Flux which ref image is which named character.
        bits = []
        for i, r in enumerate(refs, 1):
            label = (r.get("label") or f"reference {i}").strip() or f"reference {i}"
            cat = (r.get("category") or "character").strip().lower()
            if cat in ("location", "environment"):
                bits.append(
                    f"image {i} is {label}, the environment/location reference — "
                    f"match setting, lighting and atmosphere from image {i}"
                )
            elif cat == "style":
                bits.append(
                    f"image {i} is the style reference for {label} — "
                    f"match look, palette and rendering from image {i}"
                )
            else:
                bits.append(
                    f"image {i} is {label} — use their exact face, hair, body type "
                    f"and identity from image {i}"
                )
        pos_text = (
            pos_text.rstrip(". ")
            + ". "
            + " ".join(bits)
            + ". Keep each named subject consistent with their numbered reference image."
        )

    _set_input(prompt, "1", "unet_name", resolved["diffusion_models"])
    _set_input(prompt, "2", "clip_name", resolved["text_encoders"])
    _set_input(prompt, "2", "type", meta.get("clip_type", "flux2"))
    _set_input(prompt, "3", "vae_name", resolved["vae"])
    _set_input(prompt, "4", "width", int(settings_img.width))
    _set_input(prompt, "4", "height", int(settings_img.height))
    _set_input(prompt, "5", "text", pos_text)
    _set_input(prompt, "6", "text", neg_text or "")
    _set_input(prompt, "8", "seed", seed)
    _set_input(prompt, "8", "steps", int(settings_img.steps))
    # cfg 1.0 is standard for distilled Flux; keep guidance on FluxGuidance
    _set_input(prompt, "8", "cfg", 1.0)
    _set_input(prompt, "10", "filename_prefix", filename_prefix)

    if "7" in prompt and prompt["7"].get("class_type") == "FluxGuidance":
        _set_input(prompt, "7", "guidance", max(float(settings_img.cfg), 1.0))

    model_src: list[Any] = ["1", 0]
    clip_src: list[Any] = ["2", 0]

    if use_lora:
        enabled = [l for l in settings_img.loras if l.enabled and l.name][:3]
        lora_nodes = ["20", "21", "22"]
        for i, node_id in enumerate(lora_nodes):
            if node_id not in prompt:
                break
            if i < len(enabled):
                lw = enabled[i]
                _set_input(prompt, node_id, "lora_name", lw.name)
                _set_input(prompt, node_id, "strength_model", float(lw.strength_model))
                _set_input(prompt, node_id, "strength_clip", float(lw.strength_clip))
                prompt[node_id]["inputs"]["model"] = model_src
                prompt[node_id]["inputs"]["clip"] = clip_src
                model_src = [node_id, 0]
                clip_src = [node_id, 1]
            else:
                del prompt[node_id]
        prompt["5"]["inputs"]["clip"] = clip_src
        prompt["6"]["inputs"]["clip"] = clip_src
        prompt["8"]["inputs"]["model"] = model_src

    # Positive starts at FluxGuidance (7); negative at empty CLIP encode (6)
    pos_cond: list[Any] = ["7", 0]
    neg_cond: list[Any] = ["6", 0]

    # Multi-reference: LoadImage → scale → VAEEncode → ReferenceLatent (chain)
    # Order matters: first ref = image 1, second = image 2, …
    for i, r in enumerate(refs):
        base = 100 + i * 10
        load_id = str(base)
        scale_id = str(base + 1)
        enc_id = str(base + 2)
        ref_pos_id = str(base + 3)
        ref_neg_id = str(base + 4)

        prompt[load_id] = {
            "class_type": "LoadImage",
            "inputs": {"image": r["name"]},
        }
        # Cap reference tokens for VRAM while keeping identity detail
        prompt[scale_id] = {
            "class_type": "ImageScaleToTotalPixels",
            "inputs": {
                "image": [load_id, 0],
                "upscale_method": "lanczos",
                "megapixels": 1.0,
                "resolution_steps": 1,
            },
        }
        prompt[enc_id] = {
            "class_type": "VAEEncode",
            "inputs": {
                "pixels": [scale_id, 0],
                "vae": ["3", 0],
            },
        }
        prompt[ref_pos_id] = {
            "class_type": "ReferenceLatent",
            "inputs": {
                "conditioning": pos_cond,
                "latent": [enc_id, 0],
            },
        }
        prompt[ref_neg_id] = {
            "class_type": "ReferenceLatent",
            "inputs": {
                "conditioning": neg_cond,
                "latent": [enc_id, 0],
            },
        }
        pos_cond = [ref_pos_id, 0]
        neg_cond = [ref_neg_id, 0]

    if refs:
        # Tell edit/ref path how to index multi latents (Flux.2)
        prompt["90"] = {
            "class_type": "FluxKontextMultiReferenceLatentMethod",
            "inputs": {
                "conditioning": pos_cond,
                "reference_latents_method": "index",
            },
        }
        pos_cond = ["90", 0]
        log.info(
            "Flux2 multi-ref: %s",
            ", ".join(f"image{i+1}={r.get('label') or r['name']}" for i, r in enumerate(refs)),
        )

    prompt["8"]["inputs"]["positive"] = pos_cond
    prompt["8"]["inputs"]["negative"] = neg_cond
    prompt["8"]["inputs"]["model"] = model_src

    log.info(
        "Built image workflow model=%s seed=%s %sx%s refs=%d",
        model_id,
        seed,
        settings_img.width,
        settings_img.height,
        len(refs),
    )
    return prompt


def _resolve_wan_fast_lora(inv: dict[str, list[str]]) -> str | None:
    """LightX2V / FastWan distill LoRA for Wan 2.1 I2V 4-step."""
    names = list(inv.get("loras") or [])
    prefer = [
        "lightx2v_i2v_14b_480p_cfg_step_distill_rank64_bf16.safetensors",
        "lightx2v_i2v_14b_480p_cfg_step_distill_rank128_bf16.safetensors",
        "wan2.1_i2v_lora_rank64_lightx2v_4step.safetensors",
    ]
    lower_map = {n.lower().replace("\\", "/").split("/")[-1]: n for n in names}
    for p in prefer:
        if p in lower_map:
            return lower_map[p]
    for n in names:
        bn = n.lower().replace("\\", "/").split("/")[-1]
        if "lightx2v" in bn and "i2v" in bn and "480" in bn:
            return n
        if "lightx2v" in bn and "i2v" in bn:
            return n
    return None


def _resolve_turbo_lora(inv: dict[str, list[str]]) -> str | None:
    """Pick best available MiniMax FastLoRA (pruned ComfyUI format)."""
    preferred = [
        "minimax_h3_turbo_4step_ckpt850_pruned_comfyui.safetensors",
        "minimax_h3_turbo_4step_ckpt500_pruned_comfyui.safetensors",
        "minimax_h3_turbo_4step_pruned_comfyui.safetensors",
        "minimax_h3_turbo_4step_ema_ckpt850_pruned_comfyui.safetensors",
        "minimax_h3_turbo_4step_ema_ckpt500_pruned_comfyui.safetensors",
        "minimax_h3_turbo_4step_ema_pruned_comfyui.safetensors",
    ]
    loras = inv.get("loras") or []
    lower_map = {n.lower().replace("\\", "/").split("/")[-1]: n for n in loras}
    for p in preferred:
        if p.lower() in lower_map:
            return lower_map[p.lower()]
    # Any turbo/fast minimax lora
    for n in loras:
        bn = n.lower().replace("\\", "/").split("/")[-1]
        if "minimax" in bn and ("turbo" in bn or "4step" in bn or "fast" in bn):
            return n
    return None


def _host_vram_gb() -> float:
    try:
        from .models_detect import get_vram_gb

        return float(get_vram_gb() or 0)
    except Exception:
        return 0.0


def turbo_allowed_for_vram(vram_gb: float | None = None) -> bool:
    """Whether FastLoRA turbo may be used.

    Only blocked when the user enables Settings → Optimise for low VRAM.
    (A previous hard ban for all cards under 12 GB forced 12-step non-turbo
    on 8 GB machines and made every video ~3× slower than turbo 4-step.)
    """
    try:
        from . import app_settings_store

        if app_settings_store.load_user_settings().get("optimize_low_vram"):
            return False
    except Exception:
        pass
    return True


def _resolve_audio_vae(inv: dict[str, list[str]]) -> str | None:
    vaes = inv.get("vae") or []
    preferred = [
        "minimax_h3_audio_vae_fp32.safetensors",
        "minimax_h3_audio_vae.safetensors",
    ]
    lower = {n.lower().replace("\\", "/").split("/")[-1]: n for n in vaes}
    for p in preferred:
        if p.lower() in lower:
            return lower[p.lower()]
    for n in vaes:
        bn = n.lower().replace("\\", "/").split("/")[-1]
        if "minimax" in bn and "audio" in bn:
            return n
    return None


async def build_video_workflow(
    settings_vid: VideoSettings,
    image_comfy_name: str,
    filename_prefix: str = "amvs/video",
    audio_comfy_name: str | None = None,
) -> dict[str, Any]:
    inv = await inventory()
    preset = settings_vid.preset_id or "minimax-h3-i2v"
    use_turbo = "turbo" in preset.lower() or "fastlora" in preset.lower()
    vram = _host_vram_gb()

    # Only drop turbo when Settings → Optimise for low VRAM is on
    if use_turbo and not turbo_allowed_for_vram(vram):
        log.warning(
            "FastLoRA/turbo disabled (optimize_low_vram is on) — using standard MiniMax I2V"
        )
        use_turbo = False
        preset = "minimax-h3-i2v"

    # ---- LTX-2.3 Image + Audio → Video (lip sync / performance) ----
    if (
        preset in ("ltx23-ia2v", "ltx-2.3-ia2v", "ltx23", "ltx-ia2v")
        or "ltx23" in preset.lower()
        or (preset.lower().startswith("ltx") and "ia2v" in preset.lower())
    ):
        # Audio is always passed for the AV graph: real slice when lip_sync, else silent bed.
        if not audio_comfy_name:
            raise RuntimeError(
                "LTX needs an audio input for the AV graph (real track for lip sync, "
                "or silent bed for plain I2V). Check the video job audio upload."
            )
        prompt = copy.deepcopy(_load_template("ltx23_ia2v.json"))
        resolved = resolve_model_files("ltx23-ia2v", inv)
        ckpt = resolved.get("checkpoints")
        if not ckpt:
            ckpts = inv.get("checkpoints") or []
            ckpt = next((c for c in ckpts if "ltx-2.3" in c.lower() and "dev" in c.lower()), None)
            ckpt = ckpt or next((c for c in ckpts if "ltx-2.3" in c.lower()), None)
        if not ckpt:
            raise RuntimeError(
                "LTX-2.3 checkpoint missing. Put ltx-2.3-22b-dev-fp8.safetensors "
                "in ComfyUI/models/checkpoints/"
            )
        te = resolved.get("text_encoders")
        if not te:
            tes = inv.get("text_encoders") or []
            te = next((t for t in tes if "gemma" in t.lower() and "12b" in t.lower()), None)
        if not te:
            raise RuntimeError(
                "LTX text encoder missing (gemma_3_12B_it_fp4_mixed.safetensors)."
            )
        distilled = resolved.get("loras")
        if not distilled:
            loras = inv.get("loras") or []
            distilled = next(
                (
                    x
                    for x in loras
                    if "distilled" in x.lower() and "ltx" in x.lower() and "1.1" in x.lower()
                ),
                None,
            ) or next(
                (x for x in loras if "distilled" in x.lower() and "ltx" in x.lower()),
                None,
            )
        if not distilled:
            raise RuntimeError(
                "LTX distilled 1.1 LoRA missing "
                "(ltx_2.3_22b_distilled_1.1_lora_….safetensors in models/loras/)."
            )
        upscaler = resolved.get("latent_upscale_models")
        if not upscaler:
            ups = inv.get("latent_upscale_models") or []
            upscaler = next((u for u in ups if "ltx" in u.lower() and "upscaler" in u.lower()), None)

        MAX_CLIP_SEC = 20.0
        fps = max(8, min(30, int(settings_vid.fps or 24)))
        dur_sec = float(settings_vid.duration_sec or 10.0)
        if dur_sec <= 0:
            dur_sec = 10.0
        if dur_sec > MAX_CLIP_SEC:
            log.warning("LTX duration %.2fs clamped to %.0fs max", dur_sec, MAX_CLIP_SEC)
            dur_sec = MAX_CLIP_SEC
        settings_vid.duration_sec = dur_sec

        # Resolution: Draft/Final + Settings→Under 8GB ONLY.
        # Never auto-downgrade from probed VRAM — that forced 640×352@16fps on 8GB
        # cards even when Under 8GB was off (looked like slow-mo sludge).
        low_vram = False
        try:
            from . import app_settings_store

            low_vram = bool(app_settings_store.load_user_settings().get("optimize_low_vram"))
        except Exception:
            pass
        is_draft = (settings_vid.quality or "draft") == "draft"
        # Pass mode: explicit ltx_mode only (1-pass vs 2-pass). Independent of resolution.
        mode = (getattr(settings_vid, "ltx_mode", None) or "").strip().lower()
        if mode not in ("fast", "quality"):
            # Backward compat when older shots have no ltx_mode set
            mode = "fast" if is_draft else "quality"
        fast = mode == "fast"

        if low_vram:
            width, height = (768, 432) if is_draft else (960, 544)
        else:
            width, height = (960, 544) if is_draft else (1280, 720)

        if not fast and not upscaler:
            raise RuntimeError(
                "LTX 2-pass mode needs the spatial upscaler "
                "(ltx-2.3-spatial-upscaler-x2-1.1.safetensors in models/latent_upscale_models/). "
                "Use 1-pass mode without it, or install the upscaler."
            )

        # Only honor explicit sizes (schema default is 0 = auto).
        if int(settings_vid.width or 0) >= 64 and int(settings_vid.height or 0) >= 64:
            width = int(settings_vid.width)
            height = int(settings_vid.height)
        # Snap to 16px (not 32) so Final 1280×720 stays 720 — not 704
        width = max(64, int(round(int(width) / 16) * 16))
        height = max(64, int(round(int(height) / 16) * 16))
        if width == 1280 and height == 704:
            height = 720
        if height == 1280 and width == 704:
            width = 720

        # Prefer distilled-fp8 checkpoint for Fast when installed (optional)
        ckpts = inv.get("checkpoints") or []
        distilled_ckpt = next(
            (
                c
                for c in ckpts
                if "ltx-2.3" in c.lower() and "distilled" in c.lower() and "fp8" in c.lower()
            ),
            None,
        )
        use_distilled_ckpt = bool(fast and distilled_ckpt)
        if use_distilled_ckpt:
            ckpt = distilled_ckpt

        # Keep the shot's fps (default 24). Do NOT drop to 16 — that made long
        # Draft clips look like slow motion.

        seed = _random_seed(settings_vid.seed)
        # Use the user's / LLM prompt as-is. Do NOT inject mouth/jaw instructions —
        # simple prompts like "Man sings Woman Dances" work best with LTX.
        anim = (settings_vid.animation_prompt or "").strip()
        if not anim:
            anim = (
                "performers on stage moving with the music, live concert energy, "
                "camera mostly steady"
            )
        if settings_vid.camera_movement and settings_vid.camera_movement != "none":
            anim = f"{anim}, camera: {settings_vid.camera_movement}"
        audio_start = float(getattr(settings_vid, "audio_start_sec", 0.0) or 0.0)

        _set_input(prompt, "269", "image", image_comfy_name)
        _set_input(prompt, "276", "audio", audio_comfy_name)
        _set_input(prompt, "319", "value", anim)
        _set_input(prompt, "330", "value", width)
        _set_input(prompt, "324", "value", height)
        _set_input(prompt, "331", "value", float(dur_sec))
        _set_input(prompt, "323", "value", int(fps))
        _set_input(prompt, "286", "noise_seed", seed)
        _set_input(prompt, "317", "ckpt_name", ckpt)
        _set_input(prompt, "335", "ckpt_name", ckpt)
        _set_input(prompt, "318", "text_encoder", te)
        _set_input(prompt, "318", "ckpt_name", ckpt)
        _set_input(prompt, "293", "lora_name", distilled)
        # Distilled LoRA on top of distilled ckpt is usually unnecessary
        _set_input(prompt, "293", "strength_model", 0.0 if use_distilled_ckpt else 0.5)
        if upscaler and "313" in prompt:
            _set_input(prompt, "313", "model_name", upscaler)
        _set_input(prompt, "332", "start_index", float(audio_start))
        _set_input(prompt, "341", "filename_prefix", filename_prefix)

        # First-frame lock: strength 1.0 on stage-2 freezes into a "moving photo".
        if "325" in prompt:
            _set_input(prompt, "325", "strength", 0.55 if fast else 0.6)
        if "296" in prompt and not fast:
            _set_input(prompt, "296", "strength", 0.75)
        if "314" in prompt:
            _set_input(
                prompt,
                "314",
                "text",
                "static image, slideshow, ken burns zoom only, still photo, "
                "frozen pose, no motion",
            )

        if fast:
            # Single pass at the Draft/Final target resolution (no upscaler stage).
            if "299" in prompt:
                _set_input(prompt, "299", "expression", "a")
            if "301" in prompt:
                _set_input(prompt, "301", "expression", "a")
            # Decode from stage-1 separate (309); drop stage-2 / upscaler nodes
            if "316" in prompt:
                prompt["316"]["inputs"]["samples"] = ["309", 0]
            if "303" in prompt:
                prompt["303"]["inputs"]["samples"] = ["309", 1]
            for dead in ("295", "296", "287", "310", "311", "285", "288", "289", "290", "292", "313"):
                prompt.pop(dead, None)

        log.info(
            "Built LTX-2.3 IA2V pass=%s quality=%s low_vram=%s %sx%s "
            "duration=%.2fs@%dfps seed=%s ckpt=%s distilled_lora=%s upscaler=%s audio=%s",
            mode,
            "draft" if is_draft else "final",
            low_vram,
            width,
            height,
            dur_sec,
            fps,
            seed,
            ckpt,
            distilled if not use_distilled_ckpt else "(skipped on distilled-ckpt)",
            upscaler if not fast else "(skipped 1-pass)",
            audio_comfy_name,
        )
        return prompt

    if preset.startswith("minimax") or "minimax" in (settings_vid.preset_id or ""):
        lip_sync = bool(getattr(settings_vid, "lip_sync", False))
        # Lip sync must LOCK the shot still (first_frame I2V) and drive mouth from audio.
        # Ref2VA is soft reference generation — it invents new scenes and is NOT used here.
        # Correct path: FL2VA MiniMaxH3ImageToVideo + MiniMaxH3AddGuide(audio @ frame 0).
        use_lipsync = lip_sync
        if use_lipsync:
            use_turbo = False  # keep lip-sync path simple / stable
            template = "minimax_h3_i2v_lipsync.json"
            catalog_id = "minimax-h3-i2v"
        else:
            template = "minimax_h3_i2v_turbo.json" if use_turbo else "minimax_h3_i2v.json"
            catalog_id = "minimax-h3-i2v-turbo" if use_turbo else "minimax-h3-i2v"
        try:
            prompt = copy.deepcopy(_load_template(template))
        except FileNotFoundError:
            if use_lipsync:
                raise RuntimeError(
                    "MiniMax lip-sync workflow missing "
                    "(workflows/minimax_h3_i2v_lipsync.json)."
                )
            if use_turbo:
                prompt = copy.deepcopy(_load_template("minimax_h3_i2v.json"))
                use_turbo = False
                catalog_id = "minimax-h3-i2v"
            else:
                raise

        resolved = resolve_model_files("minimax-h3-i2v", inv)
        if "diffusion_models" not in resolved:
            dm = inv.get("diffusion_models") or []
            hit = next(
                (x for x in dm if "fl2va" in x.lower() and "minimax" in x.lower()),
                None,
            ) or (dm[0] if dm else None)
            if not hit:
                raise RuntimeError("No MiniMax / diffusion video model found in ComfyUI.")
            resolved["diffusion_models"] = hit
        if "text_encoders" not in resolved:
            te = inv.get("text_encoders") or []
            if not te:
                raise RuntimeError("No MiniMax text encoder found.")
            resolved["text_encoders"] = te[0]
        if "vae" not in resolved:
            vaes = inv.get("vae") or []
            video_vae = next(
                (
                    v
                    for v in vaes
                    if "video" in v.lower() and "minimax" in v.lower()
                ),
                None,
            ) or next((v for v in vaes if "minimax" in v.lower() and "audio" not in v.lower()), None)
            if not video_vae:
                raise RuntimeError("No MiniMax video VAE found.")
            resolved["vae"] = video_vae

        audio_vae = _resolve_audio_vae(inv)
        if not audio_vae:
            log.warning(
                "MiniMax audio VAE not found (minimax_h3_audio_vae_fp32.safetensors). "
                "Clips will be silent until it is installed in ComfyUI/models/vae/."
            )
        if use_lipsync and not audio_vae:
            raise RuntimeError(
                "MiniMax lip sync needs minimax_h3_audio_vae_fp32.safetensors "
                "in ComfyUI/models/vae/."
            )
        if use_lipsync and not audio_comfy_name:
            raise RuntimeError(
                "MiniMax lip sync needs an audio input for this shot. "
                "Add a project track, or turn off Lip sync for plain I2V."
            )

        turbo_lora = _resolve_turbo_lora(inv) if use_turbo else None
        if use_turbo and not turbo_lora:
            log.warning("Turbo requested but FastLoRA missing — falling back to standard I2V")
            use_turbo = False
            catalog_id = "minimax-h3-i2v"
            prompt = copy.deepcopy(_load_template("minimax_h3_i2v.json"))

        low_vram = False
        try:
            from . import app_settings_store

            low_vram = bool(app_settings_store.load_user_settings().get("optimize_low_vram"))
        except Exception:
            pass

        # Frame length at 24fps, snap UP to MiniMax 17k+5 grid (same as Comfy template math).
        # Max 15s per clip (same for plain I2V and lip-sync — do not shorten lip-sync).
        MAX_CLIP_SEC = 15.0
        fps = max(1, int(settings_vid.fps or 24))
        dur_sec = float(settings_vid.duration_sec or 5.0)
        if dur_sec <= 0:
            dur_sec = 5.0
        if dur_sec > MAX_CLIP_SEC:
            log.warning("Video duration %.2fs clamped to %.0fs max", dur_sec, MAX_CLIP_SEC)
            dur_sec = MAX_CLIP_SEC
        settings_vid.duration_sec = dur_sec
        # Official: max(5, round(sec*24)) then pad so (length - 5) % 17 == 0
        frames = max(5, int(round(dur_sec * fps)))
        rem = (frames - 5) % 17
        if rem != 0:
            frames = frames + (17 - rem)
        max_frames = 5 + 17 * int((MAX_CLIP_SEC * fps - 5) // 17)
        length = min(frames, max(5, max_frames))
        # Resolutions (16:9, multiple of 32) — same for plain I2V and lip-sync:
        #   Normal: draft ~540p (960x544), final ~720p (1280x720)
        #   Low VRAM: draft 768x432, final ~540p (960x544)
        is_draft = (settings_vid.quality or "draft") == "draft"
        if use_turbo:
            steps = 4 if is_draft else 8
            lora_strength = 1.2
        else:
            # 20 steps is overkill on MiniMax for most shots (barely visible vs 8).
            # Draft always 8; final 12 normally / 8 on low VRAM.
            if low_vram:
                steps = 8
            else:
                steps = 8 if is_draft else 12
            lora_strength = 1.0

        # MiniMax H3 requires multiples of 32 (CANVAS_MULTIPLE). 768×432 is INVALID
        # (432 % 32 != 0) and crashes sampling with a reshape error — especially lip-sync.
        if low_vram:
            if is_draft:
                width, height = 736, 416  # official ~0.3MP 16:9
            else:
                width, height = 960, 544  # official ~0.5MP 16:9
        else:
            if is_draft:
                width, height = 960, 544
            else:
                width, height = 1280, 704  # 720 is not ÷32; 704 keeps ~720p canvas
        width = max(32, int(round(int(width) / 32) * 32))
        height = max(32, int(round(int(height) / 32) * 32))

        seed = _random_seed(settings_vid.seed)
        anim = (settings_vid.animation_prompt or "").strip()
        if use_lipsync:
            # FL2VA first-frame lock + audio guide. Keep prompts simple (like LTX).
            if not anim:
                anim = (
                    "performer sings into the camera, mouth opens and closes with the "
                    "vocals, natural head motion, camera mostly steady"
                )
        else:
            if not anim:
                anim = "subtle cinematic motion, natural ambient sound"
            if (
                "audio" not in anim.lower()
                and "sound" not in anim.lower()
                and "sfx" not in anim.lower()
            ):
                anim = f"{anim.rstrip('.')}. Soft natural ambient audio matching the scene"
        if settings_vid.camera_movement and settings_vid.camera_movement != "none":
            anim = f"{anim}, camera: {settings_vid.camera_movement}"

        _set_input(prompt, "1", "unet_name", resolved["diffusion_models"])
        _set_input(prompt, "2", "clip_name", resolved["text_encoders"])
        _set_input(prompt, "2", "type", "minimax")
        _set_input(prompt, "3", "vae_name", resolved["vae"])
        if audio_vae and "13" in prompt:
            _set_input(prompt, "13", "vae_name", audio_vae)
        elif not audio_vae and "13" in prompt:
            prompt.pop("13", None)
            prompt.pop("14", None)
            if "11" in prompt and "audio" in prompt["11"].get("inputs", {}):
                del prompt["11"]["inputs"]["audio"]
        _set_input(prompt, "4", "image", image_comfy_name)
        # Always first-frame I2V on FL2VA paths (plain + lip-sync)
        if "5" in prompt and prompt["5"].get("class_type") == "MiniMaxH3ImageToVideo":
            prompt["5"]["inputs"]["first_frame"] = ["4", 0]
        if use_lipsync:
            _set_input(prompt, "6", "audio", audio_comfy_name)
            # AddGuide anchors the project-audio slice at frame 0 → drives mouth
            if "18" in prompt:
                prompt["18"]["inputs"]["positive"] = ["5", 0]
                prompt["18"]["inputs"]["latent"] = ["5", 1]
                prompt["18"]["inputs"]["audio"] = ["6", 0]
                prompt["18"]["inputs"]["audio_vae"] = ["13", 0]
                prompt["18"]["inputs"]["frame_idx"] = 0
                # Guider must read AddGuide conditioning (not raw ImageToVideo)
                if "16" in prompt:
                    prompt["16"]["inputs"]["conditioning"] = ["18", 0]
        _set_input(prompt, "5", "prompt", anim)
        _set_input(prompt, "5", "width", width)
        _set_input(prompt, "5", "height", height)
        _set_input(prompt, "5", "length", length)
        # Match Comfy job 4127ce8c: RandomNoise + BasicScheduler + res_multistep
        _set_input(prompt, "15", "noise_seed", seed)
        _set_input(prompt, "9", "steps", steps)
        _set_input(prompt, "17", "sampler_name", "res_multistep")
        _set_input(prompt, "11", "fps", fps)
        _set_input(prompt, "12", "filename_prefix", filename_prefix)

        if use_turbo and turbo_lora and "20" in prompt:
            _set_input(prompt, "20", "lora_name", turbo_lora)
            _set_input(prompt, "20", "strength_model", lora_strength)
            prompt["20"]["inputs"]["model"] = ["1", 0]
            prompt["16"]["inputs"]["model"] = ["20", 0]
            prompt["9"]["inputs"]["model"] = ["20", 0]
            log.info(
                "MiniMax turbo FastLoRA=%s strength=%.2f steps=%d",
                turbo_lora,
                lora_strength,
                steps,
            )
        elif "20" in prompt:
            prompt.pop("20", None)
            prompt["16"]["inputs"]["model"] = ["1", 0]
            prompt["9"]["inputs"]["model"] = ["1", 0]

        log.info(
            "Built MiniMax workflow preset=%s lipsync_addguide=%s turbo=%s audio_vae=%s "
            "%sx%s length=%d (%.2fs@%dfps) steps=%d max_clip=%.0fs sampler=res_multistep "
            "low_vram=%s lip_sync=%s first_frame=%s",
            catalog_id,
            use_lipsync,
            use_turbo,
            bool(audio_vae),
            width,
            height,
            length,
            length / float(fps),
            fps,
            steps,
            MAX_CLIP_SEC,
            low_vram,
            lip_sync,
            image_comfy_name,
        )
        return prompt

    # ---- Wan 2.1 Image-to-Video (real still → motion) ----
    if (
        "i2v" in preset.lower()
        or preset in ("wan21-i2v-480p", "wan21-i2v", "wan-i2v")
        or (preset.startswith("wan") and "fun" not in preset.lower())
    ):
        prompt = copy.deepcopy(_load_template("wan21_i2v_480p.json"))
        resolved = resolve_model_files("wan21-i2v-480p", inv)
        if "diffusion_models" not in resolved:
            raise RuntimeError(
                "Wan I2V model missing. Put wan2.1_i2v_480p_14B_fp8_scaled.safetensors "
                "in ComfyUI/models/diffusion_models/"
            )
        if "text_encoders" not in resolved:
            raise RuntimeError(
                "Wan text encoder missing (umt5_xxl_fp8_e4m3fn_scaled.safetensors)."
            )
        if "vae" not in resolved:
            raise RuntimeError("Wan VAE missing (wan_2.1_vae.safetensors).")
        clip_v = resolved.get("clip_vision")
        if not clip_v:
            cvs = inv.get("clip_vision") or []
            clip_v = next((c for c in cvs if "clip_vision_h" in c.lower()), None)
        if not clip_v:
            raise RuntimeError("Wan CLIP Vision missing (clip_vision_h.safetensors).")

        is_draft = (settings_vid.quality or "draft") == "draft"
        fps = max(8, min(24, int(settings_vid.fps or 16)))
        if fps == 24:
            fps = 16
        dur_sec = float(settings_vid.duration_sec or 5.0)
        if dur_sec <= 0:
            dur_sec = 5.0
        MAX_CLIP_SEC = 15.0
        if dur_sec > MAX_CLIP_SEC:
            log.warning("Wan I2V duration %.2fs clamped to %.0fs max", dur_sec, MAX_CLIP_SEC)
            dur_sec = MAX_CLIP_SEC
        settings_vid.duration_sec = dur_sec

        frames = max(5, int(round(dur_sec * fps)))
        rem = (frames - 1) % 4
        if rem != 0:
            frames = frames + (4 - rem)
        length = frames

        # Wan 480p family — native size for this model
        width, height = 832, 480
        # LightX2V / FastWan-style 4-step distill when LoRA is present
        fast_lora = _resolve_wan_fast_lora(inv)
        if fast_lora:
            steps = 4
            cfg = 1.0
        elif is_draft:
            steps = 12
            cfg = 6.0
        else:
            steps = 20
            cfg = 6.0

        anim = (settings_vid.animation_prompt or "").strip() or (
            "subtle natural motion, fabric and hair move lightly, cinematic"
        )
        seed = _random_seed(settings_vid.seed)
        neg = (
            "static, blurry, low quality, deformed, watermark, text, "
            "frozen, still frame, no motion, jitter, morphing faces, extra limbs"
        )

        _set_input(prompt, "37", "unet_name", resolved["diffusion_models"])
        _set_input(prompt, "38", "clip_name", resolved["text_encoders"])
        _set_input(prompt, "39", "vae_name", resolved["vae"])
        _set_input(prompt, "49", "clip_name", clip_v)
        _set_input(prompt, "52", "image", image_comfy_name)
        _set_input(prompt, "6", "text", anim)
        _set_input(prompt, "7", "text", neg)
        _set_input(prompt, "50", "width", width)
        _set_input(prompt, "50", "height", height)
        _set_input(prompt, "50", "length", length)
        _set_input(prompt, "54", "shift", 8.0)
        _set_input(prompt, "3", "seed", seed)
        _set_input(prompt, "3", "steps", steps)
        _set_input(prompt, "3", "cfg", cfg)
        _set_input(prompt, "55", "fps", fps)
        _set_input(prompt, "56", "filename_prefix", filename_prefix)

        if fast_lora and "20" in prompt:
            _set_input(prompt, "20", "lora_name", fast_lora)
            _set_input(prompt, "20", "strength_model", 1.0)
            prompt["20"]["inputs"]["model"] = ["37", 0]
            prompt["54"]["inputs"]["model"] = ["20", 0]
            log.info("Wan LightX2V/FastWan LoRA=%s steps=%d", fast_lora, steps)
        elif "20" in prompt:
            prompt.pop("20", None)
            prompt["54"]["inputs"]["model"] = ["37", 0]

        log.info(
            "Built Wan I2V 480p workflow %sx%s length=%d (%.2fs@%dfps) steps=%d fast_lora=%s",
            width,
            height,
            length,
            length / float(fps),
            fps,
            steps,
            bool(fast_lora),
        )
        return prompt

    raise RuntimeError(f"Unknown video preset: {preset}")


def list_video_presets() -> list[dict[str, Any]]:
    path = settings.workflows_dir / "presets.json"
    if path.exists():
        with open(path, "r", encoding="utf-8") as f:
            presets = json.load(f).get("video_presets", [])
    else:
        presets = [
            {
                "id": "minimax-h3-i2v",
                "label": "MiniMax H3 Image-to-Video",
                "controls": [
                    "animation_prompt",
                    "duration",
                    "fps",
                    "motion_strength",
                    "camera_movement",
                    "seed",
                    "resolution",
                    "quality",
                ],
            }
        ]
    # Hide FastLoRA turbo option under 12 GB so users can't pick a thrash path
    if not turbo_allowed_for_vram():
        presets = [
            p
            for p in presets
            if "turbo" not in str(p.get("id", "")).lower()
            and "fastlora" not in str(p.get("label", "")).lower()
        ]
    return presets


async def list_video_presets_installed() -> list[dict[str, Any]]:
    """Presets that are fully installed (or always-shown with available flag)."""
    from .models_detect import detect_models

    info = await detect_models()
    avail = {
        m["model_id"]: bool(m.get("available"))
        for m in (info.get("models") or [])
        if isinstance(m, dict)
    }
    # detect_models returns ModelStatus objects sometimes — normalize
    if not avail and info.get("models"):
        for m in info["models"]:
            mid = getattr(m, "model_id", None) or (m.get("model_id") if isinstance(m, dict) else None)
            av = getattr(m, "available", None)
            if av is None and isinstance(m, dict):
                av = m.get("available")
            if mid:
                avail[mid] = bool(av)
    out = []
    for p in list_video_presets():
        pid = str(p.get("id") or "")
        installed = bool(avail.get(pid, False))
        # MiniMax turbo shares base files with standard; treat turbo available if listed
        if not installed and pid.startswith("minimax"):
            installed = bool(avail.get("minimax-h3-i2v", False))
            if "turbo" in pid:
                installed = bool(avail.get("minimax-h3-i2v-turbo", False))
        item = dict(p)
        item["available"] = installed
        out.append(item)
    return out
