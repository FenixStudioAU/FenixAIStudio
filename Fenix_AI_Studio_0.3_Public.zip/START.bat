@echo off
setlocal EnableExtensions EnableDelayedExpansion
title Fenix AI Studio — KEEP THIS WINDOW OPEN
cd /d "%~dp0"

echo.
echo   ============================================
echo     Fenix AI Studio  (portable)
echo   ============================================
echo.
echo   KEEP THIS WINDOW OPEN while you work.
echo   Closing it stops the studio server.
echo   Logs: logs\app.log
echo.

set "PORT=7865"
set "LANIP="
for /f "tokens=2 delims=:" %%a in ('ipconfig ^| findstr /c:"IPv4 Address"') do (
  if not defined LANIP set "LANIP=%%a"
)
if defined LANIP set "LANIP=%LANIP: =%"

echo   Local:   http://127.0.0.1:%PORT%/
if defined LANIP echo   LAN:     http://%LANIP%:%PORT%/
echo   ComfyUI: http://127.0.0.1:8188/  (your install — set path in Settings)
echo   Ollama:  http://127.0.0.1:11434/
echo.

REM ---------- Find Python from PATH (never hard-code a folder) ----------
set "SYSPY="
where python >nul 2>&1 && set "SYSPY=python"
if not defined SYSPY (
  where py >nul 2>&1 && set "SYSPY=py -3"
)
if not defined SYSPY (
  echo ERROR: No Python on PATH.
  echo   Install Python 3.10+ from https://www.python.org/downloads/
  echo   Tick "Add python.exe to PATH", then open a NEW terminal and run START.bat again.
  pause
  exit /b 1
)

echo   System Python: 
%SYSPY% --version
if errorlevel 1 (
  echo ERROR: Could not run Python from PATH.
  pause
  exit /b 1
)

REM ---------- Validate / rebuild venv (copied venvs break across machines) ----------
set "NEED_VENV=0"
if not exist "venv\Scripts\python.exe" set "NEED_VENV=1"

if "%NEED_VENV%"=="0" (
  REM Does this venv actually run? (broken if pyvenv.cfg points at another PC's Python)
  "venv\Scripts\python.exe" -c "import sys" >nul 2>&1
  if errorlevel 1 (
    echo.
    echo   Existing venv is broken — usually because this folder was copied from
    echo   another machine. Windows venvs remember the OLD Python path.
    echo   Rebuilding venv with THIS machine's Python from PATH...
    echo.
    set "NEED_VENV=1"
    rmdir /s /q "venv" 2>nul
  )
)

if "%NEED_VENV%"=="1" (
  echo Creating virtual environment in .\venv  ...
  %SYSPY% -m venv venv
  if errorlevel 1 (
    echo ERROR: python -m venv failed.
    pause
    exit /b 1
  )
  echo Installing dependencies...
  "venv\Scripts\python.exe" -m pip install --upgrade pip
  "venv\Scripts\python.exe" -m pip install -r requirements.txt
  if errorlevel 1 (
    echo ERROR: pip install failed.
    pause
    exit /b 1
  )
  echo   venv ready.
  echo.
)

REM Always launch with the package-local venv (built from PATH Python on this PC)
set "APP_PY=%~dp0venv\Scripts\python.exe"
if not exist "%APP_PY%" (
  echo ERROR: venv python missing after setup: %APP_PY%
  pause
  exit /b 1
)

REM ---------- Already running? ----------
powershell -NoProfile -Command "try { Invoke-WebRequest -Uri 'http://127.0.0.1:%PORT%/api/health' -UseBasicParsing -TimeoutSec 2 | Out-Null; Write-Host 'Studio already running. Opening browser in 10s...'; Start-Sleep -Seconds 10; Start-Process 'http://127.0.0.1:%PORT%/'; exit 0 } catch { exit 1 }"
if not errorlevel 1 (
  echo.
  echo   Studio is already up. This window can stay open as a reminder,
  echo   or close it — the existing server keeps running.
  pause
  exit /b 0
)

REM ---------- Optional ComfyUI auto-start (from Settings only — no hard-coded drives) ----------
powershell -NoProfile -Command ^
  "$comfy = 'http://127.0.0.1:8188'; $script = ''; $settings = Join-Path '%~dp0' 'settings\user_settings.json'; if (Test-Path $settings) { try { $j = Get-Content $settings -Raw | ConvertFrom-Json; if ($j.comfy_url) { $comfy = [string]$j.comfy_url }; if ($j.comfy_start_script) { $script = [string]$j.comfy_start_script } } catch {} }; try { Invoke-WebRequest -Uri ($comfy.TrimEnd('/') + '/system_stats') -UseBasicParsing -TimeoutSec 3 | Out-Null; Write-Host 'ComfyUI is online.' } catch { Write-Host 'ComfyUI not responding.'; if ($script -and (Test-Path $script)) { Write-Host ('Starting Comfy from Settings: ' + $script); Start-Process -FilePath $script } else { Write-Host 'Set Comfy start script in Settings, or start ComfyUI yourself.' } }"

REM Refresh PATH for ffmpeg etc.
for /f "tokens=2*" %%A in ('reg query "HKLM\SYSTEM\CurrentControlSet\Control\Session Manager\Environment" /v Path 2^>nul') do set "MACHPATH=%%B"
for /f "tokens=2*" %%A in ('reg query "HKCU\Environment" /v Path 2^>nul') do set "USERPATH=%%B"
if defined MACHPATH set "PATH=%MACHPATH%;%USERPATH%;%PATH%"

echo Starting backend (LAN-accessible)...
echo   Press Ctrl+C to stop the server.
echo   Browser opens in 10 seconds (gives the server time to boot)...
echo.
start "" cmd /c "timeout /t 10 /nobreak >nul & start http://127.0.0.1:%PORT%/"
"%APP_PY%" -m uvicorn backend.main:app --host 0.0.0.0 --port %PORT%
set "EC=%ERRORLEVEL%"
echo.
if "%EC%"=="0" (
  echo Server stopped normally.
) else (
  echo Server exited with code %EC%.
)
echo.
pause
endlocal
