# Fenix Studio

Fenix Studio is a portable, zero-build browser DAW. It is plain HTML, CSS, and JavaScript: no package manager, framework, database server, PHP runtime, or command-line setup is required.

## Put it on Apache

Copy the entire `fenix-daw` folder into any Apache document root or virtual host, then open `index.html` through the site URL. Keep all files together. The included `.htaccess` only adds safe MIME, cache, compression, and permission headers; the app still works on hosts that ignore it.

The app can also be opened directly from `index.html`. Direct `file://` mode supports editing and IndexedDB autosave in browsers that allow it, but microphone/MIDI permissions, Web Workers, and the offline service worker are most reliable over `https://` or local `http://`.

## What is implemented

- Four-track starting project, expandable to eight audio, input, MIDI/instrument, or aux tracks.
- Browser audio import, drag-and-drop placement, waveform analysis in a Worker, and IndexedDB source storage.
- Musical timeline with BPM, time signatures, snap, zoom, markers, loop range, seek, and metronome.
- Non-destructive clip move, cross-track move, edge trim, split, duplicate, delete, fades, loop, gain, mute, lock, reverse, transpose, and playback-rate controls.
- Undo/redo snapshots and debounced IndexedDB autosave.
- Single-context Web Audio graph with per-track gain, three-band EQ, compressor, fader, stereo pan, mute/solo, reverb send, delay send, metering, and master limiter.
- Microphone selection, permission flow, record-arm, MediaRecorder capture, and automatic take placement.
- MIDI clips, piano-roll note entry, a built-in subtractive-style oscillator voice, and optional Web MIDI live input.
- OfflineAudioContext WAV mix and individual stem export at 44.1/48 kHz and 16/24-bit PCM.
- Portable `.fenixdaw` project download/open including available local source blobs.
- Offline shell caching when served over HTTP(S).

## Browser capability notes

Use a current desktop Chromium browser for the broadest codec, MIDI, microphone, and storage support. Firefox and Safari support the core editor and Web Audio features but differ in accepted import/recording codecs and Web MIDI availability. Fenix detects APIs at runtime and reports them under Settings.

Imported and recorded audio stays in that browser profile's IndexedDB unless you download a `.fenixdaw` project file. Clearing site data removes those local sources. Large projects are limited by browser storage quota and available memory. The app does not claim VST/AU support, sample-accurate hardware synchronization, or zero latency.

## Static file map

- `index.html` — complete application shell and dialogs.
- `styles.css` — responsive production UI and timeline/mixer styling.
- `app.js` — project model, editor, Web Audio engine, persistence, MIDI, recording, and export.
- `waveform-worker.js` — background peak analysis.
- `sw.js` — offline shell cache.
- `manifest.webmanifest` — installable web-app metadata.
- `.htaccess` — optional Apache hardening and MIME rules.

