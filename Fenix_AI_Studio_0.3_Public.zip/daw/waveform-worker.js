"use strict";

self.onmessage = event => {
  const { id, samples, buckets = 1200 } = event.data || {};
  try {
    if (!(samples instanceof Float32Array)) throw new Error("Waveform samples were unavailable.");
    const size = Math.max(1, Math.floor(samples.length / buckets));
    const peaks = new Array(buckets);
    for (let bucket = 0; bucket < buckets; bucket++) {
      let peak = 0;
      const start = bucket * size;
      const end = Math.min(samples.length, start + size);
      for (let i = start; i < end; i++) peak = Math.max(peak, Math.abs(samples[i]));
      peaks[bucket] = Math.round(peak * 10000) / 10000;
    }
    self.postMessage({ id, peaks });
  } catch (error) {
    self.postMessage({ id, error: error.message || "Waveform analysis failed." });
  }
};

