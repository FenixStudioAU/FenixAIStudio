(() => {
  "use strict";

  const PPQ = 960;
  const MAX_TRACKS = 8;
  const DEFAULT_BARS = 32;
  const DB_NAME = "fenix-studio";
  const DB_VERSION = 1;
  const TRACK_COLORS = ["#2f96ff", "#e34b58", "#8c63ff", "#27c98a", "#f2a32b", "#e260c7", "#3fc3d6", "#a9c34b"];
  const $ = (selector, root = document) => root.querySelector(selector);
  const $$ = (selector, root = document) => [...root.querySelectorAll(selector)];
  const clamp = (value, min, max) => Math.min(max, Math.max(min, value));
  const uid = (prefix = "id") => `${prefix}_${Date.now().toString(36)}_${Math.random().toString(36).slice(2, 8)}`;
  const deepClone = value => JSON.parse(JSON.stringify(value));
  const dbToGain = db => Math.pow(10, db / 20);
  const gainToDb = gain => gain <= 0.00001 ? -Infinity : 20 * Math.log10(gain);
  const beatsToTicks = beats => Math.round(beats * PPQ);
  const ticksToBeats = ticks => ticks / PPQ;
  const beatsToSeconds = beats => beats * 60 / state.project.bpm;
  const secondsToBeats = seconds => seconds * state.project.bpm / 60;
  const projectBeats = () => Math.max(DEFAULT_BARS * state.project.timeSignature.numerator, ...state.project.tracks.flatMap(track => track.clips.map(clip => ticksToBeats(clip.startTick + clip.durationTicks) + 2)), state.project.loop.endBeat + 2);
  const pxPerBeat = () => state.ui.zoom;
  const beatToPx = beat => beat * pxPerBeat();
  const pxToBeat = px => px / pxPerBeat();
  const snapBeat = beat => {
    if (!state.ui.snap) return Math.max(0, beat);
    const adaptive = state.ui.zoom < 48 ? 2 : state.ui.zoom < 80 ? 1 : state.ui.zoom < 130 ? 0.5 : 0.25;
    const grid = state.ui.grid === "adaptive" ? adaptive : Number(state.ui.grid);
    return Math.max(0, Math.round(beat / grid) * grid);
  };
  const formatTime = seconds => {
    seconds = Math.max(0, Number.isFinite(seconds) ? seconds : 0);
    const mins = Math.floor(seconds / 60);
    const secs = Math.floor(seconds % 60);
    const ms = Math.floor((seconds % 1) * 1000);
    return `${String(mins).padStart(2, "0")}:${String(secs).padStart(2, "0")}.${String(ms).padStart(3, "0")}`;
  };
  const formatBars = beat => {
    const beatsPerBar = state.project.timeSignature.numerator;
    const bar = Math.floor(beat / beatsPerBar) + 1;
    const beatInBar = Math.floor(beat % beatsPerBar) + 1;
    const tick = Math.floor((beat - Math.floor(beat)) * PPQ);
    return `${String(bar).padStart(3, "0")} · ${String(beatInBar).padStart(2, "0")} · ${String(tick).padStart(3, "0")}`;
  };
  const formatDuration = seconds => {
    const mins = Math.floor(seconds / 60);
    const secs = Math.floor(seconds % 60);
    return `${String(mins).padStart(2, "0")}:${String(secs).padStart(2, "0")}`;
  };
  const escapeHtml = value => String(value ?? "").replace(/[&<>"]/g, char => ({"&":"&amp;","<":"&lt;",">":"&gt;","\"":"&quot;"})[char]);

  function createTrack(index, type = "audio") {
    const names = { audio: `Audio ${index + 1}`, mic: `Input ${index + 1}`, midi: `Instrument ${index + 1}`, aux: `Aux ${index + 1}` };
    return {
      id: uid("trk"),
      name: names[type] || `Track ${index + 1}`,
      type,
      color: TRACK_COLORS[index % TRACK_COLORS.length],
      inputGain: 1,
      volume: .82,
      pan: 0,
      mute: false,
      solo: false,
      arm: false,
      monitor: false,
      route: "master",
      sends: { reverb: .12, delay: .08 },
      eq: { low: 0, mid: 0, high: 0 },
      compressor: { threshold: -16, ratio: 3 },
      effects: { eq: true, compressor: true },
      automation: { volume: [], pan: [], reverb: [], delay: [] },
      clips: []
    };
  }

  function createProject(name = "Untitled Session") {
    const now = new Date().toISOString();
    return {
      id: uid("project"),
      version: 1,
      name,
      createdAt: now,
      updatedAt: now,
      bpm: 120,
      timeSignature: { numerator: 4, denominator: 4 },
      displayMode: "bars",
      loop: { enabled: false, startBeat: 0, endBeat: 16 },
      punch: { enabled: false, startBeat: 0, endBeat: 8 },
      markers: [
        { id: uid("mark"), beat: 0, name: "INTRO" },
        { id: uid("mark"), beat: 16, name: "VERSE" },
        { id: uid("mark"), beat: 32, name: "CHORUS" }
      ],
      tracks: [0, 1, 2, 3].map(index => createTrack(index)),
      assets: [],
      buses: [
        { id: "reverb", name: "REVERB", volume: .5, mute: false },
        { id: "delay", name: "DELAY", volume: .42, mute: false }
      ],
      master: { volume: .86, limiter: true },
      uiState: { zoom: 72 }
    };
  }

  const state = {
    project: createProject(),
    ui: {
      selectedTrackId: null,
      selectedClipIds: new Set(),
      inspectorTab: "track",
      assetTab: "all",
      tool: "select",
      zoom: 72,
      grid: .5,
      snap: true,
      ripple: false,
      automation: false,
      compact: false,
      wideMixer: false,
      playheadBeat: 0,
      range: null,
      dragging: null,
      dirty: false
    },
    history: { undo: [], redo: [], lastLabel: "" },
    audio: {
      ctx: null,
      masterInput: null,
      masterGain: null,
      limiter: null,
      analyser: null,
      reverbInput: null,
      delayInput: null,
      trackNodes: new Map(),
      buffers: new Map(),
      reverseBuffers: new Map(),
      sources: [],
      scheduled: new Set(),
      scheduler: null,
      animation: null,
      isPlaying: false,
      anchorBeat: 0,
      anchorTime: 0,
      meterData: null,
      lastVisualTime: 0,
      recording: null,
      stream: null
    },
    db: null,
    saveTimer: null,
    waveformWorker: null,
    liveMidi: new Map(),
    selfTest: null
  };

  function getTrack(id) { return state.project.tracks.find(track => track.id === id); }
  function getClip(id) {
    for (const track of state.project.tracks) {
      const clip = track.clips.find(item => item.id === id);
      if (clip) return { clip, track };
    }
    return null;
  }
  function selectedClip() {
    const id = state.ui.selectedClipIds.values().next().value;
    return id ? getClip(id) : null;
  }
  function activeTrack() { return getTrack(state.ui.selectedTrackId) || state.project.tracks[0]; }
  function isTypingTarget(target) { return /^(INPUT|TEXTAREA|SELECT)$/.test(target?.tagName) || target?.isContentEditable; }

  async function openDatabase() {
    if (!window.indexedDB) return null;
    return new Promise((resolve, reject) => {
      const request = indexedDB.open(DB_NAME, DB_VERSION);
      request.onupgradeneeded = () => {
        const db = request.result;
        if (!db.objectStoreNames.contains("projects")) db.createObjectStore("projects", { keyPath: "id" });
        if (!db.objectStoreNames.contains("assets")) db.createObjectStore("assets", { keyPath: "id" });
        if (!db.objectStoreNames.contains("settings")) db.createObjectStore("settings", { keyPath: "key" });
      };
      request.onsuccess = () => resolve(request.result);
      request.onerror = () => reject(request.error);
    });
  }

  function dbRequest(storeName, mode, operation) {
    if (!state.db) return Promise.resolve(null);
    return new Promise((resolve, reject) => {
      const tx = state.db.transaction(storeName, mode);
      const store = tx.objectStore(storeName);
      let request;
      try { request = operation(store); } catch (error) { reject(error); return; }
      if (request) {
        request.onsuccess = () => resolve(request.result);
        request.onerror = () => reject(request.error);
      } else {
        tx.oncomplete = () => resolve(true);
      }
      tx.onerror = () => reject(tx.error);
    });
  }

  const dbGet = (store, key) => dbRequest(store, "readonly", objectStore => objectStore.get(key));
  const dbPut = (store, value) => dbRequest(store, "readwrite", objectStore => objectStore.put(value));
  const dbDelete = (store, key) => dbRequest(store, "readwrite", objectStore => objectStore.delete(key));
  const dbAll = store => dbRequest(store, "readonly", objectStore => objectStore.getAll());

  async function saveProjectNow() {
    if (!state.db) return;
    state.project.updatedAt = new Date().toISOString();
    state.project.uiState = { zoom: state.ui.zoom };
    try {
      await dbPut("projects", deepClone(state.project));
      await dbPut("settings", { key: "lastProjectId", value: state.project.id });
      state.ui.dirty = false;
      updateSaveState("saved");
      updateStorageEstimate();
    } catch (error) {
      console.error(error);
      updateSaveState("error");
      toast("Autosave failed", "Your work remains open in this tab. Check browser storage permissions or available space.", "error");
    }
  }

  function markDirty(label = "Edit") {
    state.ui.dirty = true;
    updateSaveState("dirty");
    clearTimeout(state.saveTimer);
    state.saveTimer = setTimeout(saveProjectNow, 700);
    state.history.lastLabel = label;
  }

  function snapshot(label) {
    state.history.undo.push({ label, project: deepClone(state.project) });
    if (state.history.undo.length > 60) state.history.undo.shift();
    state.history.redo.length = 0;
    updateUndoButtons();
  }

  function undo() {
    const item = state.history.undo.pop();
    if (!item) return;
    state.history.redo.push({ label: item.label, project: deepClone(state.project) });
    state.project = item.project;
    reconcileSelection();
    rebuildAudioGraph();
    renderAll();
    markDirty(`Undo ${item.label}`);
    updateUndoButtons();
  }

  function redo() {
    const item = state.history.redo.pop();
    if (!item) return;
    state.history.undo.push({ label: item.label, project: deepClone(state.project) });
    state.project = item.project;
    reconcileSelection();
    rebuildAudioGraph();
    renderAll();
    markDirty(`Redo ${item.label}`);
    updateUndoButtons();
  }

  function reconcileSelection() {
    if (!getTrack(state.ui.selectedTrackId)) state.ui.selectedTrackId = state.project.tracks[0]?.id || null;
    state.ui.selectedClipIds = new Set([...state.ui.selectedClipIds].filter(id => getClip(id)));
  }

  function updateUndoButtons() {
    const undoBtn = $("#undoBtn");
    const redoBtn = $("#redoBtn");
    undoBtn.disabled = !state.history.undo.length;
    redoBtn.disabled = !state.history.redo.length;
    undoBtn.title = state.history.undo.length ? `Undo ${state.history.undo.at(-1).label} (Ctrl/Cmd+Z)` : "Nothing to undo";
    redoBtn.title = state.history.redo.length ? `Redo ${state.history.redo.at(-1).label} (Ctrl/Cmd+Shift+Z)` : "Nothing to redo";
  }

  function updateSaveState(mode) {
    const element = $("#saveState");
    element.className = `save-state ${mode === "saved" ? "" : mode}`;
    element.lastChild.textContent = mode === "dirty" ? " Autosaving…" : mode === "error" ? " Save error" : " Saved locally";
  }

  function toast(title, message = "", type = "info", timeout = 4200) {
    const node = document.createElement("div");
    node.className = `toast ${type}`;
    node.innerHTML = `<span><strong>${escapeHtml(title)}</strong>${message ? `<small>${escapeHtml(message)}</small>` : ""}</span><button aria-label="Dismiss">×</button>`;
    node.querySelector("button").onclick = () => node.remove();
    $("#toastRegion").append(node);
    if (timeout) setTimeout(() => node.remove(), timeout);
  }

  function setStatus(text, mode = "ready") {
    $("#statusText").textContent = text;
    $("#statusLed").className = `status-led ${mode}`;
  }

  function openDialog(dialog) {
    $("#contextMenu").classList.add("hidden");
    if (!dialog.open) dialog.showModal();
  }

  function closeAllMenus() { $("#contextMenu").classList.add("hidden"); }

  function renderAll() {
    document.documentElement.style.setProperty("--lane-h", state.ui.compact ? "72px" : "108px");
    $("#projectName").value = state.project.name;
    $("#bpmInput").value = Number(state.project.bpm.toFixed(1));
    $("#timeSignatureSelect").value = `${state.project.timeSignature.numerator}/${state.project.timeSignature.denominator}`;
    $("#loopBtn").classList.toggle("active", state.project.loop.enabled);
    $("#loopBtn").setAttribute("aria-pressed", String(state.project.loop.enabled));
    $("#punchBtn").classList.toggle("active", Boolean(state.project.punch?.enabled));
    $("#punchBtn").setAttribute("aria-pressed", String(Boolean(state.project.punch?.enabled)));
    $("#snapBtn").classList.toggle("active", state.ui.snap);
    $("#snapBtn").setAttribute("aria-pressed", String(state.ui.snap));
    $("#automationBtn").classList.toggle("active", state.ui.automation);
    $("#rippleBtn").classList.toggle("active", state.ui.ripple);
    $("#compactTracksBtn").classList.toggle("active", state.ui.compact);
    $("#zoomRange").value = state.ui.zoom;
    $("#trackLimitLabel").textContent = `${state.project.tracks.length} / ${MAX_TRACKS}`;
    $("#addTrackBtn").disabled = state.project.tracks.length >= MAX_TRACKS;
    renderAssets();
    renderTimeline();
    renderMixer();
    renderInspector();
    updatePositionDisplay();
    updateUndoButtons();
  }

  function renderAssets() {
    const search = $("#assetSearch").value.trim().toLowerCase();
    const assets = state.project.assets.filter(asset => {
      const matchesSearch = !search || asset.name.toLowerCase().includes(search);
      const matchesTab = state.ui.assetTab === "all" || (state.ui.assetTab === "takes" ? asset.source === "recording" : asset.type === state.ui.assetTab);
      return matchesSearch && matchesTab;
    });
    $("#assetCount").textContent = `${state.project.assets.length} asset${state.project.assets.length === 1 ? "" : "s"}`;
    $("#assetList").innerHTML = assets.length ? assets.map(asset => {
      const uses = state.project.tracks.reduce((count, track) => count + track.clips.filter(clip => clip.assetId === asset.id).length, 0);
      const detail = asset.type === "midi" ? "MIDI PATTERN" : `${formatDuration(asset.duration || 0)} · ${asset.sampleRate ? `${Math.round(asset.sampleRate / 100) / 10}K` : "—"} · ${asset.channels || "—"}CH`;
      return `<article class="asset-item ${asset.source === "recording" ? "take" : ""}" draggable="true" data-asset-id="${asset.id}" title="Drag onto a compatible track">
        <div class="asset-type">${asset.type === "midi" ? "♬" : asset.source === "recording" ? "●" : "▰"}</div>
        <div class="asset-meta"><strong>${escapeHtml(asset.name)}</strong><small>${detail}</small></div>
        <span class="usage">${uses}×</span>
      </article>`;
    }).join("") : `<div class="inspector-empty"><div><b>NO ASSETS YET</b><span>Import audio, record a take,<br>or create a MIDI clip.</span></div></div>`;
  }

  function renderTimeline() {
    const width = Math.max($("#timelineViewport").clientWidth || 700, beatToPx(projectBeats()));
    const height = 58 + state.project.tracks.length * (state.ui.compact ? 72 : 108);
    const content = $("#timelineContent");
    content.style.width = `${width}px`;
    content.style.height = `${height}px`;
    const ruler = $("#rulerCanvas");
    ruler.style.width = `${width}px`;
    drawRuler(ruler, width);

    $("#trackHeaders").innerHTML = `<div class="corner-cell"><span>TRACKS</span><button class="micro-button" id="markerBtn">＋ MARKER</button></div>` + state.project.tracks.map((track, index) => trackHeaderHtml(track, index)).join("");
    $("#laneContainer").innerHTML = state.project.tracks.map(track => laneHtml(track)).join("");
    $("#emptyArrangement").classList.toggle("hidden", state.project.tracks.some(track => track.clips.length));
    $$(".clip").forEach(renderClipCanvas);
    renderMarkers();
    updatePlayheadElement();
    renderLoopRange();
    renderSelectionRange();
    syncTrackScroll();
  }

  function trackHeaderHtml(track, index) {
    const typeIcon = { audio: "AUDIO", mic: "INPUT", midi: "MIDI", aux: "AUX" }[track.type] || "AUDIO";
    return `<article class="track-header ${state.ui.selectedTrackId === track.id ? "selected" : ""}" data-track-id="${track.id}">
      <i class="track-color" style="--track-color:${track.color}"></i>
      <div class="track-main">
        <div class="track-topline"><span class="track-number">${String(index + 1).padStart(2, "0")}</span><input class="track-name-input" value="${escapeHtml(track.name)}" maxlength="32" aria-label="Track ${index + 1} name"><span class="track-type-badge">${typeIcon}</span></div>
        <div class="track-buttons">
          <button class="track-mini arm ${track.arm ? "active" : ""}" data-track-action="arm" title="Record arm">R</button>
          <button class="track-mini monitor ${track.monitor ? "active" : ""}" data-track-action="monitor" title="Input monitor">I</button>
          <button class="track-mini mute ${track.mute ? "active" : ""}" data-track-action="mute" title="Mute">M</button>
          <button class="track-mini solo ${track.solo ? "active" : ""}" data-track-action="solo" title="Solo">S</button>
          <button class="track-mini" data-track-action="fx" title="Effects">FX</button>
          <button class="track-mini" data-track-action="menu" title="Track menu">•••</button>
        </div>
        <div class="track-controls"><span>VOL</span><input type="range" min="0" max="1.25" step="0.01" value="${track.volume}" data-track-param="volume"><output>${Math.round(track.volume * 100)}</output></div>
      </div>
      <div class="track-meter" data-meter-track="${track.id}">${Array.from({length: 14}, () => "<i></i>").join("")}</div>
    </article>`;
  }

  function laneHtml(track) {
    const clips = [...track.clips].sort((a, b) => a.startTick - b.startTick).map(clip => clipHtml(clip, track)).join("");
    const major = beatToPx(state.project.timeSignature.numerator);
    const minor = beatToPx(1);
    return `<div class="track-lane ${state.ui.selectedTrackId === track.id ? "selected" : ""}" data-track-id="${track.id}" style="background-size:${major}px 100%, ${minor}px 100%"><span class="lane-label">${track.type.toUpperCase()}</span>${clips}${state.ui.automation ? automationHtml(track) : ""}</div>`;
  }

  function clipHtml(clip, track) {
    const start = beatToPx(ticksToBeats(clip.startTick));
    const width = Math.max(14, beatToPx(ticksToBeats(clip.durationTicks)));
    const classes = ["clip", clip.type === "midi" ? "midi" : "audio", state.ui.selectedClipIds.has(clip.id) ? "selected" : "", clip.muted ? "muted" : "", clip.locked ? "locked" : ""].filter(Boolean).join(" ");
    const fadeInWidth = Math.min(width / 2, beatsToSeconds(ticksToBeats(clip.durationTicks)) ? (clip.fadeIn / beatsToSeconds(ticksToBeats(clip.durationTicks))) * width : 0);
    const fadeOutWidth = Math.min(width / 2, beatsToSeconds(ticksToBeats(clip.durationTicks)) ? (clip.fadeOut / beatsToSeconds(ticksToBeats(clip.durationTicks))) * width : 0);
    return `<article class="${classes}" data-clip-id="${clip.id}" style="left:${start}px;width:${width}px;--clip-color:${clip.color || track.color}" title="${escapeHtml(clip.name)}">
      <div class="clip-header"><strong>${escapeHtml(clip.name)}</strong><span>${clip.type === "midi" ? `${clip.notes?.length || 0} NOTES` : clip.reverse ? "REV" : clip.loop ? "LOOP" : "AUDIO"}</span></div>
      <canvas></canvas><span class="clip-handle left" data-resize="left"></span><span class="clip-handle right" data-resize="right"></span>
      ${clip.type !== "midi" ? `<span class="fade-handle in" title="Fade in"></span><span class="fade-handle out" title="Fade out"></span><i class="fade-line in" style="width:${fadeInWidth}px;transform:rotate(${fadeInWidth ? Math.atan2(58, fadeInWidth) : 0}rad)"></i><i class="fade-line out" style="width:${fadeOutWidth}px;transform:rotate(-${fadeOutWidth ? Math.atan2(58, fadeOutWidth) : 0}rad)"></i>` : ""}
      ${clip.loop ? "<span class=\"loop-hatch\"></span>" : ""}
    </article>`;
  }

  function automationHtml(track) {
    const points = track.automation.volume || [];
    if (!points.length) return "";
    const width = Math.max($("#timelineViewport").clientWidth || 700, beatToPx(projectBeats()));
    const laneHeight = state.ui.compact ? 72 : 108;
    const poly = points.sort((a, b) => a.beat - b.beat).map(point => `${beatToPx(point.beat)},${(1 - point.value / 1.25) * (laneHeight - 12) + 6}`).join(" ");
    const dots = points.map((point, index) => `<i class="automation-point" data-track-id="${track.id}" data-point-index="${index}" style="left:${beatToPx(point.beat)}px;top:${(1 - point.value / 1.25) * (laneHeight - 12) + 6}px"></i>`).join("");
    return `<div class="automation-lane"><svg viewBox="0 0 ${width} ${laneHeight}" preserveAspectRatio="none"><polyline points="${poly}"></polyline></svg>${dots}</div>`;
  }

  function drawRuler(canvas, width) {
    const ctx = canvas.getContext("2d");
    const dpr = Math.max(1, window.devicePixelRatio || 1);
    const cssHeight = 58;
    canvas.width = Math.ceil(width * dpr);
    canvas.height = Math.ceil(cssHeight * dpr);
    canvas.style.width = `${width}px`;
    canvas.style.height = `${cssHeight}px`;
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    ctx.clearRect(0, 0, width, cssHeight);
    ctx.fillStyle = "#0b0e13";
    ctx.fillRect(0, 0, width, cssHeight);
    const beatsPerBar = state.project.timeSignature.numerator;
    const totalBeats = Math.ceil(width / pxPerBeat());
    for (let beat = 0; beat <= totalBeats; beat++) {
      const x = Math.round(beatToPx(beat)) + .5;
      const isBar = beat % beatsPerBar === 0;
      ctx.strokeStyle = isBar ? "#34415b" : "#20293a";
      ctx.beginPath(); ctx.moveTo(x, isBar ? 27 : 40); ctx.lineTo(x, 58); ctx.stroke();
      if (isBar) {
        ctx.fillStyle = "#99a2b5";
        ctx.font = "9px Consolas, monospace";
        ctx.fillText(String(beat / beatsPerBar + 1).padStart(2, "0"), x + 5, 24);
      }
      if (state.ui.zoom >= 90 && !isBar) {
        ctx.fillStyle = "#586176";
        ctx.font = "7px Consolas, monospace";
        ctx.fillText(String((beat % beatsPerBar) + 1), x + 3, 38);
      }
    }
    ctx.fillStyle = "#697186";
    ctx.font = "8px Consolas, monospace";
    ctx.fillText("BARS / BEATS", 9, 12);
  }

  function renderMarkers() {
    $("#markerLayer").innerHTML = state.project.markers.map(marker => `<span class="marker" data-marker-id="${marker.id}" style="left:${beatToPx(marker.beat)}px">${escapeHtml(marker.name)}</span>`).join("");
  }

  function renderLoopRange() {
    const loop = $("#loopRange");
    loop.style.left = `${beatToPx(state.project.loop.startBeat)}px`;
    loop.style.width = `${beatToPx(state.project.loop.endBeat - state.project.loop.startBeat)}px`;
    loop.classList.toggle("hidden", !state.project.loop.enabled);
  }

  function renderSelectionRange() {
    const element = $("#selectionRange");
    if (!state.ui.range) { element.classList.add("hidden"); $("#selectionReadout").textContent = "NO RANGE"; return; }
    const start = Math.min(state.ui.range.start, state.ui.range.end);
    const end = Math.max(state.ui.range.start, state.ui.range.end);
    element.style.left = `${beatToPx(start)}px`;
    element.style.width = `${beatToPx(end - start)}px`;
    element.classList.remove("hidden");
    $("#selectionReadout").textContent = `${formatBars(start)} — ${formatBars(end)}`;
  }

  function renderClipCanvas(element) {
    const hit = getClip(element.dataset.clipId);
    if (!hit) return;
    const { clip, track } = hit;
    const canvas = $("canvas", element);
    const rect = element.getBoundingClientRect();
    const width = Math.max(14, Math.round(rect.width));
    const height = Math.max(18, Math.round(rect.height - 19));
    const dpr = Math.min(2, window.devicePixelRatio || 1);
    canvas.width = width * dpr;
    canvas.height = height * dpr;
    const ctx = canvas.getContext("2d");
    ctx.scale(dpr, dpr);
    ctx.clearRect(0, 0, width, height);
    if (clip.type === "midi") {
      const notes = clip.notes || [];
      const pitches = notes.map(note => note.pitch);
      const minPitch = Math.min(48, ...pitches);
      const maxPitch = Math.max(72, ...pitches);
      ctx.fillStyle = track.color;
      notes.forEach(note => {
        const x = note.start / ticksToBeats(clip.durationTicks) * width;
        const w = Math.max(2, note.duration / ticksToBeats(clip.durationTicks) * width);
        const y = (maxPitch - note.pitch) / Math.max(1, maxPitch - minPitch) * (height - 6) + 2;
        ctx.fillRect(x, y, w, 4);
      });
      return;
    }
    const asset = state.project.assets.find(item => item.id === clip.assetId);
    const peaks = asset?.peaks;
    ctx.strokeStyle = track.color;
    ctx.globalAlpha = .92;
    ctx.lineWidth = 1;
    ctx.beginPath();
    if (peaks?.length) {
      for (let x = 0; x < width; x++) {
        const index = Math.floor(x / width * peaks.length);
        const amplitude = peaks[index] || 0;
        ctx.moveTo(x + .5, height / 2 - amplitude * height * .43);
        ctx.lineTo(x + .5, height / 2 + amplitude * height * .43);
      }
    } else {
      for (let x = 0; x < width; x += 2) {
        const seed = Math.sin((x + clip.id.length * 7) * .17) * .55 + Math.sin(x * .051) * .35;
        const amplitude = .18 + Math.abs(seed) * .68;
        ctx.moveTo(x + .5, height / 2 - amplitude * height * .4);
        ctx.lineTo(x + .5, height / 2 + amplitude * height * .4);
      }
    }
    ctx.stroke();
    ctx.strokeStyle = "rgba(255,255,255,.18)";
    ctx.beginPath(); ctx.moveTo(0, height / 2 + .5); ctx.lineTo(width, height / 2 + .5); ctx.stroke();
  }

  function syncTrackScroll() {
    $("#trackHeaders").scrollTop = $("#timelineViewport").scrollTop;
  }

  function renderMixer() {
    const trackChannels = state.project.tracks.map(track => mixerChannelHtml(track)).join("");
    const busChannels = state.project.buses.map(bus => busChannelHtml(bus)).join("");
    $("#mixerChannels").innerHTML = trackChannels + busChannels + masterChannelHtml();
  }

  function mixerChannelHtml(track) {
    return `<article class="mixer-channel ${state.ui.wideMixer ? "wide" : ""} ${state.ui.selectedTrackId === track.id ? "selected" : ""}" data-mixer-track="${track.id}" style="--track-color:${track.color}">
      <div class="channel-title"><i></i><strong>${escapeHtml(track.name)}</strong></div>
      <div class="channel-insert">EQ ${track.effects.eq ? "ON" : "BYP"} · COMP ${track.effects.compressor ? "ON" : "BYP"}</div>
      <label class="channel-row"><span>REV</span><input type="range" min="0" max="1" step=".01" value="${track.sends.reverb}" data-mixer-param="reverb"></label>
      <label class="channel-row"><span>PAN</span><input type="range" min="-1" max="1" step=".01" value="${track.pan}" data-mixer-param="pan"></label>
      <div class="fader-section"><div class="vertical-meter" data-mixer-meter="${track.id}"><i></i><i></i></div><div class="fader-wrap"><input type="range" min="0" max="1.25" step=".01" value="${track.volume}" data-mixer-param="volume" aria-label="${escapeHtml(track.name)} volume"></div><span class="peak-db">${Number.isFinite(gainToDb(track.volume)) ? gainToDb(track.volume).toFixed(1) : "−∞"}</span></div>
      <div class="channel-buttons"><button class="track-mini mute ${track.mute ? "active" : ""}" data-mixer-action="mute">M</button><button class="track-mini solo ${track.solo ? "active" : ""}" data-mixer-action="solo">S</button><button class="track-mini arm ${track.arm ? "active" : ""}" data-mixer-action="arm">R</button></div>
    </article>`;
  }

  function busChannelHtml(bus) {
    return `<article class="mixer-channel bus ${state.ui.wideMixer ? "wide" : ""}" data-bus-id="${bus.id}" style="--track-color:${bus.id === "reverb" ? "#8c63ff" : "#2f96ff"}">
      <div class="channel-title"><i></i><strong>${escapeHtml(bus.name)}</strong></div><div class="channel-insert">${bus.id === "reverb" ? "CONVOLUTION" : "SYNC DELAY"}</div><div></div><div></div>
      <div class="fader-section"><div class="vertical-meter"><i></i><i></i></div><div class="fader-wrap"><input type="range" min="0" max="1.25" step=".01" value="${bus.volume}" data-bus-param="volume"></div><span class="peak-db">RETURN</span></div>
      <div class="channel-buttons"><button class="track-mini mute ${bus.mute ? "active" : ""}" data-bus-action="mute">M</button></div>
    </article>`;
  }

  function masterChannelHtml() {
    return `<article class="mixer-channel master ${state.ui.wideMixer ? "wide" : ""}" data-master-channel style="--track-color:#e5323d">
      <div class="channel-title"><i></i><strong>MASTER</strong></div><div class="channel-insert">LIMITER ${state.project.master.limiter ? "ON" : "BYP"}</div><div></div><div></div>
      <div class="fader-section"><div class="vertical-meter" data-master-meter><i></i><i></i></div><div class="fader-wrap"><input type="range" min="0" max="1.1" step=".01" value="${state.project.master.volume}" data-master-param="volume"></div><span class="peak-db">0 dBFS</span></div>
      <div class="channel-buttons"><button class="track-mini ${state.project.master.limiter ? "active" : ""}" data-master-action="limiter">LIM</button></div>
    </article>`;
  }

  function renderInspector() {
    $$("[data-inspector-tab]").forEach(button => button.classList.toggle("active", button.dataset.inspectorTab === state.ui.inspectorTab));
    const content = $("#inspectorContent");
    const clipHit = selectedClip();
    const track = activeTrack();
    if (state.ui.inspectorTab === "clip") { content.innerHTML = clipHit ? clipInspectorHtml(clipHit.clip, clipHit.track) : emptyInspector("NO CLIP SELECTED", "Select a clip in the arranger."); return; }
    if (!track) { content.innerHTML = emptyInspector("NO TRACK SELECTED", "Select a track to inspect it."); return; }
    if (state.ui.inspectorTab === "fx") content.innerHTML = fxInspectorHtml(track);
    else if (state.ui.inspectorTab === "route") content.innerHTML = routingInspectorHtml(track);
    else content.innerHTML = trackInspectorHtml(track);
  }

  const emptyInspector = (title, copy) => `<div class="inspector-empty"><div><b>${title}</b><span>${copy}</span></div></div>`;

  function trackInspectorHtml(track) {
    return `<div class="inspect-title"><small>${track.type.toUpperCase()} TRACK</small><h3>${escapeHtml(track.name)}</h3></div>
      <section class="inspect-section"><h4>CHANNEL</h4>${paramHtml("Input gain", "inputGain", track.inputGain, 0, 2, .01, `${gainToDb(track.inputGain).toFixed(1)} dB`)}${paramHtml("Volume", "volume", track.volume, 0, 1.25, .01, `${gainToDb(track.volume).toFixed(1)} dB`)}${paramHtml("Pan", "pan", track.pan, -1, 1, .01, track.pan === 0 ? "CENTER" : track.pan < 0 ? `${Math.round(-track.pan * 100)} L` : `${Math.round(track.pan * 100)} R`)}</section>
      <section class="inspect-section"><h4>STATE</h4><div class="inspect-grid"><button class="secondary-button" data-inspect-action="arm">${track.arm ? "DISARM" : "ARM RECORD"}</button><button class="secondary-button" data-inspect-action="monitor">MONITOR ${track.monitor ? "ON" : "OFF"}</button><button class="secondary-button" data-inspect-action="mute">${track.mute ? "UNMUTE" : "MUTE"}</button><button class="secondary-button" data-inspect-action="solo">${track.solo ? "UNSOLO" : "SOLO"}</button></div></section>
      <section class="inspect-section"><h4>AUTOMATION</h4><div class="button-stack"><button class="secondary-button" data-inspect-action="add-volume-point">＋ VOLUME POINT AT PLAYHEAD</button><button class="secondary-button" data-inspect-action="show-automation">${state.ui.automation ? "HIDE" : "SHOW"} AUTOMATION LANE</button></div></section>
      <section class="inspect-section"><h4>TRACK ACTIONS</h4><div class="button-stack"><button class="secondary-button" data-inspect-action="duplicate-track">DUPLICATE TRACK</button><button class="danger-outline" data-inspect-action="delete-track">DELETE TRACK</button></div></section>`;
  }

  function paramHtml(label, key, value, min, max, step, display) {
    return `<div class="param-row"><label>${label}</label><input type="range" min="${min}" max="${max}" step="${step}" value="${value}" data-inspect-param="${key}"><output>${display}</output></div>`;
  }

  function clipParamHtml(label, key, value, min, max, step, display) {
    return `<div class="param-row"><label>${label}</label><input type="range" min="${min}" max="${max}" step="${step}" value="${value}" data-clip-param="${key}"><output>${display}</output></div>`;
  }

  function clipInspectorHtml(clip, track) {
    const durationBeats = ticksToBeats(clip.durationTicks);
    return `<div class="inspect-title"><small>${clip.type.toUpperCase()} CLIP · ${escapeHtml(track.name)}</small><h3>${escapeHtml(clip.name)}</h3></div>
      <section class="inspect-section"><h4>TIMING</h4><div class="inspect-grid"><label>Start (beats)<input type="number" step=".25" min="0" value="${ticksToBeats(clip.startTick)}" data-clip-param="startBeat"></label><label>Length (beats)<input type="number" step=".25" min=".125" value="${durationBeats}" data-clip-param="durationBeat"></label><label>Source offset<input type="number" step=".01" min="0" value="${(clip.sourceOffset || 0).toFixed(2)}" data-clip-param="sourceOffset"></label><label>Rate<input type="number" step=".01" min=".25" max="4" value="${clip.rate || 1}" data-clip-param="rate"></label></div></section>
      <section class="inspect-section"><h4>GAIN & FADES</h4>${clipParamHtml("Clip gain", "clipGain", clip.gain ?? 1, 0, 2, .01, `${gainToDb(clip.gain ?? 1).toFixed(1)} dB`)}${clip.type === "audio" ? clipParamHtml("Fade in", "fadeIn", clip.fadeIn || 0, 0, Math.max(.01, beatsToSeconds(durationBeats) / 2), .01, `${(clip.fadeIn || 0).toFixed(2)} s`) + clipParamHtml("Fade out", "fadeOut", clip.fadeOut || 0, 0, Math.max(.01, beatsToSeconds(durationBeats) / 2), .01, `${(clip.fadeOut || 0).toFixed(2)} s`) : ""}</section>
      ${clip.type === "audio" ? `<section class="inspect-section"><h4>TRANSFORM</h4><div class="inspect-grid"><label>Transpose<input type="number" step="1" min="-24" max="24" value="${clip.pitch || 0}" data-clip-param="pitch"></label><label>Direction<select data-clip-param="reverse"><option value="false" ${!clip.reverse ? "selected" : ""}>Forward</option><option value="true" ${clip.reverse ? "selected" : ""}>Reverse</option></select></label></div><div class="button-stack"><button class="secondary-button" data-clip-action="normalize">NORMALIZE GAIN</button><button class="secondary-button" data-clip-action="loop">${clip.loop ? "DISABLE" : "ENABLE"} CLIP LOOP</button></div></section>` : `<section class="inspect-section"><h4>INSTRUMENT</h4><button class="secondary-button" data-clip-action="edit-midi">OPEN PIANO ROLL</button></section>`}
      <section class="inspect-section"><h4>EDIT</h4><div class="inspect-grid"><button class="secondary-button" data-clip-action="split">SPLIT</button><button class="secondary-button" data-clip-action="duplicate">DUPLICATE</button><button class="secondary-button" data-clip-action="mute">${clip.muted ? "UNMUTE" : "MUTE"}</button><button class="secondary-button" data-clip-action="lock">${clip.locked ? "UNLOCK" : "LOCK"}</button></div><button class="danger-outline" data-clip-action="delete" style="width:100%;margin-top:6px">DELETE CLIP</button></section>`;
  }

  function fxInspectorHtml(track) {
    return `<div class="inspect-title"><small>INSERT CHAIN</small><h3>${escapeHtml(track.name)}</h3></div>
      <section class="inspect-section"><h4>PARAMETRIC EQ</h4><div class="fx-slot ${track.effects.eq ? "" : "bypassed"}"><i class="fx-led"></i><span><strong>3-BAND EQ</strong><small>LOW · MID · HIGH</small></span><button class="track-mini" data-fx-toggle="eq">${track.effects.eq ? "ON" : "BYP"}</button></div>${paramHtml("Low 120 Hz", "eq.low", track.eq.low, -12, 12, .1, `${track.eq.low.toFixed(1)} dB`)}${paramHtml("Mid 1.2 kHz", "eq.mid", track.eq.mid, -12, 12, .1, `${track.eq.mid.toFixed(1)} dB`)}${paramHtml("High 7 kHz", "eq.high", track.eq.high, -12, 12, .1, `${track.eq.high.toFixed(1)} dB`)}</section>
      <section class="inspect-section"><h4>DYNAMICS</h4><div class="fx-slot ${track.effects.compressor ? "" : "bypassed"}"><i class="fx-led"></i><span><strong>COMPRESSOR</strong><small>${track.compressor.threshold} dB · ${track.compressor.ratio}:1</small></span><button class="track-mini" data-fx-toggle="compressor">${track.effects.compressor ? "ON" : "BYP"}</button></div>${paramHtml("Threshold", "compressor.threshold", track.compressor.threshold, -60, 0, 1, `${track.compressor.threshold} dB`)}${paramHtml("Ratio", "compressor.ratio", track.compressor.ratio, 1, 20, .1, `${track.compressor.ratio.toFixed(1)}:1`)}</section>`;
  }

  function routingInspectorHtml(track) {
    return `<div class="inspect-title"><small>SENDS & ROUTING</small><h3>${escapeHtml(track.name)}</h3></div>
      <section class="inspect-section"><h4>OUTPUT</h4><div class="inspect-grid"><label>Destination<select data-route-param="route"><option value="master" ${track.route === "master" ? "selected" : ""}>Master</option></select></label><label>Mode<select><option>Post-fader</option></select></label></div></section>
      <section class="inspect-section"><h4>GLOBAL SENDS</h4>${paramHtml("Reverb", "sends.reverb", track.sends.reverb, 0, 1, .01, `${Math.round(track.sends.reverb * 100)}%`)}${paramHtml("Delay", "sends.delay", track.sends.delay, 0, 1, .01, `${Math.round(track.sends.delay * 100)}%`)}</section>
      <section class="inspect-section"><h4>SIGNAL FLOW</h4><div class="fine-print">Source → input gain → EQ → compressor → fader → pan → sends → master limiter</div></section>`;
  }

  function updatePositionDisplay() {
    const bars = formatBars(state.ui.playheadBeat);
    const time = formatTime(beatsToSeconds(state.ui.playheadBeat));
    $("#positionPrimary").textContent = state.project.displayMode === "seconds" ? time : bars;
    $("#positionSecondary").textContent = state.project.displayMode === "seconds" ? bars : time;
    $("#selectionStatus").textContent = state.ui.selectedClipIds.size ? `${state.ui.selectedClipIds.size} clip${state.ui.selectedClipIds.size === 1 ? "" : "s"} selected` : activeTrack() ? `${activeTrack().name} selected` : "Nothing selected";
  }

  function updatePlayheadElement() {
    $("#playhead").style.left = `${beatToPx(state.ui.playheadBeat)}px`;
  }

  async function ensureAudio() {
    if (!window.AudioContext && !window.webkitAudioContext) throw new Error("Web Audio is not supported in this browser.");
    if (!state.audio.ctx) {
      const AudioContextClass = window.AudioContext || window.webkitAudioContext;
      const ctx = new AudioContextClass({ latencyHint: "interactive" });
      state.audio.ctx = ctx;
      state.audio.masterInput = ctx.createGain();
      state.audio.limiter = ctx.createDynamicsCompressor();
      state.audio.limiter.threshold.value = -1;
      state.audio.limiter.knee.value = 0;
      state.audio.limiter.ratio.value = 20;
      state.audio.limiter.attack.value = .003;
      state.audio.limiter.release.value = .12;
      state.audio.masterGain = ctx.createGain();
      state.audio.masterGain.gain.value = state.project.master.volume;
      state.audio.analyser = ctx.createAnalyser();
      state.audio.analyser.fftSize = 512;
      state.audio.meterData = new Float32Array(state.audio.analyser.fftSize);
      connectMasterChain();
      createSendEffects();
      buildTrackNodes();
      $("#sampleRateReadout").textContent = `${Math.round(ctx.sampleRate / 100) / 10}K`;
      $("#engineState").textContent = "ACTIVE";
      const latency = ((ctx.baseLatency || 0) + (ctx.outputLatency || 0)) * 1000;
      $("#latencyReadout").textContent = latency ? `LATENCY ~${Math.round(latency)}ms` : "LATENCY BROWSER";
      ctx.onstatechange = () => {
        $("#engineState").textContent = ctx.state.toUpperCase();
        if (ctx.state === "suspended" && state.audio.isPlaying) toast("Audio engine suspended", "Click Play to resume browser audio.", "warning");
      };
      setStatus("Audio engine initialized", "ready");
    }
    if (state.audio.ctx.state === "suspended") await state.audio.ctx.resume();
    return state.audio.ctx;
  }

  function connectMasterChain() {
    const audio = state.audio;
    try { audio.masterInput.disconnect(); audio.limiter.disconnect(); audio.masterGain.disconnect(); audio.analyser.disconnect(); } catch (_) {}
    if (state.project.master.limiter) {
      audio.masterInput.connect(audio.limiter).connect(audio.masterGain).connect(audio.analyser).connect(audio.ctx.destination);
    } else {
      audio.masterInput.connect(audio.masterGain).connect(audio.analyser).connect(audio.ctx.destination);
    }
  }

  function createImpulse(ctx, seconds = 2.4, decay = 2.7) {
    const length = Math.floor(ctx.sampleRate * seconds);
    const impulse = ctx.createBuffer(2, length, ctx.sampleRate);
    for (let channel = 0; channel < 2; channel++) {
      const data = impulse.getChannelData(channel);
      for (let i = 0; i < length; i++) data[i] = (Math.random() * 2 - 1) * Math.pow(1 - i / length, decay);
    }
    return impulse;
  }

  function createSendEffects() {
    const ctx = state.audio.ctx;
    const reverbInput = ctx.createGain();
    const convolver = ctx.createConvolver();
    const reverbReturn = ctx.createGain();
    convolver.buffer = createImpulse(ctx);
    reverbReturn.gain.value = state.project.buses.find(bus => bus.id === "reverb")?.volume ?? .5;
    reverbInput.connect(convolver).connect(reverbReturn).connect(state.audio.masterInput);

    const delayInput = ctx.createGain();
    const delay = ctx.createDelay(3);
    const feedback = ctx.createGain();
    const delayReturn = ctx.createGain();
    delay.delayTime.value = 60 / state.project.bpm * .75;
    feedback.gain.value = .32;
    delayReturn.gain.value = state.project.buses.find(bus => bus.id === "delay")?.volume ?? .42;
    delayInput.connect(delay);
    delay.connect(feedback).connect(delay);
    delay.connect(delayReturn).connect(state.audio.masterInput);
    state.audio.reverbInput = reverbInput;
    state.audio.reverbReturn = reverbReturn;
    state.audio.delayInput = delayInput;
    state.audio.delayNode = delay;
    state.audio.delayReturn = delayReturn;
  }

  function buildTrackNodes() {
    if (!state.audio.ctx) return;
    for (const nodes of state.audio.trackNodes.values()) {
      Object.values(nodes).forEach(node => { try { node?.disconnect?.(); } catch (_) {} });
    }
    state.audio.trackNodes.clear();
    const ctx = state.audio.ctx;
    state.project.tracks.forEach(track => {
      const input = ctx.createGain();
      const low = ctx.createBiquadFilter();
      const mid = ctx.createBiquadFilter();
      const high = ctx.createBiquadFilter();
      const compressor = ctx.createDynamicsCompressor();
      const fader = ctx.createGain();
      const pan = ctx.createStereoPanner();
      const analyser = ctx.createAnalyser();
      const reverbSend = ctx.createGain();
      const delaySend = ctx.createGain();
      low.type = "lowshelf"; low.frequency.value = 120; low.gain.value = track.effects.eq ? track.eq.low : 0;
      mid.type = "peaking"; mid.frequency.value = 1200; mid.Q.value = .8; mid.gain.value = track.effects.eq ? track.eq.mid : 0;
      high.type = "highshelf"; high.frequency.value = 7000; high.gain.value = track.effects.eq ? track.eq.high : 0;
      compressor.threshold.value = track.effects.compressor ? track.compressor.threshold : 0;
      compressor.ratio.value = track.effects.compressor ? track.compressor.ratio : 1;
      compressor.attack.value = .008; compressor.release.value = .18; compressor.knee.value = 10;
      input.gain.value = track.inputGain;
      fader.gain.value = track.volume;
      pan.pan.value = track.pan;
      analyser.fftSize = 256;
      reverbSend.gain.value = track.sends.reverb;
      delaySend.gain.value = track.sends.delay;
      input.connect(low).connect(mid).connect(high).connect(compressor).connect(fader).connect(pan).connect(analyser).connect(state.audio.masterInput);
      pan.connect(reverbSend).connect(state.audio.reverbInput);
      pan.connect(delaySend).connect(state.audio.delayInput);
      state.audio.trackNodes.set(track.id, { input, low, mid, high, compressor, fader, pan, analyser, reverbSend, delaySend, meterData: new Float32Array(analyser.fftSize) });
    });
    applyMixState();
  }

  function rebuildAudioGraph() {
    if (!state.audio.ctx) return;
    stopLiveSources();
    buildTrackNodes();
  }

  function applyMixState() {
    if (!state.audio.ctx) return;
    const ctx = state.audio.ctx;
    const soloed = state.project.tracks.filter(track => track.solo);
    state.project.tracks.forEach(track => {
      const nodes = state.audio.trackNodes.get(track.id);
      if (!nodes) return;
      const audible = !track.mute && (!soloed.length || track.solo);
      const automatedVolume = automationValue(track.automation.volume, state.ui.playheadBeat, track.volume);
      const automatedPan = automationValue(track.automation.pan, state.ui.playheadBeat, track.pan);
      nodes.input.gain.setTargetAtTime(track.inputGain, ctx.currentTime, .01);
      nodes.fader.gain.setTargetAtTime(audible ? automatedVolume : 0, ctx.currentTime, .008);
      nodes.pan.pan.setTargetAtTime(automatedPan, ctx.currentTime, .01);
      nodes.low.gain.setTargetAtTime(track.effects.eq ? track.eq.low : 0, ctx.currentTime, .01);
      nodes.mid.gain.setTargetAtTime(track.effects.eq ? track.eq.mid : 0, ctx.currentTime, .01);
      nodes.high.gain.setTargetAtTime(track.effects.eq ? track.eq.high : 0, ctx.currentTime, .01);
      nodes.compressor.threshold.setTargetAtTime(track.effects.compressor ? track.compressor.threshold : 0, ctx.currentTime, .01);
      nodes.compressor.ratio.setTargetAtTime(track.effects.compressor ? track.compressor.ratio : 1, ctx.currentTime, .01);
      nodes.reverbSend.gain.setTargetAtTime(automationValue(track.automation.reverb, state.ui.playheadBeat, track.sends.reverb), ctx.currentTime, .01);
      nodes.delaySend.gain.setTargetAtTime(automationValue(track.automation.delay, state.ui.playheadBeat, track.sends.delay), ctx.currentTime, .01);
    });
    state.audio.masterGain.gain.setTargetAtTime(state.project.master.volume, ctx.currentTime, .01);
    const reverbBus = state.project.buses.find(bus => bus.id === "reverb");
    const delayBus = state.project.buses.find(bus => bus.id === "delay");
    if (state.audio.reverbReturn) state.audio.reverbReturn.gain.setTargetAtTime(reverbBus?.mute ? 0 : reverbBus?.volume ?? .5, ctx.currentTime, .01);
    if (state.audio.delayReturn) state.audio.delayReturn.gain.setTargetAtTime(delayBus?.mute ? 0 : delayBus?.volume ?? .42, ctx.currentTime, .01);
    if (state.audio.inputMonitorGain) {
      const monitoring = state.project.tracks.some(track => track.monitor && track.arm);
      state.audio.inputMonitorGain.gain.setTargetAtTime(monitoring ? Number($("#monitorLevel").value || .7) : 0, ctx.currentTime, .01);
    }
  }

  function automationValue(points, beat, fallback) {
    if (!points?.length) return fallback;
    const sorted = [...points].sort((a, b) => a.beat - b.beat);
    if (beat <= sorted[0].beat) return sorted[0].value;
    if (beat >= sorted.at(-1).beat) return sorted.at(-1).value;
    for (let i = 0; i < sorted.length - 1; i++) {
      const a = sorted[i], b = sorted[i + 1];
      if (beat >= a.beat && beat <= b.beat) {
        const t = (beat - a.beat) / Math.max(.0001, b.beat - a.beat);
        return a.value + (b.value - a.value) * t;
      }
    }
    return fallback;
  }

  async function decodeAsset(assetId) {
    if (state.audio.buffers.has(assetId)) return state.audio.buffers.get(assetId);
    const asset = state.project.assets.find(item => item.id === assetId);
    if (!asset || asset.type !== "audio") return null;
    await ensureAudio();
    const record = await dbGet("assets", assetId);
    if (!record?.blob) throw new Error(`The source for “${asset.name}” is missing. Relink or re-import it.`);
    const arrayBuffer = await record.blob.arrayBuffer();
    const buffer = await state.audio.ctx.decodeAudioData(arrayBuffer.slice(0));
    state.audio.buffers.set(assetId, buffer);
    return buffer;
  }

  async function getReverseBuffer(assetId) {
    if (state.audio.reverseBuffers.has(assetId)) return state.audio.reverseBuffers.get(assetId);
    const source = await decodeAsset(assetId);
    if (!source) return null;
    const reversed = state.audio.ctx.createBuffer(source.numberOfChannels, source.length, source.sampleRate);
    for (let channel = 0; channel < source.numberOfChannels; channel++) reversed.copyToChannel(Float32Array.from(source.getChannelData(channel)).reverse(), channel);
    state.audio.reverseBuffers.set(assetId, reversed);
    return reversed;
  }

  function currentBeat() {
    if (!state.audio.isPlaying || !state.audio.ctx) return state.ui.playheadBeat;
    return state.audio.anchorBeat + secondsToBeats(state.audio.ctx.currentTime - state.audio.anchorTime);
  }

  async function play() {
    if (state.audio.isPlaying) { pause(); return; }
    try {
      await ensureAudio();
      await hydrateNeededAssets();
      state.audio.isPlaying = true;
      state.audio.anchorBeat = state.ui.playheadBeat;
      state.audio.anchorTime = state.audio.ctx.currentTime + .04;
      state.audio.scheduled.clear();
      $("#playBtn").classList.add("active");
      $("#playBtn").textContent = "Ⅱ";
      setStatus("Playback running", "ready");
      scheduleTick();
      state.audio.scheduler = setInterval(scheduleTick, 25);
      state.audio.animation = requestAnimationFrame(updateVisuals);
    } catch (error) {
      console.error(error);
      toast("Playback could not start", error.message, "error", 7000);
      setStatus("Playback unavailable", "error");
    }
  }

  function pause() {
    if (!state.audio.isPlaying) return;
    state.ui.playheadBeat = clamp(currentBeat(), 0, projectBeats());
    state.audio.isPlaying = false;
    clearInterval(state.audio.scheduler);
    cancelAnimationFrame(state.audio.animation);
    stopLiveSources();
    $("#playBtn").classList.remove("active");
    $("#playBtn").textContent = "▶";
    updatePlayheadElement();
    updatePositionDisplay();
    setStatus("Playback paused", "ready");
  }

  function stop(reset = false) {
    if (state.audio.isPlaying) pause();
    stopRecording(true);
    state.ui.playheadBeat = reset ? 0 : state.ui.playheadBeat;
    if (!reset) state.ui.playheadBeat = 0;
    state.audio.scheduled.clear();
    updatePlayheadElement();
    updatePositionDisplay();
    setStatus("Stopped", "ready");
  }

  function seek(beat, continuePlaying = state.audio.isPlaying) {
    const wasPlaying = state.audio.isPlaying;
    if (wasPlaying) {
      state.audio.isPlaying = false;
      clearInterval(state.audio.scheduler);
      cancelAnimationFrame(state.audio.animation);
      stopLiveSources();
    }
    state.ui.playheadBeat = clamp(beat, 0, projectBeats());
    state.audio.scheduled.clear();
    updatePlayheadElement();
    updatePositionDisplay();
    if (continuePlaying) play();
  }

  function stopLiveSources() {
    state.audio.sources.splice(0).forEach(source => {
      try { source.stop?.(); } catch (_) {}
      try { source.disconnect?.(); } catch (_) {}
    });
  }

  function scheduleTick() {
    if (!state.audio.isPlaying || !state.audio.ctx) return;
    let beat = currentBeat();
    if (state.project.loop.enabled && beat >= state.project.loop.endBeat) {
      stopLiveSources();
      state.audio.scheduled.clear();
      state.audio.anchorBeat = state.project.loop.startBeat;
      state.audio.anchorTime = state.audio.ctx.currentTime + .015;
      beat = state.project.loop.startBeat;
    }
    if (!state.project.loop.enabled && beat >= projectBeats()) { pause(); return; }
    const horizon = beat + secondsToBeats(.16);
    state.project.tracks.forEach(track => {
      track.clips.forEach(clip => scheduleClipIfNeeded(track, clip, beat, horizon));
    });
    if ($("#metroBtn").classList.contains("active")) scheduleMetronome(beat, horizon);
    applyMixState();
  }

  function scheduleClipIfNeeded(track, clip, beat, horizon) {
    const start = ticksToBeats(clip.startTick);
    const end = start + ticksToBeats(clip.durationTicks);
    if (end <= beat || start > horizon || clip.muted) return;
    const key = `clip:${clip.id}`;
    if (state.audio.scheduled.has(key)) return;
    state.audio.scheduled.add(key);
    if (clip.type === "midi") scheduleMidiClip(track, clip, beat);
    else scheduleAudioClip(track, clip, beat).catch(error => {
      console.error(error);
      toast("Clip could not play", error.message, "error");
    });
  }

  async function scheduleAudioClip(track, clip, playBeat) {
    const ctx = state.audio.ctx;
    const nodes = state.audio.trackNodes.get(track.id);
    if (!nodes) return;
    const buffer = clip.reverse ? await getReverseBuffer(clip.assetId) : await decodeAsset(clip.assetId);
    if (!buffer || !state.audio.isPlaying) return;
    const clipStart = ticksToBeats(clip.startTick);
    const clipDurationSeconds = beatsToSeconds(ticksToBeats(clip.durationTicks));
    const lateSeconds = playBeat > clipStart ? beatsToSeconds(playBeat - clipStart) : 0;
    const when = state.audio.anchorTime + beatsToSeconds(Math.max(0, clipStart - state.audio.anchorBeat));
    const actualWhen = Math.max(ctx.currentTime + .006, when);
    const rate = (clip.rate || 1) * Math.pow(2, (clip.pitch || 0) / 12);
    const source = ctx.createBufferSource();
    const gain = ctx.createGain();
    source.buffer = buffer;
    source.playbackRate.value = rate;
    source.loop = Boolean(clip.loop);
    if (clip.loop) {
      source.loopStart = clamp(clip.sourceOffset || 0, 0, buffer.duration);
      source.loopEnd = clamp((clip.sourceOffset || 0) + Math.min(clip.sourceDuration || buffer.duration, buffer.duration), source.loopStart + .01, buffer.duration);
    }
    const offset = clamp((clip.sourceOffset || 0) + lateSeconds * rate, 0, Math.max(0, buffer.duration - .001));
    const remaining = Math.max(.01, clipDurationSeconds - lateSeconds);
    const endTime = actualWhen + remaining;
    gain.gain.setValueAtTime(0, actualWhen);
    gain.gain.linearRampToValueAtTime(clip.gain ?? 1, actualWhen + Math.min(clip.fadeIn || .005, remaining / 2));
    gain.gain.setValueAtTime(clip.gain ?? 1, Math.max(actualWhen, endTime - Math.min(clip.fadeOut || .005, remaining / 2)));
    gain.gain.linearRampToValueAtTime(0, endTime);
    source.connect(gain).connect(nodes.input);
    try { source.start(actualWhen, offset); source.stop(endTime + .01); } catch (error) { console.warn(error); }
    state.audio.sources.push(source, gain);
  }

  function scheduleMidiClip(track, clip, playBeat) {
    const ctx = state.audio.ctx;
    const nodes = state.audio.trackNodes.get(track.id);
    if (!nodes) return;
    const clipStart = ticksToBeats(clip.startTick);
    const clipEnd = clipStart + ticksToBeats(clip.durationTicks);
    (clip.notes || []).forEach(note => {
      const noteStart = clipStart + note.start;
      const noteEnd = Math.min(clipEnd, noteStart + note.duration);
      if (noteEnd <= playBeat) return;
      const when = Math.max(ctx.currentTime + .006, state.audio.anchorTime + beatsToSeconds(noteStart - state.audio.anchorBeat));
      const duration = Math.max(.02, beatsToSeconds(noteEnd - Math.max(noteStart, playBeat)));
      scheduleSynthNote(nodes.input, note.pitch, note.velocity ?? .72, when, duration, clip.wave || "sawtooth");
    });
  }

  function scheduleSynthNote(destination, pitch, velocity, when, duration, wave = "sawtooth") {
    const ctx = state.audio.ctx;
    const osc = ctx.createOscillator();
    const filter = ctx.createBiquadFilter();
    const gain = ctx.createGain();
    osc.type = wave;
    osc.frequency.value = 440 * Math.pow(2, (pitch - 69) / 12);
    filter.type = "lowpass";
    filter.frequency.value = 3200;
    filter.Q.value = 1.4;
    const level = clamp(velocity, 0, 1) * .16;
    gain.gain.setValueAtTime(0, when);
    gain.gain.linearRampToValueAtTime(level, when + .008);
    gain.gain.exponentialRampToValueAtTime(Math.max(.0001, level * .55), when + Math.min(.13, duration * .35));
    gain.gain.setValueAtTime(Math.max(.0001, level * .55), when + Math.max(.14, duration - .06));
    gain.gain.exponentialRampToValueAtTime(.0001, when + duration);
    osc.connect(filter).connect(gain).connect(destination);
    osc.start(when); osc.stop(when + duration + .02);
    state.audio.sources.push(osc, filter, gain);
  }

  function scheduleMetronome(beat, horizon) {
    const first = Math.ceil(beat - .01);
    for (let b = first; b <= horizon; b++) {
      const key = `metro:${Math.round(b * 1000)}`;
      if (state.audio.scheduled.has(key)) continue;
      state.audio.scheduled.add(key);
      const when = Math.max(state.audio.ctx.currentTime + .005, state.audio.anchorTime + beatsToSeconds(b - state.audio.anchorBeat));
      const osc = state.audio.ctx.createOscillator();
      const gain = state.audio.ctx.createGain();
      const accent = b % state.project.timeSignature.numerator === 0;
      osc.frequency.value = accent ? 1320 : 880;
      gain.gain.setValueAtTime(accent ? .16 : .09, when);
      gain.gain.exponentialRampToValueAtTime(.0001, when + .045);
      osc.connect(gain).connect(state.audio.masterGain);
      osc.start(when); osc.stop(when + .05);
      state.audio.sources.push(osc, gain);
    }
  }

  function updateVisuals(timestamp) {
    if (!state.audio.isPlaying) return;
    state.ui.playheadBeat = currentBeat();
    updatePlayheadElement();
    updatePositionDisplay();
    if (timestamp - state.audio.lastVisualTime > 65) {
      updateMeters();
      state.audio.lastVisualTime = timestamp;
      const viewport = $("#timelineViewport");
      const x = beatToPx(state.ui.playheadBeat);
      if (x > viewport.scrollLeft + viewport.clientWidth - 55 || x < viewport.scrollLeft) viewport.scrollLeft = Math.max(0, x - 80);
    }
    state.audio.animation = requestAnimationFrame(updateVisuals);
  }

  function analyserLevel(analyser, data) {
    analyser.getFloatTimeDomainData(data);
    let sum = 0, peak = 0;
    for (let i = 0; i < data.length; i++) { const value = Math.abs(data[i]); sum += value * value; peak = Math.max(peak, value); }
    return { rms: Math.sqrt(sum / data.length), peak };
  }

  function updateMeters() {
    if (!state.audio.ctx) return;
    state.project.tracks.forEach(track => {
      const nodes = state.audio.trackNodes.get(track.id);
      if (!nodes) return;
      const { rms, peak } = analyserLevel(nodes.analyser, nodes.meterData);
      const normalized = clamp(Math.max(rms * 3.2, peak * .72), 0, 1);
      const segments = $$(`[data-meter-track="${track.id}"] i`);
      segments.forEach((node, index) => {
        const on = index < Math.round(normalized * segments.length);
        node.className = on ? index > 12 ? "clip" : index > 9 ? "warn" : "on" : "";
      });
      $$(`[data-mixer-meter="${track.id}"] i`).forEach(node => node.style.height = `${normalized * 100}%`);
    });
    const master = analyserLevel(state.audio.analyser, state.audio.meterData);
    const masterValue = clamp(Math.max(master.rms * 3.2, master.peak * .72), 0, 1);
    $("#masterMeterL").style.width = `${masterValue * 100}%`;
    $("#masterMeterR").style.width = `${masterValue * 94}%`;
    $("#masterDb").textContent = Number.isFinite(gainToDb(master.peak)) ? `${gainToDb(master.peak).toFixed(1)}` : "−∞";
    $$(`[data-master-meter] i`).forEach(node => node.style.height = `${masterValue * 100}%`);
    $("#cpuReadout").textContent = `${Math.round(clamp(state.project.tracks.length * 2.1 + state.audio.sources.length * .18, 1, 94))}%`;
  }

  async function hydrateNeededAssets() {
    const ids = [...new Set(state.project.assets.filter(asset => asset.type === "audio").map(asset => asset.id))];
    const failures = [];
    for (const id of ids) {
      if (state.audio.buffers.has(id)) continue;
      try { await decodeAsset(id); } catch (error) { failures.push(error.message); }
    }
    if (failures.length) toast("Some sources are unavailable", failures[0], "warning", 7000);
  }

  async function importAudioFiles(files, targetTrackId = null, targetBeat = null, source = "import") {
    const accepted = [...files].filter(file => file.type.startsWith("audio/") || /\.(wav|mp3|ogg|opus|m4a|aac|flac)$/i.test(file.name));
    if (!accepted.length) { toast("No supported audio files", "Choose an audio file that your browser can decode.", "warning"); return; }
    setStatus(`Importing ${accepted.length} audio file${accepted.length === 1 ? "" : "s"}…`, "busy");
    await ensureAudio();
    for (const file of accepted) {
      try {
        const arrayBuffer = await file.arrayBuffer();
        const hash = await hashBuffer(arrayBuffer);
        const existing = state.project.assets.find(asset => asset.hash === hash);
        if (existing) {
          createAudioClip(existing, targetTrackId, targetBeat);
          toast("Reused existing asset", file.name, "success");
          continue;
        }
        const buffer = await state.audio.ctx.decodeAudioData(arrayBuffer.slice(0));
        const id = uid("asset");
        const asset = {
          id, name: file.name.replace(/\.[^.]+$/, ""), fileName: file.name, type: "audio", source,
          mimeType: file.type || "application/octet-stream", size: file.size, duration: buffer.duration,
          sampleRate: buffer.sampleRate, channels: buffer.numberOfChannels, hash, createdAt: new Date().toISOString(), peaks: null
        };
        state.project.assets.push(asset);
        state.audio.buffers.set(id, buffer);
        await dbPut("assets", { id, blob: file, name: file.name, mimeType: file.type });
        asset.peaks = await analyzeWaveform(buffer);
        createAudioClip(asset, targetTrackId, targetBeat);
      } catch (error) {
        console.error(error);
        toast(`Could not import ${file.name}`, "The file may be damaged or use a codec this browser cannot decode.", "error", 7000);
      }
    }
    rebuildAudioGraph();
    renderAll();
    markDirty("Import audio");
    setStatus("Import complete", "ready");
  }

  async function hashBuffer(buffer) {
    if (!crypto?.subtle) return `${buffer.byteLength}-${Date.now()}`;
    const slice = buffer.byteLength > 2_000_000 ? buffer.slice(0, 2_000_000) : buffer;
    const digest = await crypto.subtle.digest("SHA-256", slice);
    return [...new Uint8Array(digest)].slice(0, 16).map(byte => byte.toString(16).padStart(2, "0")).join("");
  }

  async function analyzeWaveform(buffer) {
    const channel = buffer.getChannelData(0).slice();
    if (window.Worker) {
      try {
        if (!state.waveformWorker) state.waveformWorker = new Worker("waveform-worker.js");
        return await new Promise((resolve, reject) => {
          const requestId = uid("wave");
          const workerSamples = channel.slice();
          const timeout = setTimeout(() => {
            state.waveformWorker.removeEventListener("message", handler);
            state.waveformWorker.removeEventListener("error", errorHandler);
            reject(new Error("Waveform worker timed out."));
          }, 6000);
          const handler = event => {
            if (event.data.id !== requestId) return;
            clearTimeout(timeout);
            state.waveformWorker.removeEventListener("message", handler);
            state.waveformWorker.removeEventListener("error", errorHandler);
            if (event.data.error) reject(new Error(event.data.error)); else resolve(event.data.peaks);
          };
          const errorHandler = () => {
            clearTimeout(timeout);
            state.waveformWorker.removeEventListener("message", handler);
            state.waveformWorker.removeEventListener("error", errorHandler);
            reject(new Error("Waveform worker could not start."));
          };
          state.waveformWorker.addEventListener("message", handler);
          state.waveformWorker.addEventListener("error", errorHandler);
          state.waveformWorker.postMessage({ id: requestId, samples: workerSamples, buckets: 1200 }, [workerSamples.buffer]);
        });
      } catch (error) { console.warn("Waveform worker fallback", error); }
    }
    const buckets = 1200;
    const size = Math.max(1, Math.floor(channel.length / buckets));
    return Array.from({ length: buckets }, (_, index) => {
      let peak = 0;
      const start = index * size, end = Math.min(channel.length, start + size);
      for (let i = start; i < end; i++) peak = Math.max(peak, Math.abs(channel[i]));
      return peak;
    });
  }

  function chooseAudioTrack(targetTrackId = null) {
    const target = getTrack(targetTrackId);
    if (target && ["audio", "mic"].includes(target.type)) return target;
    const selected = activeTrack();
    if (selected && ["audio", "mic"].includes(selected.type)) return selected;
    return state.project.tracks.find(track => ["audio", "mic"].includes(track.type)) || state.project.tracks[0];
  }

  function createAudioClip(asset, targetTrackId = null, targetBeat = null) {
    const track = chooseAudioTrack(targetTrackId);
    if (!track) return;
    const startBeat = targetBeat == null ? state.ui.playheadBeat : targetBeat;
    const durationBeats = Math.max(.125, secondsToBeats(asset.duration));
    snapshot("Import clip");
    const clip = {
      id: uid("clip"), assetId: asset.id, type: "audio", name: asset.name,
      startTick: beatsToTicks(snapBeat(startBeat)), durationTicks: beatsToTicks(durationBeats),
      sourceOffset: 0, sourceDuration: asset.duration, gain: 1, fadeIn: .02, fadeOut: .04,
      loop: false, muted: false, locked: false, reverse: false, pitch: 0, rate: 1, color: track.color
    };
    track.clips.push(clip);
    state.ui.selectedTrackId = track.id;
    state.ui.selectedClipIds = new Set([clip.id]);
  }

  function addTrack(type = "audio") {
    if (state.project.tracks.length >= MAX_TRACKS) { toast("Eight-track limit reached", "Delete or consolidate a track before adding another.", "warning"); return null; }
    snapshot("Add track");
    const track = createTrack(state.project.tracks.length, type);
    state.project.tracks.push(track);
    state.ui.selectedTrackId = track.id;
    rebuildAudioGraph();
    renderAll();
    markDirty("Add track");
    return track;
  }

  function duplicateTrack(trackId) {
    const track = getTrack(trackId);
    if (!track) return;
    if (state.project.tracks.length >= MAX_TRACKS) { toast("Eight-track limit reached", "Delete another track first.", "warning"); return; }
    snapshot("Duplicate track");
    const copy = deepClone(track);
    copy.id = uid("trk");
    copy.name = `${track.name} Copy`;
    copy.arm = false;
    copy.solo = false;
    copy.clips.forEach(clip => clip.id = uid("clip"));
    state.project.tracks.splice(state.project.tracks.indexOf(track) + 1, 0, copy);
    state.ui.selectedTrackId = copy.id;
    rebuildAudioGraph(); renderAll(); markDirty("Duplicate track");
  }

  function deleteTrack(trackId) {
    if (state.project.tracks.length <= 1) { toast("Keep at least one track", "A project cannot have zero tracks.", "warning"); return; }
    const track = getTrack(trackId);
    if (!track) return;
    snapshot("Delete track");
    state.project.tracks = state.project.tracks.filter(item => item.id !== trackId);
    state.ui.selectedTrackId = state.project.tracks[0]?.id || null;
    state.ui.selectedClipIds.clear();
    rebuildAudioGraph(); renderAll(); markDirty("Delete track");
  }

  function toggleTrack(trackId, key, exclusive = false) {
    const track = getTrack(trackId);
    if (!track) return;
    snapshot(`${key} track`);
    if (key === "solo" && exclusive) state.project.tracks.forEach(item => { if (item.id !== trackId) item.solo = false; });
    if (key === "arm" && !track.arm) state.project.tracks.forEach(item => { if (item.id !== trackId) item.arm = false; });
    track[key] = !track[key];
    applyMixState(); renderAll(); markDirty(`${key} track`);
  }

  function selectClip(clipId, additive = false) {
    const hit = getClip(clipId);
    if (!hit) return;
    state.ui.selectedTrackId = hit.track.id;
    if (additive) {
      if (state.ui.selectedClipIds.has(clipId)) state.ui.selectedClipIds.delete(clipId); else state.ui.selectedClipIds.add(clipId);
    } else state.ui.selectedClipIds = new Set([clipId]);
    state.ui.inspectorTab = "clip";
    renderAll();
  }

  function deleteSelectedClips() {
    if (!state.ui.selectedClipIds.size) return;
    snapshot("Delete clip");
    const removed = new Set(state.ui.selectedClipIds);
    state.project.tracks.forEach(track => track.clips = track.clips.filter(clip => !removed.has(clip.id)));
    state.ui.selectedClipIds.clear();
    renderAll(); markDirty("Delete clip");
  }

  function duplicateSelectedClips() {
    if (!state.ui.selectedClipIds.size) return;
    snapshot("Duplicate clip");
    const newIds = [];
    state.project.tracks.forEach(track => {
      const additions = track.clips.filter(clip => state.ui.selectedClipIds.has(clip.id)).map(clip => {
        const copy = deepClone(clip);
        copy.id = uid("clip");
        copy.name = `${clip.name} Copy`;
        copy.startTick += clip.durationTicks;
        newIds.push(copy.id);
        return copy;
      });
      track.clips.push(...additions);
    });
    state.ui.selectedClipIds = new Set(newIds);
    renderAll(); markDirty("Duplicate clip");
  }

  function splitSelectedAt(beat = state.ui.playheadBeat) {
    const selected = [...state.ui.selectedClipIds].map(getClip).filter(Boolean);
    if (!selected.length) return;
    snapshot("Split clip");
    const newIds = [];
    selected.forEach(({ clip, track }) => {
      if (clip.locked) return;
      const start = ticksToBeats(clip.startTick);
      const end = start + ticksToBeats(clip.durationTicks);
      if (beat <= start + .02 || beat >= end - .02) return;
      const leftBeats = beat - start;
      const right = deepClone(clip);
      right.id = uid("clip");
      right.name = `${clip.name} B`;
      right.startTick = beatsToTicks(beat);
      right.durationTicks = beatsToTicks(end - beat);
      right.sourceOffset = (clip.sourceOffset || 0) + beatsToSeconds(leftBeats) * (clip.rate || 1);
      clip.durationTicks = beatsToTicks(leftBeats);
      clip.name = `${clip.name} A`;
      track.clips.push(right);
      newIds.push(right.id);
    });
    state.ui.selectedClipIds = new Set(newIds);
    renderAll(); markDirty("Split clip");
  }

  function normalizeSelectedClip() {
    const hit = selectedClip();
    if (!hit || hit.clip.type !== "audio") return;
    const asset = state.project.assets.find(item => item.id === hit.clip.assetId);
    const peak = Math.max(...(asset?.peaks || [1]), .001);
    snapshot("Normalize clip");
    hit.clip.gain = clamp(dbToGain(-1) / peak, 0, 2);
    renderAll(); markDirty("Normalize clip");
  }

  function createMidiClip(trackId = null, startBeat = state.ui.playheadBeat) {
    let track = getTrack(trackId);
    if (!track || track.type !== "midi") track = state.project.tracks.find(item => item.type === "midi");
    if (!track) track = addTrack("midi");
    if (!track) return;
    snapshot("Create MIDI clip");
    const clip = {
      id: uid("clip"), assetId: null, type: "midi", name: "MIDI Pattern",
      startTick: beatsToTicks(snapBeat(startBeat)), durationTicks: beatsToTicks(4),
      gain: 1, muted: false, locked: false, loop: true, rate: 1, pitch: 0, color: track.color,
      wave: "sawtooth",
      notes: [
        { id: uid("note"), start: 0, duration: .75, pitch: 48, velocity: .82 },
        { id: uid("note"), start: 1, duration: .75, pitch: 55, velocity: .72 },
        { id: uid("note"), start: 2, duration: .75, pitch: 58, velocity: .76 },
        { id: uid("note"), start: 3, duration: .75, pitch: 55, velocity: .72 }
      ]
    };
    track.clips.push(clip);
    const asset = { id: uid("midiasset"), name: clip.name, type: "midi", source: "created", duration: beatsToSeconds(4), createdAt: new Date().toISOString() };
    state.project.assets.push(asset);
    state.ui.selectedTrackId = track.id;
    state.ui.selectedClipIds = new Set([clip.id]);
    state.ui.inspectorTab = "clip";
    renderAll(); markDirty("Create MIDI clip");
    openMidiEditor(clip.id);
  }

  async function requestMicrophone() {
    if (!navigator.mediaDevices?.getUserMedia) throw new Error("Microphone capture is unavailable in this browser or context.");
    const deviceId = $("#inputDeviceSelect").value;
    const constraints = { audio: { echoCancellation: false, noiseSuppression: false, autoGainControl: false, ...(deviceId && deviceId !== "default" ? { deviceId: { exact: deviceId } } : {}) } };
    const stream = await navigator.mediaDevices.getUserMedia(constraints);
    await ensureAudio();
    if (state.audio.stream) state.audio.stream.getTracks().forEach(track => track.stop());
    try { state.audio.inputMonitorSource?.disconnect(); state.audio.inputMonitorGain?.disconnect(); } catch (_) {}
    state.audio.stream = stream;
    state.audio.inputMonitorSource = state.audio.ctx.createMediaStreamSource(stream);
    state.audio.inputMonitorGain = state.audio.ctx.createGain();
    state.audio.inputMonitorGain.gain.value = 0;
    state.audio.inputMonitorSource.connect(state.audio.inputMonitorGain).connect(state.audio.masterInput);
    applyMixState();
    await enumerateAudioDevices();
    toast("Microphone enabled", stream.getAudioTracks()[0]?.label || "Input ready", "success");
    return stream;
  }

  async function enumerateAudioDevices() {
    if (!navigator.mediaDevices?.enumerateDevices) return;
    const devices = (await navigator.mediaDevices.enumerateDevices()).filter(device => device.kind === "audioinput");
    const select = $("#inputDeviceSelect");
    const current = select.value;
    select.innerHTML = `<option value="default">Default input</option>` + devices.map((device, index) => `<option value="${device.deviceId}">${escapeHtml(device.label || `Audio input ${index + 1}`)}</option>`).join("");
    if ([...select.options].some(option => option.value === current)) select.value = current;
  }

  async function toggleRecording() {
    if (state.audio.recording) { stopRecording(true); return; }
    let track = state.project.tracks.find(item => item.arm) || activeTrack();
    if (!track || !["audio", "mic"].includes(track.type)) {
      track = state.project.tracks.find(item => ["audio", "mic"].includes(item.type));
      if (!track) track = addTrack("mic");
    }
    if (!track) return;
    track.arm = true;
    try {
      await ensureAudio();
      const stream = state.audio.stream?.active ? state.audio.stream : await requestMicrophone();
      if (!window.MediaRecorder) throw new Error("MediaRecorder is unavailable. Try a current Chromium, Firefox, or Safari release.");
      const preferred = ["audio/webm;codecs=opus", "audio/ogg;codecs=opus", "audio/webm", "audio/mp4"].find(type => MediaRecorder.isTypeSupported?.(type));
      const recorder = new MediaRecorder(stream, preferred ? { mimeType: preferred } : undefined);
      const chunks = [];
      const countBars = Number($("#countInSelect").value || 0);
      if (state.project.punch?.enabled) seek(state.project.punch.startBeat, false);
      if (!state.audio.isPlaying && countBars) await performCountIn(countBars);
      if (!state.audio.isPlaying) await play();
      const startBeat = state.ui.playheadBeat;
      recorder.ondataavailable = event => { if (event.data.size) chunks.push(event.data); };
      recorder.onerror = event => toast("Recording failed", event.error?.message || "The input stream was interrupted.", "error");
      recorder.onstop = async () => {
        if (!chunks.length) return;
        const blob = new Blob(chunks, { type: recorder.mimeType || "audio/webm" });
        await finishRecordingBlob(blob, track, startBeat);
      };
      state.audio.recording = { recorder, chunks, trackId: track.id, startBeat };
      recorder.start(250);
      if (state.project.punch?.enabled) state.audio.recording.punchTimer = setTimeout(() => stopRecording(true), beatsToSeconds(state.project.punch.endBeat - state.project.punch.startBeat) * 1000);
      $("#recordBtn").classList.add("active");
      setStatus(`Recording to ${track.name}`, "busy");
      toast("Recording started", "Press Record again or Stop to finish the take.", "warning");
    } catch (error) {
      console.error(error);
      toast("Microphone unavailable", `${error.message} Your existing project data is safe.`, "error", 8000);
    }
  }

  async function performCountIn(bars) {
    const ctx = state.audio.ctx;
    const beats = bars * state.project.timeSignature.numerator;
    const secondsPerBeat = 60 / state.project.bpm;
    setStatus(`Count-in: ${bars} bar${bars === 1 ? "" : "s"}`, "busy");
    for (let beat = 0; beat < beats; beat++) {
      const when = ctx.currentTime + .05 + beat * secondsPerBeat;
      const osc = ctx.createOscillator(), gain = ctx.createGain();
      osc.frequency.value = beat % state.project.timeSignature.numerator === 0 ? 1320 : 880;
      gain.gain.setValueAtTime(beat % state.project.timeSignature.numerator === 0 ? .18 : .1, when);
      gain.gain.exponentialRampToValueAtTime(.0001, when + .05);
      osc.connect(gain).connect(state.audio.masterGain); osc.start(when); osc.stop(when + .055);
    }
    await new Promise(resolve => setTimeout(resolve, beats * secondsPerBeat * 1000));
  }

  function stopRecording(keepTake = true) {
    const recording = state.audio.recording;
    if (!recording) return;
    state.audio.recording = null;
    clearTimeout(recording.punchTimer);
    $("#recordBtn").classList.remove("active");
    if (keepTake && recording.recorder.state !== "inactive") recording.recorder.stop();
    else if (recording.recorder.state !== "inactive") { recording.recorder.onstop = null; recording.recorder.stop(); }
    setStatus(keepTake ? "Finalizing recorded take…" : "Recording cancelled", keepTake ? "busy" : "ready");
  }

  async function finishRecordingBlob(blob, track, startBeat) {
    try {
      const file = new File([blob], `Take ${new Date().toLocaleTimeString().replace(/:/g, "-")}.webm`, { type: blob.type });
      const arrayBuffer = await blob.arrayBuffer();
      const buffer = await state.audio.ctx.decodeAudioData(arrayBuffer.slice(0));
      const id = uid("asset");
      const asset = { id, name: `Take ${state.project.assets.filter(item => item.source === "recording").length + 1}`, fileName: file.name, type: "audio", source: "recording", mimeType: blob.type, size: blob.size, duration: buffer.duration, sampleRate: buffer.sampleRate, channels: buffer.numberOfChannels, hash: await hashBuffer(arrayBuffer), createdAt: new Date().toISOString(), peaks: await analyzeWaveform(buffer) };
      state.project.assets.push(asset);
      state.audio.buffers.set(id, buffer);
      await dbPut("assets", { id, blob, name: file.name, mimeType: blob.type });
      createAudioClip(asset, track.id, startBeat);
      renderAll(); markDirty("Record take");
      setStatus("Recorded take saved", "ready");
      toast("Take captured", `${asset.name} · ${formatDuration(asset.duration)}`, "success");
    } catch (error) {
      console.error(error);
      toast("Could not finalize recording", "The recorder stopped, but this browser could not decode its own recording format.", "error", 8000);
      setStatus("Recording finalize failed", "error");
    }
  }

  function openMidiEditor(clipId) {
    const hit = getClip(clipId);
    if (!hit || hit.clip.type !== "midi") return;
    state.ui.editingMidiClipId = clipId;
    $("#midiEditorTitle").textContent = hit.clip.name;
    $("#midiLength").value = String(ticksToBeats(hit.clip.durationTicks));
    $("#synthWave").value = hit.clip.wave || "sawtooth";
    renderPianoRoll();
    openDialog($("#midiDialog"));
    enableWebMidi().catch(() => {});
  }

  function renderPianoRoll() {
    const hit = getClip(state.ui.editingMidiClipId);
    if (!hit) return;
    const clip = hit.clip;
    const canvas = $("#pianoRoll");
    const rowHeight = 24;
    const pitchLow = 48, pitchHigh = 63;
    const cssWidth = 980, cssHeight = (pitchHigh - pitchLow + 1) * rowHeight;
    const dpr = Math.max(1, window.devicePixelRatio || 1);
    canvas.width = cssWidth * dpr; canvas.height = cssHeight * dpr;
    canvas.style.width = `${cssWidth}px`; canvas.style.height = `${cssHeight}px`;
    const ctx = canvas.getContext("2d"); ctx.scale(dpr, dpr);
    const length = ticksToBeats(clip.durationTicks);
    const grid = Number($("#midiGrid").value || .25);
    for (let pitch = pitchHigh; pitch >= pitchLow; pitch--) {
      const y = (pitchHigh - pitch) * rowHeight;
      const black = [1,3,6,8,10].includes(pitch % 12);
      ctx.fillStyle = black ? "#0a0d12" : "#10141c"; ctx.fillRect(0, y, cssWidth, rowHeight);
      ctx.strokeStyle = "#222b3c"; ctx.beginPath(); ctx.moveTo(0, y + .5); ctx.lineTo(cssWidth, y + .5); ctx.stroke();
    }
    for (let beat = 0; beat <= length + .0001; beat += grid) {
      const x = beat / length * cssWidth;
      ctx.strokeStyle = beat % state.project.timeSignature.numerator === 0 ? "#3a4761" : Number.isInteger(beat) ? "#29344a" : "#1c2433";
      ctx.beginPath(); ctx.moveTo(x + .5, 0); ctx.lineTo(x + .5, cssHeight); ctx.stroke();
    }
    (clip.notes || []).forEach(note => {
      const x = note.start / length * cssWidth;
      const width = Math.max(4, note.duration / length * cssWidth);
      const y = (pitchHigh - clamp(note.pitch, pitchLow, pitchHigh)) * rowHeight + 3;
      ctx.fillStyle = hit.track.color; ctx.fillRect(x + 1, y, width - 2, rowHeight - 6);
      ctx.strokeStyle = "rgba(255,255,255,.55)"; ctx.strokeRect(x + 1.5, y + .5, width - 3, rowHeight - 7);
    });
    const names = ["C","C♯","D","D♯","E","F","F♯","G","G♯","A","A♯","B"];
    $("#pianoKeys").innerHTML = Array.from({ length: pitchHigh - pitchLow + 1 }, (_, index) => pitchHigh - index).map(pitch => `<div class="piano-key ${[1,3,6,8,10].includes(pitch % 12) ? "black" : ""}" data-pitch="${pitch}">${names[pitch % 12]}${Math.floor(pitch / 12) - 1}</div>`).join("");
  }

  async function enableWebMidi() {
    if (!navigator.requestMIDIAccess || state.midiAccess) return;
    const access = await navigator.requestMIDIAccess();
    state.midiAccess = access;
    const bind = () => access.inputs.forEach(input => input.onmidimessage = handleMidiMessage);
    bind(); access.onstatechange = bind;
  }

  async function handleMidiMessage(event) {
    const [status, pitch, velocity] = event.data;
    const command = status & 0xf0;
    if (command === 0x90 && velocity > 0) {
      await ensureAudio();
      const track = activeTrack()?.type === "midi" ? activeTrack() : state.project.tracks.find(item => item.type === "midi");
      const nodes = track && state.audio.trackNodes.get(track.id);
      if (nodes) scheduleSynthNote(nodes.input, pitch, velocity / 127, state.audio.ctx.currentTime + .005, .5, selectedClip()?.clip.wave || "sawtooth");
    }
  }

  function getExportRange() {
    const mode = $("#exportRange").value;
    if (mode === "loop" && state.project.loop.endBeat > state.project.loop.startBeat) return { start: state.project.loop.startBeat, end: state.project.loop.endBeat };
    if (mode === "selection" && state.ui.range) return { start: Math.min(state.ui.range.start, state.ui.range.end), end: Math.max(state.ui.range.start, state.ui.range.end) };
    return { start: 0, end: projectBeats() };
  }

  async function renderOffline(soloTrackId = null) {
    if (!window.OfflineAudioContext) throw new Error("Offline audio rendering is unavailable in this browser.");
    await ensureAudio();
    await hydrateNeededAssets();
    const sampleRate = Number($("#exportSampleRate").value || 48000);
    const range = getExportRange();
    const tail = $("#includeTails").checked ? 2 : 0;
    const duration = Math.max(.1, beatsToSeconds(range.end - range.start) + tail);
    const offline = new OfflineAudioContext(2, Math.ceil(duration * sampleRate), sampleRate);
    const masterIn = offline.createGain();
    const limiter = offline.createDynamicsCompressor();
    const masterGain = offline.createGain();
    limiter.threshold.value = -1; limiter.knee.value = 0; limiter.ratio.value = 20; limiter.attack.value = .003; limiter.release.value = .12;
    masterGain.gain.value = state.project.master.volume;
    if (state.project.master.limiter) masterIn.connect(limiter).connect(masterGain).connect(offline.destination);
    else masterIn.connect(masterGain).connect(offline.destination);

    const convolver = offline.createConvolver();
    const reverbReturn = offline.createGain();
    convolver.buffer = createImpulse(offline);
    reverbReturn.gain.value = state.project.buses.find(bus => bus.id === "reverb")?.mute ? 0 : state.project.buses.find(bus => bus.id === "reverb")?.volume ?? .5;
    convolver.connect(reverbReturn).connect(masterIn);
    const delay = offline.createDelay(3), feedback = offline.createGain(), delayReturn = offline.createGain();
    delay.delayTime.value = 60 / state.project.bpm * .75; feedback.gain.value = .32;
    delayReturn.gain.value = state.project.buses.find(bus => bus.id === "delay")?.mute ? 0 : state.project.buses.find(bus => bus.id === "delay")?.volume ?? .42;
    delay.connect(feedback).connect(delay); delay.connect(delayReturn).connect(masterIn);

    const soloed = state.project.tracks.filter(track => track.solo);
    for (const track of state.project.tracks) {
      const include = soloTrackId ? track.id === soloTrackId : !track.mute && (!soloed.length || track.solo);
      if (!include) continue;
      const input = offline.createGain(), low = offline.createBiquadFilter(), mid = offline.createBiquadFilter(), high = offline.createBiquadFilter(), comp = offline.createDynamicsCompressor(), fader = offline.createGain(), pan = offline.createStereoPanner(), rev = offline.createGain(), del = offline.createGain();
      input.gain.value = track.inputGain; low.type = "lowshelf"; low.frequency.value = 120; low.gain.value = track.effects.eq ? track.eq.low : 0;
      mid.type = "peaking"; mid.frequency.value = 1200; mid.Q.value = .8; mid.gain.value = track.effects.eq ? track.eq.mid : 0;
      high.type = "highshelf"; high.frequency.value = 7000; high.gain.value = track.effects.eq ? track.eq.high : 0;
      comp.threshold.value = track.effects.compressor ? track.compressor.threshold : 0; comp.ratio.value = track.effects.compressor ? track.compressor.ratio : 1;
      fader.gain.value = track.volume; pan.pan.value = track.pan; rev.gain.value = track.sends.reverb; del.gain.value = track.sends.delay;
      input.connect(low).connect(mid).connect(high).connect(comp).connect(fader).connect(pan).connect(masterIn);
      pan.connect(rev).connect(convolver); pan.connect(del).connect(delay);
      for (const clip of track.clips) {
        if (clip.muted) continue;
        const clipStart = ticksToBeats(clip.startTick), clipEnd = clipStart + ticksToBeats(clip.durationTicks);
        const overlapStart = Math.max(range.start, clipStart), overlapEnd = Math.min(range.end, clipEnd);
        if (overlapEnd <= overlapStart) continue;
        const when = beatsToSeconds(overlapStart - range.start);
        const durationSeconds = beatsToSeconds(overlapEnd - overlapStart);
        if (clip.type === "audio") {
          let buffer = state.audio.buffers.get(clip.assetId);
          if (clip.reverse) {
            const sourceBuffer = buffer;
            buffer = offline.createBuffer(sourceBuffer.numberOfChannels, sourceBuffer.length, sourceBuffer.sampleRate);
            for (let channel = 0; channel < sourceBuffer.numberOfChannels; channel++) buffer.copyToChannel(Float32Array.from(sourceBuffer.getChannelData(channel)).reverse(), channel);
          }
          if (!buffer) continue;
          const source = offline.createBufferSource(), gain = offline.createGain();
          const rate = (clip.rate || 1) * Math.pow(2, (clip.pitch || 0) / 12);
          source.buffer = buffer; source.playbackRate.value = rate; source.loop = Boolean(clip.loop);
          if (clip.loop) { source.loopStart = clip.sourceOffset || 0; source.loopEnd = clamp((clip.sourceOffset || 0) + (clip.sourceDuration || buffer.duration), source.loopStart + .01, buffer.duration); }
          const late = beatsToSeconds(overlapStart - clipStart);
          const offset = clamp((clip.sourceOffset || 0) + late * rate, 0, Math.max(0, buffer.duration - .001));
          gain.gain.setValueAtTime(0, when); gain.gain.linearRampToValueAtTime(clip.gain ?? 1, when + Math.min(clip.fadeIn || .005, durationSeconds / 2));
          gain.gain.setValueAtTime(clip.gain ?? 1, Math.max(when, when + durationSeconds - Math.min(clip.fadeOut || .005, durationSeconds / 2))); gain.gain.linearRampToValueAtTime(0, when + durationSeconds);
          source.connect(gain).connect(input); source.start(when, offset); source.stop(when + durationSeconds + .01);
        } else {
          (clip.notes || []).forEach(note => {
            const noteStart = clipStart + note.start, noteEnd = noteStart + note.duration;
            if (noteEnd <= range.start || noteStart >= range.end) return;
            const start = beatsToSeconds(Math.max(noteStart, range.start) - range.start);
            const noteDuration = Math.max(.02, beatsToSeconds(Math.min(noteEnd, range.end) - Math.max(noteStart, range.start)));
            scheduleOfflineSynthNote(offline, input, note.pitch, note.velocity ?? .72, start, noteDuration, clip.wave || "sawtooth");
          });
        }
      }
    }
    return offline.startRendering();
  }

  function scheduleOfflineSynthNote(ctx, destination, pitch, velocity, when, duration, wave) {
    const osc = ctx.createOscillator(), filter = ctx.createBiquadFilter(), gain = ctx.createGain();
    osc.type = wave; osc.frequency.value = 440 * Math.pow(2, (pitch - 69) / 12); filter.type = "lowpass"; filter.frequency.value = 3200;
    const level = clamp(velocity, 0, 1) * .16;
    gain.gain.setValueAtTime(.0001, when); gain.gain.linearRampToValueAtTime(level, when + .008); gain.gain.exponentialRampToValueAtTime(Math.max(.0001, level * .55), when + Math.min(.13, duration * .35)); gain.gain.exponentialRampToValueAtTime(.0001, when + duration);
    osc.connect(filter).connect(gain).connect(destination); osc.start(when); osc.stop(when + duration + .02);
  }

  function encodeWav(audioBuffer, bitDepth = 16, normalize = true) {
    const channels = Math.min(2, audioBuffer.numberOfChannels);
    const length = audioBuffer.length;
    let peak = 0;
    for (let ch = 0; ch < channels; ch++) {
      const data = audioBuffer.getChannelData(ch);
      for (let i = 0; i < data.length; i++) peak = Math.max(peak, Math.abs(data[i]));
    }
    const scale = normalize && peak > 0 ? Math.min(1.8, dbToGain(-1) / peak) : 1;
    const bytesPerSample = bitDepth === 24 ? 3 : 2;
    const dataSize = length * channels * bytesPerSample;
    const buffer = new ArrayBuffer(44 + dataSize);
    const view = new DataView(buffer);
    const writeString = (offset, text) => [...text].forEach((char, index) => view.setUint8(offset + index, char.charCodeAt(0)));
    writeString(0, "RIFF"); view.setUint32(4, 36 + dataSize, true); writeString(8, "WAVE"); writeString(12, "fmt ");
    view.setUint32(16, 16, true); view.setUint16(20, 1, true); view.setUint16(22, channels, true); view.setUint32(24, audioBuffer.sampleRate, true);
    view.setUint32(28, audioBuffer.sampleRate * channels * bytesPerSample, true); view.setUint16(32, channels * bytesPerSample, true); view.setUint16(34, bitDepth, true);
    writeString(36, "data"); view.setUint32(40, dataSize, true);
    let offset = 44;
    for (let i = 0; i < length; i++) {
      for (let ch = 0; ch < channels; ch++) {
        const sample = clamp(audioBuffer.getChannelData(ch)[i] * scale, -1, 1);
        if (bitDepth === 24) {
          let value = sample < 0 ? Math.round(sample * 0x800000) : Math.round(sample * 0x7fffff);
          if (value < 0) value += 0x1000000;
          view.setUint8(offset++, value & 255); view.setUint8(offset++, value >> 8 & 255); view.setUint8(offset++, value >> 16 & 255);
        } else {
          view.setInt16(offset, sample < 0 ? sample * 0x8000 : sample * 0x7fff, true); offset += 2;
        }
      }
    }
    return new Blob([view], { type: "audio/wav" });
  }

  function safeFileName(value) { return value.replace(/[^a-z0-9 _-]/gi, "").trim().replace(/\s+/g, "-") || "fenix-export"; }

  function downloadBlob(blob, filename) {
    const url = URL.createObjectURL(blob);
    const anchor = document.createElement("a");
    anchor.href = url; anchor.download = filename; document.body.append(anchor); anchor.click(); anchor.remove();
    setTimeout(() => URL.revokeObjectURL(url), 30000);
  }

  async function renderMix() {
    const button = $("#renderBtn"), progress = $("#exportProgress"), bar = $("i", progress), label = $("span", progress);
    button.disabled = true; progress.classList.remove("hidden"); bar.style.width = "16%"; label.textContent = "Loading project audio…";
    setStatus("Rendering mix offline…", "busy");
    try {
      bar.style.width = "42%"; label.textContent = "Rendering tracks and effects…";
      const rendered = await renderOffline();
      bar.style.width = "78%"; label.textContent = "Encoding PCM wave file…";
      const bitDepth = Number($("#exportBitDepth").value || 16);
      const blob = encodeWav(rendered, bitDepth, $("#normalizeExport").checked);
      bar.style.width = "100%"; label.textContent = `${(blob.size / 1024 / 1024).toFixed(1)} MB ready`;
      downloadBlob(blob, `${safeFileName(state.project.name)}-${bitDepth}bit.wav`);
      toast("WAV export complete", `${formatDuration(rendered.duration)} · ${(blob.size / 1024 / 1024).toFixed(1)} MB`, "success");
      setStatus("Export complete", "ready");
    } catch (error) {
      console.error(error); label.textContent = "Render failed"; bar.style.width = "0%";
      toast("Export failed", `${error.message} Your project and source files are unchanged.`, "error", 8000); setStatus("Export failed", "error");
    } finally { button.disabled = false; }
  }

  async function renderStems() {
    if (!state.project.tracks.length) return;
    $("#stemsBtn").disabled = true;
    const progress = $("#exportProgress"), bar = $("i", progress), label = $("span", progress); progress.classList.remove("hidden");
    try {
      for (let index = 0; index < state.project.tracks.length; index++) {
        const track = state.project.tracks[index];
        bar.style.width = `${index / state.project.tracks.length * 100}%`; label.textContent = `Rendering stem ${index + 1} of ${state.project.tracks.length}: ${track.name}`;
        const rendered = await renderOffline(track.id);
        downloadBlob(encodeWav(rendered, Number($("#exportBitDepth").value || 16), $("#normalizeExport").checked), `${String(index + 1).padStart(2, "0")}-${safeFileName(track.name)}.wav`);
      }
      bar.style.width = "100%"; label.textContent = `${state.project.tracks.length} stems exported`;
      toast("Stem export complete", "Your browser may ask permission for multiple downloads.", "success", 6500);
    } catch (error) { toast("Stem export failed", error.message, "error", 8000); }
    finally { $("#stemsBtn").disabled = false; }
  }

  async function exportProjectFile() {
    setStatus("Packaging project and local sources…", "busy");
    try {
      const assets = [];
      for (const asset of state.project.assets.filter(item => item.type === "audio")) {
        const record = await dbGet("assets", asset.id);
        if (record?.blob) assets.push({ id: asset.id, mimeType: record.blob.type, data: await blobToDataUrl(record.blob) });
      }
      const payload = { format: "fenix-daw-project", version: 1, exportedAt: new Date().toISOString(), project: state.project, assetFiles: assets };
      downloadBlob(new Blob([JSON.stringify(payload)], { type: "application/json" }), `${safeFileName(state.project.name)}.fenixdaw`);
      toast("Project file downloaded", "This portable file includes the arrangement and available local audio sources.", "success");
      setStatus("Project package ready", "ready");
    } catch (error) { toast("Project export failed", error.message, "error"); setStatus("Project export failed", "error"); }
  }

  function blobToDataUrl(blob) {
    return new Promise((resolve, reject) => { const reader = new FileReader(); reader.onload = () => resolve(reader.result); reader.onerror = () => reject(reader.error); reader.readAsDataURL(blob); });
  }

  function dataUrlToBlob(dataUrl) {
    const [header, data] = dataUrl.split(",");
    const mime = header.match(/data:([^;]+)/)?.[1] || "application/octet-stream";
    const bytes = atob(data), array = new Uint8Array(bytes.length);
    for (let i = 0; i < bytes.length; i++) array[i] = bytes.charCodeAt(i);
    return new Blob([array], { type: mime });
  }

  async function importProjectFile(file) {
    try {
      const payload = JSON.parse(await file.text());
      if (payload.format !== "fenix-daw-project" || !payload.project?.tracks) throw new Error("This is not a valid Fenix Studio project file.");
      stop(true);
      state.project = payload.project;
      state.project.id = uid("project");
      state.project.name = `${state.project.name} Imported`;
      for (const record of payload.assetFiles || []) await dbPut("assets", { id: record.id, blob: dataUrlToBlob(record.data), mimeType: record.mimeType });
      state.audio.buffers.clear(); state.audio.reverseBuffers.clear(); state.history.undo.length = 0; state.history.redo.length = 0;
      state.ui.selectedTrackId = state.project.tracks[0]?.id || null; state.ui.selectedClipIds.clear(); state.ui.zoom = state.project.uiState?.zoom || 72;
      rebuildAudioGraph(); renderAll(); await saveProjectNow();
      toast("Project imported", "A new local copy was created.", "success");
    } catch (error) { console.error(error); toast("Could not open project", error.message, "error", 8000); }
  }

  async function removeUnusedAssets() {
    const used = new Set(state.project.tracks.flatMap(track => track.clips.map(clip => clip.assetId).filter(Boolean)));
    const unused = state.project.assets.filter(asset => !used.has(asset.id));
    if (!unused.length) { toast("Library is clean", "Every asset is used in the arrangement.", "success"); return; }
    snapshot("Remove unused assets");
    state.project.assets = state.project.assets.filter(asset => used.has(asset.id));
    const otherProjects = (await dbAll("projects") || []).filter(project => project.id !== state.project.id);
    const globallyReferenced = new Set(otherProjects.flatMap(project => project.tracks.flatMap(track => track.clips.map(clip => clip.assetId).filter(Boolean))));
    for (const asset of unused) {
      if (!globallyReferenced.has(asset.id)) await dbDelete("assets", asset.id);
      state.audio.buffers.delete(asset.id); state.audio.reverseBuffers.delete(asset.id);
    }
    renderAssets(); markDirty("Remove unused assets");
    toast("Unused assets removed", `${unused.length} local source${unused.length === 1 ? "" : "s"} deleted from this browser.`, "success");
  }

  async function updateStorageEstimate() {
    if (!navigator.storage?.estimate) return;
    try {
      const { usage = 0, quota = 0 } = await navigator.storage.estimate();
      const percent = quota ? usage / quota * 100 : 0;
      $("#storageReadout").textContent = percent ? `${percent.toFixed(1)}%` : "LOCAL";
      if (quota && quota - usage < 50 * 1024 * 1024) toast("Storage is running low", "Export a project file and remove unused assets before recording more audio.", "warning", 8000);
    } catch (_) {}
  }

  function renderCapabilities() {
    const caps = [
      [state.selfTest ? `Core self-test ${state.selfTest.passed}/${state.selfTest.total}` : "Core self-test", Boolean(state.selfTest?.ok)],
      ["Web Audio", Boolean(window.AudioContext || window.webkitAudioContext)], ["Audio worklets", Boolean(window.AudioWorkletNode)],
      ["Offline WAV render", Boolean(window.OfflineAudioContext)], ["Microphone capture", Boolean(navigator.mediaDevices?.getUserMedia)],
      ["MediaRecorder", Boolean(window.MediaRecorder)], ["Web MIDI", Boolean(navigator.requestMIDIAccess)],
      ["IndexedDB projects", Boolean(window.indexedDB)], ["Storage quota estimate", Boolean(navigator.storage?.estimate)],
      ["Waveform worker", Boolean(window.Worker)], ["Service worker / offline", Boolean(navigator.serviceWorker) && location.protocol !== "file:"]
    ];
    $("#capabilityReport").innerHTML = caps.map(([name, value]) => `<div class="capability-row"><span>${name}</span><b class="${value ? "" : "no"}">${value ? "AVAILABLE" : "UNAVAILABLE"}</b></div>`).join("");
    $("#capabilitySummary").textContent = caps.filter(([, value]) => value).slice(0, 3).map(([name]) => name.toUpperCase()).join(" • ");
  }

  function runSelfTests() {
    const checks = [
      ["tick round-trip", () => ticksToBeats(beatsToTicks(7.25)) === 7.25],
      ["gain round-trip", () => Math.abs(gainToDb(dbToGain(-6)) + 6) < .0001],
      ["default tracks", () => createProject("Test").tracks.length === 4],
      ["bar formatting", () => formatBars(4).startsWith("002")],
      ["snap grid", () => { const old = state.ui.grid; state.ui.grid = .5; const value = snapBeat(1.24); state.ui.grid = old; return value === 1; }],
      ["WAV header", () => { const fake = { numberOfChannels: 2, length: 16, sampleRate: 48000, getChannelData: () => new Float32Array(16) }; return encodeWav(fake, 16, false).size === 44 + 16 * 2 * 2; }]
    ];
    let passed = 0;
    for (const [name, check] of checks) { try { if (check()) passed++; else console.error(`Self-test failed: ${name}`); } catch (error) { console.error(`Self-test error: ${name}`, error); } }
    state.selfTest = { passed, total: checks.length, ok: passed === checks.length };
    return state.selfTest;
  }

  function setByPath(object, path, value) {
    const keys = path.split(".");
    const last = keys.pop();
    const target = keys.reduce((current, key) => current[key], object);
    target[last] = value;
  }

  function beginClipPointer(event, element) {
    if (event.button !== 0) return;
    const hit = getClip(element.dataset.clipId);
    if (!hit || hit.clip.locked) return;
    const resize = event.target.dataset.resize;
    const fade = event.target.classList.contains("fade-handle") ? (event.target.classList.contains("in") ? "fadeIn" : "fadeOut") : null;
    if (!state.ui.selectedClipIds.has(hit.clip.id)) selectClip(hit.clip.id, event.shiftKey || event.metaKey || event.ctrlKey);
    snapshot(resize ? "Trim clip" : fade ? "Adjust fade" : "Move clip");
    const originals = [...state.ui.selectedClipIds].map(id => {
      const item = getClip(id);
      return item && { id, trackId: item.track.id, startTick: item.clip.startTick, durationTicks: item.clip.durationTicks, sourceOffset: item.clip.sourceOffset || 0, fadeIn: item.clip.fadeIn || 0, fadeOut: item.clip.fadeOut || 0 };
    }).filter(Boolean);
    const primaryStart = ticksToBeats(hit.clip.startTick);
    const rippleFollowers = state.ui.ripple && !resize && !fade ? hit.track.clips
      .filter(clip => !state.ui.selectedClipIds.has(clip.id) && ticksToBeats(clip.startTick) >= primaryStart + ticksToBeats(hit.clip.durationTicks))
      .map(clip => ({ id: clip.id, startTick: clip.startTick })) : [];
    state.ui.dragging = { kind: resize ? `resize-${resize}` : fade || "move", startX: event.clientX, originals, primaryId: hit.clip.id, rippleFollowers };
    element.setPointerCapture?.(event.pointerId);
    event.preventDefault(); event.stopPropagation();
  }

  function moveClipPointer(event) {
    const drag = state.ui.dragging;
    if (!drag) return;
    const deltaBeatRaw = pxToBeat(event.clientX - drag.startX);
    const primary = drag.originals.find(item => item.id === drag.primaryId);
    const snappedPrimary = primary ? snapBeat(ticksToBeats(primary.startTick) + deltaBeatRaw) : 0;
    const deltaBeat = primary && drag.kind === "move" ? snappedPrimary - ticksToBeats(primary.startTick) : deltaBeatRaw;
    drag.originals.forEach(original => {
      const hit = getClip(original.id); if (!hit) return;
      if (drag.kind === "move") hit.clip.startTick = beatsToTicks(Math.max(0, ticksToBeats(original.startTick) + deltaBeat));
      else if (drag.kind === "resize-right") hit.clip.durationTicks = beatsToTicks(Math.max(.125, snapBeat(ticksToBeats(original.durationTicks) + deltaBeat)));
      else if (drag.kind === "resize-left") {
        const oldStart = ticksToBeats(original.startTick), oldDuration = ticksToBeats(original.durationTicks);
        const nextStart = clamp(snapBeat(oldStart + deltaBeat), 0, oldStart + oldDuration - .125);
        hit.clip.startTick = beatsToTicks(nextStart); hit.clip.durationTicks = beatsToTicks(oldDuration - (nextStart - oldStart));
        if (hit.clip.type === "audio") hit.clip.sourceOffset = Math.max(0, original.sourceOffset + beatsToSeconds(nextStart - oldStart) * (hit.clip.rate || 1));
      } else if (drag.kind === "fadeIn" || drag.kind === "fadeOut") {
        const signedSeconds = beatsToSeconds(drag.kind === "fadeIn" ? deltaBeat : -deltaBeat);
        const max = beatsToSeconds(ticksToBeats(hit.clip.durationTicks)) / 2;
        hit.clip[drag.kind] = clamp(original[drag.kind] + signedSeconds, 0, max);
      }
    });
    renderTimeline();
  }

  function endClipPointer(event) {
    const drag = state.ui.dragging;
    if (!drag) return;
    if (drag.kind === "move") {
      const lane = document.elementFromPoint(event.clientX, event.clientY)?.closest(".track-lane");
      const targetTrack = lane && getTrack(lane.dataset.trackId);
      const primaryHit = getClip(drag.primaryId);
      if (targetTrack && primaryHit && targetTrack.id !== primaryHit.track.id && compatibleTrack(targetTrack, primaryHit.clip)) {
        const moving = primaryHit.clip;
        primaryHit.track.clips = primaryHit.track.clips.filter(clip => clip.id !== moving.id);
        targetTrack.clips.push(moving);
        moving.color = targetTrack.color;
        state.ui.selectedTrackId = targetTrack.id;
      }
      const primaryOriginal = drag.originals.find(item => item.id === drag.primaryId);
      const movedPrimary = getClip(drag.primaryId)?.clip;
      if (state.ui.ripple && primaryOriginal && movedPrimary) {
        const deltaTicks = movedPrimary.startTick - primaryOriginal.startTick;
        drag.rippleFollowers.forEach(item => { const follower = getClip(item.id); if (follower) follower.clip.startTick = Math.max(0, item.startTick + deltaTicks); });
      }
    }
    state.ui.dragging = null;
    renderAll(); markDirty(drag.kind.includes("resize") ? "Trim clip" : drag.kind.includes("fade") ? "Adjust fade" : "Move clip");
  }

  function compatibleTrack(track, clip) { return clip.type === "midi" ? track.type === "midi" : ["audio", "mic"].includes(track.type); }

  function showContextMenu(event, items) {
    const menu = $("#contextMenu");
    menu.innerHTML = items.map(item => item.separator ? "<hr>" : `<button type="button" data-menu-action="${item.action}"><span>${escapeHtml(item.label)}</span><small>${item.shortcut || ""}</small></button>`).join("");
    menu.style.left = `${Math.min(event.clientX, innerWidth - 190)}px`; menu.style.top = `${Math.min(event.clientY, innerHeight - items.length * 31 - 20)}px`;
    menu.classList.remove("hidden");
    menu.onclick = click => { const action = click.target.closest("button")?.dataset.menuAction; if (action) runContextAction(action); menu.classList.add("hidden"); };
    event.preventDefault(); event.stopPropagation();
  }

  function runContextAction(action) {
    const clipHit = selectedClip();
    const track = activeTrack();
    if (action === "split") splitSelectedAt();
    else if (action === "duplicate") duplicateSelectedClips();
    else if (action === "delete") deleteSelectedClips();
    else if (action === "mute" && clipHit) { snapshot("Mute clip"); clipHit.clip.muted = !clipHit.clip.muted; renderAll(); markDirty("Mute clip"); }
    else if (action === "loop" && clipHit) { snapshot("Loop clip"); clipHit.clip.loop = !clipHit.clip.loop; renderAll(); markDirty("Loop clip"); }
    else if (action === "reverse" && clipHit?.clip.type === "audio") { snapshot("Reverse clip"); clipHit.clip.reverse = !clipHit.clip.reverse; renderAll(); markDirty("Reverse clip"); }
    else if (action === "normalize") normalizeSelectedClip();
    else if (action === "duplicate-track" && track) duplicateTrack(track.id);
    else if (action === "delete-track" && track) deleteTrack(track.id);
  }

  function clipContextItems(clip) {
    return [
      { label: "Split at playhead", action: "split", shortcut: "S" }, { label: "Duplicate", action: "duplicate", shortcut: "Ctrl D" },
      { label: clip.muted ? "Unmute clip" : "Mute clip", action: "mute" }, { label: clip.loop ? "Disable loop" : "Loop clip", action: "loop" },
      { separator: true }, ...(clip.type === "audio" ? [{ label: clip.reverse ? "Play forward" : "Reverse", action: "reverse" }, { label: "Normalize peak", action: "normalize" }] : []),
      { separator: true }, { label: "Delete", action: "delete", shortcut: "Delete" }
    ];
  }

  async function renderProjectList() {
    const projects = (await dbAll("projects") || []).sort((a, b) => b.updatedAt.localeCompare(a.updatedAt));
    $("#projectList").innerHTML = projects.length ? projects.map(project => `<article class="project-card ${project.id === state.project.id ? "current" : ""}"><div><strong>${escapeHtml(project.name)}</strong><small>${project.tracks.length} TRACKS · ${project.assets.length} ASSETS · ${new Date(project.updatedAt).toLocaleString()}</small></div><div class="project-card-actions"><button type="button" class="secondary-button" data-open-project="${project.id}">${project.id === state.project.id ? "OPEN" : "LOAD"}</button>${project.id !== state.project.id ? `<button type="button" class="danger-outline" data-delete-project="${project.id}">×</button>` : ""}</div></article>`).join("") : emptyInspector("NO SAVED PROJECTS", "Create a session to begin.");
  }

  async function loadProject(id) {
    const project = await dbGet("projects", id);
    if (!project) return;
    pause();
    state.project = project; state.ui.zoom = project.uiState?.zoom || 72; state.ui.playheadBeat = 0; state.ui.selectedTrackId = project.tracks[0]?.id || null; state.ui.selectedClipIds.clear(); state.audio.buffers.clear(); state.audio.reverseBuffers.clear(); state.history.undo.length = 0; state.history.redo.length = 0;
    rebuildAudioGraph(); renderAll(); $("#projectDialog").close(); await dbPut("settings", { key: "lastProjectId", value: id });
    toast("Project loaded", project.name, "success");
  }

  async function createNewProject(copyCurrent = false) {
    if (state.ui.dirty) await saveProjectNow();
    pause();
    const project = copyCurrent ? deepClone(state.project) : createProject();
    project.id = uid("project"); project.createdAt = new Date().toISOString(); project.updatedAt = project.createdAt;
    if (copyCurrent) project.name = `${project.name} Copy`;
    state.project = project; state.ui.playheadBeat = 0; state.ui.selectedTrackId = project.tracks[0]?.id || null; state.ui.selectedClipIds.clear(); state.history.undo.length = 0; state.history.redo.length = 0;
    if (!copyCurrent) { state.audio.buffers.clear(); state.audio.reverseBuffers.clear(); }
    rebuildAudioGraph(); renderAll(); await saveProjectNow();
    if ($("#projectDialog").open) $("#projectDialog").close();
    toast(copyCurrent ? "Project duplicated" : "New project created", project.name, "success");
  }

  function setupEvents() {
    $("#playBtn").addEventListener("click", play);
    $("#stopBtn").addEventListener("click", () => stop());
    $("#returnBtn").addEventListener("click", () => seek(0));
    $("#recordBtn").addEventListener("click", toggleRecording);
    $("#undoBtn").addEventListener("click", undo); $("#redoBtn").addEventListener("click", redo);
    $("#importBtn").addEventListener("click", () => $("#audioFileInput").click());
    $("#assetImportBtn").addEventListener("click", () => $("#audioFileInput").click());
    $("#audioFileInput").addEventListener("change", event => { importAudioFiles(event.target.files); event.target.value = ""; });
    $("#newMidiBtn").addEventListener("click", () => createMidiClip());
    $("#emptyImportBtn").addEventListener("click", () => $("#audioFileInput").click());
    $("#emptyRecordBtn").addEventListener("click", toggleRecording);
    $("#emptyMidiBtn").addEventListener("click", () => createMidiClip());
    $("#assetSearch").addEventListener("input", renderAssets);
    $("#cleanAssetsBtn").addEventListener("click", removeUnusedAssets);

    $("#projectName").addEventListener("change", event => { snapshot("Rename project"); state.project.name = event.target.value.trim() || "Untitled Session"; renderAll(); markDirty("Rename project"); });
    $("#bpmInput").addEventListener("change", event => { snapshot("Change tempo"); state.project.bpm = clamp(Number(event.target.value) || 120, 30, 300); if (state.audio.delayNode) state.audio.delayNode.delayTime.setTargetAtTime(60 / state.project.bpm * .75, state.audio.ctx.currentTime, .02); renderAll(); markDirty("Change tempo"); });
    $("#timeSignatureSelect").addEventListener("change", event => { snapshot("Change time signature"); const [numerator, denominator] = event.target.value.split("/").map(Number); state.project.timeSignature = { numerator, denominator }; renderAll(); markDirty("Change time signature"); });
    $("#gridSelect").addEventListener("change", event => { state.ui.grid = event.target.value; renderTimeline(); });
    $("#snapBtn").addEventListener("click", () => { state.ui.snap = !state.ui.snap; renderAll(); });
    $("#loopBtn").addEventListener("click", () => { snapshot("Toggle loop"); state.project.loop.enabled = !state.project.loop.enabled; renderAll(); markDirty("Toggle loop"); });
    $("#punchBtn").addEventListener("click", () => { snapshot("Toggle punch recording"); state.project.punch ||= { enabled: false, startBeat: 0, endBeat: 8 }; state.project.punch.enabled = !state.project.punch.enabled; if (state.project.loop.enabled) { state.project.punch.startBeat = state.project.loop.startBeat; state.project.punch.endBeat = state.project.loop.endBeat; } renderAll(); markDirty("Toggle punch recording"); });
    $("#metroBtn").addEventListener("click", event => { event.currentTarget.classList.toggle("active"); event.currentTarget.setAttribute("aria-pressed", event.currentTarget.classList.contains("active")); });
    $("#rippleBtn").addEventListener("click", () => { state.ui.ripple = !state.ui.ripple; renderAll(); });
    $("#automationBtn").addEventListener("click", () => { state.ui.automation = !state.ui.automation; renderAll(); });
    $("#compactTracksBtn").addEventListener("click", () => { state.ui.compact = !state.ui.compact; renderAll(); });
    $("#zoomRange").addEventListener("input", event => { state.ui.zoom = Number(event.target.value); renderTimeline(); });
    $("#zoomRange").addEventListener("change", () => markDirty("Timeline zoom"));
    $("#zoomInBtn").addEventListener("click", () => { state.ui.zoom = clamp(state.ui.zoom + 12, 36, 180); renderAll(); });
    $("#zoomOutBtn").addEventListener("click", () => { state.ui.zoom = clamp(state.ui.zoom - 12, 36, 180); renderAll(); });
    $("#fitBtn").addEventListener("click", () => { state.ui.zoom = clamp(($("#timelineViewport").clientWidth - 20) / Math.max(16, projectBeats()), 36, 180); renderAll(); $("#timelineViewport").scrollLeft = 0; });
    $("#tapTempoBtn").addEventListener("click", tapTempo);
    $("#positionDisplay").addEventListener("click", () => { state.project.displayMode = state.project.displayMode === "bars" ? "seconds" : "bars"; updatePositionDisplay(); markDirty("Position display mode"); });

    $("#collapseAssetsBtn").addEventListener("click", () => { $(".workspace").classList.add("assets-collapsed"); $("#assetPanelBtn").classList.remove("active"); $("#assetPanelBtn").setAttribute("aria-pressed", "false"); renderTimeline(); });
    $("#collapseInspectorBtn").addEventListener("click", () => { $(".workspace").classList.add("inspector-collapsed"); $("#inspectorPanelBtn").classList.remove("active"); $("#inspectorPanelBtn").setAttribute("aria-pressed", "false"); renderTimeline(); });
    $("#assetPanelBtn").addEventListener("click", event => { const collapsed = $(".workspace").classList.toggle("assets-collapsed"); event.currentTarget.classList.toggle("active", !collapsed); event.currentTarget.setAttribute("aria-pressed", String(!collapsed)); renderTimeline(); });
    $("#inspectorPanelBtn").addEventListener("click", event => { const collapsed = $(".workspace").classList.toggle("inspector-collapsed"); event.currentTarget.classList.toggle("active", !collapsed); event.currentTarget.setAttribute("aria-pressed", String(!collapsed)); renderTimeline(); });
    $("#mixerToggleBtn").addEventListener("click", () => { $("#mixerDrawer").classList.toggle("collapsed"); $("#app").classList.toggle("mixer-collapsed"); $("#mixerToggleBtn").textContent = $("#mixerDrawer").classList.contains("collapsed") ? "⌃" : "⌄"; });
    $("#wideMixerBtn").addEventListener("click", () => { state.ui.wideMixer = !state.ui.wideMixer; renderMixer(); });

    $("#helpBtn").addEventListener("click", () => openDialog($("#helpDialog")));
    $("#settingsBtn").addEventListener("click", () => { renderCapabilities(); openDialog($("#settingsDialog")); });
    $("#exportBtn").addEventListener("click", () => { const option = $('#exportRange option[value="selection"]'); option.disabled = !state.ui.range; if (!state.ui.range && $("#exportRange").value === "selection") $("#exportRange").value = "project"; const range = getExportRange(); $("#exportProjectName").textContent = state.project.name; $("#exportDuration").textContent = formatDuration(beatsToSeconds(range.end - range.start)); openDialog($("#exportDialog")); });
    $("#renderBtn").addEventListener("click", renderMix); $("#stemsBtn").addEventListener("click", renderStems);
    $("#requestMicBtn").addEventListener("click", () => requestMicrophone().catch(error => toast("Microphone permission denied", `${error.message} Retry after allowing microphone access in your browser.`, "error", 8000)));
    $("#monitorLevel").addEventListener("input", applyMixState);
    $("#saveProjectFileBtn").addEventListener("click", exportProjectFile);
    $("#openProjectFileBtn").addEventListener("click", () => $("#projectFileInput").click());
    $("#projectFileInput").addEventListener("change", event => { if (event.target.files[0]) importProjectFile(event.target.files[0]); event.target.value = ""; });
    $("#newProjectBtn").addEventListener("click", () => createNewProject(false));
    $("#projectBrowserBtn").addEventListener("click", async () => { await renderProjectList(); openDialog($("#projectDialog")); });
    $("#createProjectBtn").addEventListener("click", () => createNewProject(false));
    $("#duplicateProjectBtn").addEventListener("click", () => createNewProject(true));
    $("#addTrackBtn").addEventListener("click", () => openDialog($("#trackDialog")));

    $$('[data-track-type]').forEach(button => button.addEventListener("click", () => { addTrack(button.dataset.trackType); $("#trackDialog").close(); }));
    $$('[data-asset-tab]').forEach(button => button.addEventListener("click", () => { state.ui.assetTab = button.dataset.assetTab; $$('[data-asset-tab]').forEach(item => item.classList.toggle("active", item === button)); renderAssets(); }));
    $$('[data-inspector-tab]').forEach(button => button.addEventListener("click", () => { state.ui.inspectorTab = button.dataset.inspectorTab; renderInspector(); }));
    $$('[data-tool]').forEach(button => button.addEventListener("click", () => { state.ui.tool = button.dataset.tool; $$('[data-tool]').forEach(item => item.classList.toggle("active", item === button)); }));

    $("#dropZone").addEventListener("dragover", event => { event.preventDefault(); event.currentTarget.classList.add("dragover"); });
    $("#dropZone").addEventListener("dragleave", event => event.currentTarget.classList.remove("dragover"));
    $("#dropZone").addEventListener("drop", event => { event.preventDefault(); event.currentTarget.classList.remove("dragover"); importAudioFiles(event.dataTransfer.files); });
    document.addEventListener("dragover", event => { if ([...event.dataTransfer.types].includes("Files")) event.preventDefault(); });
    document.addEventListener("drop", event => { if ([...event.dataTransfer.types].includes("Files") && !event.target.closest("#dropZone,.track-lane")) { event.preventDefault(); importAudioFiles(event.dataTransfer.files); } });

    $("#assetList").addEventListener("dragstart", event => { const item = event.target.closest(".asset-item"); if (item) { event.dataTransfer.setData("application/x-fenix-asset", item.dataset.assetId); event.dataTransfer.effectAllowed = "copy"; } });
    $("#assetList").addEventListener("dblclick", event => { const item = event.target.closest(".asset-item"); if (item) previewAsset(item.dataset.assetId); });

    $("#timelineViewport").addEventListener("scroll", syncTrackScroll);
    $("#timelineContent").addEventListener("dragover", event => { const lane = event.target.closest(".track-lane"); if (lane) { event.preventDefault(); lane.classList.add("drop-target"); } });
    $("#timelineContent").addEventListener("dragleave", event => event.target.closest(".track-lane")?.classList.remove("drop-target"));
    $("#timelineContent").addEventListener("drop", event => {
      const lane = event.target.closest(".track-lane"); if (!lane) return; event.preventDefault(); lane.classList.remove("drop-target");
      const rect = $("#timelineContent").getBoundingClientRect(); const beat = snapBeat(pxToBeat(event.clientX - rect.left)); const assetId = event.dataTransfer.getData("application/x-fenix-asset");
      const asset = state.project.assets.find(item => item.id === assetId);
      if (asset?.type === "audio") createAudioClip(asset, lane.dataset.trackId, beat), renderAll(), markDirty("Place asset");
      else if (event.dataTransfer.files?.length) importAudioFiles(event.dataTransfer.files, lane.dataset.trackId, beat);
    });

    $("#timelineContent").addEventListener("pointerdown", event => {
      const lane = event.target.closest(".track-lane"); const rect = $("#timelineContent").getBoundingClientRect(); const beat = snapBeat(pxToBeat(event.clientX - rect.left));
      const clip = event.target.closest(".clip");
      if (clip) { if (state.ui.tool === "split") { selectClip(clip.dataset.clipId); splitSelectedAt(beat); } else beginClipPointer(event, clip); return; }
      if (event.target.id === "rulerCanvas" && event.shiftKey) { state.ui.range = { start: beat, end: beat }; state.ui.draggingRange = true; renderSelectionRange(); event.preventDefault(); return; }
      if (lane) { state.ui.selectedTrackId = lane.dataset.trackId; state.ui.selectedClipIds.clear(); state.ui.inspectorTab = "track"; if (state.ui.tool === "draw" && state.ui.automation) addAutomationPoint(activeTrack(), "volume", beat, activeTrack().volume); else seek(beat); renderAll(); }
      else if (event.target.id === "rulerCanvas") seek(beat);
    });
    document.addEventListener("pointermove", event => { if (state.ui.draggingRange) { const rect = $("#timelineContent").getBoundingClientRect(); state.ui.range.end = snapBeat(pxToBeat(event.clientX - rect.left)); renderSelectionRange(); } else moveClipPointer(event); });
    document.addEventListener("pointerup", event => { if (state.ui.draggingRange) { state.ui.draggingRange = false; renderSelectionRange(); } else endClipPointer(event); });
    $("#timelineContent").addEventListener("dblclick", event => { const clip = event.target.closest(".clip"); if (clip && getClip(clip.dataset.clipId)?.clip.type === "midi") openMidiEditor(clip.dataset.clipId); });
    $("#timelineContent").addEventListener("contextmenu", event => { const element = event.target.closest(".clip"); if (element) { selectClip(element.dataset.clipId); const hit = getClip(element.dataset.clipId); showContextMenu(event, clipContextItems(hit.clip)); } });

    $("#trackHeaders").addEventListener("click", handleTrackHeaderClick);
    $("#trackHeaders").addEventListener("change", handleTrackHeaderChange);
    $("#trackHeaders").addEventListener("input", handleTrackHeaderInput);
    $("#mixerChannels").addEventListener("click", handleMixerClick);
    $("#mixerChannels").addEventListener("input", handleMixerInput);
    $("#mixerChannels").addEventListener("change", () => { renderTimeline(); renderInspector(); markDirty("Mix change"); });
    $("#inspectorContent").addEventListener("click", handleInspectorClick);
    $("#inspectorContent").addEventListener("input", handleInspectorInput);
    $("#inspectorContent").addEventListener("change", handleInspectorChange);
    $("#inspectorContent").addEventListener("pointerdown", event => { if (event.target.matches("input[type=range]")) snapshot("Adjust parameter"); });

    $("#projectList").addEventListener("click", async event => {
      const openId = event.target.dataset.openProject, deleteId = event.target.dataset.deleteProject;
      if (openId) loadProject(openId);
      if (deleteId) { await dbDelete("projects", deleteId); await renderProjectList(); toast("Project removed", "Its shared audio assets remain available to other local projects.", "success"); }
    });

    $("#pianoRoll").addEventListener("mousedown", handlePianoRollMouse);
    $("#pianoRoll").addEventListener("contextmenu", event => { event.preventDefault(); handlePianoRollMouse(event, true); });
    $("#pianoKeys").addEventListener("pointerdown", event => previewMidiPitch(Number(event.target.closest(".piano-key")?.dataset.pitch)));
    $("#midiLength").addEventListener("change", event => { const hit = getClip(state.ui.editingMidiClipId); if (!hit) return; snapshot("Resize MIDI clip"); hit.clip.durationTicks = beatsToTicks(Number(event.target.value)); renderPianoRoll(); renderTimeline(); markDirty("Resize MIDI clip"); });
    $("#midiGrid").addEventListener("change", renderPianoRoll);
    $("#synthWave").addEventListener("change", event => { const hit = getClip(state.ui.editingMidiClipId); if (hit) { snapshot("Change instrument"); hit.clip.wave = event.target.value; renderTimeline(); markDirty("Change instrument"); } });
    $("#clearMidiBtn").addEventListener("click", () => { const hit = getClip(state.ui.editingMidiClipId); if (hit) { snapshot("Clear MIDI notes"); hit.clip.notes = []; renderPianoRoll(); renderTimeline(); markDirty("Clear MIDI notes"); } });

    document.addEventListener("keydown", handleKeyboard);
    document.addEventListener("click", event => { if (!event.target.closest("#contextMenu")) closeAllMenus(); });
    window.addEventListener("resize", () => renderTimeline());
    window.addEventListener("beforeunload", () => { if (state.ui.dirty) saveProjectNow(); });
  }

  function handleTrackHeaderClick(event) {
    if (event.target.id === "markerBtn") { addMarker(); return; }
    const header = event.target.closest(".track-header"); if (!header) return;
    const track = getTrack(header.dataset.trackId); if (!track) return;
    state.ui.selectedTrackId = track.id; state.ui.selectedClipIds.clear(); state.ui.inspectorTab = "track";
    const action = event.target.dataset.trackAction;
    if (["arm", "monitor", "mute", "solo"].includes(action)) toggleTrack(track.id, action, event.altKey);
    else if (action === "fx") { state.ui.inspectorTab = "fx"; renderAll(); }
    else if (action === "menu") showContextMenu(event, [{ label: "Duplicate track", action: "duplicate-track" }, { separator: true }, { label: "Delete track", action: "delete-track" }]);
    else renderAll();
  }

  function handleTrackHeaderChange(event) {
    const header = event.target.closest(".track-header"); if (!header) return;
    const track = getTrack(header.dataset.trackId); if (!track) return;
    if (event.target.classList.contains("track-name-input")) { snapshot("Rename track"); track.name = event.target.value.trim() || "Untitled Track"; renderAll(); markDirty("Rename track"); }
    else if (event.target.dataset.trackParam) { renderMixer(); renderInspector(); markDirty("Track volume"); }
  }

  function handleTrackHeaderInput(event) {
    const header = event.target.closest(".track-header"); const track = header && getTrack(header.dataset.trackId); if (!track) return;
    if (event.target.dataset.trackParam === "volume") { track.volume = Number(event.target.value); event.target.nextElementSibling.textContent = Math.round(track.volume * 100); applyMixState(); }
  }

  function handleMixerClick(event) {
    const channel = event.target.closest("[data-mixer-track]");
    if (channel) {
      const track = getTrack(channel.dataset.mixerTrack); state.ui.selectedTrackId = track.id;
      const action = event.target.dataset.mixerAction;
      if (["mute", "solo", "arm"].includes(action)) toggleTrack(track.id, action, event.altKey); else renderAll();
    }
    const busElement = event.target.closest("[data-bus-id]");
    if (busElement && event.target.dataset.busAction === "mute") { snapshot("Mute bus"); const bus = state.project.buses.find(item => item.id === busElement.dataset.busId); bus.mute = !bus.mute; applyMixState(); renderMixer(); markDirty("Mute bus"); }
    if (event.target.dataset.masterAction === "limiter") { snapshot("Toggle limiter"); state.project.master.limiter = !state.project.master.limiter; connectMasterChain(); renderMixer(); markDirty("Toggle limiter"); }
  }

  function handleMixerInput(event) {
    const channel = event.target.closest("[data-mixer-track]");
    if (channel && event.target.dataset.mixerParam) {
      const track = getTrack(channel.dataset.mixerTrack), key = event.target.dataset.mixerParam, value = Number(event.target.value);
      if (key === "reverb") track.sends.reverb = value; else track[key] = value;
      applyMixState();
    }
    const busElement = event.target.closest("[data-bus-id]");
    if (busElement && event.target.dataset.busParam === "volume") { const bus = state.project.buses.find(item => item.id === busElement.dataset.busId); bus.volume = Number(event.target.value); applyMixState(); }
    if (event.target.dataset.masterParam === "volume") { state.project.master.volume = Number(event.target.value); applyMixState(); }
  }

  function handleInspectorInput(event) {
    const track = activeTrack(); const clipHit = selectedClip();
    const trackPath = event.target.dataset.inspectParam;
    if (track && trackPath) { setByPath(track, trackPath, Number(event.target.value)); applyMixState(); const output = event.target.nextElementSibling; if (output) output.textContent = displayParameter(trackPath, Number(event.target.value)); }
    const clipPath = event.target.dataset.clipParam;
    if (clipHit && clipPath && event.target.type === "range") {
      if (clipPath === "clipGain") clipHit.clip.gain = Number(event.target.value); else clipHit.clip[clipPath] = Number(event.target.value);
      const output = event.target.nextElementSibling; if (output) output.textContent = displayParameter(clipPath, Number(event.target.value));
      renderTimeline();
    }
  }

  function displayParameter(path, value) {
    if (path.includes("pan")) return value === 0 ? "CENTER" : value < 0 ? `${Math.round(-value * 100)} L` : `${Math.round(value * 100)} R`;
    if (["volume", "inputGain", "clipGain"].includes(path)) return `${gainToDb(value).toFixed(1)} dB`;
    if (path.includes("threshold") || path.startsWith("eq.")) return `${value.toFixed(1)} dB`;
    if (path.includes("ratio")) return `${value.toFixed(1)}:1`;
    if (path.includes("fade")) return `${value.toFixed(2)} s`;
    if (path.includes("send")) return `${Math.round(value * 100)}%`;
    return String(value);
  }

  function handleInspectorChange(event) {
    const track = activeTrack(), clipHit = selectedClip();
    const trackPath = event.target.dataset.inspectParam;
    if (track && trackPath) { setByPath(track, trackPath, Number(event.target.value)); applyMixState(); renderMixer(); renderTimeline(); markDirty("Adjust track parameter"); }
    const clipPath = event.target.dataset.clipParam;
    if (clipHit && clipPath) {
      if (event.target.type !== "range") snapshot("Edit clip");
      const value = event.target.value;
      if (clipPath === "startBeat") clipHit.clip.startTick = beatsToTicks(snapBeat(Number(value)));
      else if (clipPath === "durationBeat") clipHit.clip.durationTicks = beatsToTicks(Math.max(.125, Number(value)));
      else if (clipPath === "reverse") clipHit.clip.reverse = value === "true";
      else if (clipPath === "clipGain") clipHit.clip.gain = Number(value);
      else clipHit.clip[clipPath] = Number(value);
      renderAll(); markDirty("Edit clip");
    }
    if (track && event.target.dataset.routeParam === "route") { snapshot("Change routing"); track.route = event.target.value; markDirty("Change routing"); }
  }

  function handleInspectorClick(event) {
    const track = activeTrack(), clipHit = selectedClip();
    const action = event.target.dataset.inspectAction;
    if (track && ["arm", "monitor", "mute", "solo"].includes(action)) toggleTrack(track.id, action);
    else if (action === "duplicate-track") duplicateTrack(track.id);
    else if (action === "delete-track") deleteTrack(track.id);
    else if (action === "show-automation") { state.ui.automation = !state.ui.automation; renderAll(); }
    else if (action === "add-volume-point") addAutomationPoint(track, "volume", state.ui.playheadBeat, track.volume);
    const fx = event.target.dataset.fxToggle;
    if (fx && track) { snapshot(`Toggle ${fx}`); track.effects[fx] = !track.effects[fx]; applyMixState(); renderInspector(); renderMixer(); markDirty(`Toggle ${fx}`); }
    const clipAction = event.target.dataset.clipAction;
    if (!clipAction || !clipHit) return;
    if (clipAction === "split") splitSelectedAt();
    else if (clipAction === "duplicate") duplicateSelectedClips();
    else if (clipAction === "delete") deleteSelectedClips();
    else if (clipAction === "normalize") normalizeSelectedClip();
    else if (clipAction === "edit-midi") openMidiEditor(clipHit.clip.id);
    else if (["loop", "mute", "lock"].includes(clipAction)) { snapshot(`${clipAction} clip`); clipHit.clip[clipAction] = !clipHit.clip[clipAction]; renderAll(); markDirty(`${clipAction} clip`); }
  }

  function addAutomationPoint(track, parameter, beat, value) {
    if (!track) return;
    snapshot("Add automation point");
    const points = track.automation[parameter] || (track.automation[parameter] = []);
    const existing = points.find(point => Math.abs(point.beat - beat) < .03);
    if (existing) existing.value = value; else points.push({ beat: snapBeat(beat), value });
    state.ui.automation = true; renderAll(); markDirty("Add automation point");
  }

  function addMarker() {
    const name = `MARKER ${state.project.markers.length + 1}`;
    snapshot("Add marker"); state.project.markers.push({ id: uid("mark"), beat: snapBeat(state.ui.playheadBeat), name }); renderTimeline(); markDirty("Add marker");
  }

  function handlePianoRollMouse(event, removeOnly = false) {
    const hit = getClip(state.ui.editingMidiClipId); if (!hit) return;
    const canvas = $("#pianoRoll"), rect = canvas.getBoundingClientRect(), length = ticksToBeats(hit.clip.durationTicks), grid = Number($("#midiGrid").value || .25);
    const beat = clamp(Math.floor(((event.clientX - rect.left) / rect.width * length) / grid) * grid, 0, length - grid);
    const pitch = clamp(63 - Math.floor((event.clientY - rect.top) / (rect.height / 16)), 48, 63);
    const found = hit.clip.notes.find(note => beat >= note.start && beat <= note.start + note.duration && pitch === note.pitch);
    snapshot(found || removeOnly || event.button === 2 ? "Delete MIDI note" : "Add MIDI note");
    if (found || removeOnly || event.button === 2) hit.clip.notes = hit.clip.notes.filter(note => note !== found);
    else { hit.clip.notes.push({ id: uid("note"), start: beat, duration: grid, pitch, velocity: .78 }); previewMidiPitch(pitch); }
    renderPianoRoll(); renderTimeline(); markDirty("Edit MIDI notes");
  }

  async function previewMidiPitch(pitch) {
    if (!Number.isFinite(pitch)) return;
    try { await ensureAudio(); const track = activeTrack()?.type === "midi" ? activeTrack() : state.project.tracks.find(item => item.type === "midi"); const nodes = track && state.audio.trackNodes.get(track.id); if (nodes) scheduleSynthNote(nodes.input, pitch, .7, state.audio.ctx.currentTime + .005, .32, selectedClip()?.clip.wave || "sawtooth"); } catch (_) {}
  }

  async function previewAsset(assetId) {
    const asset = state.project.assets.find(item => item.id === assetId); if (!asset || asset.type !== "audio") return;
    try {
      await ensureAudio();
      if (state.audio.previewSource) { try { state.audio.previewSource.stop(); } catch (_) {} state.audio.previewSource = null; setStatus("Asset preview stopped", "ready"); return; }
      const buffer = await decodeAsset(assetId), source = state.audio.ctx.createBufferSource(), gain = state.audio.ctx.createGain(); gain.gain.value = .7; source.buffer = buffer; source.connect(gain).connect(state.audio.masterGain); source.start(); source.onended = () => { state.audio.previewSource = null; setStatus("Asset preview complete", "ready"); }; state.audio.previewSource = source; setStatus(`Previewing ${asset.name}`, "ready");
    } catch (error) { toast("Preview unavailable", error.message, "error"); }
  }

  let tapTimes = [];
  function tapTempo() {
    const now = performance.now(); tapTimes = tapTimes.filter(time => now - time < 2500); tapTimes.push(now);
    if (tapTimes.length > 1) {
      const intervals = tapTimes.slice(1).map((time, index) => time - tapTimes[index]);
      const bpm = clamp(60000 / (intervals.reduce((a, b) => a + b, 0) / intervals.length), 30, 300);
      state.project.bpm = Math.round(bpm * 10) / 10; $("#bpmInput").value = state.project.bpm; markDirty("Tap tempo");
    }
  }

  function handleKeyboard(event) {
    if (isTypingTarget(event.target) || $("dialog[open]")) return;
    const cmd = event.metaKey || event.ctrlKey;
    if (event.code === "Space") { event.preventDefault(); play(); }
    else if (event.key === "Enter") { event.preventDefault(); seek(0); }
    else if (cmd && event.key.toLowerCase() === "z" && event.shiftKey) { event.preventDefault(); redo(); }
    else if (cmd && event.key.toLowerCase() === "z") { event.preventDefault(); undo(); }
    else if (cmd && event.key.toLowerCase() === "d") { event.preventDefault(); duplicateSelectedClips(); }
    else if (["Delete", "Backspace"].includes(event.key)) { event.preventDefault(); deleteSelectedClips(); }
    else if (event.key.toLowerCase() === "s") splitSelectedAt();
    else if (event.key.toLowerCase() === "r") toggleRecording();
    else if (event.key.toLowerCase() === "l" && event.shiftKey && state.ui.range) { snapshot("Set loop range"); state.project.loop.startBeat = Math.min(state.ui.range.start, state.ui.range.end); state.project.loop.endBeat = Math.max(state.ui.range.start, state.ui.range.end); state.project.loop.enabled = true; renderAll(); markDirty("Set loop range"); }
    else if (event.key.toLowerCase() === "l") { state.project.loop.enabled = !state.project.loop.enabled; renderAll(); markDirty("Toggle loop"); }
    else if (event.key.toLowerCase() === "m") $("#metroBtn").click();
    else if (event.key === "+" || event.key === "=") $("#zoomInBtn").click();
    else if (event.key === "-") $("#zoomOutBtn").click();
    else if (event.key === "ArrowLeft") seek(state.ui.playheadBeat - Number(state.ui.grid || .5));
    else if (event.key === "ArrowRight") seek(state.ui.playheadBeat + Number(state.ui.grid || .5));
  }

  async function bootstrap() {
    try {
      state.db = await openDatabase();
      const last = await dbGet("settings", "lastProjectId");
      const saved = last?.value ? await dbGet("projects", last.value) : null;
      if (saved?.tracks?.length) state.project = saved;
      else await saveProjectNow();
    } catch (error) {
      console.error(error);
      toast("Local persistence unavailable", "The DAW will run, but this browser cannot autosave projects. Download a project file before closing.", "warning", 9000);
    }
    state.ui.zoom = state.project.uiState?.zoom || 72;
    state.ui.selectedTrackId = state.project.tracks[0]?.id || null;
    setupEvents();
    const selfTest = runSelfTests();
    renderCapabilities();
    renderAll();
    updateStorageEstimate();
    enumerateAudioDevices().catch(() => {});
    if ("serviceWorker" in navigator && location.protocol !== "file:") navigator.serviceWorker.register("sw.js").catch(error => console.warn("Offline cache unavailable", error));
    if (!selfTest.ok) toast("Core self-test warning", `${selfTest.passed} of ${selfTest.total} checks passed. Reload before trusting an export.`, "warning", 9000);
    setStatus(location.protocol === "file:" ? "Portable file mode — autosave active; offline cache needs a web server" : "Ready — project autosave and offline cache active", selfTest.ok ? "ready" : "error");
  }

  bootstrap();
})();
