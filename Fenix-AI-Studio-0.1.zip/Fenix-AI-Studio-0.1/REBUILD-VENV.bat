@echo off
setlocal EnableExtensions
title Rebuild Fenix venv (portable)
cd /d "%~dp0"

echo.
echo   Deletes .\venv and recreates it with Python from PATH.
echo   Use this after copying the package to a new machine.
echo.

set "SYSPY="
where python >nul 2>&1 && set "SYSPY=python"
if not defined SYSPY where py >nul 2>&1 && set "SYSPY=py -3"
if not defined SYSPY (
  echo ERROR: Python not on PATH. Install Python and tick "Add to PATH".
  pause
  exit /b 1
)

echo Using:
%SYSPY% --version
echo.

if exist "venv" (
  echo Removing old venv...
  rmdir /s /q "venv"
)

echo Creating venv...
%SYSPY% -m venv venv
if errorlevel 1 (
  echo FAILED: venv create
  pause
  exit /b 1
)

echo Installing requirements...
"venv\Scripts\python.exe" -m pip install --upgrade pip
"venv\Scripts\python.exe" -m pip install -r requirements.txt
if errorlevel 1 (
  echo FAILED: pip install
  pause
  exit /b 1
)

echo.
echo   Done. Run START.bat
pause
endlocal
