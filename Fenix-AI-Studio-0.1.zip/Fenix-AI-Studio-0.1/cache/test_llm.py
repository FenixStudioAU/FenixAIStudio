import asyncio
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from backend import llm_client


async def main() -> None:
    print("test qwen3.5:4b format_json think=false...")
    t = await llm_client.chat(
        "qwen3.5:4b",
        [
            {"role": "system", "content": "Output ONLY valid JSON."},
            {
                "role": "user",
                "content": 'Return {"ok": true, "beats": [{"index": 1, "label": "open", "beat": "car leaves town"}]}',
            },
        ],
        format_json=True,
        num_predict=512,
        timeout=180,
        retries=2,
        disable_thinking=True,
    )
    print("TEXT:", t[:500])
    print("JSON:", llm_client.extract_json(t))

    print("\ntest qwen2.5-coder:14b-instruct...")
    t2 = await llm_client.chat(
        "qwen2.5-coder:14b-instruct",
        [
            {"role": "system", "content": "Output ONLY valid JSON."},
            {"role": "user", "content": 'Return {"ok": true, "n": 3}'},
        ],
        format_json=True,
        num_predict=128,
        timeout=180,
        retries=1,
        disable_thinking=True,
    )
    print("TEXT2:", t2[:300])
    print("JSON2:", llm_client.extract_json(t2))


if __name__ == "__main__":
    asyncio.run(main())
