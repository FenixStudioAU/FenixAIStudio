/** Code Companion–style workspace for Studio Coder mode. */
import { api } from "./api.js";

const $ = (s, r = document) => r.querySelector(s);
const $$ = (s, r = document) => [...r.querySelectorAll(s)];

function escapeHtml(s) {
  return String(s ?? "")
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;");
}

function extractImplPrompt(text) {
  const t = String(text || "");
  const m = t.match(/IMPLEMENTATION PROMPT\s*[:\-]?\s*([\s\S]+)/i);
  if (m) return m[1].trim();
  return t.trim();
}

export function createCoderController({ getSettings }) {
  let project = null;
  let settingsCache = {};
  let busy = false;
  let lastAssistantText = "";
  let lastInspectorReport = "";
  let runtimeLines = [];

  function setStatus(show, text, loading = false) {
    const bar = $("#coder-status");
    const t = $("#coder-status-text");
    if (!bar || !t) return;
    bar.classList.toggle("hidden", !show);
    bar.classList.toggle("loading", !!loading);
    t.textContent = text || "";
  }

  function logEvent(line) {
    const el = $("#coder-event-stream");
    const stamp = new Date().toLocaleTimeString();
    const prev = el?.textContent || "";
    if (el) {
      el.textContent = `${prev}${prev ? "\n" : ""}[${stamp}] ${line}`;
      el.scrollTop = el.scrollHeight;
    }
  }

  function setStreamContent(text) {
    const el = $("#coder-content-stream");
    if (el) {
      el.textContent = text || "";
      el.scrollTop = el.scrollHeight;
    }
    const chars = $("#coder-stream-chars");
    if (chars) chars.textContent = `${(text || "").length.toLocaleString()} chars`;
  }

  function setStage(label) {
    const el = $("#coder-stream-stage");
    if (el) el.textContent = label;
  }

  function updatePromptChars() {
    const ta = $("#coder-build-prompt");
    const n = (ta?.value || "").length;
    const el = $("#coder-prompt-chars");
    if (el) el.textContent = `${n.toLocaleString()} characters`;
  }

  function renderDesignerLog() {
    const box = $("#coder-designer-log");
    if (!box) return;
    const msgs = project?.designer_messages || [];
    if (!msgs.length) {
      box.innerHTML = `<div class="chat-empty muted">Discuss what you want to build. Then use “Use as build prompt”.</div>`;
      return;
    }
    box.innerHTML = msgs
      .map((m) => {
        const role = m.role === "user" ? "user" : "assistant";
        return `<div class="chat-message ${role}"><div class="chat-bubble">${escapeHtml(m.content)}</div></div>`;
      })
      .join("");
    box.scrollTop = box.scrollHeight;
    const hasAsst = msgs.some((m) => m.role === "assistant");
    $("#btn-coder-to-build") && ($("#btn-coder-to-build").disabled = !hasAsst);
    $("#btn-coder-to-repair") && ($("#btn-coder-to-repair").disabled = !hasAsst);
  }

  function renderVersionList() {
    const list = $("#coder-version-list");
    const sel = $("#coder-preview-version");
    if (!list || !sel) return;
    const versions = project?.versions || [];
    const active = project?.active_version_id;
    const accepted = project?.accepted_version_id;

    if (!versions.length) {
      list.innerHTML = `<p class="muted small">No versions yet.</p>`;
      sel.innerHTML = `<option value="">No versions</option>`;
      $("#coder-version-badge") && ($("#coder-version-badge").textContent = "No version");
      $("#btn-coder-accept") && ($("#btn-coder-accept").disabled = true);
      $("#btn-coder-delete-version") && ($("#btn-coder-delete-version").disabled = true);
      return;
    }

    list.innerHTML = versions
      .map((v) => {
        const tags = [];
        if (v.id === accepted) tags.push("accepted");
        if (v.id === active) tags.push("active");
        if (v.valid === false) tags.push("invalid");
        return `<button type="button" class="coder-version-item ${v.id === active ? "active" : ""}" data-vid="${escapeHtml(v.id)}">
          <strong>${escapeHtml(v.id)}</strong>
          <span class="muted small">${escapeHtml(v.kind || "build")} · ${(v.char_count || 0).toLocaleString()} chars ${tags.length ? "· " + tags.join(", ") : ""}</span>
        </button>`;
      })
      .join("");

    list.querySelectorAll("[data-vid]").forEach((btn) => {
      btn.addEventListener("click", () => selectVersion(btn.dataset.vid));
    });

    sel.innerHTML = versions
      .map(
        (v) =>
          `<option value="${escapeHtml(v.id)}" ${v.id === active ? "selected" : ""}>${escapeHtml(v.id)} (${escapeHtml(v.kind || "build")})</option>`
      )
      .join("");

    const cur = versions.find((v) => v.id === active) || versions[0];
    $("#coder-version-badge") && ($("#coder-version-badge").textContent = cur?.id || "No version");
    const st = $("#coder-version-status");
    if (st && cur) {
      st.textContent = [
        cur.complete === false ? "incomplete" : "complete",
        cur.valid === false ? "validation failed" : "validation ok",
        cur.id === accepted ? "ACCEPTED" : "",
      ]
        .filter(Boolean)
        .join(" · ");
    }
    $("#btn-coder-accept") && ($("#btn-coder-accept").disabled = !cur);
    $("#btn-coder-delete-version") && ($("#btn-coder-delete-version").disabled = !cur);
  }

  function clearRuntime() {
    runtimeLines = [];
    const el = $("#coder-runtime-log");
    if (el) el.textContent = "Preview messages and browser errors will appear here.";
  }

  function pushRuntime(line) {
    runtimeLines.push(line);
    if (runtimeLines.length > 200) runtimeLines.shift();
    const el = $("#coder-runtime-log");
    if (el) {
      el.textContent = runtimeLines.join("\n");
      el.scrollTop = el.scrollHeight;
    }
  }

  function loadPreview(versionId) {
    const frame = $("#coder-preview-frame");
    const ph = $("#coder-preview-placeholder");
    if (!versionId) {
      if (frame) frame.removeAttribute("src");
      if (ph) ph.classList.remove("hidden");
      return;
    }
    if (ph) ph.classList.add("hidden");
    if (frame) {
      // cache-bust
      frame.src = `${api.coderVersionHtmlUrl(versionId)}?t=${Date.now()}`;
    }
    clearRuntime();
    pushRuntime(`Loaded version ${versionId}`);
  }

  async function selectVersion(versionId) {
    if (!versionId || !project) return;
    project.active_version_id = versionId;
    try {
      await api.coderSaveProject({ active_version_id: versionId });
    } catch (_) {}
    renderVersionList();
    loadPreview(versionId);
  }

  async function fillModels() {
    try {
      settingsCache = (await getSettings()) || {};
    } catch {
      settingsCache = {};
    }
    let models = [];
    try {
      const o = await api.llmModels();
      models = (o.models || o || [])
        .map((m) => (typeof m === "string" ? m : m.id || m.name || m.model))
        .filter(Boolean);
    } catch (_) {
      models = [];
    }

    const pairs = [
      ["coder-designer-model", settingsCache.coder_designer_model || settingsCache.chat_model],
      ["coder-build-model", settingsCache.coder_model || settingsCache.chat_model],
      ["coder-repair-model", settingsCache.coder_repair_model || settingsCache.coder_model],
      ["coder-inspector-model", settingsCache.coder_repair_model || settingsCache.chat_model],
    ];
    for (const [id, preferred] of pairs) {
      const sel = $(`#${id}`);
      if (!sel) continue;
      const opts = models.length
        ? models.map((m) => `<option value="${escapeHtml(m)}">${escapeHtml(m)}</option>`).join("")
        : `<option value="">(no models — start Ollama)</option>`;
      sel.innerHTML = opts;
      if (preferred && models.includes(preferred)) sel.value = preferred;
      else if (models[0]) sel.value = models[0];
    }
  }

  async function refresh() {
    project = await api.coderProject();
    if ($("#coder-build-prompt") && project.build_prompt != null) {
      $("#coder-build-prompt").value = project.build_prompt || "";
    }
    if ($("#coder-repair-prompt") && project.repair_prompt != null) {
      $("#coder-repair-prompt").value = project.repair_prompt || "";
    }
    updatePromptChars();
    renderDesignerLog();
    renderVersionList();
    if (project.active_version_id) loadPreview(project.active_version_id);
    else loadPreview(null);
  }

  async function persistSoft() {
    if (!project) return;
    try {
      project = await api.coderSaveProject({
        designer_messages: project.designer_messages || [],
        build_prompt: $("#coder-build-prompt")?.value || "",
        repair_prompt: $("#coder-repair-prompt")?.value || "",
        active_version_id: project.active_version_id,
        accepted_version_id: project.accepted_version_id,
      });
    } catch (e) {
      console.warn("coder save failed", e);
    }
  }

  async function designerSend() {
    if (busy) return;
    const input = $("#coder-designer-input");
    const text = (input?.value || "").trim();
    if (!text) return;
    await fillModels();
    const model = $("#coder-designer-model")?.value || settingsCache.coder_designer_model || "";
    project.designer_messages = project.designer_messages || [];
    project.designer_messages.push({ role: "user", content: text, at: Date.now() });
    if (input) input.value = "";
    renderDesignerLog();

    busy = true;
    setStatus(true, model ? `Designer · loading ${model}…` : "Designer · loading model…", true);
    setStage("Designer running");
    logEvent(`Designer send → ${model || "auto"}`);
    try {
      const history = project.designer_messages.map((m) => ({ role: m.role, content: m.content }));
      const res = await api.chat({
        mode: "coder",
        stage: "designer",
        model: model || null,
        messages: history,
        num_predict: 4096,
      });
      const content = res.content || "";
      lastAssistantText = content;
      project.designer_messages.push({ role: "assistant", content, at: Date.now() });
      await persistSoft();
      renderDesignerLog();
      setStreamContent(content);
      logEvent("Designer reply received");
      setStatus(false, "");
      setStage("Idle");
    } catch (e) {
      setStatus(false, "");
      setStage("Error");
      logEvent(`Designer error: ${e.message}`);
      alert(`Designer failed: ${e.message}`);
    } finally {
      busy = false;
    }
  }

  function useAsBuildPrompt() {
    const msgs = project?.designer_messages || [];
    const last = [...msgs].reverse().find((m) => m.role === "assistant");
    if (!last) return;
    const prompt = extractImplPrompt(last.content);
    const ta = $("#coder-build-prompt");
    if (ta) ta.value = prompt;
    updatePromptChars();
    persistSoft();
    logEvent("Copied designer reply → build prompt");
  }

  function useAsRepairPrompt() {
    const msgs = project?.designer_messages || [];
    const last = [...msgs].reverse().find((m) => m.role === "assistant");
    if (!last) return;
    const ta = $("#coder-repair-prompt");
    if (ta) ta.value = extractImplPrompt(last.content);
    persistSoft();
    logEvent("Copied designer reply → repair prompt");
  }

  async function runBuild() {
    if (busy) return;
    const prompt = ($("#coder-build-prompt")?.value || "").trim();
    if (!prompt) {
      alert("Write or paste an implementation prompt first.");
      return;
    }
    await fillModels();
    const model = $("#coder-build-model")?.value || settingsCache.coder_model || "";
    busy = true;
    setStatus(true, model ? `Coder · loading ${model}…` : "Coder · loading model…", true);
    setStage("Building complete file");
    setStreamContent("");
    logEvent(`Build start → ${model || "auto"}`);
    try {
      const res = await api.chat({
        mode: "coder",
        stage: "coder",
        model: model || null,
        messages: [{ role: "user", content: prompt }],
        num_predict: 12288,
      });
      const raw = res.content || "";
      setStreamContent(raw);
      logEvent(`Build response ${raw.length} chars — saving version…`);
      const saved = await api.coderAddVersion({
        prompt,
        raw_response: raw,
        kind: "build",
        model: res.model || model || "",
      });
      project = saved.project || (await api.coderProject());
      renderVersionList();
      if (saved.version?.id) loadPreview(saved.version.id);
      const val = saved.validation;
      if (val) {
        logEvent(
          `Validation: ${val.valid ? "OK" : "FAILED"} — ${(val.results || [])
            .map((r) => (r.ok ? "✓" : "✗") + " " + r.message)
            .join("; ")}`
        );
      }
      setStatus(false, "");
      setStage(val?.valid ? "Build complete" : "Build complete (validation issues)");
    } catch (e) {
      setStatus(false, "");
      setStage("Error");
      logEvent(`Build error: ${e.message}`);
      alert(`Build failed: ${e.message}`);
    } finally {
      busy = false;
      await persistSoft();
    }
  }

  async function runInspect() {
    if (busy) return;
    const vid = project?.active_version_id || project?.accepted_version_id;
    if (!vid) {
      alert("Generate a version first.");
      return;
    }
    const fault = ($("#coder-repair-prompt")?.value || "").trim() || "Review the code for bugs.";
    await fillModels();
    const model =
      $("#coder-inspector-model")?.value ||
      settingsCache.coder_repair_model ||
      settingsCache.chat_model ||
      "";
    busy = true;
    setStatus(true, model ? `Inspector · loading ${model}…` : "Inspector · loading…", true);
    setStage("Inspecting");
    logEvent(`Inspect ${vid} → ${model || "auto"}`);
    try {
      const detail = await api.coderVersion(vid);
      const html = detail.html || "";
      const runtime = runtimeLines.slice(-40).join("\n");
      const userMsg = [
        "CURRENT HTML FILE:",
        html.slice(0, 120000),
        "",
        "USER FAULT DESCRIPTION:",
        fault,
        "",
        "RUNTIME CONSOLE (if any):",
        runtime || "(none)",
      ].join("\n");
      const res = await api.chat({
        mode: "coder",
        stage: "inspect",
        model: model || null,
        messages: [{ role: "user", content: userMsg }],
        num_predict: 4096,
      });
      lastInspectorReport = res.content || "";
      const reportEl = $("#coder-inspector-report");
      if (reportEl) reportEl.textContent = lastInspectorReport;
      $("#btn-coder-use-report") && ($("#btn-coder-use-report").disabled = !lastInspectorReport);
      setStreamContent(lastInspectorReport);
      logEvent("Inspector report ready");
      setStatus(false, "");
      setStage("Inspect done");
      return lastInspectorReport;
    } catch (e) {
      setStatus(false, "");
      setStage("Error");
      logEvent(`Inspect error: ${e.message}`);
      alert(`Inspect failed: ${e.message}`);
      return "";
    } finally {
      busy = false;
    }
  }

  async function runRepair() {
    if (busy) return;
    let fault = ($("#coder-repair-prompt")?.value || "").trim();
    if (!fault) {
      alert("Describe the fault to repair.");
      return;
    }
    const auto = !!$("#coder-auto-inspect")?.checked;
    if (auto && !lastInspectorReport) {
      const rep = await runInspect();
      if (!rep) return;
    }
    if (lastInspectorReport && !fault.includes(lastInspectorReport.slice(0, 80))) {
      // already may have been appended; keep fault as-is
    }

    const vid = project?.accepted_version_id || project?.active_version_id;
    if (!vid) {
      alert("No baseline version to repair.");
      return;
    }
    await fillModels();
    const model = $("#coder-repair-model")?.value || settingsCache.coder_repair_model || "";
    busy = true;
    setStatus(true, model ? `Repair · loading ${model}…` : "Repair · loading…", true);
    setStage("Repairing full file");
    setStreamContent("");
    logEvent(`Repair from ${vid} → ${model || "auto"}`);
    try {
      const detail = await api.coderVersion(vid);
      const html = detail.html || "";
      const promptParts = [
        "You must return a COMPLETE updated HTML document (no markdown fences).",
        "",
        "ORIGINAL / CURRENT FILE:",
        html.slice(0, 120000),
        "",
        "REPAIR REQUEST:",
        fault,
      ];
      if (lastInspectorReport) {
        promptParts.push("", "INSPECTOR REPORT:", lastInspectorReport);
      }
      const prompt = promptParts.join("\n");
      const res = await api.chat({
        mode: "coder",
        stage: "repair",
        model: model || null,
        messages: [{ role: "user", content: prompt }],
        num_predict: 12288,
      });
      const raw = res.content || "";
      setStreamContent(raw);
      const saved = await api.coderAddVersion({
        prompt: fault,
        raw_response: raw,
        kind: "repair",
        inspector_report: lastInspectorReport || "",
        model: res.model || model || "",
      });
      project = saved.project || (await api.coderProject());
      renderVersionList();
      if (saved.version?.id) loadPreview(saved.version.id);
      logEvent(`Repair version saved: ${saved.version?.id}`);
      setStatus(false, "");
      setStage("Repair complete");
    } catch (e) {
      setStatus(false, "");
      setStage("Error");
      logEvent(`Repair error: ${e.message}`);
      alert(`Repair failed: ${e.message}`);
    } finally {
      busy = false;
      await persistSoft();
    }
  }

  function appendReportToRepair() {
    if (!lastInspectorReport) return;
    const ta = $("#coder-repair-prompt");
    if (!ta) return;
    const cur = ta.value || "";
    ta.value = cur
      ? `${cur}\n\n--- Inspector report ---\n${lastInspectorReport}`
      : lastInspectorReport;
    persistSoft();
  }

  async function acceptVersion() {
    const vid = project?.active_version_id;
    if (!vid) return;
    if (!confirm(`Accept ${vid} as the new baseline?`)) return;
    project = await api.coderAcceptVersion(vid);
    renderVersionList();
    logEvent(`Accepted ${vid}`);
  }

  async function deleteVersion() {
    const vid = project?.active_version_id;
    if (!vid) return;
    if (!confirm(`Delete version ${vid}?`)) return;
    project = await api.coderDeleteVersion(vid);
    renderVersionList();
    if (project.active_version_id) loadPreview(project.active_version_id);
    else loadPreview(null);
    logEvent(`Deleted ${vid}`);
  }

  function wire() {
    $("#btn-coder-designer-send")?.addEventListener("click", () => designerSend());
    $("#coder-designer-input")?.addEventListener("keydown", (e) => {
      if (e.key === "Enter" && !e.shiftKey) {
        e.preventDefault();
        designerSend();
      }
    });
    $("#btn-coder-to-build")?.addEventListener("click", () => useAsBuildPrompt());
    $("#btn-coder-to-repair")?.addEventListener("click", () => useAsRepairPrompt());
    $("#btn-coder-build")?.addEventListener("click", () => runBuild());
    $("#btn-coder-inspect")?.addEventListener("click", () => runInspect());
    $("#btn-coder-repair")?.addEventListener("click", () => runRepair());
    $("#btn-coder-use-report")?.addEventListener("click", () => appendReportToRepair());
    $("#btn-coder-accept")?.addEventListener("click", () => acceptVersion());
    $("#btn-coder-delete-version")?.addEventListener("click", () => deleteVersion());
    $("#btn-coder-preview-refresh")?.addEventListener("click", () => {
      if (project?.active_version_id) loadPreview(project.active_version_id);
    });
    $("#btn-coder-preview-external")?.addEventListener("click", () => {
      if (project?.active_version_id) {
        window.open(api.coderVersionHtmlUrl(project.active_version_id), "_blank");
      }
    });
    $("#btn-coder-clear-runtime")?.addEventListener("click", () => clearRuntime());
    $("#coder-preview-version")?.addEventListener("change", (e) => {
      selectVersion(e.target.value);
    });
    $("#coder-build-prompt")?.addEventListener("input", () => {
      updatePromptChars();
    });
    $("#coder-build-prompt")?.addEventListener("change", () => persistSoft());
    $("#coder-repair-prompt")?.addEventListener("change", () => persistSoft());

    $$("[data-coder-stream]").forEach((btn) => {
      btn.addEventListener("click", () => {
        const tab = btn.dataset.coderStream;
        $$("[data-coder-stream]").forEach((b) => b.classList.toggle("active", b === btn));
        $("#coder-content-stream")?.classList.toggle("active", tab === "content");
        $("#coder-event-stream")?.classList.toggle("active", tab === "events");
      });
    });

    // Capture iframe console via postMessage if generated pages send it;
    // also listen for errors from same-origin iframe when possible.
    window.addEventListener("message", (ev) => {
      if (ev?.data?.type === "coder-runtime") {
        pushRuntime(String(ev.data.message || ev.data));
      }
    });
  }

  async function open() {
    await fillModels();
    await refresh();
  }

  return { wire, open, refresh, fillModels };
}
