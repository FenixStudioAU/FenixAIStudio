/** Editable multi-track timeline with drag, resize, snap, zoom, swap, file drop. */

function uid(prefix = "shot_") {
  return prefix + Math.random().toString(16).slice(2, 10);
}

export class TimelineView {
  constructor(root, opts) {
    this.root = root;
    this.shotsLane = root.querySelector("#shots-lane");
    this.titlesLane = root.querySelector("#titles-lane");
    this.fxLane = root.querySelector("#fx-lane");
    this.ruler = root.querySelector("#ruler");
    this.playheadEl = root.querySelector("#playhead");
    this.waveform = root.querySelector("#waveform");
    this.opts = opts;
    this.project = null;
    this.selectedShotId = null;
    this.pxPerSec = 40;
    this.snap = true;
    this.drag = null;
    this.swapTargetId = null;
    this._bind();
  }

  setProject(project) {
    this.project = project;
    this.pxPerSec = project.timeline?.zoom || 40;
    this.render();
  }

  setPlayhead(t) {
    if (!this.project) return;
    const x = 72 + t * this.pxPerSec;
    this.playheadEl.style.left = `${x}px`;
  }

  duration() {
    return this.project?.audio?.duration || this._shotsEnd() || 60;
  }

  _shotsEnd() {
    const shots = this.project?.timeline?.shots || [];
    return shots.reduce((m, s) => Math.max(m, s.start + s.duration), 0);
  }

  contentWidth() {
    return Math.max(800, this.duration() * this.pxPerSec + 120);
  }

  render() {
    if (!this.project) return;
    const w = this.contentWidth();
    [this.shotsLane, this.titlesLane, this.fxLane, this.ruler].forEach((el) => {
      if (el) el.style.width = `${w}px`;
    });
    this._renderRuler(w);
    this._renderShots();
    this._renderTitles();
    this._renderFx();
    this.setPlayhead(this.project.timeline.playhead || 0);
    this.drawWaveform();
  }

  _renderRuler(w) {
    const dur = this.duration();
    const step = this.pxPerSec >= 60 ? 1 : this.pxPerSec >= 30 ? 2 : 5;
    let html = "";
    for (let t = 0; t <= dur + step; t += step) {
      const x = t * this.pxPerSec;
      html += `<span style="position:absolute;left:${x}px;top:2px;font-size:10px;color:#8b93a7;font-family:var(--mono)">${this._fmt(t)}</span>`;
      html += `<span style="position:absolute;left:${x}px;bottom:0;width:1px;height:8px;background:#2a3142"></span>`;
    }
    this.ruler.style.position = "relative";
    this.ruler.style.width = `${w}px`;
    this.ruler.innerHTML = html;
  }

  _fmt(t) {
    const m = Math.floor(t / 60);
    const s = (t % 60).toFixed(t % 1 ? 1 : 0);
    return `${m}:${String(Math.floor(t % 60)).padStart(2, "0")}${t % 1 ? s.slice(s.indexOf(".")) : ""}`;
  }

  _statusBadge(shot) {
    const vs = shot.video_status;
    const is = shot.image_status;
    const hasVid = !!(shot.video_path || shot.draft_video_path);
    if (vs === "running" || is === "running") return ["gen…", "running"];
    if (vs === "error" || is === "error") return ["err", "error"];
    if (hasVid && (vs === "final" || vs === "ready" || vs === "draft" || vs === "uploaded")) {
      return [vs === "draft" ? "VID draft" : "VIDEO", "ready"];
    }
    if (hasVid) return ["VIDEO", "ready"];
    if (is === "ready" || is === "uploaded") return ["IMG", "ready"];
    return ["empty", ""];
  }

  _renderShots() {
    const shots = this.project.timeline.shots || [];
    this.shotsLane.innerHTML = "";
    this.shotsLane.style.position = "relative";
    this.shotsLane.style.height = "72px";
    this.shotsLane.classList.add("shots-lane-tall");
    for (const shot of shots) {
      const el = document.createElement("div");
      let cls = "clip";
      if (shot.id === this.selectedShotId) cls += " active";
      if (this.drag?.id === shot.id) cls += " dragging";
      if (this.swapTargetId === shot.id) cls += " swap-target";
      el.className = cls;
      el.dataset.id = shot.id;
      el.style.left = `${shot.start * this.pxPerSec}px`;
      el.style.width = `${Math.max(24, shot.duration * this.pxPerSec)}px`;
      const [badge, bcls] = this._statusBadge(shot);
      // Cache-bust so new gens appear immediately
      const bust = (p) => {
        if (!p) return "";
        const u = this.opts.fileUrl(p);
        const v = (shot.image_path || shot.video_path || shot.thumbnail_path || "").length;
        return `${u}${u.includes("?") ? "&" : "?"}v=${v}`;
      };
      let thumbSrc = "";
      if (shot.thumbnail_path) thumbSrc = bust(shot.thumbnail_path);
      else if (shot.image_path) thumbSrc = bust(shot.image_path);
      const thumb = thumbSrc
        ? `<img class="thumb" src="${thumbSrc}" alt="" draggable="false" />`
        : `<div class="thumb thumb-empty"></div>`;
      el.innerHTML = `
        ${thumb}
        <div class="meta">${shot.label || "Shot"} · ${Number(shot.duration).toFixed(1)}s</div>
        <span class="badge ${bcls}">${badge}</span>
        <div class="resize-handle left" data-edge="left"></div>
        <div class="resize-handle right" data-edge="right"></div>
      `;
      this.shotsLane.appendChild(el);
    }
  }

  _renderTitles() {
    this.titlesLane.innerHTML = "";
    this.titlesLane.style.position = "relative";
    this.titlesLane.style.height = "48px";
    for (const t of this.project.timeline.titles || []) {
      const el = document.createElement("div");
      el.className = "clip title-clip";
      el.dataset.id = t.id;
      el.style.left = `${t.start * this.pxPerSec}px`;
      el.style.width = `${Math.max(24, t.duration * this.pxPerSec)}px`;
      el.innerHTML = `<div class="meta">${t.text || "Title"}</div>`;
      this.titlesLane.appendChild(el);
    }
  }

  _renderFx() {
    this.fxLane.innerHTML = "";
    this.fxLane.style.position = "relative";
    this.fxLane.style.height = "40px";
    for (const shot of this.project.timeline.shots || []) {
      if (!shot.transition_out || shot.transition_out === "hard_cut" || !shot.transition_duration) continue;
      const el = document.createElement("div");
      el.className = "clip fx-clip";
      const start = shot.start + shot.duration - shot.transition_duration;
      el.style.left = `${Math.max(0, start) * this.pxPerSec}px`;
      el.style.width = `${Math.max(12, shot.transition_duration * this.pxPerSec)}px`;
      el.innerHTML = `<div class="meta">${shot.transition_out}</div>`;
      this.fxLane.appendChild(el);
    }
  }

  async drawWaveform() {
    const canvas = this.waveform;
    if (!canvas || !this.project?.audio?.waveform_path) {
      if (canvas) {
        const ctx = canvas.getContext("2d");
        canvas.width = this.contentWidth();
        ctx.fillStyle = "#12151e";
        ctx.fillRect(0, 0, canvas.width, canvas.height);
      }
      return;
    }
    try {
      const url = this.opts.fileUrl(this.project.audio.waveform_path);
      const data = await fetch(url).then((r) => r.json());
      const peaks = data.peaks || [];
      const w = this.contentWidth();
      const h = 48;
      canvas.width = w;
      canvas.height = h;
      canvas.style.width = `${w}px`;
      const ctx = canvas.getContext("2d");
      ctx.fillStyle = "#0e1118";
      ctx.fillRect(0, 0, w, h);
      ctx.fillStyle = "#4b6fff";
      const n = peaks.length;
      for (let i = 0; i < n; i++) {
        const x = (i / n) * (this.duration() * this.pxPerSec);
        const ph = peaks[i] * (h * 0.9);
        ctx.fillRect(x, (h - ph) / 2, Math.max(1, (this.duration() * this.pxPerSec) / n), ph);
      }
    } catch (e) {
      console.warn("waveform", e);
    }
  }

  _timeFromClientX(clientX) {
    const rect = this.shotsLane.getBoundingClientRect();
    return Math.max(0, (clientX - rect.left) / this.pxPerSec);
  }

  _shotAtTime(t, excludeId = null) {
    const shots = this.project?.timeline?.shots || [];
    // Prefer shot whose center is closest under cursor time
    let best = null;
    let bestDist = Infinity;
    for (const s of shots) {
      if (excludeId && s.id === excludeId) continue;
      if (t >= s.start && t < s.start + s.duration) {
        const mid = s.start + s.duration / 2;
        const d = Math.abs(t - mid);
        if (d < bestDist) {
          best = s;
          bestDist = d;
        }
      }
    }
    return best;
  }

  _shotAtClientX(clientX, excludeId = null) {
    return this._shotAtTime(this._timeFromClientX(clientX), excludeId);
  }

  _bind() {
    this.root.addEventListener("mousedown", (e) => this._onDown(e));
    window.addEventListener("mousemove", (e) => this._onMove(e));
    window.addEventListener("mouseup", (e) => this._onUp(e));
    this.root.addEventListener("click", (e) => {
      // Don't seek when interacting with clips (select/drag only)
      if (e.target.closest(".clip")) return;
      if (e.target.closest(".resize-handle")) return;
      const lane = e.target.closest(".track-lane, .ruler, .timeline");
      if (!lane) return;
      // Ignore if we just finished a drag
      if (this._suppressClick) {
        this._suppressClick = false;
        return;
      }
      const t = this._snap(this._timeFromClientX(e.clientX));
      this.opts.onSeek?.(t);
    });

    // File drag-and-drop onto shots (from Explorer)
    const onDragOver = (e) => {
      if (![...e.dataTransfer.types].includes("Files")) return;
      e.preventDefault();
      e.dataTransfer.dropEffect = "copy";
      const shot = this._shotAtClientX(e.clientX);
      this.shotsLane.querySelectorAll(".clip").forEach((c) => c.classList.remove("drop-target"));
      if (shot) {
        const el = this.shotsLane.querySelector(`.clip[data-id="${shot.id}"]`);
        el?.classList.add("drop-target");
        this.selectedShotId = shot.id;
      }
    };
    const onDragLeave = (e) => {
      if (!this.shotsLane.contains(e.relatedTarget)) {
        this.shotsLane.querySelectorAll(".clip").forEach((c) => c.classList.remove("drop-target"));
      }
    };
    const onDrop = (e) => {
      e.preventDefault();
      this.shotsLane.querySelectorAll(".clip").forEach((c) => c.classList.remove("drop-target"));
      const files = [...(e.dataTransfer.files || [])];
      if (!files.length) return;
      let shot = this._shotAtClientX(e.clientX);
      if (!shot) {
        // Drop on empty lane → create shot at that time and attach
        const t = this._snap(this._timeFromClientX(e.clientX));
        shot = this.addShotAt(t);
      }
      this.selectedShotId = shot.id;
      this.opts.onSelectShot?.(shot.id);
      this.opts.onFilesDrop?.(shot.id, files);
      this.render();
    };
    this.shotsLane.addEventListener("dragover", onDragOver);
    this.shotsLane.addEventListener("dragleave", onDragLeave);
    this.shotsLane.addEventListener("drop", onDrop);
    // Also allow drop on whole timeline shell
    this.root.addEventListener("dragover", (e) => {
      if ([...e.dataTransfer.types].includes("Files")) {
        e.preventDefault();
      }
    });
  }

  _snap(t) {
    if (!this.snap) return Math.max(0, t);
    const g = this.project?.timeline?.snap_grid_sec || 0.25;
    return Math.max(0, Math.round(t / g) * g);
  }

  _onDown(e) {
    if (e.button !== 0) return;
    const handle = e.target.closest(".resize-handle");
    const clip = e.target.closest(".clip");
    if (!clip || !clip.dataset.id) return;
    // only shot clips on shots lane
    if (!this.shotsLane.contains(clip)) return;
    const shot = (this.project.timeline.shots || []).find((s) => s.id === clip.dataset.id);
    if (!shot) return;
    e.preventDefault();
    // Capture times BEFORE any select/save callback can touch the shot
    const origStart = Number(shot.start) || 0;
    const origDur = Number(shot.duration) || 0.2;
    this.selectedShotId = shot.id;
    this.drag = {
      id: shot.id,
      mode: handle ? handle.dataset.edge : "move",
      startX: e.clientX,
      origStart,
      origDur,
      moved: false,
    };
    this.swapTargetId = null;
    // Select for inspector/preview (must not rewrite start — app.js only writes bound shot)
    this.opts.onSelectShot?.(shot.id);
    this.render();
  }

  _onMove(e) {
    if (!this.drag) return;
    const dx = (e.clientX - this.drag.startX) / this.pxPerSec;
    if (Math.abs(dx) > 0.02) this.drag.moved = true;
    const shot = this.project.timeline.shots.find((s) => s.id === this.drag.id);
    if (!shot) return;
    if (this.drag.mode === "move") {
      // Live-move the clip under the cursor; mark swap target when over another clip
      const t = this._timeFromClientX(e.clientX);
      const other = this._shotAtTime(t, this.drag.id);
      this.swapTargetId = other ? other.id : null;
      // Always show free move preview (don't pin back to origin while over another clip —
      // that made both clips appear stuck at the source after drop)
      shot.start = this._snap(Math.max(0, this.drag.origStart + dx));
    } else if (this.drag.mode === "left") {
      const end = this.drag.origStart + this.drag.origDur;
      let start = this._snap(Math.max(0, this.drag.origStart + dx));
      if (end - start < 0.2) start = end - 0.2;
      shot.duration = end - start;
      shot.start = start;
      if (shot.video) shot.video.duration_sec = shot.duration;
      this.swapTargetId = null;
    } else if (this.drag.mode === "right") {
      shot.duration = Math.max(0.2, this._snap(this.drag.origDur + dx));
      if (shot.video) shot.video.duration_sec = shot.duration;
      this.swapTargetId = null;
    }
    this.render();
  }

  _onUp(e) {
    if (!this.drag) return;
    const drag = this.drag;
    // Re-resolve swap target at release (cursor may have moved after last mousemove)
    let swapId = null;
    if (drag.mode === "move" && drag.moved) {
      const t = this._timeFromClientX(e.clientX);
      const other = this._shotAtTime(t, drag.id);
      swapId = other ? other.id : this.swapTargetId;
    }
    this.drag = null;
    this.swapTargetId = null;
    if (drag.moved) this._suppressClick = true;

    let changed = false;

    // Swap time ranges (keep each shot's own duration) when dropped onto another clip
    if (drag.mode === "move" && swapId) {
      const a = this.project.timeline.shots.find((s) => s.id === drag.id);
      const b = this.project.timeline.shots.find((s) => s.id === swapId);
      if (a && b && a.id !== b.id) {
        const aStart = drag.origStart;
        const aDur = drag.origDur;
        const bStart = Number(b.start) || 0;
        const bDur = Number(b.duration) || 0.2;
        // Only swap start times — keep each scene's own length
        a.start = bStart;
        a.duration = aDur;
        b.start = aStart;
        b.duration = bDur;
        if (a.video) a.video.duration_sec = a.duration;
        if (b.video) b.video.duration_sec = b.duration;
        this.selectedShotId = a.id;
        changed = true;
      }
    } else if (drag.mode === "move" && !drag.moved) {
      // Pure click — selection already done on mousedown; don't re-select (avoids double flush)
      this.selectedShotId = drag.id;
    } else if (drag.moved || drag.mode === "left" || drag.mode === "right") {
      // Free move / resize already applied during mousemove
      const shot = this.project.timeline.shots.find((s) => s.id === drag.id);
      if (shot && shot.video) shot.video.duration_sec = shot.duration;
      changed = true;
    }

    this.project.timeline.shots.sort((x, y) => x.start - y.start);
    this.render();
    if (changed) {
      // Sync inspector start/duration from timeline only (no full re-select / seek)
      this.opts.onChange?.(true);
    }
  }

  /** Pack shots back-to-back from t=0 (or first shot), closing gaps. */
  realignShots() {
    if (!this.project?.timeline?.shots?.length) return;
    const shots = [...this.project.timeline.shots].sort((a, b) => a.start - b.start);
    let t = 0;
    for (const s of shots) {
      s.start = this._snap(t);
      if (s.video) s.video.duration_sec = s.duration;
      t = s.start + (Number(s.duration) || 0.2);
    }
    this.project.timeline.shots = shots;
    this.render();
    this.opts.onChange?.(true);
  }

  zoom(delta) {
    this.pxPerSec = Math.min(200, Math.max(10, this.pxPerSec + delta));
    if (this.project) this.project.timeline.zoom = this.pxPerSec;
    this.render();
    this.opts.onChange?.(false);
  }

  addShotAt(t) {
    const d = 5;
    const shot = {
      id: uid("shot_"),
      start: this._snap(t),
      duration: d,
      label: `Shot ${(this.project.timeline.shots.length || 0) + 1}`,
      image: {
        positive_prompt: "",
        negative_prompt: this.project.global_negative || "",
        seed: -1,
        width: 1024,
        height: 576,
        aspect_ratio: "16:9",
        model_id: this.project.global_image_model || "flux2-klein-4b",
        steps: 20,
        cfg: 3.5,
        loras: [],
        reference_ids: [],
        batch_count: 1,
      },
      video: {
        preset_id: this.project.global_video_preset || "minimax-h3-i2v",
        animation_prompt: "",
        duration_sec: d,
        fps: 24,
        motion_strength: 1,
        camera_movement: "none",
        seed: -1,
        width: 768,
        height: 432,
        quality: "draft",
        mute_clip_audio: true,
      },
      image_path: null,
      image_alternatives: [],
      video_path: null,
      draft_video_path: null,
      thumbnail_path: null,
      image_status: "empty",
      video_status: "empty",
      last_error: null,
      transition_out: "hard_cut",
      transition_duration: 0,
    };
    this.project.timeline.shots.push(shot);
    this.selectedShotId = shot.id;
    this.render();
    this.opts.onSelectShot?.(shot.id);
    this.opts.onChange?.();
    return shot;
  }

  deleteSelected() {
    if (!this.selectedShotId) return;
    this.project.timeline.shots = this.project.timeline.shots.filter(
      (s) => s.id !== this.selectedShotId
    );
    this.selectedShotId = null;
    this.render();
    this.opts.onChange?.();
  }

  splitAt(t) {
    const shot = this.project.timeline.shots.find(
      (s) => t > s.start + 0.15 && t < s.start + s.duration - 0.15
    );
    if (!shot) return;
    const end = shot.start + shot.duration;
    const leftDur = t - shot.start;
    const right = { ...JSON.parse(JSON.stringify(shot)), id: uid("shot_"), start: t, duration: end - t };
    right.label = (shot.label || "Shot") + " B";
    shot.duration = leftDur;
    this.project.timeline.shots.push(right);
    this.project.timeline.shots.sort((a, b) => a.start - b.start);
    this.render();
    this.opts.onChange?.();
  }
}
