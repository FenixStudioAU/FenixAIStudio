"""Saved ACE-Step / studio music tracks (metadata + files under music_tracks/)."""
from __future__ import annotations

import json
import shutil
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Optional
from uuid import uuid4

from .config import ROOT
from .logging_setup import log

MUSIC_DIR = ROOT / "music_tracks"
META_PATH = MUSIC_DIR / "library.json"

DEFAULT_LYRICS = """[Verse]
Fire up the screen, turn the noise up loud,
Building something different from the digital crowd.
Games, beats, worlds — whatever comes alive,
Throw it in the furnace, see what survives.

[Pre-Chorus]
No rules, no waiting,
Make it, break it, start again.

[Chorus]
Fenix Studio — rise from the flame,
Build another world, give the madness a name.
From an empty page to a midnight glow,
If we can imagine it — we make it go.

Fenix Studio — louder every time,
Code in the blood and a beat in the mind.
Create. Destroy. Rebuild. Reload.
Fenix Studio — make your own road.

[Outro]
Turn it up.
Light the flame.
Fenix Studio.
"""

DEFAULT_TAGS = "pop, energetic, electronic, anthem, cinematic, fenix studio"


def _now() -> str:
    return datetime.now(timezone.utc).isoformat()


def _ensure() -> None:
    MUSIC_DIR.mkdir(parents=True, exist_ok=True)
    (MUSIC_DIR / "audio").mkdir(parents=True, exist_ok=True)
    if not META_PATH.exists():
        META_PATH.write_text(json.dumps({"tracks": []}, indent=2), encoding="utf-8")


def _load() -> dict[str, Any]:
    _ensure()
    try:
        return json.loads(META_PATH.read_text(encoding="utf-8-sig"))
    except Exception:
        return {"tracks": []}


def _save(data: dict[str, Any]) -> None:
    _ensure()
    META_PATH.write_text(json.dumps(data, indent=2), encoding="utf-8")


def list_tracks() -> list[dict[str, Any]]:
    tracks = list(_load().get("tracks") or [])
    tracks.sort(key=lambda t: t.get("created_at") or "", reverse=True)
    return tracks


def get_track(track_id: str) -> Optional[dict[str, Any]]:
    for t in list_tracks():
        if t.get("id") == track_id:
            return t
    return None


def abs_audio_path(rel: str) -> Optional[Path]:
    if not rel:
        return None
    p = MUSIC_DIR / rel
    return p if p.is_file() else None


def add_track(
    *,
    title: str,
    tags: str = "",
    lyrics: str = "",
    duration_sec: float = 0,
    bpm: int = 120,
    keyscale: str = "E minor",
    source_path: Path | None = None,
    audio_bytes: bytes | None = None,
    suffix: str = ".mp3",
) -> dict[str, Any]:
    _ensure()
    data = _load()
    tid = "trk_" + uuid4().hex[:12]
    rel = ""
    if source_path and source_path.is_file():
        suffix = source_path.suffix or suffix
        dest = MUSIC_DIR / "audio" / f"{tid}{suffix}"
        shutil.copy2(source_path, dest)
        rel = f"audio/{tid}{suffix}"
    elif audio_bytes:
        if not suffix.startswith("."):
            suffix = f".{suffix}"
        dest = MUSIC_DIR / "audio" / f"{tid}{suffix}"
        dest.write_bytes(audio_bytes)
        rel = f"audio/{tid}{suffix}"
    item = {
        "id": tid,
        "title": (title or "Untitled Track").strip(),
        "tags": (tags or "").strip(),
        "lyrics": (lyrics or "").strip(),
        "duration_sec": float(duration_sec or 0),
        "bpm": int(bpm or 120),
        "keyscale": keyscale or "E minor",
        "path": rel,
        "created_at": _now(),
    }
    tracks = data.get("tracks") or []
    tracks.append(item)
    data["tracks"] = tracks
    _save(data)
    log.info("Music track saved: %s (%s)", item["title"], tid)
    return item


def delete_track(track_id: str) -> bool:
    data = _load()
    tracks = data.get("tracks") or []
    kept = []
    found = False
    for t in tracks:
        if t.get("id") == track_id:
            found = True
            p = abs_audio_path(t.get("path") or "")
            if p and p.is_file():
                try:
                    p.unlink()
                except Exception:
                    pass
            continue
        kept.append(t)
    data["tracks"] = kept
    _save(data)
    return found
