"""Project folder storage, autosave helpers."""
from __future__ import annotations

import json
import shutil
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Optional

from .config import settings
from .logging_setup import log
from .schemas import Project, Shot, Timeline, new_id


def _now() -> str:
    return datetime.now(timezone.utc).isoformat()


PROJECT_SUBDIRS = [
    "audio",
    "images",
    "images/uploaded",
    "images/generated",
    "references",
    "videos",
    "videos/draft",
    "videos/final",
    "thumbnails",
    "exports",
    "workflows",
    "subtitles",
    "cache",
]


def project_dir(project_id: str) -> Path:
    return settings.projects_dir / project_id


def project_json_path(project_id: str) -> Path:
    return project_dir(project_id) / "project.json"


def list_projects() -> list[dict[str, Any]]:
    items = []
    for p in sorted(settings.projects_dir.iterdir() if settings.projects_dir.exists() else []):
        if not p.is_dir():
            continue
        jp = p / "project.json"
        if not jp.exists():
            continue
        try:
            data = json.loads(jp.read_text(encoding="utf-8"))
            pid = data.get("id", p.name)
            shots = (data.get("timeline") or {}).get("shots") or []
            preview = None
            for s in shots:
                preview = s.get("thumbnail_path") or s.get("image_path")
                if preview:
                    break
            letter = (data.get("name") or "P")[:1].upper()
            name = data.get("name", p.name)
            # Hide internal chat media workspace from the project grid
            if name == "Chat Media (studio)":
                continue
            items.append(
                {
                    "id": pid,
                    "name": name,
                    "kind": data.get("kind") or "music",
                    "updated_at": data.get("updated_at"),
                    "created_at": data.get("created_at"),
                    "duration": (data.get("audio") or {}).get("duration", 0),
                    "shot_count": len(shots),
                    "preview_path": preview,
                    "preview_letter": letter,
                }
            )
        except Exception as e:
            log.warning("Skip project %s: %s", p, e)
    items.sort(key=lambda x: x.get("updated_at") or "", reverse=True)
    return items


def create_project(
    name: str = "Untitled Music Video",
    *,
    kind: str = "music",
    notes: str = "",
) -> Project:
    pid = new_id("proj_")
    root = project_dir(pid)
    root.mkdir(parents=True, exist_ok=True)
    for sub in PROJECT_SUBDIRS:
        (root / sub).mkdir(parents=True, exist_ok=True)
    k = (kind or "music").strip().lower()
    if k not in ("music", "film"):
        k = "music"
    proj = Project(
        id=pid,
        name=name or ("Untitled Film" if k == "film" else "Untitled Music Video"),
        kind=k,
        notes=(notes or "").strip(),
        created_at=_now(),
        updated_at=_now(),
    )
    save_project(proj)
    log.info("Created project %s kind=%s (%s)", proj.name, k, pid)
    return proj


def load_project(project_id: str) -> Project:
    path = project_json_path(project_id)
    if not path.exists():
        raise FileNotFoundError(f"Project not found: {project_id}")
    data = json.loads(path.read_text(encoding="utf-8"))
    return Project.model_validate(data)


def save_project(project: Project, *, merge_media: bool = True) -> Project:
    """Persist project. When merge_media=True, never let a client wipe generation paths."""
    path = project_json_path(project.id)
    if merge_media and path.exists():
        try:
            disk = load_project(project.id)
            by_id = {s.id: s for s in disk.timeline.shots}
            for shot in project.timeline.shots:
                old = by_id.get(shot.id)
                if not old:
                    continue
                # Keep server-side media if client sent empty/stale empties
                if old.image_path and not shot.image_path:
                    shot.image_path = old.image_path
                    shot.image_status = old.image_status
                    shot.image_alternatives = old.image_alternatives or shot.image_alternatives
                    shot.thumbnail_path = old.thumbnail_path or shot.thumbnail_path
                if old.thumbnail_path and not shot.thumbnail_path:
                    shot.thumbnail_path = old.thumbnail_path
                if old.video_path and not shot.video_path:
                    shot.video_path = old.video_path
                    shot.video_status = old.video_status
                    shot.draft_video_path = old.draft_video_path or shot.draft_video_path
                if old.draft_video_path and not shot.draft_video_path:
                    shot.draft_video_path = old.draft_video_path
                if old.video_alternatives and not shot.video_alternatives:
                    shot.video_alternatives = old.video_alternatives
        except Exception as e:
            log.warning("merge_media skipped: %s", e)

    project.updated_at = _now()
    root = project_dir(project.id)
    root.mkdir(parents=True, exist_ok=True)
    for sub in PROJECT_SUBDIRS:
        (root / sub).mkdir(parents=True, exist_ok=True)
    # atomic write
    tmp = path.with_suffix(".tmp")
    tmp.write_text(project.model_dump_json(indent=2), encoding="utf-8")
    tmp.replace(path)
    return project


def delete_project(project_id: str) -> None:
    root = project_dir(project_id)
    if root.exists():
        shutil.rmtree(root)
        log.info("Deleted project %s", project_id)


def abs_path(project_id: str, rel: str | None) -> Optional[Path]:
    if not rel:
        return None
    p = Path(rel)
    if p.is_absolute():
        return p
    return project_dir(project_id) / rel


def rel_to_project(project_id: str, path: Path) -> str:
    root = project_dir(project_id).resolve()
    path = path.resolve()
    try:
        return str(path.relative_to(root)).replace("\\", "/")
    except ValueError:
        return str(path)


def ensure_default_slots(project: Project, slot_duration: float | None = None) -> Project:
    """If audio loaded and no shots, create fixed-duration slots covering the song."""
    if project.timeline.shots:
        return project
    duration = project.audio.duration or 0
    if duration <= 0:
        return project
    slot = slot_duration or settings.default_slot
    shots: list[Shot] = []
    t = 0.0
    idx = 1
    while t < duration - 0.05:
        d = min(slot, duration - t)
        shots.append(
            Shot(
                start=round(t, 3),
                duration=round(d, 3),
                label=f"Shot {idx}",
            )
        )
        t += d
        idx += 1
    project.timeline.shots = shots
    return project


def rebuild_slots_fixed(project: Project, slot_duration: float) -> Project:
    duration = project.audio.duration or 0
    if duration <= 0:
        return project
    shots: list[Shot] = []
    t = 0.0
    idx = 1
    while t < duration - 0.05:
        d = min(slot_duration, duration - t)
        shots.append(Shot(start=round(t, 3), duration=round(d, 3), label=f"Shot {idx}"))
        t += d
        idx += 1
    project.timeline.shots = shots
    return project
