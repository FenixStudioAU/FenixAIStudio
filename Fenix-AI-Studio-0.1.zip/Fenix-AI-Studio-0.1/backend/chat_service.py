"""Standalone studio chat + coder pipeline (Ollama). Does not touch timeline state."""
from __future__ import annotations

from typing import Any, Optional

from . import llm_client
from .logging_setup import log
from .persona import with_persona

CHAT_SYSTEM = """You are the chat assistant inside Fenix AI Studio.
You help with creative writing, prompts, music-video ideas, and general questions.

ATTACHMENTS: The user may attach images or PDFs. Attachment metadata and extracted PDF text
appear in system context. Prefer those over inventing new images.

When the user wants a NEW still image, reply briefly then one JSON block:
```json
{"action":"generate_image","prompt":"<detailed visual prompt for Flux>","negative":"optional"}
```

When they want VIDEO from an existing/attached/last image (e.g. "make this a video", "animate it"):
```json
{"action":"generate_video","prompt":"<motion / camera prompt only>","use_attached_image":true}
```
Do NOT set image_prompt when use_attached_image is true — never regenerate a still first.

When they want video from a brand-new scene with no reference image:
```json
{"action":"generate_video","prompt":"<motion>","image_prompt":"<still prompt for a new image first>"}
```

When they need live web facts (and search results are not already provided), you may request:
```json
{"action":"web_search","query":"<search query>"}
```

Only include JSON when they actually ask for media or search. Be concise."""

DESIGNER_SYSTEM = """You are the DESIGNER role (like Fenix Code Companion).
Help clarify the software idea, resolve contradictions, and write strong implementation or repair prompts
for a separate coder model. Do not pretend you executed code.
When the user wants something built, end with a section titled:
IMPLEMENTATION PROMPT
containing a self-contained build request that asks for one complete runnable HTML file (or the
language they asked for), with concrete acceptance criteria.
Keep ordinary discussion natural. You do not write full applications yourself."""

CODER_SYSTEM = """You are the CODER role. Produce exactly what was requested.
If the request is for a complete HTML app/game: return one complete file from <!DOCTYPE html> through </html>.
No markdown fences, no commentary before/after.
If the request is for another language: return only the code.
Never leave TODOs or placeholders. Honour every explicit requirement."""

REPAIR_SYSTEM = """You are the CORRECTIONS / REPAIR coder.
Return a complete updated artifact (full file), not a patch.
Preserve working behaviour unless the user explicitly changes requirements.
If HTML was requested originally, return the entire HTML document with no fences or commentary."""

INSPECTOR_SYSTEM = """You are the CODE INSPECTOR role (like Fenix Code Companion).
You receive the complete current HTML file, original requirements (if any), the user's fault
description, and optional runtime console errors.
Diagnose only — do not rewrite the whole file.
Structure your report as:
1) Summary of the problem
2) Likely root cause(s) with file/section references
3) Concrete fix steps the repair coder should follow
4) Risks / what must be preserved
Be specific and actionable."""


async def chat_reply(
    *,
    mode: str,
    messages: list[dict[str, str]],
    model: str,
    stage: str = "chat",
    temperature: float | None = None,
    num_predict: int = 4096,
) -> dict[str, Any]:
    """Run one Ollama turn. mode=chat|coder; stage for coder: designer|coder|repair."""
    if not model:
        raise RuntimeError("No model selected")
    mode = (mode or "chat").lower()
    stage = (stage or "chat").lower()

    if mode == "coder":
        if stage == "designer":
            system = with_persona(DESIGNER_SYSTEM)
            temp = 0.55 if temperature is None else temperature
            npred = max(num_predict, 4096)
        elif stage == "repair":
            system = with_persona(REPAIR_SYSTEM)
            temp = 0.15 if temperature is None else temperature
            npred = max(num_predict, 8192)
        elif stage == "inspect":
            system = with_persona(INSPECTOR_SYSTEM)
            temp = 0.2 if temperature is None else temperature
            npred = max(num_predict, 4096)
        else:
            system = with_persona(CODER_SYSTEM)
            temp = 0.2 if temperature is None else temperature
            npred = max(num_predict, 8192)
    else:
        system = with_persona(CHAT_SYSTEM)
        temp = 0.7 if temperature is None else temperature
        npred = num_predict

    # Keep system first; allow client to pass recent history as user/assistant only
    payload_msgs: list[dict[str, str]] = [{"role": "system", "content": system}]
    for m in messages[-40:]:
        role = m.get("role") or "user"
        if role not in ("user", "assistant", "system"):
            role = "user"
        content = (m.get("content") or "").strip()
        if not content:
            continue
        # Don't stack multiple systems from client
        if role == "system":
            continue
        payload_msgs.append({"role": role, "content": content})

    log.info("chat mode=%s stage=%s model=%s msgs=%d", mode, stage, model, len(payload_msgs))
    text = await llm_client.chat(
        model,
        payload_msgs,
        temperature=temp,
        num_predict=npred,
        timeout=600.0,
    )
    return {
        "content": text,
        "model": model,
        "mode": mode,
        "stage": stage,
        "loading": False,
    }
