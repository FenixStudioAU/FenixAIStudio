"""ComfyUI HTTP + WebSocket client. Never modifies the ComfyUI install."""
from __future__ import annotations

import asyncio
import json
import uuid
from pathlib import Path
from typing import Any, Callable, Optional

import httpx

from .config import settings
from .logging_setup import log

comfy_log = logging = __import__("logging").getLogger("amvs.comfyui")


class ComfyUIClient:
    def __init__(self, base_url: str | None = None):
        self.base_url = (base_url or settings.comfy_url).rstrip("/")
        self.client_id = str(uuid.uuid4())
        self._http: Optional[httpx.AsyncClient] = None

    async def _client(self) -> httpx.AsyncClient:
        # Always pick up live settings.comfy_url (LAN / settings page)
        want = (settings.comfy_url or self.base_url).rstrip("/")
        if want != self.base_url:
            self.base_url = want
            if self._http and not self._http.is_closed:
                await self._http.aclose()
            self._http = None
        if self._http is None or self._http.is_closed:
            # Uploads + long Comfy waits need more than the default 60s when a model is loading
            self._http = httpx.AsyncClient(
                base_url=self.base_url,
                timeout=httpx.Timeout(300.0, connect=30.0),
            )
        return self._http

    async def close(self) -> None:
        if self._http and not self._http.is_closed:
            await self._http.aclose()
        self._http = None

    async def is_online(self) -> bool:
        try:
            c = await self._client()
            r = await c.get("/system_stats", timeout=3.0)
            return r.status_code == 200
        except Exception:
            return False

    async def system_stats(self) -> dict[str, Any]:
        c = await self._client()
        r = await c.get("/system_stats", timeout=5.0)
        r.raise_for_status()
        return r.json()

    async def list_models(self, folder: str) -> list[str]:
        c = await self._client()
        r = await c.get(f"/models/{folder}", timeout=8.0)
        if r.status_code == 404:
            return []
        r.raise_for_status()
        data = r.json()
        return data if isinstance(data, list) else []

    async def object_info(self, node: str | None = None) -> dict[str, Any]:
        c = await self._client()
        path = f"/object_info/{node}" if node else "/object_info"
        r = await c.get(path, timeout=120.0)
        r.raise_for_status()
        return r.json()

    async def upload_image(
        self,
        path: Path,
        subfolder: str = "",
        overwrite: bool = True,
        image_type: str = "input",
    ) -> dict[str, Any]:
        c = await self._client()
        data = {
            "overwrite": "true" if overwrite else "false",
            "type": image_type,
            "subfolder": subfolder,
        }
        files = {"image": (path.name, path.read_bytes(), "application/octet-stream")}
        r = await c.post("/upload/image", data=data, files=files)
        r.raise_for_status()
        result = r.json()
        comfy_log.info("Uploaded image %s -> %s", path.name, result)
        return result

    async def queue_prompt(self, prompt: dict[str, Any]) -> str:
        c = await self._client()
        payload = {"prompt": prompt, "client_id": self.client_id}
        comfy_log.info("Queue prompt keys=%s", list(prompt.keys()))
        r = await c.post("/prompt", json=payload)
        if r.status_code >= 400:
            comfy_log.error("Prompt error %s: %s", r.status_code, r.text)
            raise RuntimeError(f"ComfyUI prompt error: {r.text}")
        data = r.json()
        if "error" in data:
            raise RuntimeError(str(data["error"]))
        prompt_id = data.get("prompt_id")
        if not prompt_id:
            raise RuntimeError(f"No prompt_id in response: {data}")
        comfy_log.info("Queued prompt_id=%s", prompt_id)
        return prompt_id

    async def interrupt(self) -> None:
        c = await self._client()
        await c.post("/interrupt")
        comfy_log.info("Interrupt sent")

    async def free_memory(self, *, unload_models: bool = True, free_memory: bool = True) -> None:
        """Ask Comfy to unload models / free VRAM before a heavy switch (e.g. video → ACE)."""
        try:
            c = await self._client()
            r = await c.post(
                "/free",
                json={"unload_models": unload_models, "free_memory": free_memory},
                timeout=30.0,
            )
            comfy_log.info(
                "Comfy /free unload_models=%s free_memory=%s status=%s",
                unload_models,
                free_memory,
                r.status_code,
            )
        except Exception as e:
            comfy_log.warning("Comfy /free failed (continuing): %s", e)

    async def get_history(self, prompt_id: str) -> dict[str, Any]:
        c = await self._client()
        r = await c.get(f"/history/{prompt_id}")
        r.raise_for_status()
        return r.json()

    async def get_queue(self) -> dict[str, Any]:
        c = await self._client()
        r = await c.get("/queue")
        r.raise_for_status()
        return r.json()

    async def download_view(
        self,
        filename: str,
        subfolder: str = "",
        folder_type: str = "output",
        dest: Path | None = None,
    ) -> bytes:
        c = await self._client()
        # Comfy may report subfolders with backslashes on Windows
        sub = (subfolder or "").replace("\\", "/")
        params = {"filename": filename, "subfolder": sub, "type": folder_type}
        r = await c.get("/view", params=params, timeout=120.0)
        if r.status_code >= 400:
            # Fallback: copy straight from Comfy output folder when API view fails
            comfy_out = settings.comfy_install / "output"
            candidates = [
                comfy_out / sub / filename if sub else comfy_out / filename,
                comfy_out / (subfolder or "") / filename,
            ]
            for cand in candidates:
                if cand.is_file():
                    data = cand.read_bytes()
                    if dest:
                        dest.parent.mkdir(parents=True, exist_ok=True)
                        dest.write_bytes(data)
                    comfy_log.info("Downloaded via filesystem fallback %s", cand)
                    return data
            r.raise_for_status()
        data = r.content
        if dest:
            dest.parent.mkdir(parents=True, exist_ok=True)
            dest.write_bytes(data)
        return data

    def _history_entry(self, hist: dict[str, Any], prompt_id: str) -> dict[str, Any] | None:
        """Normalize /history and /history/{id} shapes."""
        if not hist:
            return None
        if prompt_id in hist and isinstance(hist[prompt_id], dict):
            return hist[prompt_id]
        # Some builds return the entry at the root
        if "outputs" in hist or "status" in hist:
            return hist
        return None

    def _entry_failed(self, entry: dict[str, Any]) -> str | None:
        status = entry.get("status") or {}
        if status.get("status_str") == "error":
            return str(status)[:1500]
        for m in status.get("messages") or []:
            if isinstance(m, list) and m and m[0] == "execution_error":
                return str(m)[:1500]
        return None

    def _entry_succeeded(self, entry: dict[str, Any]) -> bool:
        """True when Comfy has finished and produced outputs (or empty success)."""
        if not entry:
            return False
        if self._entry_failed(entry):
            return False
        outputs = entry.get("outputs")
        status = entry.get("status") or {}
        if outputs:
            return True
        if status.get("status_str") == "success" and status.get("completed") is not False:
            return True
        if status.get("completed") is True:
            return True
        return False

    async def wait_for_prompt(
        self,
        prompt_id: str,
        timeout: float | None = None,
        on_progress: Optional[Callable[[dict[str, Any]], Any]] = None,
    ) -> dict[str, Any]:
        """Poll /history only until outputs exist.

        No WebSocket — WS cleanup previously hung the job after Comfy finished
        (UI stuck at 99%, image never imported).
        """
        import time

        timeout = float(timeout or settings.comfy_timeout)
        deadline = time.monotonic() + timeout
        last_log = 0.0
        # Optional: fire progress callback with synthetic ticks from history is N/A;
        # keep signature for callers.
        _ = on_progress

        while time.monotonic() < deadline:
            try:
                hist = await self.get_history(prompt_id)
            except Exception as e:
                comfy_log.warning("get_history(%s) failed: %s", prompt_id, e)
                await asyncio.sleep(1.0)
                continue

            entry = self._history_entry(hist, prompt_id)
            if entry:
                err = self._entry_failed(entry)
                if err:
                    raise RuntimeError(f"ComfyUI execution error: {err}")
                if self._entry_succeeded(entry):
                    outs = entry.get("outputs") or {}
                    if outs or (entry.get("status") or {}).get("status_str") == "success":
                        comfy_log.info(
                            "Prompt %s complete outputs=%s", prompt_id, bool(outs)
                        )
                        return entry

            # Also treat "not in queue anymore + history has entry" as done
            try:
                q = await self.get_queue()
                running = q.get("queue_running") or []
                pending = q.get("queue_pending") or []
                in_queue = False
                for item in list(running) + list(pending):
                    # item shape: [number, prompt_id, prompt, extra]
                    if isinstance(item, (list, tuple)) and len(item) > 1 and item[1] == prompt_id:
                        in_queue = True
                        break
                if not in_queue and entry and entry.get("outputs"):
                    comfy_log.info("Prompt %s left queue with outputs", prompt_id)
                    return entry
            except Exception:
                pass

            now = time.monotonic()
            if now - last_log > 10:
                comfy_log.info("Waiting for prompt %s …", prompt_id)
                last_log = now
            await asyncio.sleep(0.4)

        hist = await self.get_history(prompt_id)
        entry = self._history_entry(hist, prompt_id)
        if entry and self._entry_succeeded(entry):
            return entry
        raise TimeoutError(f"ComfyUI prompt {prompt_id} timed out after {timeout}s")

    def extract_output_images(self, history_entry: dict[str, Any]) -> list[dict[str, str]]:
        images: list[dict[str, str]] = []
        for _nid, node_out in (history_entry.get("outputs") or {}).items():
            for img in node_out.get("images", []) or []:
                images.append(
                    {
                        "filename": img.get("filename", ""),
                        "subfolder": img.get("subfolder", ""),
                        "type": img.get("type", "output"),
                    }
                )
            for vid in node_out.get("gifs", []) or []:  # some nodes report video as gifs
                images.append(
                    {
                        "filename": vid.get("filename", ""),
                        "subfolder": vid.get("subfolder", ""),
                        "type": vid.get("type", "output"),
                        "kind": "video",
                    }
                )
            for vid in node_out.get("videos", []) or []:
                images.append(
                    {
                        "filename": vid.get("filename", ""),
                        "subfolder": vid.get("subfolder", ""),
                        "type": vid.get("type", "output"),
                        "kind": "video",
                    }
                )
        return images


comfy = ComfyUIClient()
