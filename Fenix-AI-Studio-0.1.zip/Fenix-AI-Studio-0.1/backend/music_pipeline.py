"""ACE-Step 1.5 text-to-audio via ComfyUI API workflows."""
from __future__ import annotations

import asyncio
import copy
import json
import math
import random
from pathlib import Path
from typing import Any, Optional

from .comfyui_client import comfy
from .config import settings
from .gen_activity import clear_activity, set_activity
from .logging_setup import log
from .models_detect import inventory
from .workflow_engine import _load_template, _set_input

log_m = log


def _music_status(msg: str, on_status=None) -> None:
    set_activity(msg, source="music", busy=True)
    if on_status:
        try:
            on_status(msg)
        except Exception:
            pass


def _pick(pool: list[str], needles: list[str]) -> Optional[str]:
    lower = {n.lower().replace("\\", "/").split("/")[-1]: n for n in pool}
    for nd in needles:
        if nd.lower() in lower:
            return lower[nd.lower()]
    for n in pool:
        bn = n.lower().replace("\\", "/").split("/")[-1]
        for nd in needles:
            if nd.lower() in bn:
                return n
    return None


async def resolve_ace_models() -> dict[str, str]:
    inv = await inventory()
    dm = inv.get("diffusion_models") or []
    te = inv.get("text_encoders") or []
    vaes = inv.get("vae") or []
    unet = _pick(
        dm,
        [
            "acestep_v1.5_turbo.safetensors",
            "acestep_v1.5.safetensors",
            "ace_step",
            "acestep",
        ],
    )
    clip1 = _pick(te, ["qwen_0.6b_ace15.safetensors", "0.6b_ace", "qwen_0.6b"])
    clip2 = _pick(te, ["qwen_4b_ace15.safetensors", "4b_ace15", "qwen_4b_ace"])
    vae = _pick(vaes, ["ace_1.5_vae.safetensors", "ace_1.5_vae", "ace15_vae", "ace_vae"])
    missing = []
    if not unet:
        missing.append("diffusion_models/acestep_v1.5_turbo.safetensors")
    if not clip1 or not clip2:
        missing.append("text_encoders/qwen_0.6b_ace15 + qwen_4b_ace15")
    if not vae:
        missing.append("vae/ace_1.5_vae.safetensors")
    if missing:
        raise RuntimeError(
            "ACE-Step 1.5 models missing in ComfyUI: " + "; ".join(missing)
        )
    return {"unet": unet, "clip1": clip1, "clip2": clip2, "vae": vae}


async def build_ace_workflow(
    *,
    tags: str,
    lyrics: str,
    duration_sec: float = 30.0,
    bpm: int = 120,
    seed: int = -1,
    keyscale: str = "E minor",
    language: str = "en",
    timesignature: str = "4",
    steps: int = 8,
    generate_audio_codes: bool = False,
    filename_prefix: str = "audio/fenix",
) -> dict[str, Any]:
    models = await resolve_ace_models()
    prompt = copy.deepcopy(_load_template("ace_step15_t2a.json"))
    if seed is None or seed < 0:
        seed = random.randint(0, 2**32 - 1)
    # Comfy ACE uses math.ceil(duration); keep integer seconds for latent + encode
    duration_sec = float(math.ceil(max(10.0, min(240.0, float(duration_sec or 30)))))
    bpm = max(40, min(220, int(bpm or 120)))
    steps = max(4, min(30, int(steps or 8)))
    # Hard bool — Comfy node default is True (LLM, duration*5 tokens on the 4B).
    # That is the usual “GPU pegged forever” path; only enable when user opts in.
    use_audio_codes = bool(generate_audio_codes)

    _set_input(prompt, "1", "unet_name", models["unet"])
    _set_input(prompt, "1", "weight_dtype", "default")
    _set_input(prompt, "2", "clip_name1", models["clip1"])
    _set_input(prompt, "2", "clip_name2", models["clip2"])
    _set_input(prompt, "2", "type", "ace")
    _set_input(prompt, "2", "device", "default")
    _set_input(prompt, "3", "vae_name", models["vae"])
    _set_input(prompt, "4", "tags", (tags or "").strip())
    _set_input(prompt, "4", "lyrics", lyrics or "")
    _set_input(prompt, "4", "seed", int(seed))
    _set_input(prompt, "4", "bpm", int(bpm))
    _set_input(prompt, "4", "duration", float(duration_sec))
    _set_input(prompt, "4", "timesignature", str(timesignature or "4"))
    _set_input(prompt, "4", "language", language or "en")
    _set_input(prompt, "4", "keyscale", keyscale or "E minor")
    _set_input(prompt, "4", "generate_audio_codes", use_audio_codes)
    # Match official template advanced defaults (only matter when codes=True)
    _set_input(prompt, "4", "cfg_scale", 2.0)
    _set_input(prompt, "4", "temperature", 0.85)
    _set_input(prompt, "4", "top_p", 0.9)
    _set_input(prompt, "4", "top_k", 0)
    _set_input(prompt, "4", "min_p", 0.0)
    # Latent length must match encode duration (this is what makes long tracks heavy)
    _set_input(prompt, "6", "seconds", float(duration_sec))
    _set_input(prompt, "6", "batch_size", 1)
    _set_input(prompt, "7", "shift", 3.0)
    _set_input(prompt, "8", "seed", int(seed))
    _set_input(prompt, "8", "steps", int(steps))
    _set_input(prompt, "8", "cfg", 1.0)
    _set_input(prompt, "8", "sampler_name", "euler")
    _set_input(prompt, "8", "scheduler", "simple")
    _set_input(prompt, "8", "denoise", 1.0)
    # Tiled VAE decode: full-buffer decode OOMs / thrash after 8/8 on long tracks
    # when TE (~9GB) + DiT (~4.5GB) are still staged ("0 models unloaded").
    # Smaller tiles for longer songs keep peak VRAM down.
    if duration_sec >= 90:
        tile_size, overlap = 256, 32
    elif duration_sec >= 45:
        tile_size, overlap = 384, 48
    else:
        tile_size, overlap = 512, 64
    if prompt.get("9", {}).get("class_type") == "VAEDecodeAudioTiled":
        _set_input(prompt, "9", "tile_size", int(tile_size))
        _set_input(prompt, "9", "overlap", int(overlap))
    _set_input(prompt, "10", "filename_prefix", filename_prefix)
    _set_input(prompt, "10", "quality", "V0")

    te = prompt["4"]["inputs"]
    log_m.info(
        "ACE-Step payload unet=%s clip1=%s clip2=%s vae=%s | "
        "tags_len=%d lyrics_len=%d duration=%.0fs bpm=%d seed=%s steps=%d "
        "audio_codes=%s (if True, LLM runs ~%d tokens BEFORE 8/8)",
        models["unet"],
        models["clip1"],
        models["clip2"],
        models["vae"],
        len(tags or ""),
        len(lyrics or ""),
        duration_sec,
        bpm,
        seed,
        steps,
        use_audio_codes,
        int(duration_sec) * 5 if use_audio_codes else 0,
    )
    log_m.info(
        "ACE-Step TextEncode inputs: %s",
        {k: (v if k not in ("tags", "lyrics") else f"<{len(str(v))} chars>") for k, v in te.items()},
    )
    # Dump exact API prompt so it can be Load'd in Comfy for A/B
    try:
        dump_dir = Path(settings.cache_dir) / "music_tmp"
        dump_dir.mkdir(parents=True, exist_ok=True)
        dump_path = dump_dir / "last_ace_prompt.json"
        dump_path.write_text(json.dumps(prompt, indent=2), encoding="utf-8")
        log_m.info("ACE-Step API prompt dumped to %s", dump_path)
    except Exception as e:
        log_m.debug("ACE prompt dump failed: %s", e)
    return prompt


def extract_audio_outputs(history_entry: dict[str, Any]) -> list[dict[str, str]]:
    """Pull audio file refs from Comfy history (SaveAudio / SaveAudioMP3)."""
    found: list[dict[str, str]] = []

    def _add(item: dict) -> None:
        fn = str(item.get("filename") or "")
        if not fn:
            return
        found.append(
            {
                "filename": fn,
                "subfolder": item.get("subfolder", "") or "",
                "type": item.get("type", "output") or "output",
                "kind": "audio",
            }
        )

    for _nid, node_out in (history_entry.get("outputs") or {}).items():
        if not isinstance(node_out, dict):
            continue
        for key in ("audio", "audios", "flac", "mp3", "wav"):
            for item in node_out.get(key) or []:
                if isinstance(item, dict):
                    _add(item)
        for item in node_out.get("images") or []:
            if isinstance(item, dict):
                fn = str(item.get("filename") or "")
                if fn.lower().endswith((".mp3", ".flac", ".wav", ".ogg", ".opus")):
                    _add(item)
        # UI payload from SaveAudio helpers
        ui = node_out.get("ui") if isinstance(node_out.get("ui"), dict) else {}
        for key in ("audio", "images"):
            for item in ui.get(key) or []:
                if isinstance(item, dict):
                    fn = str(item.get("filename") or "")
                    if not fn or fn.lower().endswith((".mp3", ".flac", ".wav", ".ogg", ".opus", ".webm")):
                        if fn:
                            _add(item)
    return found


def _scan_comfy_audio(filename_prefix: str, *, newer_than: float = 0.0) -> list[Path]:
    """Find audio files written under Comfy output for this prefix."""
    out_root = settings.comfy_install / "output"
    if not out_root.is_dir():
        return []
    prefix = filename_prefix.replace("\\", "/").split("/")[-1]
    # Also match subfolder path pieces (amvs/music/trk_xxx)
    parts = [p for p in filename_prefix.replace("\\", "/").split("/") if p]
    candidates: list[Path] = []
    for p in out_root.rglob("*"):
        if not p.is_file():
            continue
        if p.suffix.lower() not in {".mp3", ".flac", ".wav", ".ogg", ".opus"}:
            continue
        name = p.name
        rel = str(p.relative_to(out_root)).replace("\\", "/")
        if prefix and prefix not in name and prefix not in rel:
            # match last path segment of prefix
            if not any(part in name or part in rel for part in parts[-2:]):
                continue
        try:
            if newer_than and p.stat().st_mtime < newer_than - 2:
                continue
            # Ignore empty / still-writing files
            if p.stat().st_size < 2048:
                continue
        except OSError:
            continue
        candidates.append(p)
    candidates.sort(key=lambda x: x.stat().st_mtime, reverse=True)
    return candidates


async def run_ace_generation(
    *,
    tags: str,
    lyrics: str,
    duration_sec: float,
    bpm: int,
    seed: int,
    keyscale: str,
    language: str,
    steps: int,
    filename_prefix: str,
    generate_audio_codes: bool = False,
    on_status=None,
    timeout_sec: float | None = None,
) -> Path:
    """
    Queue ACE-Step and wait until audio exists.

    After KSampler hits N/N, Comfy still runs VAEDecodeAudio + SaveAudio — that can
    peg the GPU for a long time on long tracks. We therefore:
      - use a long timeout (default 45 min for music)
      - also watch the Comfy output folder so we succeed as soon as the file lands
        even if history JSON is slow/odd
    """
    import time

    try:
        _music_status("Building ACE-Step workflow…", on_status)
        prompt = await build_ace_workflow(
            tags=tags,
            lyrics=lyrics,
            duration_sec=duration_sec,
            bpm=bpm,
            seed=seed,
            keyscale=keyscale,
            language=language,
            steps=8,  # fixed turbo steps — not user-configurable
            generate_audio_codes=generate_audio_codes,
            filename_prefix=filename_prefix,
        )
        # Free hard before queue. Long tracks need headroom for post-8/8 audio VAE
        dur_guess = float(duration_sec or 30)
        # No automatic /free here — unloading forces multi‑GB cold reloads and
        # made gens "insanely slow". Use EMERGENCY STOP only when you want a hard clear.
        started = time.time()
        codes_on = bool(prompt.get("4", {}).get("inputs", {}).get("generate_audio_codes"))
        dur = prompt.get("6", {}).get("inputs", {}).get("seconds", duration_sec)
        tile = prompt.get("9", {}).get("inputs", {}).get("tile_size")
        if codes_on:
            _music_status(
                f"Queued ACE ({dur:.0f}s, audio-codes ON ≈{int(dur)*5} LLM tokens — heavy)…",
                on_status,
            )
        else:
            _music_status(
                f"Queued ACE ({dur:.0f}s, codes OFF, tiled VAE tile={tile})…",
                on_status,
            )
        prompt_id = await comfy.queue_prompt(prompt)
        _music_status(
            "Loading ACE models / sampling (then audio decode after 8/8)…",
            on_status,
        )
    except Exception:
        clear_activity("Music failed")
        raise

    # Music is slow: encode + sample + audio VAE decode for full song length
    timeout = float(timeout_sec or max(float(settings.comfy_timeout), 1800.0))
    deadline = time.monotonic() + timeout
    last_status = 0.0
    hist_entry: dict[str, Any] | None = None

    while time.monotonic() < deadline:
        # 1) Disk win: SaveAudio already wrote the file
        disk = _scan_comfy_audio(filename_prefix, newer_than=started)
        if disk:
            # Prefer a file that hasn't grown in 1.5s (write finished)
            p = disk[0]
            try:
                s1 = p.stat().st_size
                await asyncio.sleep(1.2)
                s2 = p.stat().st_size
                if s2 >= s1 and s2 > 4096:
                    log_m.info("ACE audio found on disk: %s (%s bytes)", p, s2)
                    _music_status("Track ready — importing…", on_status)
                    clear_activity("Track ready")
                    return p
            except OSError:
                pass

        # 2) History win
        try:
            hist = await comfy.get_history(prompt_id)
            entry = comfy._history_entry(hist, prompt_id)
            if entry:
                err = comfy._entry_failed(entry)
                if err:
                    raise RuntimeError(f"ComfyUI execution error: {err}")
                outs = extract_audio_outputs(entry)
                if outs or comfy._entry_succeeded(entry):
                    hist_entry = entry
                    if outs:
                        break
                    # Succeeded but no audio keys yet — keep scanning disk a bit
        except RuntimeError:
            raise
        except Exception as e:
            log_m.debug("ACE history poll: %s", e)

        # 3) Left queue without us noticing?
        try:
            q = await comfy.get_queue()
            running = q.get("queue_running") or []
            pending = q.get("queue_pending") or []
            in_q = any(
                isinstance(item, (list, tuple)) and len(item) > 1 and item[1] == prompt_id
                for item in list(running) + list(pending)
            )
            if not in_q:
                disk = _scan_comfy_audio(filename_prefix, newer_than=started)
                if disk:
                    if on_status:
                        on_status("Track ready — importing…")
                    return disk[0]
                if hist_entry and extract_audio_outputs(hist_entry):
                    break
        except Exception:
            pass

        now = time.monotonic()
        if on_status and now - last_status > 8:
            elapsed = int(time.time() - started)
            _music_status(
                f"Still working ({elapsed}s) — past 8/8 is audio VAE decode "
                f"(slower cards may delay here)…",
                on_status,
            )
            last_status = now
        await asyncio.sleep(1.0)

    if hist_entry:
        outs = extract_audio_outputs(hist_entry)
        if outs:
            o = outs[0]
            dest = Path(settings.cache_dir) / "music_tmp" / o["filename"]
            dest.parent.mkdir(parents=True, exist_ok=True)
            await comfy.download_view(
                o["filename"], o.get("subfolder", ""), o.get("type", "output"), dest
            )
            clear_activity("Track ready")
            return dest

    disk = _scan_comfy_audio(filename_prefix, newer_than=started)
    if disk:
        clear_activity("Track ready")
        return disk[0]

    clear_activity("Music timed out")
    raise TimeoutError(
        f"ACE-Step timed out after {timeout:.0f}s (prompt {prompt_id}). "
        "If Comfy already finished, check ComfyUI/output for the mp3 and we can import it next time."
    )
