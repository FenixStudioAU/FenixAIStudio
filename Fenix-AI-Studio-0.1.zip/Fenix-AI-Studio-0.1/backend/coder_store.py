"""Persistent Code Companion–style projects for Studio Coder mode."""
from __future__ import annotations

import json
import re
import secrets
import time
from pathlib import Path
from typing import Any, Optional

from .config import ROOT

CODER_ROOT = ROOT / "coder_projects"
DEFAULT_PROJECT_ID = "default"


def _now() -> str:
    return time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())


def _project_dir(project_id: str = DEFAULT_PROJECT_ID) -> Path:
    d = CODER_ROOT / project_id
    d.mkdir(parents=True, exist_ok=True)
    (d / "versions").mkdir(parents=True, exist_ok=True)
    return d


def _project_path(project_id: str = DEFAULT_PROJECT_ID) -> Path:
    return _project_dir(project_id) / "project.json"


def _default_project(project_id: str = DEFAULT_PROJECT_ID) -> dict[str, Any]:
    return {
        "id": project_id,
        "name": "Studio Coder",
        "created_at": _now(),
        "updated_at": _now(),
        "designer_messages": [],
        "build_prompt": "",
        "repair_prompt": "",
        "accepted_version_id": None,
        "active_version_id": None,
        "versions": [],
    }


def load_project(project_id: str = DEFAULT_PROJECT_ID) -> dict[str, Any]:
    path = _project_path(project_id)
    if not path.exists():
        data = _default_project(project_id)
        save_project(data)
        return data
    with open(path, "r", encoding="utf-8") as f:
        data = json.load(f)
    data.setdefault("designer_messages", [])
    data.setdefault("build_prompt", "")
    data.setdefault("repair_prompt", "")
    data.setdefault("versions", [])
    data.setdefault("accepted_version_id", None)
    data.setdefault("active_version_id", None)
    return data


def save_project(data: dict[str, Any]) -> dict[str, Any]:
    project_id = data.get("id") or DEFAULT_PROJECT_ID
    data["id"] = project_id
    data["updated_at"] = _now()
    path = _project_path(project_id)
    path.parent.mkdir(parents=True, exist_ok=True)
    with open(path, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=2, ensure_ascii=False)
    return data


def patch_project(fields: dict[str, Any], project_id: str = DEFAULT_PROJECT_ID) -> dict[str, Any]:
    data = load_project(project_id)
    for key in (
        "name",
        "designer_messages",
        "build_prompt",
        "repair_prompt",
        "accepted_version_id",
        "active_version_id",
    ):
        if key in fields and fields[key] is not None:
            data[key] = fields[key]
    return save_project(data)


def _new_version_id() -> str:
    return f"v{int(time.time())}-{secrets.token_hex(3)}"


def extract_complete_html(raw: str) -> dict[str, Any]:
    text = str(raw or "").lstrip("\ufeff")
    starts = [m.start() for m in re.finditer(r"(?i)<!doctype\s+html|<html[\s>]", text)]
    start = min(starts) if starts else -1
    closes = list(re.finditer(r"(?i)</html\s*>", text))
    if start >= 0 and closes:
        end = closes[-1].end()
        return {"html": text[start:end].strip(), "complete": True, "source": "html-document"}
    fence = re.search(r"```(?:html)?\s*([\s\S]*?)```", text, re.I)
    if fence and re.search(r"(?i)<html[\s>]", fence.group(1)) and re.search(r"(?i)</html\s*>", fence.group(1)):
        return {"html": fence.group(1).strip(), "complete": True, "source": "code-fence"}
    return {
        "html": text[start:].strip() if start >= 0 else text.strip(),
        "complete": False,
        "source": "partial",
    }


def _balanced(text: str, open_c: str, close_c: str) -> bool:
    depth = 0
    quote = None
    escaped = False
    line_comment = False
    block_comment = False
    i = 0
    n = len(text)
    while i < n:
        ch = text[i]
        nxt = text[i + 1] if i + 1 < n else ""
        if line_comment:
            if ch == "\n":
                line_comment = False
            i += 1
            continue
        if block_comment:
            if ch == "*" and nxt == "/":
                block_comment = False
                i += 2
                continue
            i += 1
            continue
        if quote:
            if escaped:
                escaped = False
            elif ch == "\\":
                escaped = True
            elif ch == quote:
                quote = None
            i += 1
            continue
        if ch == "/" and nxt == "/":
            line_comment = True
            i += 2
            continue
        if ch == "/" and nxt == "*":
            block_comment = True
            i += 2
            continue
        if ch in "\"'`":
            quote = ch
            i += 1
            continue
        if ch == open_c:
            depth += 1
        elif ch == close_c:
            depth -= 1
            if depth < 0:
                return False
        i += 1
    return depth == 0 and not quote and not block_comment


def validate_html(html: str, complete: bool = True) -> dict[str, Any]:
    results: list[dict[str, Any]] = []
    text = str(html or "")
    results.append(
        {
            "ok": len(text) >= 200,
            "message": f"File contains {len(text):,} characters"
            if len(text) >= 200
            else "Output is suspiciously short",
        }
    )
    results.append(
        {
            "ok": complete,
            "message": "Complete HTML closing tag was captured"
            if complete
            else "Output stopped before a complete </html> document was captured",
        }
    )
    for tag in ("html", "head", "body"):
        opens = len(re.findall(rf"(?i)<{tag}\b", text))
        closes = len(re.findall(rf"(?i)</{tag}\s*>", text))
        ok = opens >= 1 and closes >= 1
        results.append(
            {
                "ok": ok,
                "message": f"<{tag}> structure is present" if ok else f"Missing or incomplete <{tag}> structure",
            }
        )
    results.append(
        {
            "ok": _balanced(text, "{", "}"),
            "message": "Curly braces appear balanced"
            if _balanced(text, "{", "}")
            else "Curly braces appear unbalanced",
        }
    )
    results.append(
        {
            "ok": _balanced(text, "(", ")"),
            "message": "Parentheses appear balanced"
            if _balanced(text, "(", ")")
            else "Parentheses appear unbalanced",
        }
    )
    return {"valid": all(r["ok"] for r in results), "results": results}


def add_version(
    *,
    prompt: str,
    raw_response: str,
    kind: str = "build",
    inspector_report: str = "",
    project_id: str = DEFAULT_PROJECT_ID,
    model: str = "",
) -> dict[str, Any]:
    data = load_project(project_id)
    extraction = extract_complete_html(raw_response)
    validation = validate_html(extraction["html"], extraction["complete"])
    vid = _new_version_id()
    vdir = _project_dir(project_id) / "versions" / vid
    vdir.mkdir(parents=True, exist_ok=True)
    (vdir / "index.html").write_text(extraction["html"], encoding="utf-8")
    (vdir / "PROMPT.txt").write_text(prompt or "", encoding="utf-8")
    (vdir / "RAW_RESPONSE.txt").write_text(raw_response or "", encoding="utf-8")
    run_info = {
        "id": vid,
        "kind": kind,
        "model": model,
        "created_at": _now(),
        "extraction": extraction["source"],
        "complete": extraction["complete"],
        "validation": validation,
        "char_count": len(extraction["html"]),
    }
    (vdir / "RUN_INFO.txt").write_text(json.dumps(run_info, indent=2), encoding="utf-8")
    if inspector_report:
        (vdir / "INSPECTOR_REPORT.txt").write_text(inspector_report, encoding="utf-8")

    meta = {
        "id": vid,
        "kind": kind,
        "model": model,
        "created_at": run_info["created_at"],
        "complete": extraction["complete"],
        "valid": validation["valid"],
        "char_count": len(extraction["html"]),
        "prompt_preview": (prompt or "")[:160],
        "accepted": False,
    }
    data["versions"].insert(0, meta)
    data["active_version_id"] = vid
    save_project(data)
    return {"version": meta, "validation": validation, "project": data}


def version_dir(version_id: str, project_id: str = DEFAULT_PROJECT_ID) -> Path:
    return _project_dir(project_id) / "versions" / version_id


def get_version_html(version_id: str, project_id: str = DEFAULT_PROJECT_ID) -> Optional[str]:
    path = version_dir(version_id, project_id) / "index.html"
    if not path.exists():
        return None
    return path.read_text(encoding="utf-8")


def get_version_detail(version_id: str, project_id: str = DEFAULT_PROJECT_ID) -> Optional[dict[str, Any]]:
    vdir = version_dir(version_id, project_id)
    if not vdir.exists():
        return None
    data = load_project(project_id)
    meta = next((v for v in data["versions"] if v["id"] == version_id), {"id": version_id})
    def _read(name: str) -> str:
        p = vdir / name
        return p.read_text(encoding="utf-8") if p.exists() else ""

    return {
        **meta,
        "html": _read("index.html"),
        "prompt": _read("PROMPT.txt"),
        "raw": _read("RAW_RESPONSE.txt"),
        "run_info": _read("RUN_INFO.txt"),
        "inspector_report": _read("INSPECTOR_REPORT.txt"),
        "accepted": data.get("accepted_version_id") == version_id,
    }


def accept_version(version_id: str, project_id: str = DEFAULT_PROJECT_ID) -> dict[str, Any]:
    data = load_project(project_id)
    if not any(v["id"] == version_id for v in data["versions"]):
        raise FileNotFoundError(f"version {version_id} not found")
    data["accepted_version_id"] = version_id
    data["active_version_id"] = version_id
    for v in data["versions"]:
        v["accepted"] = v["id"] == version_id
    return save_project(data)


def delete_version(version_id: str, project_id: str = DEFAULT_PROJECT_ID) -> dict[str, Any]:
    import shutil

    data = load_project(project_id)
    data["versions"] = [v for v in data["versions"] if v["id"] != version_id]
    if data.get("active_version_id") == version_id:
        data["active_version_id"] = data["versions"][0]["id"] if data["versions"] else None
    if data.get("accepted_version_id") == version_id:
        data["accepted_version_id"] = None
    vdir = version_dir(version_id, project_id)
    if vdir.exists():
        shutil.rmtree(vdir, ignore_errors=True)
    return save_project(data)


def baseline_html(project_id: str = DEFAULT_PROJECT_ID) -> str:
    """Accepted version if any, else active, else empty."""
    data = load_project(project_id)
    vid = data.get("accepted_version_id") or data.get("active_version_id")
    if not vid:
        return ""
    return get_version_html(vid, project_id) or ""
