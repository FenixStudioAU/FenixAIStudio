"""Load ComfyUI API workflow templates and inject parameters."""
from __future__ import annotations

import copy
import json
import random
from pathlib import Path
from typing import Any, Optional

from .config import settings
from .logging_setup import log
from .models_detect import MODEL_CATALOG, inventory, resolve_model_files
from .schemas import ImageSettings, LoraWeight, VideoSettings


def _load_template(name: str) -> dict[str, Any]:
    path = settings.workflows_dir / name
    if not path.exists():
        raise FileNotFoundError(f"Workflow template missing: {path}")
    with open(path, "r", encoding="utf-8") as f:
        return json.load(f)


def _set_input(prompt: dict, node_id: str, key: str, value: Any) -> None:
    if node_id not in prompt:
        raise KeyError(f"Node {node_id} not in workflow")
    prompt[node_id].setdefault("inputs", {})[key] = value


def _random_seed(seed: int) -> int:
    if seed is None or seed < 0:
        return random.randint(0, 2**32 - 1)
    return int(seed)


async def build_image_workflow(
    settings_img: ImageSettings,
    filename_prefix: str = "amvs/image",
    image_name: str | None = None,
    reference_comfy_names: list[str] | None = None,
) -> dict[str, Any]:
    inv = await inventory()
    model_id = settings_img.model_id or "flux2-klein-4b"
    resolved = resolve_model_files(model_id, inv)
    meta = MODEL_CATALOG.get(model_id, MODEL_CATALOG["flux2-klein-4b"])

    # Never fall back to Wan2GP *quanto* names — they crash Comfy (meta tensor).
    def _is_bad(n: str) -> bool:
        nl = n.lower()
        return "quanto" in nl or "mbf16_int8" in nl

    if "diffusion_models" not in resolved:
        for name in inv.get("diffusion_models", []):
            if _is_bad(name):
                continue
            if "flux" in name.lower() and "klein" in name.lower() and "4b" in name.lower():
                resolved["diffusion_models"] = name
                break
        if "diffusion_models" not in resolved:
            for name in inv.get("diffusion_models", []):
                if _is_bad(name):
                    continue
                if "flux-2-klein" in name.lower() or "flux2-klein" in name.lower():
                    resolved["diffusion_models"] = name
                    break
    if "vae" not in resolved:
        for name in inv.get("vae", []):
            if _is_bad(name):
                continue
            bn = name.replace("\\", "/").split("/")[-1].lower()
            if bn in ("flux2-vae.safetensors", "flux2_vae.safetensors"):
                resolved["vae"] = name
                break
    if "text_encoders" not in resolved:
        for name in inv.get("text_encoders", []) + inv.get("clip", []):
            if _is_bad(name):
                continue
            bn = name.replace("\\", "/").split("/")[-1].lower()
            if "qwen_3_4b" in bn or "qwen3_4b" in bn:
                resolved["text_encoders"] = name
                break
            if "qwen_3_8b" in bn or "qwen3_8b" in bn:
                resolved["text_encoders"] = name
                break

    missing = [k for k in ("diffusion_models", "text_encoders", "vae") if k not in resolved]
    if missing:
        raise RuntimeError(
            f"Image model '{model_id}' is not fully installed (Comfy-native weights only). "
            f"Missing: {missing}. "
            f"Download from https://huggingface.co/Comfy-Org/flux2-klein-4B into "
            f"ComfyUI/models/diffusion_models, text_encoders, vae. "
            f"Wan2GP quanto files are ignored on purpose."
        )
    for k, v in resolved.items():
        if _is_bad(v):
            raise RuntimeError(
                f"Refusing to load Wan2GP/quanto weight for {k}: {v}. "
                f"Install Comfy-native FLUX.2 Klein 4B instead."
            )

    use_lora = any(l.enabled and l.name for l in settings_img.loras)
    template_name = "flux2_klein_t2i_lora.json" if use_lora else "flux2_klein_t2i.json"
    prompt = copy.deepcopy(_load_template(template_name))

    # Normalize reference list: strings or {name, label, category}
    refs: list[dict[str, str]] = []
    for r in reference_comfy_names or []:
        if isinstance(r, str) and r.strip():
            refs.append({"name": r.strip(), "label": "", "category": ""})
        elif isinstance(r, dict) and r.get("name"):
            refs.append(
                {
                    "name": str(r["name"]),
                    "label": str(r.get("label") or ""),
                    "category": str(r.get("category") or ""),
                }
            )
    refs = refs[:6]  # Flux.2 can take multiple; keep GPU-friendly

    seed = _random_seed(settings_img.seed)
    pos_text = settings_img.positive_prompt or "cinematic still, high detail"
    neg_text = settings_img.negative_prompt or ""
    # No-character-refs mode: never force cast likeness via character ref images.
    # Generic people in the text prompt ("a man on the beach") remain allowed.
    if getattr(settings_img, "strict_named_characters_only", False):
        refs = [
            r
            for r in refs
            if (r.get("category") or "character").strip().lower()
            in ("location", "environment", "style")
        ]
    if refs:
        # Flux.2 / Klein: chained ReferenceLatent = image 1, image 2, … (same as Comfy UI)
        bits = []
        for i, r in enumerate(refs, 1):
            label = (r.get("label") or f"reference {i}").strip() or f"reference {i}"
            cat = (r.get("category") or "character").strip().lower()
            if cat in ("location", "environment"):
                bits.append(
                    f"image {i} is {label}, the environment/location reference — "
                    f"match setting, lighting and atmosphere from image {i}"
                )
            elif cat == "style":
                bits.append(
                    f"image {i} is the style reference for {label} — "
                    f"match look, palette and rendering from image {i}"
                )
            else:
                bits.append(
                    f"image {i} is {label} — use their exact face, hair, body type "
                    f"and identity from image {i}"
                )
        pos_text = (
            pos_text.rstrip(". ")
            + ". "
            + " ".join(bits)
            + ". Keep each named subject consistent with their numbered reference image."
        )

    _set_input(prompt, "1", "unet_name", resolved["diffusion_models"])
    _set_input(prompt, "2", "clip_name", resolved["text_encoders"])
    _set_input(prompt, "2", "type", meta.get("clip_type", "flux2"))
    _set_input(prompt, "3", "vae_name", resolved["vae"])
    _set_input(prompt, "4", "width", int(settings_img.width))
    _set_input(prompt, "4", "height", int(settings_img.height))
    _set_input(prompt, "5", "text", pos_text)
    _set_input(prompt, "6", "text", neg_text or "")
    _set_input(prompt, "8", "seed", seed)
    _set_input(prompt, "8", "steps", int(settings_img.steps))
    # cfg 1.0 is standard for distilled Flux; keep guidance on FluxGuidance
    _set_input(prompt, "8", "cfg", 1.0)
    _set_input(prompt, "10", "filename_prefix", filename_prefix)

    if "7" in prompt and prompt["7"].get("class_type") == "FluxGuidance":
        _set_input(prompt, "7", "guidance", max(float(settings_img.cfg), 1.0))

    model_src: list[Any] = ["1", 0]
    clip_src: list[Any] = ["2", 0]

    if use_lora:
        enabled = [l for l in settings_img.loras if l.enabled and l.name][:3]
        lora_nodes = ["20", "21", "22"]
        for i, node_id in enumerate(lora_nodes):
            if node_id not in prompt:
                break
            if i < len(enabled):
                lw = enabled[i]
                _set_input(prompt, node_id, "lora_name", lw.name)
                _set_input(prompt, node_id, "strength_model", float(lw.strength_model))
                _set_input(prompt, node_id, "strength_clip", float(lw.strength_clip))
                prompt[node_id]["inputs"]["model"] = model_src
                prompt[node_id]["inputs"]["clip"] = clip_src
                model_src = [node_id, 0]
                clip_src = [node_id, 1]
            else:
                del prompt[node_id]
        prompt["5"]["inputs"]["clip"] = clip_src
        prompt["6"]["inputs"]["clip"] = clip_src
        prompt["8"]["inputs"]["model"] = model_src

    # Positive starts at FluxGuidance (7); negative at empty CLIP encode (6)
    pos_cond: list[Any] = ["7", 0]
    neg_cond: list[Any] = ["6", 0]

    # Multi-reference: LoadImage → scale → VAEEncode → ReferenceLatent (chain)
    # Order matters: first ref = image 1, second = image 2, …
    for i, r in enumerate(refs):
        base = 100 + i * 10
        load_id = str(base)
        scale_id = str(base + 1)
        enc_id = str(base + 2)
        ref_pos_id = str(base + 3)
        ref_neg_id = str(base + 4)

        prompt[load_id] = {
            "class_type": "LoadImage",
            "inputs": {"image": r["name"]},
        }
        # Cap reference tokens for VRAM while keeping identity detail
        prompt[scale_id] = {
            "class_type": "ImageScaleToTotalPixels",
            "inputs": {
                "image": [load_id, 0],
                "upscale_method": "lanczos",
                "megapixels": 1.0,
                "resolution_steps": 1,
            },
        }
        prompt[enc_id] = {
            "class_type": "VAEEncode",
            "inputs": {
                "pixels": [scale_id, 0],
                "vae": ["3", 0],
            },
        }
        prompt[ref_pos_id] = {
            "class_type": "ReferenceLatent",
            "inputs": {
                "conditioning": pos_cond,
                "latent": [enc_id, 0],
            },
        }
        prompt[ref_neg_id] = {
            "class_type": "ReferenceLatent",
            "inputs": {
                "conditioning": neg_cond,
                "latent": [enc_id, 0],
            },
        }
        pos_cond = [ref_pos_id, 0]
        neg_cond = [ref_neg_id, 0]

    if refs:
        # Tell edit/ref path how to index multi latents (Flux.2)
        prompt["90"] = {
            "class_type": "FluxKontextMultiReferenceLatentMethod",
            "inputs": {
                "conditioning": pos_cond,
                "reference_latents_method": "index",
            },
        }
        pos_cond = ["90", 0]
        log.info(
            "Flux2 multi-ref: %s",
            ", ".join(f"image{i+1}={r.get('label') or r['name']}" for i, r in enumerate(refs)),
        )

    prompt["8"]["inputs"]["positive"] = pos_cond
    prompt["8"]["inputs"]["negative"] = neg_cond
    prompt["8"]["inputs"]["model"] = model_src

    log.info(
        "Built image workflow model=%s seed=%s %sx%s refs=%d",
        model_id,
        seed,
        settings_img.width,
        settings_img.height,
        len(refs),
    )
    return prompt


def _resolve_turbo_lora(inv: dict[str, list[str]]) -> str | None:
    """Pick best available MiniMax FastLoRA (pruned ComfyUI format)."""
    preferred = [
        "minimax_h3_turbo_4step_ckpt850_pruned_comfyui.safetensors",
        "minimax_h3_turbo_4step_ckpt500_pruned_comfyui.safetensors",
        "minimax_h3_turbo_4step_pruned_comfyui.safetensors",
        "minimax_h3_turbo_4step_ema_ckpt850_pruned_comfyui.safetensors",
        "minimax_h3_turbo_4step_ema_ckpt500_pruned_comfyui.safetensors",
        "minimax_h3_turbo_4step_ema_pruned_comfyui.safetensors",
    ]
    loras = inv.get("loras") or []
    lower_map = {n.lower().replace("\\", "/").split("/")[-1]: n for n in loras}
    for p in preferred:
        if p.lower() in lower_map:
            return lower_map[p.lower()]
    # Any turbo/fast minimax lora
    for n in loras:
        bn = n.lower().replace("\\", "/").split("/")[-1]
        if "minimax" in bn and ("turbo" in bn or "4step" in bn or "fast" in bn):
            return n
    return None


def _host_vram_gb() -> float:
    try:
        from .models_detect import get_vram_gb

        return float(get_vram_gb() or 0)
    except Exception:
        return 0.0


def turbo_allowed_for_vram(vram_gb: float | None = None) -> bool:
    """Whether FastLoRA turbo may be used.

    Only blocked when the user enables Settings → Optimise for low VRAM.
    (A previous hard ban for all cards under 12 GB forced 12-step non-turbo
    on 8 GB machines and made every video ~3× slower than turbo 4-step.)
    """
    try:
        from . import app_settings_store

        if app_settings_store.load_user_settings().get("optimize_low_vram"):
            return False
    except Exception:
        pass
    return True


def _resolve_audio_vae(inv: dict[str, list[str]]) -> str | None:
    vaes = inv.get("vae") or []
    preferred = [
        "minimax_h3_audio_vae_fp32.safetensors",
        "minimax_h3_audio_vae.safetensors",
    ]
    lower = {n.lower().replace("\\", "/").split("/")[-1]: n for n in vaes}
    for p in preferred:
        if p.lower() in lower:
            return lower[p.lower()]
    for n in vaes:
        bn = n.lower().replace("\\", "/").split("/")[-1]
        if "minimax" in bn and "audio" in bn:
            return n
    return None


async def build_video_workflow(
    settings_vid: VideoSettings,
    image_comfy_name: str,
    filename_prefix: str = "amvs/video",
) -> dict[str, Any]:
    inv = await inventory()
    preset = settings_vid.preset_id or "minimax-h3-i2v"
    use_turbo = "turbo" in preset.lower() or "fastlora" in preset.lower()
    vram = _host_vram_gb()

    # Only drop turbo when Settings → Optimise for low VRAM is on
    if use_turbo and not turbo_allowed_for_vram(vram):
        log.warning(
            "FastLoRA/turbo disabled (optimize_low_vram is on) — using standard MiniMax I2V"
        )
        use_turbo = False
        preset = "minimax-h3-i2v"

    if preset.startswith("minimax") or "minimax" in (settings_vid.preset_id or ""):
        template = "minimax_h3_i2v_turbo.json" if use_turbo else "minimax_h3_i2v.json"
        try:
            prompt = copy.deepcopy(_load_template(template))
        except FileNotFoundError:
            if use_turbo:
                prompt = copy.deepcopy(_load_template("minimax_h3_i2v.json"))
                use_turbo = False
            else:
                raise

        catalog_id = "minimax-h3-i2v-turbo" if use_turbo else "minimax-h3-i2v"
        resolved = resolve_model_files("minimax-h3-i2v", inv)
        if "diffusion_models" not in resolved:
            dm = inv.get("diffusion_models") or []
            if not dm:
                raise RuntimeError("No MiniMax / diffusion video model found in ComfyUI.")
            resolved["diffusion_models"] = dm[0]
        if "text_encoders" not in resolved:
            te = inv.get("text_encoders") or []
            if not te:
                raise RuntimeError("No MiniMax text encoder found.")
            resolved["text_encoders"] = te[0]
        if "vae" not in resolved:
            vaes = inv.get("vae") or []
            video_vae = next(
                (
                    v
                    for v in vaes
                    if "video" in v.lower() and "minimax" in v.lower()
                ),
                None,
            ) or next((v for v in vaes if "minimax" in v.lower() and "audio" not in v.lower()), None)
            if not video_vae:
                raise RuntimeError("No MiniMax video VAE found.")
            resolved["vae"] = video_vae

        audio_vae = _resolve_audio_vae(inv)
        if not audio_vae:
            log.warning(
                "MiniMax audio VAE not found (minimax_h3_audio_vae_fp32.safetensors). "
                "Clips will be silent until it is installed in ComfyUI/models/vae/."
            )

        turbo_lora = _resolve_turbo_lora(inv) if use_turbo else None
        if use_turbo and not turbo_lora:
            log.warning("Turbo requested but FastLoRA missing — falling back to standard I2V")
            use_turbo = False
            catalog_id = "minimax-h3-i2v"
            prompt = copy.deepcopy(_load_template("minimax_h3_i2v.json"))

        # Frame length at 24fps, snap UP to MiniMax 17k+5 grid (same as Comfy template math).
        # Max 15s per clip (model can go ~20s; we cap for stability on consumer GPUs).
        MAX_CLIP_SEC = 15.0
        fps = max(1, int(settings_vid.fps or 24))
        dur_sec = float(settings_vid.duration_sec or 5.0)
        if dur_sec <= 0:
            dur_sec = 5.0
        if dur_sec > MAX_CLIP_SEC:
            log.warning("Video duration %.2fs clamped to %.0fs max", dur_sec, MAX_CLIP_SEC)
            dur_sec = MAX_CLIP_SEC
        settings_vid.duration_sec = dur_sec
        # Official: max(5, round(sec*24)) then pad so (length - 5) % 17 == 0
        frames = max(5, int(round(dur_sec * fps)))
        rem = (frames - 5) % 17
        if rem != 0:
            frames = frames + (17 - rem)
        # Hard safety: 15s * 24fps = 360 → snap to 5+17*21 = 362
        max_frames = 5 + 17 * int((MAX_CLIP_SEC * fps - 5) // 17)
        length = min(frames, max(5, max_frames))
        low_vram = False
        try:
            from . import app_settings_store

            low_vram = bool(app_settings_store.load_user_settings().get("optimize_low_vram"))
        except Exception:
            pass
        # Only force low-res draft sizes when user opts in (not auto by VRAM alone)
        # Auto low_vram under 12GB previously overrode draft sizes constantly.

        if use_turbo:
            if settings_vid.quality == "draft":
                steps = 4
                width = min(settings_vid.width, 640)
                height = min(settings_vid.height, 368)
            else:
                steps = 8
                width = max(32, (int(settings_vid.width) // 32) * 32)
                height = max(32, (int(settings_vid.height) // 32) * 32)
            width = max(32, (width // 32) * 32)
            height = max(32, (height // 32) * 32)
            shift_video = 12.0
            shift_audio = 5.0
            sampler_name = "res_multistep"
            lora_strength = 1.2
        elif settings_vid.quality == "draft":
            steps = 12
            # Keep draft modest on 8–11 GB without thrashing extreme tiny sizes
            width = min(settings_vid.width, 640 if low_vram else 768)
            height = min(settings_vid.height, 368 if low_vram else 432)
            width = max(32, (width // 32) * 32)
            height = max(32, (height // 32) * 32)
            shift_video = 3.0 + float(settings_vid.motion_strength) * 2.0
            shift_audio = 3.0
            sampler_name = "euler"
            lora_strength = 1.0
        else:
            steps = 20
            # Final: prefer model-native-ish 16:9; avoid 1152 on <12GB (VRAM thrash)
            if low_vram:
                fw, fh = 768, 432
            else:
                fw = int(settings_vid.width) or 768
                fh = int(settings_vid.height) or 432
            width = max(32, (fw // 32) * 32)
            height = max(32, (fh // 32) * 32)
            shift_video = 3.0 + float(settings_vid.motion_strength) * 2.0
            shift_audio = 3.0
            sampler_name = "euler"
            lora_strength = 1.0

        seed = _random_seed(settings_vid.seed)
        anim = settings_vid.animation_prompt or "subtle cinematic motion, natural ambient sound"
        # Encourage native MiniMax audio in the motion prompt
        if "audio" not in anim.lower() and "sound" not in anim.lower() and "sfx" not in anim.lower():
            anim = f"{anim.rstrip('.')}. Soft natural ambient audio matching the scene"
        if settings_vid.camera_movement and settings_vid.camera_movement != "none":
            anim = f"{anim}, camera: {settings_vid.camera_movement}"

        _set_input(prompt, "1", "unet_name", resolved["diffusion_models"])
        _set_input(prompt, "2", "clip_name", resolved["text_encoders"])
        _set_input(prompt, "2", "type", "minimax")
        _set_input(prompt, "3", "vae_name", resolved["vae"])
        if audio_vae and "13" in prompt:
            _set_input(prompt, "13", "vae_name", audio_vae)
        elif not audio_vae and "13" in prompt:
            # Drop audio decode path so Comfy doesn't fail missing VAE
            prompt.pop("13", None)
            prompt.pop("14", None)
            if "10" in prompt and "audio" in prompt["10"].get("inputs", {}):
                del prompt["10"]["inputs"]["audio"]
        _set_input(prompt, "4", "image", image_comfy_name)
        _set_input(prompt, "5", "prompt", anim)
        _set_input(prompt, "5", "width", width)
        _set_input(prompt, "5", "height", height)
        _set_input(prompt, "5", "length", length)
        _set_input(prompt, "6", "shift_video", shift_video)
        if "shift_audio" in prompt.get("6", {}).get("inputs", {}):
            _set_input(prompt, "6", "shift_audio", shift_audio)
        _set_input(prompt, "8", "seed", seed)
        _set_input(prompt, "8", "steps", steps)
        _set_input(prompt, "8", "sampler_name", sampler_name)
        _set_input(prompt, "10", "fps", fps)
        _set_input(prompt, "11", "filename_prefix", filename_prefix)

        if use_turbo and turbo_lora and "12" in prompt:
            _set_input(prompt, "12", "lora_name", turbo_lora)
            _set_input(prompt, "12", "strength_model", lora_strength)
            prompt["12"]["inputs"]["model"] = ["1", 0]
            prompt["6"]["inputs"]["model"] = ["12", 0]
            log.info(
                "MiniMax turbo FastLoRA=%s strength=%.2f steps=%d shift_v=%.1f",
                turbo_lora,
                lora_strength,
                steps,
                shift_video,
            )
        elif not use_turbo and "12" in prompt:
            # Standard path: no LoRA node
            prompt.pop("12", None)
            prompt["6"]["inputs"]["model"] = ["1", 0]

        log.info(
            "Built video workflow preset=%s turbo=%s audio_vae=%s %sx%s length=%d (%.2fs@%dfps) steps=%d vram=%.1f",
            catalog_id,
            use_turbo,
            bool(audio_vae),
            width,
            height,
            length,
            length / float(fps),
            fps,
            steps,
            vram,
        )
        return prompt

    raise RuntimeError(f"Unknown video preset: {preset}")


def list_video_presets() -> list[dict[str, Any]]:
    path = settings.workflows_dir / "presets.json"
    if path.exists():
        with open(path, "r", encoding="utf-8") as f:
            presets = json.load(f).get("video_presets", [])
    else:
        presets = [
            {
                "id": "minimax-h3-i2v",
                "label": "MiniMax H3 Image-to-Video",
                "controls": [
                    "animation_prompt",
                    "duration",
                    "fps",
                    "motion_strength",
                    "camera_movement",
                    "seed",
                    "resolution",
                    "quality",
                ],
            }
        ]
    # Hide FastLoRA turbo option under 12 GB so users can't pick a thrash path
    if not turbo_allowed_for_vram():
        presets = [
            p
            for p in presets
            if "turbo" not in str(p.get("id", "")).lower()
            and "fastlora" not in str(p.get("label", "")).lower()
        ]
    return presets
