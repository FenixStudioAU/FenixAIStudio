"""Runtime user settings (LAN Comfy/Ollama URLs) — no hardcoded machine paths required at runtime."""
from __future__ import annotations

import json
from pathlib import Path
from typing import Any

from .config import ROOT, settings
from .logging_setup import log

SETTINGS_PATH = ROOT / "settings" / "user_settings.json"

DEFAULTS: dict[str, Any] = {
    "comfy_url": "http://127.0.0.1:8188",
    "ollama_url": "http://127.0.0.1:11434",
    "comfy_install_path": "",
    "comfy_start_script": "",
    "studio_port": 7865,
    # Studio chat (separate from story wizard models)
    "chat_model": "",
    "coder_designer_model": "",
    "coder_model": "",
    "coder_repair_model": "",
    # Low VRAM mode: filter chat/coder models ≤6GB, smaller draft frames, final 1152×646
    "optimize_low_vram": False,
    "onboarding_complete": False,
}


def load_user_settings() -> dict[str, Any]:
    data = dict(DEFAULTS)
    if SETTINGS_PATH.exists():
        try:
            raw = json.loads(SETTINGS_PATH.read_text(encoding="utf-8-sig"))
            if isinstance(raw, dict):
                data.update({k: v for k, v in raw.items() if k in DEFAULTS or k in raw})
        except Exception as e:
            log.warning("user_settings load failed: %s", e)
    return data


def save_user_settings(patch: dict[str, Any]) -> dict[str, Any]:
    data = load_user_settings()
    for k, v in patch.items():
        if v is None:
            continue
        data[k] = v
    SETTINGS_PATH.parent.mkdir(parents=True, exist_ok=True)
    SETTINGS_PATH.write_text(json.dumps(data, indent=2), encoding="utf-8")
    apply_user_settings(data)
    return data


def apply_user_settings(data: dict[str, Any] | None = None) -> None:
    """Push settings into live config + clients."""
    data = data or load_user_settings()
    comfy = (data.get("comfy_url") or DEFAULTS["comfy_url"]).rstrip("/")
    ollama = (data.get("ollama_url") or DEFAULTS["ollama_url"]).rstrip("/")
    settings.comfy_url = comfy
    settings.ollama_url = ollama
    if data.get("comfy_install_path"):
        settings.comfy_install = Path(str(data["comfy_install_path"]))
    if data.get("comfy_start_script"):
        settings.comfy_start_script = Path(str(data["comfy_start_script"]))
    try:
        from .comfyui_client import comfy as comfy_client

        comfy_client.base_url = comfy
        # force client rebuild on next call
        if hasattr(comfy_client, "_http") and comfy_client._http is not None:
            # leave open; next request uses new base if recreated
            pass
        if hasattr(comfy_client, "close"):
            # recreate lazily
            import asyncio

            try:
                loop = asyncio.get_event_loop()
                if loop.is_running():
                    loop.create_task(comfy_client.close())
                else:
                    loop.run_until_complete(comfy_client.close())
            except Exception:
                comfy_client._http = None
    except Exception as e:
        log.debug("comfy client rebind skip: %s", e)
    log.info("Applied user settings comfy=%s ollama=%s", comfy, ollama)
