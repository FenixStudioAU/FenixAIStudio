"""Background generation jobs with progress tracking."""
from __future__ import annotations

import asyncio
import shutil
import traceback
from dataclasses import dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Optional
from uuid import uuid4

from PIL import Image

from .comfyui_client import comfy
from .logging_setup import log
from .project_store import abs_path, load_project, project_dir, rel_to_project, save_project
from .schemas import GenStatus, ImageSettings, VideoSettings
from .workflow_engine import build_image_workflow, build_video_workflow

jobs_log = __import__("logging").getLogger("amvs.jobs")


@dataclass
class Job:
    id: str
    project_id: str
    shot_id: str
    kind: str  # image | video
    status: str = "queued"
    progress: float = 0.0
    message: str = ""
    error: Optional[str] = None
    result_paths: list[str] = field(default_factory=list)
    created_at: str = field(default_factory=lambda: datetime.now(timezone.utc).isoformat())
    prompt_id: Optional[str] = None


class JobManager:
    def __init__(self) -> None:
        self.jobs: dict[str, Job] = {}
        self._queue: asyncio.Queue[str] = asyncio.Queue()
        self._worker_task: Optional[asyncio.Task] = None
        self._cancel: set[str] = set()

    def start(self) -> None:
        if self._worker_task is None or self._worker_task.done():
            self._worker_task = asyncio.create_task(self._worker())

    def get(self, job_id: str) -> Optional[Job]:
        return self.jobs.get(job_id)

    def list_jobs(self, project_id: str | None = None) -> list[dict[str, Any]]:
        items = list(self.jobs.values())
        if project_id:
            items = [j for j in items if j.project_id == project_id]
        return [j.__dict__ for j in sorted(items, key=lambda x: x.created_at, reverse=True)[:100]]

    def cancel(self, job_id: str) -> None:
        self._cancel.add(job_id)
        j = self.jobs.get(job_id)
        if j and j.status in ("queued", "running"):
            j.status = "cancelled"
            j.message = "Cancelled"
            asyncio.create_task(comfy.interrupt())

    async def enqueue_image(
        self, project_id: str, shot_id: str, settings_img: ImageSettings | None = None
    ) -> Job:
        job = Job(id=uuid4().hex[:12], project_id=project_id, shot_id=shot_id, kind="image")
        self.jobs[job.id] = job
        # stash settings on job via message field temporarily — store on object
        job._settings = settings_img  # type: ignore[attr-defined]
        await self._queue.put(job.id)
        self.start()
        return job

    async def enqueue_video(
        self, project_id: str, shot_id: str, settings_vid: VideoSettings | None = None
    ) -> Job:
        job = Job(id=uuid4().hex[:12], project_id=project_id, shot_id=shot_id, kind="video")
        self.jobs[job.id] = job
        job._settings = settings_vid  # type: ignore[attr-defined]
        await self._queue.put(job.id)
        self.start()
        return job

    async def _worker(self) -> None:
        while True:
            job_id = await self._queue.get()
            job = self.jobs.get(job_id)
            if not job or job_id in self._cancel:
                self._queue.task_done()
                continue
            try:
                job.status = "running"
                job.message = "Starting"
                if job.kind == "image":
                    await self._run_image(job)
                else:
                    await self._run_video(job)
                if job.status != "cancelled":
                    job.status = "done"
                    job.progress = 1.0
                    job.message = "Complete"
            except Exception as e:
                job.status = "error"
                job.error = str(e)
                job.message = "Error"
                jobs_log.error("Job %s failed: %s\n%s", job.id, e, traceback.format_exc())
                try:
                    proj = load_project(job.project_id)
                    shot = next((s for s in proj.timeline.shots if s.id == job.shot_id), None)
                    if shot:
                        if job.kind == "image":
                            shot.image_status = GenStatus.error
                        else:
                            shot.video_status = GenStatus.error
                        shot.last_error = str(e)[:500]
                        save_project(proj)
                except Exception:
                    pass
            finally:
                self._queue.task_done()

    async def _run_image(self, job: Job) -> None:
        proj = load_project(job.project_id)
        shot = next((s for s in proj.timeline.shots if s.id == job.shot_id), None)
        if not shot:
            raise RuntimeError("Shot not found")
        settings_img = getattr(job, "_settings", None) or shot.image
        shot.image = settings_img
        shot.image_status = GenStatus.running
        save_project(proj)

        # Resolve reference images for Flux.2 multi-ref (image 1, image 2, …)
        # 1) explicit IDs on the shot  2) auto-match library names mentioned in the prompt
        selected_refs = _select_references_for_shot(proj, settings_img)
        if selected_refs:
            settings_img.reference_ids = [r.id for r in selected_refs]
            shot.image.reference_ids = list(settings_img.reference_ids)
            jobs_log.info(
                "Refs for shot %s: %s",
                job.shot_id,
                ", ".join(f"{r.name!r}[{getattr(r, 'category', '')}]" for r in selected_refs),
            )
            try:
                save_project(proj)
            except Exception:
                pass
        else:
            jobs_log.warning(
                "No reference images for shot %s (prompt has names but no library match, "
                "or library empty). Flux will run text-only.",
                job.shot_id,
            )

        ref_payload: list[dict] = []
        for ref in selected_refs:
            rp = abs_path(job.project_id, ref.path)
            if not rp or not rp.exists():
                jobs_log.warning("Missing reference file %s (%s)", ref.name, ref.path)
                continue
            up = await comfy.upload_image(rp, subfolder=f"amvs/{job.project_id}/refs")
            name = up.get("name") or up.get("filename") or rp.name
            sub = (up.get("subfolder") or "").replace("\\", "/")
            comfy_name = f"{sub}/{name}".strip("/") if sub else name
            label = (ref.name or Path(rp).stem or "").strip()
            ref_payload.append(
                {
                    "name": comfy_name,
                    "label": label,
                    "category": (getattr(ref, "category", None) or "character").strip(),
                }
            )
            jobs_log.info("Uploaded ref %s -> %s", label, comfy_name)

        if selected_refs and not ref_payload:
            raise RuntimeError(
                "Character/location references are selected but their image files are missing. "
                "Re-add them under References."
            )

        prefix = f"amvs/{job.project_id}/img_{job.shot_id}"
        results: list[str] = []
        count = max(1, min(4, int(settings_img.batch_count or 1)))
        ref_names = ", ".join(r["label"] for r in ref_payload) or "none"
        for b in range(count):
            if job.id in self._cancel:
                job.status = "cancelled"
                return
            job.message = (
                f"Generating image {b+1}/{count}"
                + (f" (refs: {ref_names})" if ref_payload else " (no refs)")
            )
            job.progress = b / count
            s = settings_img.model_copy()
            if b > 0:
                s.seed = -1
            # No character refs: strip any character-like refs from the payload for this shot
            if getattr(s, "strict_named_characters_only", False):
                ref_payload = [
                    r
                    for r in (ref_payload or [])
                    if (r.get("category") or "character").strip().lower()
                    in ("location", "environment", "style")
                ]
            prompt = await build_image_workflow(
                s, filename_prefix=f"{prefix}_{b}", reference_comfy_names=ref_payload
            )
            prompt_id = await comfy.queue_prompt(prompt)
            job.prompt_id = prompt_id
            jobs_log.info("Image job %s prompt_id=%s shot=%s", job.id, prompt_id, job.shot_id)

            job.message = f"Image {b+1}/{count}: waiting for Comfy…"
            job.progress = min(0.5, job.progress + 0.05)

            # Poll history ourselves with progress bumps (no websocket)
            hist = await comfy.wait_for_prompt(prompt_id, on_progress=None)
            job.progress = 0.95
            job.message = f"Image {b+1}/{count}: importing from disk…"

            images = comfy.extract_output_images(hist)
            scanned = _scan_comfy_output_for_prefix(prefix)
            by_name: dict[str, dict] = {}
            for im in images + scanned:
                fn = im.get("filename") or ""
                if fn and im.get("kind") != "video":
                    by_name[fn] = im
            if not by_name:
                # Broader scan: any new file for this shot under amvs/project
                scanned2 = _scan_comfy_output_for_prefix(
                    f"amvs/{job.project_id}/img_{job.shot_id}"
                )
                for im in scanned2:
                    fn = im.get("filename") or ""
                    if fn:
                        by_name[fn] = im
            if not by_name:
                raise RuntimeError(
                    f"Comfy finished but no image files found for {prefix}. "
                    f"Check ComfyUI/output/amvs/{job.project_id}/"
                )

            dest_dir = project_dir(job.project_id) / "images" / "generated"
            dest_dir.mkdir(parents=True, exist_ok=True)
            from .config import settings as _settings

            # Prefer newest file first
            ordered = sorted(
                by_name.values(),
                key=lambda im: Path(im["local_path"]).stat().st_mtime
                if im.get("local_path") and Path(im["local_path"]).is_file()
                else 0,
                reverse=True,
            )
            for im in ordered:
                fn = im.get("filename") or ""
                dest = dest_dir / f"{job.shot_id}_{b}_{Path(fn).name}"
                copied = False
                # 1) local_path from scan
                lp = im.get("local_path")
                if lp and Path(lp).is_file():
                    shutil.copy2(lp, dest)
                    copied = True
                # 2) comfy output path
                if not copied:
                    sub = (im.get("subfolder") or "").replace("\\", "/")
                    fs = (
                        _settings.comfy_install / "output" / sub / fn
                        if sub
                        else _settings.comfy_install / "output" / fn
                    )
                    if fs.is_file():
                        shutil.copy2(fs, dest)
                        copied = True
                # 3) API last resort (short timeout client-side)
                if not copied:
                    try:
                        await asyncio.wait_for(
                            comfy.download_view(
                                fn, im.get("subfolder", ""), im.get("type", "output"), dest
                            ),
                            timeout=30.0,
                        )
                        copied = dest.is_file()
                    except Exception as e:
                        jobs_log.warning("download_view failed for %s: %s", fn, e)
                if not dest.is_file() or dest.stat().st_size < 100:
                    jobs_log.warning("Skip bad import %s", fn)
                    continue
                rel = rel_to_project(job.project_id, dest)
                results.append(rel)
                thumb = project_dir(job.project_id) / "thumbnails" / f"{job.shot_id}.jpg"
                try:
                    _make_thumb(dest, thumb)
                    shot.thumbnail_path = rel_to_project(job.project_id, thumb)
                except Exception as e:
                    jobs_log.warning("thumb failed: %s", e)
                    shot.thumbnail_path = rel  # use full image as thumb fallback
                jobs_log.info("Imported image %s -> %s", fn, rel)
                break  # one good image is enough for this batch slot

        if not results:
            raise RuntimeError("No image files were imported into the project")
        shot.image_alternatives = results
        shot.image_path = results[0]
        shot.image_status = GenStatus.ready
        shot.last_error = None
        # New still invalidates old animation — clear video so export/play use the new image
        shot.video_path = None
        shot.draft_video_path = None
        shot.video_alternatives = []
        shot.video_status = GenStatus.empty
        job.result_paths = results
        job.progress = 1.0
        job.message = "Saving to project"
        _update_shot_image(job.project_id, shot, clear_video=True)
        jobs_log.info(
            "Image job %s DONE shot=%s path=%s (video cleared)",
            job.id,
            job.shot_id,
            shot.image_path,
        )

    async def _run_video(self, job: Job) -> None:
        proj = load_project(job.project_id)
        shot = next((s for s in proj.timeline.shots if s.id == job.shot_id), None)
        if not shot:
            raise RuntimeError("Shot not found")
        settings_vid = getattr(job, "_settings", None) or shot.video
        # Timeline slot length is source of truth; MiniMax H3 hard-cap at 15s per clip
        MAX_CLIP_SEC = 15.0
        dur = float(shot.duration or 0) or float(getattr(settings_vid, "duration_sec", 0) or 0) or 5.0
        if dur > MAX_CLIP_SEC:
            jobs_log.warning(
                "Video job %s: shot duration %.2fs > %.0fs max — clamping for MiniMax",
                job.id,
                dur,
                MAX_CLIP_SEC,
            )
            dur = MAX_CLIP_SEC
        dur = max(0.5, dur)
        settings_vid.duration_sec = dur
        # Keep timeline slot in sync so UI matches what we send to Comfy
        if abs(float(shot.duration or 0) - dur) > 0.05 and float(shot.duration or 0) > MAX_CLIP_SEC:
            shot.duration = dur
        # If no dedicated motion prompt, reuse the image prompt so I2V still has guidance
        anim = (settings_vid.animation_prompt or "").strip()
        if not anim:
            img_prompt = (shot.image.positive_prompt if shot.image else "") or ""
            img_prompt = img_prompt.strip()
            if img_prompt:
                settings_vid.animation_prompt = img_prompt
                jobs_log.info(
                    "Video job %s: empty motion prompt — using image prompt (%d chars)",
                    job.id,
                    len(img_prompt),
                )
        shot.video = settings_vid
        if not shot.image_path:
            raise RuntimeError("Shot has no image — generate or upload an image first")
        img_path = abs_path(job.project_id, shot.image_path)
        if not img_path or not img_path.exists():
            raise RuntimeError(f"Image missing: {shot.image_path}")

        shot.video_status = GenStatus.running
        save_project(proj)

        up = await comfy.upload_image(img_path, subfolder=f"amvs/{job.project_id}")
        name = up.get("name") or up.get("filename") or img_path.name
        sub = up.get("subfolder") or ""
        comfy_name = f"{sub}/{name}".strip("/") if sub else name

        prefix = f"amvs/{job.project_id}/vid_{job.shot_id}"
        job.message = f"Building video workflow ({dur:.1f}s)"
        jobs_log.info(
            "Video job %s shot=%s duration_sec=%.2f (timeline=%.2f)",
            job.id,
            job.shot_id,
            settings_vid.duration_sec,
            float(shot.duration or 0),
        )
        prompt = await build_video_workflow(settings_vid, comfy_name, filename_prefix=prefix)
        # Surface requested frame length in job UI
        try:
            length = int(prompt.get("5", {}).get("inputs", {}).get("length") or 0)
            if length:
                job.message = f"Queued MiniMax · {length} frames (~{length/24:.1f}s)"
        except Exception:
            pass
        job.message = "Queued in ComfyUI"
        prompt_id = await comfy.queue_prompt(prompt)
        job.prompt_id = prompt_id

        def on_prog(msg: dict) -> None:
            if msg.get("type") == "progress":
                data = msg.get("data") or {}
                val, mx = data.get("value", 0), data.get("max", 1) or 1
                job.progress = float(val) / float(mx)
                job.message = f"Animating: step {val}/{mx}"

        hist = await comfy.wait_for_prompt(prompt_id, on_progress=on_prog)
        outputs = comfy.extract_output_images(hist)
        # Also scan outputs for video files in history more carefully
        video_files = [o for o in outputs if o.get("kind") == "video" or str(o.get("filename", "")).endswith((".mp4", ".webm", ".gif"))]
        if not video_files:
            # check all output filenames
            for _nid, node_out in (hist.get("outputs") or {}).items():
                for key in ("images", "gifs", "videos"):
                    for item in node_out.get(key) or []:
                        fn = item.get("filename", "")
                        if fn.endswith((".mp4", ".webm", ".mkv", ".mov", ".gif")) or key in ("gifs", "videos"):
                            video_files.append(
                                {
                                    "filename": fn,
                                    "subfolder": item.get("subfolder", ""),
                                    "type": item.get("type", "output"),
                                }
                            )
        if not video_files:
            # last resort: any output file
            for o in outputs:
                video_files.append(o)
        if not video_files:
            raise RuntimeError("ComfyUI returned no video outputs. Check ComfyUI logs.")

        quality_dir = "draft" if settings_vid.quality == "draft" else "final"
        dest_dir = project_dir(job.project_id) / "videos" / quality_dir
        archive_dir = project_dir(job.project_id) / "videos" / "history"
        dest_dir.mkdir(parents=True, exist_ok=True)
        archive_dir.mkdir(parents=True, exist_ok=True)

        # Archive previous active clip (keep on disk) before replacing
        proj = load_project(job.project_id)
        shot = next(s for s in proj.timeline.shots if s.id == job.shot_id)
        prev = shot.video_path or shot.draft_video_path
        if prev:
            prev_path = abs_path(job.project_id, prev)
            if prev_path and prev_path.exists():
                ts = datetime.now(timezone.utc).strftime("%Y%m%d_%H%M%S")
                arch = archive_dir / f"{job.shot_id}_{ts}_{prev_path.name}"
                try:
                    shutil.copy2(prev_path, arch)
                    jobs_log.info("Archived previous video %s -> %s", prev_path, arch)
                except Exception as e:
                    jobs_log.warning("Could not archive previous video: %s", e)

        vf = video_files[0]
        # Unique filename so browser cache doesn't stick to old clip
        ts_name = datetime.now(timezone.utc).strftime("%Y%m%d_%H%M%S")
        dest = dest_dir / f"{job.shot_id}_{ts_name}_{vf['filename']}"
        await comfy.download_view(vf["filename"], vf.get("subfolder", ""), vf.get("type", "output"), dest)
        # ensure mp4 extension if missing
        if dest.suffix.lower() not in {".mp4", ".webm", ".mov", ".mkv", ".gif"}:
            mp4 = dest.with_suffix(".mp4")
            shutil.move(str(dest), str(mp4))
            dest = mp4

        rel = rel_to_project(job.project_id, dest)
        proj = load_project(job.project_id)
        shot = next(s for s in proj.timeline.shots if s.id == job.shot_id)
        # Active path always points at newest; both draft and final replace "what plays"
        if settings_vid.quality == "draft":
            shot.draft_video_path = rel
            # Draft becomes the active playable clip until a final exists; still overrides stills
            if not shot.video_path:
                shot.video_path = rel
            else:
                # Prefer newest generation as active video_path so playback isn't stuck on old final
                shot.video_path = rel
            shot.video_status = GenStatus.draft
        else:
            shot.video_path = rel
            shot.video_status = GenStatus.final
        shot.last_error = None
        if not isinstance(shot.video_alternatives, list):
            shot.video_alternatives = []
        if rel not in shot.video_alternatives:
            shot.video_alternatives.append(rel)
        job.result_paths = [rel]
        _update_shot_video(job.project_id, shot)
        jobs_log.info("Shot %s video active path=%s", job.shot_id, rel)


def _update_shot_image(project_id: str, shot_src, *, clear_video: bool = False) -> None:
    """Merge media fields onto disk project (avoid wiping other concurrent edits)."""
    proj = load_project(project_id)
    for i, s in enumerate(proj.timeline.shots):
        if s.id == shot_src.id:
            s.image_path = shot_src.image_path
            s.image_alternatives = list(shot_src.image_alternatives or [])
            s.thumbnail_path = shot_src.thumbnail_path
            s.image_status = shot_src.image_status
            s.last_error = shot_src.last_error
            if shot_src.image:
                s.image = shot_src.image
            if clear_video:
                s.video_path = None
                s.draft_video_path = None
                s.video_alternatives = []
                s.video_status = GenStatus.empty
            proj.timeline.shots[i] = s
            break
    # merge_media=False so intentional video clear is not restored from disk
    save_project(proj, merge_media=False)


def _update_shot_video(project_id: str, shot_src) -> None:
    proj = load_project(project_id)
    for i, s in enumerate(proj.timeline.shots):
        if s.id == shot_src.id:
            s.video_path = shot_src.video_path
            s.draft_video_path = shot_src.draft_video_path
            s.video_status = shot_src.video_status
            s.video_alternatives = list(getattr(shot_src, "video_alternatives", None) or [])
            s.thumbnail_path = shot_src.thumbnail_path or s.thumbnail_path
            s.last_error = shot_src.last_error
            if shot_src.video:
                s.video = shot_src.video
            proj.timeline.shots[i] = s
            break
    save_project(proj)


def _make_thumb(src: Path, dest: Path, size: tuple[int, int] = (320, 180)) -> None:
    dest.parent.mkdir(parents=True, exist_ok=True)
    with Image.open(src) as im:
        im = im.convert("RGB")
        im.thumbnail(size)
        im.save(dest, "JPEG", quality=85)


def _select_references_for_shot(proj, settings_img) -> list:
    """Return ReferenceItem list: explicit IDs first, else auto-match by name in prompt."""
    import re

    refs = list(proj.references or [])
    if not refs:
        return []
    by_id = {r.id: r for r in refs}
    chosen = []
    seen = set()
    prompt = settings_img.positive_prompt or ""
    # Checkbox: never use character (cast) reference images for this shot.
    # Location/style refs still allowed. Generic people in the text prompt are fine.
    no_char_refs = bool(getattr(settings_img, "strict_named_characters_only", False))

    def _is_character_ref(r) -> bool:
        cat = (getattr(r, "category", None) or "character").strip().lower()
        return cat in ("character", "clothing", "object")

    for rid in settings_img.reference_ids or []:
        r = by_id.get(rid)
        if r and r.id not in seen:
            if no_char_refs and _is_character_ref(r):
                continue
            chosen.append(r)
            seen.add(r.id)
    if chosen:
        return chosen[:6]

    # Auto-attach: character / location / style names mentioned in the prompt
    if not prompt.strip():
        return []
    # Prefer longer names first (avoid partial collisions)
    ranked = sorted(refs, key=lambda r: len((r.name or "").strip()), reverse=True)
    for r in ranked:
        name = (r.name or "").strip()
        if len(name) < 2:
            continue
        if no_char_refs and _is_character_ref(r):
            continue
        # word-boundary-ish match (case-insensitive); strip so "Psycho " still matches
        if re.search(rf"(?i)(?<!\w){re.escape(name)}(?!\w)", prompt):
            if r.id not in seen:
                chosen.append(r)
                seen.add(r.id)
    if no_char_refs:
        return chosen[:6]
    # Characters first, then location/style/other
    order = {
        "character": 0,
        "clothing": 1,
        "object": 2,
        "location": 3,
        "environment": 3,
        "style": 4,
        "other": 5,
    }
    chosen.sort(
        key=lambda r: (
            order.get((getattr(r, "category", None) or "other").strip().lower(), 9),
            (r.name or "").strip().lower(),
        )
    )
    return chosen[:6]


def _scan_comfy_output_for_prefix(prefix: str) -> list[dict[str, str]]:
    """Find files under ComfyUI/output matching SaveImage prefix when history is thin."""
    from .config import settings

    out_root = settings.comfy_install / "output"
    # prefix like amvs/proj_xxx/img_shot_yyy_0
    rel = prefix.replace("\\", "/")
    parent = out_root / Path(rel).parent
    stem = Path(rel).name
    found: list[dict[str, str]] = []
    if not parent.is_dir():
        return found
    for p in sorted(parent.glob(f"{stem}*")):
        if p.suffix.lower() in {".png", ".jpg", ".jpeg", ".webp"}:
            sub = str(p.parent.relative_to(out_root)).replace("\\", "/")
            found.append(
                {
                    "filename": p.name,
                    "subfolder": "" if sub == "." else sub,
                    "type": "output",
                    "local_path": str(p),
                }
            )
    return found


job_manager = JobManager()
