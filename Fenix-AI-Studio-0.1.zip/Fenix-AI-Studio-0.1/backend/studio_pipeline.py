"""Direct Image / Video generation for the home studio (no timeline project)."""
from __future__ import annotations

import asyncio
import shutil
import time
from pathlib import Path
from typing import Any, Optional
from uuid import uuid4

from .comfyui_client import comfy
from .config import settings
from .gen_activity import clear_activity, set_activity
from .logging_setup import log
from .schemas import ImageSettings, VideoSettings
from . import studio_store
from .workflow_engine import build_image_workflow, build_video_workflow

log_s = log


def _status(msg: str, on_status=None) -> None:
    set_activity(msg, source="studio", busy=True)
    if on_status:
        try:
            on_status(msg)
        except Exception:
            pass


def _scan_outputs(prefix: str, *, newer_than: float = 0.0, kinds: set[str] | None = None) -> list[Path]:
    out_root = settings.comfy_install / "output"
    if not out_root.is_dir():
        return []
    kinds = kinds or {".png", ".jpg", ".jpeg", ".webp", ".mp4", ".webm", ".gif", ".mov"}
    parts = [p for p in prefix.replace("\\", "/").split("/") if p]
    needle = parts[-1] if parts else prefix
    found: list[Path] = []
    for p in out_root.rglob("*"):
        if not p.is_file():
            continue
        if p.suffix.lower() not in kinds:
            continue
        rel = str(p.relative_to(out_root)).replace("\\", "/")
        if needle not in p.name and needle not in rel and not any(x in rel for x in parts[-2:]):
            continue
        try:
            if newer_than and p.stat().st_mtime < newer_than - 2:
                continue
            if p.stat().st_size < 512:
                continue
        except OSError:
            continue
        found.append(p)
    found.sort(key=lambda x: x.stat().st_mtime, reverse=True)
    return found


async def _import_history_file(
    hist: dict[str, Any],
    *,
    prefer_video: bool = False,
    dest: Path,
) -> Optional[Path]:
    outs = comfy.extract_output_images(hist)
    if prefer_video:
        ordered = [
            o
            for o in outs
            if o.get("kind") == "video"
            or str(o.get("filename", "")).lower().endswith((".mp4", ".webm", ".mov", ".mkv", ".gif"))
        ] or outs
    else:
        ordered = [
            o
            for o in outs
            if not str(o.get("filename", "")).lower().endswith((".mp4", ".webm", ".mov", ".mkv"))
        ] or outs
    for o in ordered:
        fn = o.get("filename") or ""
        if not fn:
            continue
        try:
            await comfy.download_view(
                fn, o.get("subfolder", "") or "", o.get("type", "output") or "output", dest
            )
            if dest.is_file() and dest.stat().st_size > 200:
                return dest
        except Exception as e:
            log_s.debug("studio download_view %s: %s", fn, e)
    # history may nest outputs under nodes
    for _nid, node_out in (hist.get("outputs") or {}).items():
        if not isinstance(node_out, dict):
            continue
        for key in ("images", "gifs", "videos", "audio"):
            for item in node_out.get(key) or []:
                if not isinstance(item, dict):
                    continue
                fn = item.get("filename") or ""
                if not fn:
                    continue
                try:
                    await comfy.download_view(
                        fn,
                        item.get("subfolder", "") or "",
                        item.get("type", "output") or "output",
                        dest,
                    )
                    if dest.is_file() and dest.stat().st_size > 200:
                        return dest
                except Exception:
                    pass
    return None


async def generate_studio_image(
    *,
    prompt: str,
    negative_prompt: str = "",
    width: int = 1024,
    height: int = 576,
    seed: int = -1,
    steps: int = 20,
    model_id: str = "flux2-klein-4b",
    on_status=None,
) -> dict[str, Any]:
    prompt = (prompt or "").strip()
    if not prompt:
        raise ValueError("Prompt is required")
    if not await comfy.is_online():
        raise RuntimeError("ComfyUI is offline")

    width = max(256, min(2048, int(width or 1024)))
    height = max(256, min(2048, int(height or 576)))
    steps = max(4, min(50, int(steps or 20)))
    settings_img = ImageSettings(
        positive_prompt=prompt,
        negative_prompt=negative_prompt or "",
        seed=seed,
        width=width,
        height=height,
        model_id=model_id or "flux2-klein-4b",
        steps=steps,
        batch_count=1,
    )
    run_id = "studio_" + uuid4().hex[:10]
    prefix = f"studio/img/{run_id}"

    try:
        # Do NOT call Comfy /free before every gen — that unloads models and forces
        # a full cold reload next run (felt "insanely slow" vs warm cache).
        _status("Building Flux workflow…", on_status)
        wf = await build_image_workflow(settings_img, filename_prefix=prefix)
        started = time.time()
        _status("Queued in ComfyUI — loading models if needed…", on_status)
        prompt_id = await comfy.queue_prompt(wf)
        _status("Loading models / sampling image…", on_status)
        hist = await comfy.wait_for_prompt(
            prompt_id, timeout=max(float(settings.comfy_timeout), 600.0)
        )
        _status("Importing image from Comfy…", on_status)

        tmp = Path(settings.cache_dir) / "studio_tmp" / f"{run_id}.png"
        tmp.parent.mkdir(parents=True, exist_ok=True)
        got = await _import_history_file(hist, prefer_video=False, dest=tmp)
        if not got:
            disk = _scan_outputs(prefix, newer_than=started, kinds={".png", ".jpg", ".jpeg", ".webp"})
            if disk:
                shutil.copy2(disk[0], tmp)
                got = tmp
        if not got or not tmp.is_file():
            raise RuntimeError(
                "Comfy finished but no image file was found (check ComfyUI/output/studio/)"
            )

        item = studio_store.add_item(
            kind="image",
            title=prompt[:60],
            prompt=prompt,
            negative_prompt=negative_prompt or "",
            source_path=tmp,
            width=width,
            height=height,
            seed=seed,
            model=model_id or "flux2-klein-4b",
        )
        try:
            tmp.unlink(missing_ok=True)
        except Exception:
            pass
        _status("Image ready", on_status)
        clear_activity("Image ready")
        return item
    except Exception:
        clear_activity("Image failed")
        raise


async def generate_studio_video(
    *,
    image_path: Path,
    animation_prompt: str = "",
    duration_sec: float = 5.0,
    seed: int = -1,
    parent_id: str = "",
    quality: str = "draft",
    on_status=None,
) -> dict[str, Any]:
    if not image_path or not Path(image_path).is_file():
        raise ValueError("Source image is required for I2V")
    if not await comfy.is_online():
        raise RuntimeError("ComfyUI is offline")

    image_path = Path(image_path)
    anim = (animation_prompt or "").strip() or "subtle cinematic motion, natural movement"
    dur = max(1.0, min(15.0, float(duration_sec or 5.0)))
    q = (quality or "draft").strip().lower()
    if q not in ("draft", "final"):
        q = "draft"
    settings_vid = VideoSettings(
        preset_id="minimax-h3-i2v",
        animation_prompt=anim,
        duration_sec=dur,
        seed=seed,
        quality=q,  # type: ignore[arg-type]
        mute_clip_audio=True,
    )
    run_id = "studio_" + uuid4().hex[:10]
    prefix = f"studio/vid/{run_id}"

    try:
        _status("Uploading source frame to Comfy…", on_status)
        up = await comfy.upload_image(image_path, subfolder="studio/i2v")
        name = up.get("name") or up.get("filename") or image_path.name
        sub = (up.get("subfolder") or "").replace("\\", "/")
        comfy_name = f"{sub}/{name}".strip("/") if sub else name

        _status(f"Building MiniMax I2V workflow ({q})…", on_status)
        wf = await build_video_workflow(settings_vid, comfy_name, filename_prefix=prefix)
        started = time.time()
        _status(f"Queued video (~{dur:.0f}s, {q}) — loading models…", on_status)
        prompt_id = await comfy.queue_prompt(wf)
        _status("Loading video models / sampling frames…", on_status)
        hist = await comfy.wait_for_prompt(
            prompt_id, timeout=max(float(settings.comfy_timeout), 1800.0)
        )
        _status("Decoding / importing video…", on_status)

        tmp = Path(settings.cache_dir) / "studio_tmp" / f"{run_id}.mp4"
        tmp.parent.mkdir(parents=True, exist_ok=True)
        got = await _import_history_file(hist, prefer_video=True, dest=tmp)
        if not got:
            disk = _scan_outputs(prefix, newer_than=started, kinds={".mp4", ".webm", ".mov", ".gif"})
            if disk:
                shutil.copy2(disk[0], tmp)
                got = tmp
        if not got or not tmp.is_file():
            raise RuntimeError(
                "Comfy finished but no video file was found (check ComfyUI/output/studio/)"
            )

        item = studio_store.add_item(
            kind="video",
            title=anim[:60],
            prompt=anim,
            source_path=tmp,
            duration_sec=dur,
            seed=seed,
            model=f"minimax-h3-i2v-{q}",
            parent_id=parent_id or "",
        )
        try:
            tmp.unlink(missing_ok=True)
        except Exception:
            pass
        _status("Video ready", on_status)
        clear_activity("Video ready")
        return item
    except Exception:
        clear_activity("Video failed")
        raise
