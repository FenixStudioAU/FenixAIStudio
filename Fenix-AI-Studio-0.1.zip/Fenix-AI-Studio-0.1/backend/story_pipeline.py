"""Multi-agent local LLM pipeline: planner → writer → editor for music-video scenes."""
from __future__ import annotations

import math
from typing import Any, Callable, Optional

from . import llm_client
from .logging_setup import log
from .persona import with_persona
from .schemas import ImageSettings, Project, Shot, StoryBrief, VideoSettings, new_id

# Style templates: prefix + guidance baked into every prompt
STYLE_TEMPLATES: dict[str, dict[str, str]] = {
    "cinematic_drama": {
        "label": "Cinematic drama music video",
        "prefix": (
            "Cinematic dramatic music video still, film grain, anamorphic bokeh, "
            "moody contrast, emotional lighting, 35mm film look"
        ),
        "motion": "slow deliberate camera moves, emotional micro-expressions, cinematic pacing",
        "guidance": "Serious emotional stakes, grounded performances, movie-trailer framing.",
    },
    "childrens": {
        "label": "Children's entertainment video",
        "prefix": (
            "Bright cheerful children's music video still, soft friendly lighting, "
            "wholesome characters, playful props, safe colorful world"
        ),
        "motion": "bouncy gentle motion, happy expressions, playful camera wobble",
        "guidance": "Kid-safe, warm, simple readable actions, no horror or dark themes.",
    },
    "mtv": {
        "label": "MTV style video",
        "prefix": (
            "High-energy MTV music video still, bold color grading, dynamic composition, "
            "fashion-forward, punchy contrast, iconic pop aesthetics"
        ),
        "motion": "quick rhythmic motion, whip pans energy, performance attitude",
        "guidance": "Style-forward cuts, performance energy, bold looks, pop-culture cool.",
    },
    "grunge": {
        "label": "Grunge video",
        "prefix": (
            "Grunge 90s music video still, desaturated teal-orange grime, handheld raw look, "
            "distressed textures, underground DIY energy"
        ),
        "motion": "shaky handheld energy, restless pacing, raw imperfect movement",
        "guidance": "Raw, imperfect, angst, alleyways, diners, amps, rain, authenticity over polish.",
    },
    "rock_50s": {
        "label": "50s rock video",
        "prefix": (
            "1950s rock and roll music video still, vintage Technicolor, chrome diners, "
            "leather jackets, classic cars, period costumes, warm nostalgic glow"
        ),
        "motion": "jive energy, classic car cruise, period dance moves",
        "guidance": "Period-accurate 1950s Americana, sock hop, drive-in, rockabilly vibes.",
    },
    "bright_happy": {
        "label": "Bright happy aesthetic",
        "prefix": (
            "Colorful bright happy energetic scene with saturated colors and a fun vibe, "
            "sun-kissed lighting, cheerful expressions, clean pop look"
        ),
        "motion": "upbeat bounce, smiling faces, lively camera push-ins",
        "guidance": "Joyful, high-key light, candy colors, feel-good summer energy.",
    },
    "night_neon": {
        "label": "Night neon / city lights",
        "prefix": (
            "Nighttime neon music video still, wet asphalt reflections, cyan-magenta neon, "
            "urban night atmosphere, cinematic low-key lighting"
        ),
        "motion": "slow neon drifts, traffic light trails, nocturnal mood",
        "guidance": "After-dark city, neon signs, rain streets, intimate night conversations.",
    },
    "horror_ballad": {
        "label": "Dark ballad / soft horror",
        "prefix": (
            "Dark atmospheric music video still, fog, cold moonlight, uneasy beauty, "
            "subtle horror mood without gore"
        ),
        "motion": "creeping camera, wind-stirred fabric, unsettling stillness",
        "guidance": "Melancholy, eerie beauty, tension — not jump-scare gore.",
    },
}

DEFAULT_MODELS = {
    # Prefer small/fast models for story beats (user machines often low VRAM)
    "planner": "qwen2.5:3b",
    "writer": "qwen2.5:3b",
    "editor": "qwen2.5:3b",
}

# Fallbacks if preferred model missing — smallest first (never jump to 14B as first resort)
FALLBACKS = {
    "planner": [
        "qwen2.5:3b",
        "qwen2.5:1.5b",
        "llama3.2:3b",
        "llama3.2:1b",
        "tinyllama",
        "gemma2:2b",
        "phi3:mini",
        "qwen3.5:4b",
        "qwen3:4b",
        "qwen2.5-coder:3b",
        "qwen3:8b",
        "dolphin-mistral:latest",
    ],
    "writer": [
        "qwen2.5:3b",
        "qwen2.5:1.5b",
        "llama3.2:3b",
        "tinyllama",
        "gemma2:2b",
        "qwen3.5:4b",
        "qwen3:4b",
        "qwen2.5-coder:3b",
        "qwen3:8b",
        "dolphin-mistral:latest",
    ],
    "editor": [
        "qwen2.5:3b",
        "qwen2.5:1.5b",
        "llama3.2:3b",
        "tinyllama",
        "qwen3.5:4b",
        "qwen3:4b",
        "qwen2.5-coder:3b",
        "qwen3:8b",
        "dolphin-mistral:latest",
    ],
}

# Hard cap for systems under 8 GB VRAM (or optimize_low_vram)
LOW_VRAM_MAX_B = 4.5


def list_style_templates() -> list[dict[str, str]]:
    return [{"id": k, "label": v["label"], "prefix": v["prefix"]} for k, v in STYLE_TEMPLATES.items()]


def _model_param_b(name: str) -> float:
    """Best-effort parameter count in billions from Ollama model id (e.g. qwen2.5:3b → 3)."""
    import re

    n = (name or "").lower()
    # Prefer the last NNb tag (avoids matching year-like digits)
    m = re.search(r"(?:^|[:\-_./])(\d+(?:\.\d+)?)\s*b\b", n)
    if m:
        return float(m.group(1))
    if "mini" in n or "tiny" in n:
        return 1.5
    if "small" in n:
        return 3.0
    # Unknown size — treat as large so low-VRAM mode won't pick it unless nothing else
    return 99.0


def _score_model_for_json(name: str, *, prefer_small: bool = False) -> int:
    """Higher = better for structured story JSON. When prefer_small, smaller wins hard."""
    n = (name or "").lower()
    size = _model_param_b(n)
    score = 0
    if "instruct" in n or "coder" in n or "dolphin" in n:
        score += 40
    if "qwen2.5" in n:
        score += 35
    if "qwen2" in n and "qwen3" not in n:
        score += 20
    if "gemma" in n:
        score += 15
    if "mistral" in n or "llama" in n:
        score += 12
    # CoT models work with think=false but are slower; slight deprioritize
    if "qwen3.5" in n:
        score -= 15
    if "qwen3.6" in n:
        score -= 10
    if prefer_small:
        # Strongly prefer ≤4B; punish big models
        if size <= 4.5:
            score += int(50 - size * 5)
        elif size <= 8:
            score -= 20
        else:
            score -= 80
    else:
        # Mild preference for usable size, but not 14B+
        if size <= 4.5:
            score += 25
        elif size <= 8:
            score += 10
        elif size >= 12:
            score -= 40
    return score


def pick_model(
    role: str,
    preferred: str | None,
    available: set[str],
    *,
    max_param_b: float | None = None,
) -> str:
    """
    Choose an Ollama model.
    - If preferred is installed, use it EXACTLY (unless over max_param_b and a smaller model exists).
    - Never prefix-match a small name onto a huge sibling (e.g. qwen2.5 → 14b).
    - When max_param_b is set (low VRAM), only pick models ≤ that size if any exist.
    """
    if not available:
        raise RuntimeError("No Ollama models available. Install/pull a model and ensure Ollama is running.")

    pool = set(available)
    if max_param_b is not None:
        small = {a for a in available if _model_param_b(a) <= max_param_b}
        if small:
            pool = small
        # else keep full pool with a warning via scoring that prefers small

    pref = (preferred or "").strip()
    if pref:
        # Exact id
        if pref in pool:
            return pref
        if pref in available and (max_param_b is None or _model_param_b(pref) <= max_param_b or not any(
            _model_param_b(a) <= max_param_b for a in available
        )):
            return pref
        # Exact tag variants: name:tag only within same base + similar size
        pref_base = pref.split(":")[0].lower()
        pref_size = _model_param_b(pref)
        same_base = [
            a
            for a in pool
            if a.lower() == pref.lower()
            or a.lower().startswith(pref_base + ":")
            or a.lower().split(":")[0] == pref_base
        ]
        if same_base:
            # Prefer same size band as requested
            same_base.sort(
                key=lambda a: (
                    abs(_model_param_b(a) - pref_size),
                    -_score_model_for_json(a, prefer_small=max_param_b is not None),
                    a,
                )
            )
            # Reject jumping from ~3B request to 14B of same family
            best = same_base[0]
            if pref_size <= 8 and _model_param_b(best) > pref_size + 4 and any(
                _model_param_b(a) <= pref_size + 1.5 for a in same_base
            ):
                for a in same_base:
                    if _model_param_b(a) <= pref_size + 1.5:
                        return a
            return best

    # Named fallbacks (small first)
    for c in FALLBACKS.get(role, []):
        if c in pool:
            return c
        base = c.split(":")[0].lower()
        want = _model_param_b(c)
        matches = [
            a
            for a in pool
            if a.lower().startswith(base + ":") or a.lower().split(":")[0] == base
        ]
        if not matches:
            continue
        # Closest size to the fallback entry, not arbitrary first match
        matches.sort(key=lambda a: (abs(_model_param_b(a) - want), _model_param_b(a), a))
        pick = matches[0]
        if max_param_b is not None and _model_param_b(pick) > max_param_b:
            continue
        if want <= 4.5 and _model_param_b(pick) > 8:
            continue
        return pick

    prefer_small = max_param_b is not None
    return max(pool, key=lambda a: (_score_model_for_json(a, prefer_small=prefer_small), -_model_param_b(a)))


def resolve_max_param_b_for_host() -> float | None:
    """Under 8GB VRAM (or low-vram setting) → cap story models ~4B."""
    try:
        from . import app_settings_store
        from .models_detect import get_vram_gb

        low = bool(app_settings_store.load_user_settings().get("optimize_low_vram"))
        vram = float(get_vram_gb() or 0)
        if low or (0 < vram < 8):
            return LOW_VRAM_MAX_B
    except Exception:
        pass
    return None


# on_progress(message, progress_0_1, detail_snippet)
ProgressCb = Optional[Callable[..., None]]


async def run_story_pipeline(
    *,
    idea: str = "",
    lyrics: str = "",
    use_story: bool = True,
    use_lyrics: bool = True,
    style_id: str = "cinematic_drama",
    character_names: list[str] | None = None,
    scene_count: int,
    slot_duration: float = 5.0,
    song_duration: float = 0.0,
    planner_model: str | None = None,
    writer_model: str | None = None,
    editor_model: str | None = None,
    on_progress: ProgressCb = None,
) -> dict[str, Any]:
    """
    Returns {
      "story_summary": str,
      "scenes": [{"index":1,"label":"...","image_prompt":"...","motion_prompt":"...","characters":[]}, ...],
      "models_used": {...},
      "style_id": str,
    }
    """
    if scene_count < 1:
        raise ValueError("scene_count must be >= 1")
    if scene_count > 120:
        scene_count = 120

    style = STYLE_TEMPLATES.get(style_id) or STYLE_TEMPLATES["cinematic_drama"]
    # character_names may be strings or {name, description} dicts
    char_lines: list[str] = []
    chars: list[str] = []
    for c in character_names or []:
        if isinstance(c, dict):
            n = (c.get("name") or "").strip()
            d = (c.get("description") or c.get("notes") or "").strip()
            if n:
                chars.append(n)
                char_lines.append(f"- {n}: {d}" if d else f"- {n}")
        else:
            n = str(c).strip()
            if n:
                chars.append(n)
                char_lines.append(f"- {n}")

    story_bits = []
    if use_story and (idea or "").strip():
        story_bits.append(f"STORY / IDEA:\n{(idea or '').strip()}")
    if use_lyrics and (lyrics or "").strip():
        story_bits.append(f"LYRICS:\n{(lyrics or '').strip()}")
    if char_lines:
        story_bits.append(
            "CHARACTERS (keep visual identity consistent; use names exactly):\n"
            + "\n".join(char_lines)
        )
    if not story_bits:
        raise ValueError("Provide a story idea and/or lyrics (enable at least one source).")
    source_text = "\n\n".join(story_bits)

    models = await llm_client.list_ollama_models()
    avail = {m["id"] for m in models}
    if not avail:
        online = await llm_client.ollama_online()
        raise RuntimeError(
            "Ollama has no models listed."
            + (" Is Ollama running on :11434?" if not online else " Pull a model (e.g. gemma4:12b).")
        )

    max_b = resolve_max_param_b_for_host()
    planner = pick_model(
        "planner",
        planner_model or DEFAULT_MODELS["planner"],
        avail,
        max_param_b=max_b,
    )
    writer = pick_model(
        "writer",
        writer_model or DEFAULT_MODELS["writer"],
        avail,
        max_param_b=max_b,
    )
    editor = pick_model(
        "editor",
        editor_model or DEFAULT_MODELS["editor"],
        avail,
        max_param_b=max_b,
    )
    models_used = {
        "planner": planner,
        "writer": writer,
        "editor": editor,
        "max_param_b": max_b,
        "vram_capped": max_b is not None,
    }
    log.info("Story pipeline models: %s (max_param_b=%s)", models_used, max_b)

    def prog(msg: str, p: float, detail: str = "") -> None:
        if on_progress:
            try:
                on_progress(msg, p, detail or "")
            except TypeError:
                on_progress(msg, p)
        log.info("story_pipeline: %s (%.0f%%)", msg, p * 100)

    # ----- 1) PLANNER: beat sheet matching exact scene count -----
    # Large scene counts (e.g. 58) blow the token budget if done in one shot,
    # especially on CoT models — chunk the beat sheet.
    prog(f"Planner ({planner}): outlining {scene_count} beats…", 0.05)
    planner_sys = with_persona(
        "You are a music-video director's assistant. Output ONLY valid JSON. "
        "No chain-of-thought, no markdown, no preamble — JSON object only. "
        "Plan a continuous story arc for a music video. "
        "Rules: cover the song once (beginning→middle→end), no filler, no repeated beats, "
        "no padding scenes, every beat advances the story or lyric meaning. "
        "Use the given character names exactly when they appear. "
        "Only put a character name in a beat if that character is actually in that beat."
    )
    import json as _json

    plan_chunk = 16
    beats: list[Any] = []
    story_summary = ""
    for start in range(0, scene_count, plan_chunk):
        end = min(start + plan_chunk, scene_count)
        n_chunk = end - start
        prev_note = ""
        if beats:
            prev_note = (
                "Continue AFTER these previous beats (do not repeat them):\n"
                + _json.dumps(beats[-4:], ensure_ascii=False)
            )
        planner_user = f"""Create beats {start + 1}..{end} of a music video with TOTAL {scene_count} scenes.
This chunk has EXACTLY {n_chunk} beats. Indices must be {start + 1} through {end}.
Each scene is about {slot_duration:.1f} seconds.
Song duration: {song_duration or scene_count * slot_duration:.1f}s.
Style: {style['label']} — {style['guidance']}
Characters: {', '.join(chars) if chars else '(none named)'}

{source_text}

{prev_note}

Return JSON only:
{{
  "story_summary": "2-4 sentences of the overall arc (full video)",
  "beats": [
    {{"index": {start + 1}, "label": "short title", "beat": "what happens (1-2 sentences)", "characters": ["Name"], "lyric_hook": "optional lyric fragment"}}
  ]
}}
beats array length MUST be {n_chunk}.
"""
        prog(
            f"Planner ({planner}): writing beats {start + 1}–{end}…",
            0.05 + 0.25 * (start / max(1, scene_count)),
            f"Calling Ollama · {planner} · JSON beat sheet chunk",
        )
        plan_raw = await llm_client.chat(
            planner,
            [{"role": "system", "content": planner_sys}, {"role": "user", "content": planner_user}],
            temperature=0.5,
            num_predict=8192,
            format_json=True,
            timeout=600.0,
            retries=3,
            disable_thinking=True,
        )
        prog(
            f"Planner: got beats {start + 1}–{end}",
            0.05 + 0.28 * (end / scene_count),
            (plan_raw or "")[:900],
        )
        plan = llm_client.extract_json(plan_raw)
        chunk_beats = plan.get("beats") or plan.get("scenes") or []
        if not isinstance(chunk_beats, list):
            chunk_beats = []
        # Force indices into this chunk range
        fixed = []
        for i, b in enumerate(chunk_beats[:n_chunk]):
            if not isinstance(b, dict):
                b = {"beat": str(b)}
            b = dict(b)
            b["index"] = start + 1 + i
            fixed.append(b)
        while len(fixed) < n_chunk:
            idx = start + 1 + len(fixed)
            fixed.append(
                {
                    "index": idx,
                    "label": f"Beat {idx}",
                    "beat": "Continue the story arc naturally.",
                    "characters": chars[:2],
                    "lyric_hook": "",
                }
            )
        beats.extend(fixed)
        if plan.get("story_summary"):
            story_summary = str(plan["story_summary"]).strip()
        prog(
            f"Planner: beats {start + 1}–{end}…",
            0.05 + 0.28 * (end / scene_count),
        )

    beats = _normalize_beats(beats, scene_count, chars)
    story_summary = story_summary or "Music video following the provided story/lyrics."

    # ----- 2) WRITER: detailed image + motion prompts -----
    prog(f"Writer ({writer}): writing detailed scene prompts…", 0.35)
    writer_sys = with_persona(
        "You write FLUX-ready image prompts for music video stills. "
        "Output ONLY valid JSON. Each image_prompt must be one dense paragraph: "
        "subject, action, setting, lighting, camera, wardrobe — specific and visual. "
        "Include a character name ONLY when that character is in the beat — never force-cast every character. "
        "If a beat has no characters list (or empty), write a scene WITHOUT named people from the cast. "
        "Do NOT invent songs-within-songs. Do NOT pad with empty atmosphere-only scenes. "
        "Do NOT repeat the same composition across scenes."
    )
    # Chunk writer if many scenes (avoid context blow-up)
    import json as _json

    written: list[dict[str, Any]] = []
    chunk_size = 12
    for start in range(0, scene_count, chunk_size):
        chunk = beats[start : start + chunk_size]
        writer_user = f"""Expand these music-video beats into production prompts.
Style prefix (weave this into every image_prompt naturally):
"{style['prefix']}"
Motion style: {style['motion']}
Overall story: {story_summary}
Characters: {', '.join(chars) if chars else 'none'}

Beats JSON:
{_json.dumps(chunk, ensure_ascii=False)}

Return JSON:
{{
  "scenes": [
    {{
      "index": <int>,
      "label": "short title",
      "image_prompt": "full visual prompt…",
      "motion_prompt": "short I2V motion description",
      "characters": ["Name"]
    }}
  ]
}}
Exactly {len(chunk)} scenes with the same indices as the beats.
"""
        prog(
            f"Writer ({writer}): prompts for scenes {start + 1}–{min(start + chunk_size, scene_count)}…",
            0.35 + 0.35 * (start / max(1, scene_count)),
            f"Calling Ollama · {writer}",
        )
        w_raw = await llm_client.chat(
            writer,
            [{"role": "system", "content": writer_sys}, {"role": "user", "content": writer_user}],
            temperature=0.75,
            num_predict=8192,
            format_json=True,
            timeout=600.0,
            retries=3,
            disable_thinking=True,
        )
        prog(
            f"Writer: finished chunk {start + 1}–{min(start + chunk_size, scene_count)}",
            0.35 + 0.35 * (min(start + chunk_size, scene_count) / scene_count),
            (w_raw or "")[:900],
        )
        w_data = llm_client.extract_json(w_raw)
        sc = w_data.get("scenes") or w_data.get("beats") or []
        if isinstance(sc, list):
            written.extend(sc)
        prog(f"Writer: scenes {start + 1}–{min(start + chunk_size, scene_count)}…", 0.35 + 0.35 * ((start + chunk_size) / scene_count))

    written = _normalize_scenes(written, beats, style, chars)

    # ----- 3) EDITOR: verify + fix -----
    prog(f"Editor ({editor}): QA pass — completeness & no padding…", 0.8)
    import json as _json

    editor_sys = with_persona(
        "You are a strict music-video continuity editor. Output ONLY valid JSON. "
        "No chain-of-thought, no markdown. "
        "Ensure every scene has a unique, detailed image_prompt. "
        "Fix empty/short/generic prompts. Remove pure padding. "
        "Keep exact scene count. Only keep character names that belong in that scene. "
        "Do not change the story arc into something unrelated."
    )
    editor_user = f"""Review and fix this music-video scene list.
Required scene count: {scene_count}
Style: {style['label']} / prefix idea: {style['prefix']}
Characters: {', '.join(chars) if chars else 'none'}
Story summary: {story_summary}

Scenes:
{_json.dumps(written, ensure_ascii=False)[:50000]}

Rules:
- Exactly {scene_count} scenes
- Every image_prompt >= 40 words, concrete visuals
- No two scenes nearly identical
- Motion prompts short but useful for image-to-video
- Keep labels short

Return JSON:
{{
  "story_summary": "...",
  "issues_fixed": ["..."],
  "scenes": [{{"index":1,"label":"...","image_prompt":"...","motion_prompt":"...","characters":[]}}]
}}
"""
    try:
        prog(f"Editor ({editor}): QA pass…", 0.82, f"Calling Ollama · {editor}")
        e_raw = await llm_client.chat(
            editor,
            [{"role": "system", "content": editor_sys}, {"role": "user", "content": editor_user}],
            temperature=0.3,
            num_predict=12288,
            format_json=True,
            timeout=600.0,
            retries=2,
            disable_thinking=True,
        )
        prog("Editor: review complete", 0.92, (e_raw or "")[:900])
        e_data = llm_client.extract_json(e_raw)
        final_scenes = e_data.get("scenes") or written
        if e_data.get("story_summary"):
            story_summary = str(e_data["story_summary"]).strip()
        issues = e_data.get("issues_fixed") or []
    except Exception as e:
        log.warning("Editor pass failed, using writer output: %s", e)
        final_scenes = written
        issues = [f"editor skipped: {e}"]

    final_scenes = _normalize_scenes(final_scenes, beats, style, chars)
    # ensure style prefix present if model dropped it
    for sc in final_scenes:
        ip = (sc.get("image_prompt") or "").strip()
        if ip and style["prefix"].split(",")[0].lower() not in ip.lower()[:120]:
            sc["image_prompt"] = f"{style['prefix']}. {ip}"
        if not (sc.get("motion_prompt") or "").strip():
            sc["motion_prompt"] = style["motion"]

    prog("Story pipeline complete", 1.0)
    return {
        "story_summary": story_summary,
        "scenes": final_scenes,
        "models_used": models_used,
        "style_id": style_id,
        "issues_fixed": issues if isinstance(issues, list) else [],
        "scene_count": len(final_scenes),
    }


def _normalize_beats(beats: list, n: int, chars: list[str]) -> list[dict[str, Any]]:
    out = []
    for i in range(n):
        b = beats[i] if i < len(beats) and isinstance(beats[i], dict) else {}
        out.append(
            {
                "index": i + 1,
                "label": str(b.get("label") or f"Scene {i + 1}")[:80],
                "beat": str(b.get("beat") or b.get("description") or f"Scene {i + 1} of the story")[:500],
                "characters": b.get("characters") if isinstance(b.get("characters"), list) else list(chars[:2]),
                "lyric_hook": str(b.get("lyric_hook") or "")[:200],
            }
        )
    return out


def _normalize_scenes(
    scenes: list, beats: list[dict[str, Any]], style: dict[str, str], chars: list[str]
) -> list[dict[str, Any]]:
    by_idx = {}
    for s in scenes:
        if not isinstance(s, dict):
            continue
        try:
            idx = int(s.get("index") or 0)
        except (TypeError, ValueError):
            continue
        if idx >= 1:
            by_idx[idx] = s
    out = []
    for i, beat in enumerate(beats):
        idx = i + 1
        s = by_idx.get(idx) or {}
        ip = str(s.get("image_prompt") or s.get("prompt") or "").strip()
        if len(ip) < 20:
            # synthesize from beat
            who = ", ".join(s.get("characters") or beat.get("characters") or chars[:2] or ["the subject"])
            ip = (
                f"{style['prefix']}. {who} — {beat.get('beat', '')}. "
                f"Detailed environment, clear faces, music video framing, high detail."
            )
        mp = str(s.get("motion_prompt") or s.get("animation_prompt") or style["motion"]).strip()
        out.append(
            {
                "index": idx,
                "label": str(s.get("label") or beat.get("label") or f"Scene {idx}")[:80],
                "image_prompt": ip,
                "motion_prompt": mp[:400],
                "characters": s.get("characters")
                if isinstance(s.get("characters"), list)
                else beat.get("characters") or [],
            }
        )
    return out


def apply_scenes_to_project(
    proj: Project,
    scenes: list[dict[str, Any]],
    *,
    slot_duration: float,
    song_duration: float,
    story_summary: str = "",
    style_id: str = "",
    idea: str = "",
    lyrics: str = "",
    track_title: str = "",
    include_title_card: bool = True,
) -> Project:
    """Replace timeline shots with LLM scenes covering the target duration.

    Music AI wizard: include_title_card=True inserts shot 0 as a title poster
    for the track/project name (LLM scenes follow after).

    Film / story mode: include_title_card=False — every LLM scene is used as-is
    (including the first prompt; no forced title poster).
    """
    if song_duration <= 0:
        song_duration = max(slot_duration * max(len(scenes), 1), slot_duration)
    title = (track_title or proj.name or "Untitled Track").strip() or "Untitled Track"
    is_film = (getattr(proj, "kind", None) or "music").strip().lower() == "film"
    # Title poster is music-only; never force it for film/story projects
    want_title = bool(include_title_card) and not is_film

    title_dur = 0.0
    if want_title:
        title_dur = min(max(slot_duration, 3.0), max(3.0, song_duration * 0.08))
    body_duration = max(0.5, song_duration - title_dur)
    n = len(scenes) or max(1, int(math.ceil(body_duration / slot_duration)))
    t = 0.0
    shots: list[Shot] = []

    if want_title:
        title_prompt = (
            f'Animated music video title poster for the song "{title}", '
            f'bold cinematic typography clearly reading "{title}", '
            f"stylized poster composition, high contrast, music-video title card, "
            f"dramatic lighting, film grain, 16:9 frame"
        )
        title_motion = (
            f'slow push-in on the title "{title}", subtle particle glow, '
            "gentle parallax on poster layers, cinematic title-card animation"
        )
        shots.append(
            Shot(
                id=new_id("shot_"),
                start=0.0,
                duration=round(title_dur, 3),
                label=f"Title · {title}"[:80],
                image=ImageSettings(
                    positive_prompt=title_prompt,
                    negative_prompt=(
                        (proj.global_negative or "blurry, low quality, watermark")
                        + ", readable faces of specific people, photoreal portraits of cast"
                    ),
                    strict_named_characters_only=True,
                ),
                video=VideoSettings(
                    animation_prompt=title_motion,
                    duration_sec=round(title_dur, 3),
                ),
            )
        )
        t = title_dur

    for i, sc in enumerate(scenes):
        remaining = max(0.1, song_duration - t)
        if i == len(scenes) - 1:
            dur = remaining
        else:
            dur = min(slot_duration, remaining)
            ideal = body_duration / max(1, n)
            if abs(ideal - slot_duration) > 0.5:
                dur = min(ideal, remaining)
        dur = max(0.5, round(dur, 3))
        label = str(sc.get("label") or f"Scene {i + 1}")
        ip = str(sc.get("image_prompt") or "").strip()
        if not ip:
            if is_film:
                ip = (
                    f'Cinematic short-film still for "{title}", {label}, '
                    f"story beat opening, atmospheric, detailed, clear subjects"
                )
            else:
                ip = f'Cinematic music video still continuing "{title}", {label}, atmospheric, detailed'
        img = ImageSettings(
            positive_prompt=ip,
            negative_prompt=proj.global_negative or "blurry, low quality, watermark, text artifacts",
        )
        vid = VideoSettings(
            animation_prompt=str(sc.get("motion_prompt") or ""),
            duration_sec=dur,
        )
        shots.append(
            Shot(
                id=new_id("shot_"),
                start=round(t, 3),
                duration=dur,
                label=label,
                image=img,
                video=vid,
            )
        )
        t += dur
        if t >= song_duration - 0.05:
            break
    if shots and t < song_duration - 0.1:
        shots[-1].duration = round(shots[-1].duration + (song_duration - t), 3)

    proj.timeline.shots = shots
    if not hasattr(proj, "story") or proj.story is None:
        proj.story = StoryBrief()
    proj.story.idea = idea or proj.story.idea
    proj.story.lyrics = lyrics or proj.story.lyrics
    proj.story.style_template = style_id or proj.story.style_template
    proj.story.summary = story_summary
    proj.story.slot_duration = slot_duration
    if story_summary:
        proj.notes = (proj.notes + "\n\n" if proj.notes else "") + f"[Story] {story_summary}"
    return proj
