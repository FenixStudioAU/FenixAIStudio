@echo off
setlocal EnableExtensions
title KAT Coder — SMALL installs only (8GB VRAM PC)
cd /d "%~dp0"

echo.
echo   NOTHING downloads until you pick an option.
echo   Large quants (Q3/Q4 ~16-21GB) are NOT offered here.
echo.
echo   Options:
echo     [1] KAT-Coder "AIR-size"  — bartowski IQ2_XXS  (~10 GB disk)
echo         Best fit for 8GB VRAM (MoE offload to RAM). Alias: kat-coder-air
echo.
echo     [2] KAT-Coder APEX Mini   — mudler APEX-I-Mini (~13.5 GB disk)
echo         Slightly larger, still much smaller than Q3/Q4. Alias: kat-coder-apex-mini
echo.
echo     [3] Install BOTH (1 then 2)
echo.
echo     [4] Cancel — do nothing
echo.
echo  ============================================================
choice /C 1234 /N /M "Choose 1, 2, 3, or 4: "
set "SEL=%ERRORLEVEL%"

if "%SEL%"=="4" goto :cancel
if "%SEL%"=="1" goto :air
if "%SEL%"=="2" goto :apex
if "%SEL%"=="3" goto :both
goto :cancel

:both
call :do_air
if errorlevel 1 goto :fail
call :do_apex
if errorlevel 1 goto :fail
goto :done

:air
call :do_air
if errorlevel 1 goto :fail
goto :done

:apex
call :do_apex
if errorlevel 1 goto :fail
goto :done

:do_air
echo.
echo --- [AIR-size] Pulling bartowski IQ2_XXS (~10 GB) ---
echo Source: hf.co/bartowski/Kwaipilot_KAT-Coder-V2.5-Dev-GGUF:IQ2_XXS
where ollama >nul 2>&1
if errorlevel 1 (
  echo ERROR: ollama not on PATH. Start Ollama app first.
  exit /b 1
)
ollama pull hf.co/bartowski/Kwaipilot_KAT-Coder-V2.5-Dev-GGUF:IQ2_XXS
if errorlevel 1 (
  echo Pull failed for IQ2_XXS.
  exit /b 1
)
ollama cp hf.co/bartowski/Kwaipilot_KAT-Coder-V2.5-Dev-GGUF:IQ2_XXS kat-coder-air
if errorlevel 1 (
  echo Warning: alias kat-coder-air failed — use the full hf.co name.
) else (
  echo OK: ollama run kat-coder-air
)
exit /b 0

:do_apex
echo.
echo --- [APEX Mini] Pulling mudler APEX-I-Mini (~13.5 GB) ---
echo Source: hf.co/mudler/KAT-Coder-V2.5-Dev-APEX-GGUF:KAT-Coder-V2.5-Dev-APEX-I-Mini.gguf
where ollama >nul 2>&1
if errorlevel 1 (
  echo ERROR: ollama not on PATH. Start Ollama app first.
  exit /b 1
)
ollama pull hf.co/mudler/KAT-Coder-V2.5-Dev-APEX-GGUF:KAT-Coder-V2.5-Dev-APEX-I-Mini.gguf
if errorlevel 1 (
  echo Tag pull failed — trying filename-style tag Mini...
  ollama pull hf.co/mudler/KAT-Coder-V2.5-Dev-APEX-GGUF:APEX-I-Mini
  if errorlevel 1 (
    echo.
    echo Ollama HF tag failed. Fallback: download GGUF with huggingface-cli then ollama create.
    echo File: https://huggingface.co/mudler/KAT-Coder-V2.5-Dev-APEX-GGUF/resolve/main/KAT-Coder-V2.5-Dev-APEX-I-Mini.gguf
    exit /b 1
  )
  ollama cp hf.co/mudler/KAT-Coder-V2.5-Dev-APEX-GGUF:APEX-I-Mini kat-coder-apex-mini
  exit /b 0
)
ollama cp hf.co/mudler/KAT-Coder-V2.5-Dev-APEX-GGUF:KAT-Coder-V2.5-Dev-APEX-I-Mini.gguf kat-coder-apex-mini
if errorlevel 1 (
  echo Warning: alias failed — model is still installed under the hf.co name.
) else (
  echo OK: ollama run kat-coder-apex-mini
)
exit /b 0

:done
echo.
echo ============================================================
echo  Finished. Check with:  ollama list
echo  Run air:   ollama run kat-coder-air
echo  Run mini:  ollama run kat-coder-apex-mini
echo ============================================================
echo.
pause
endlocal
exit /b 0

:cancel
echo Cancelled. Nothing downloaded.
pause
endlocal
exit /b 0

:fail
echo.
echo Install failed. Ollama may need to be running (tray icon).
echo No large models were selected by this script.
pause
endlocal
exit /b 1
