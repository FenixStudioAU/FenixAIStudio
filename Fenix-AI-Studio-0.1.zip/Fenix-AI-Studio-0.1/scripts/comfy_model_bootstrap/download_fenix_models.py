#!/usr/bin/env python3
"""
Download all models Fenix AI Studio expects for ComfyUI.

Place this next to FENIX_DOWNLOAD_MODELS.bat inside a ComfyUI portable folder
(or run from Fenix scripts). Detects ComfyUI/models; if missing, asks for a
download folder so files can be copied into Comfy later.

Estimated size (required set): ~65–80 GB depending on variants.
"""
from __future__ import annotations

import argparse
import os
import shutil
import sys
from dataclasses import dataclass, field
from pathlib import Path
from typing import Optional


# ---------------------------------------------------------------------------
# Model catalog — Hugging Face resolve paths + dest under models/
# size_gb is approximate (for space / user messaging only)
# ---------------------------------------------------------------------------

@dataclass
class ModelFile:
    group: str
    label: str
    repo: str
    remote: str  # path inside HF repo
    dest_rel: str  # relative under models/
    size_gb: float
    required: bool = True
    # If any of these basenames already exist under models/, treat as present
    alt_names: list[str] = field(default_factory=list)


# Required for Fenix Music + Image + Video Gen (recommended consumer set)
MODELS: list[ModelFile] = [
    # --- FLUX.2 Klein 4B ---
    ModelFile(
        "image",
        "FLUX.2 Klein 4B diffusion",
        "Comfy-Org/flux2-klein-4B",
        "split_files/diffusion_models/flux-2-klein-4b.safetensors",
        "diffusion_models/flux-2-klein-4b.safetensors",
        4.8,
        alt_names=["flux-2-klein-4b-fp8.safetensors", "flux2-klein-4b.safetensors"],
    ),
    ModelFile(
        "image",
        "FLUX text encoder (Qwen 3 4B)",
        "Comfy-Org/flux2-klein-4B",
        "split_files/text_encoders/qwen_3_4b.safetensors",
        "text_encoders/qwen_3_4b.safetensors",
        7.5,
        alt_names=["qwen3_4b.safetensors", "qwen_3_4b_fp8mixed.safetensors"],
    ),
    ModelFile(
        "image",
        "FLUX.2 VAE",
        "Comfy-Org/flux2-klein-4B",
        "split_files/vae/flux2-vae.safetensors",
        "vae/flux2-vae.safetensors",
        0.2,
        alt_names=["flux2_vae.safetensors"],
    ),
    # --- MiniMax H3 I2V (pruned int8 = best size/quality for Fenix) ---
    ModelFile(
        "video",
        "MiniMax H3 diffusion (pruned int8)",
        "Comfy-Org/MiniMax-H3",
        "diffusion_models/minimax_h3_fl2va_pruned_int8_convrot.safetensors",
        "diffusion_models/minimax_h3_fl2va_pruned_int8_convrot.safetensors",
        21.0,
        alt_names=[
            "minimax_h3_fl2va_pruned_fp8_scaled.safetensors",
            "minimax_h3_fl2va_int8_convrot.safetensors",
        ],
    ),
    ModelFile(
        "video",
        "MiniMax text encoder (nvfp4 AWQ)",
        "Comfy-Org/MiniMax-H3",
        "text_encoders/qwen3vl_32b_minimax_h3_nvfp4_awq.safetensors",
        "text_encoders/qwen3vl_32b_minimax_h3_nvfp4_awq.safetensors",
        15.7,
        alt_names=[
            "qwen3vl_32b_minimax_h3_int8_convrot.safetensors",
            "qwen3vl_32b_minimax_h3_bf16.safetensors",
        ],
    ),
    ModelFile(
        "video",
        "MiniMax video VAE",
        "Comfy-Org/MiniMax-H3",
        "vae/minimax_h3_video_vae_fp16.safetensors",
        "vae/minimax_h3_video_vae_fp16.safetensors",
        5.2,
    ),
    ModelFile(
        "video",
        "MiniMax audio VAE (clip sound)",
        "Comfy-Org/MiniMax-H3",
        "vae/minimax_h3_audio_vae_fp32.safetensors",
        "vae/minimax_h3_audio_vae_fp32.safetensors",
        0.6,
    ),
    # --- ACE-Step 1.5 music ---
    ModelFile(
        "music",
        "ACE-Step 1.5 turbo diffusion",
        "Comfy-Org/ace_step_1.5_ComfyUI_files",
        "split_files/diffusion_models/acestep_v1.5_turbo.safetensors",
        "diffusion_models/acestep_v1.5_turbo.safetensors",
        4.8,
        alt_names=["acestep_v1.5.safetensors", "acestep_v1.5_base.safetensors"],
    ),
    ModelFile(
        "music",
        "ACE text encoder 0.6B",
        "Comfy-Org/ace_step_1.5_ComfyUI_files",
        "split_files/text_encoders/qwen_0.6b_ace15.safetensors",
        "text_encoders/qwen_0.6b_ace15.safetensors",
        1.2,
    ),
    ModelFile(
        "music",
        "ACE text encoder 4B (HQ codes path)",
        "Comfy-Org/ace_step_1.5_ComfyUI_files",
        "split_files/text_encoders/qwen_4b_ace15.safetensors",
        "text_encoders/qwen_4b_ace15.safetensors",
        8.4,
        # 1.7b works with official split template; Fenix prefers 4b
        alt_names=["qwen_1.7b_ace15.safetensors"],
    ),
    ModelFile(
        "music",
        "ACE 1.5 VAE",
        "Comfy-Org/ace_step_1.5_ComfyUI_files",
        "split_files/vae/ace_1.5_vae.safetensors",
        "vae/ace_1.5_vae.safetensors",
        0.3,
    ),
]

# Optional — FastLoRA for MiniMax turbo (≥12 GB VRAM)
OPTIONAL: list[ModelFile] = [
    ModelFile(
        "video-optional",
        "MiniMax FastLoRA turbo (optional, ≥12GB VRAM)",
        "drbaph/MiniMax-H3-Turbo-Lora-ComfyUI",
        "minimax_h3_turbo_4step_ckpt850_pruned_comfyui.safetensors",
        "loras/minimax_h3_turbo_4step_ckpt850_pruned_comfyui.safetensors",
        0.5,
        required=False,
        alt_names=[
            "minimax_h3_turbo_4step_ckpt500_pruned_comfyui.safetensors",
            "minimax_h3_turbo_4step_pruned_comfyui.safetensors",
        ],
    ),
]


def eprint(*a, **k) -> None:
    print(*a, file=sys.stderr, **k)


def find_file_under(models: Path, names: list[str]) -> Optional[Path]:
    """Find basename anywhere under models/ (subfolders ok)."""
    want = {n.lower() for n in names if n}
    if not models.is_dir():
        return None
    for p in models.rglob("*"):
        if p.is_file() and p.name.lower() in want:
            return p
    return None


def is_present(models: Path, m: ModelFile) -> bool:
    dest = models / m.dest_rel
    if dest.is_file() and dest.stat().st_size > 1_000_000:
        return True
    names = [Path(m.dest_rel).name] + list(m.alt_names)
    hit = find_file_under(models, names)
    return bool(hit and hit.stat().st_size > 1_000_000)


def free_gb(path: Path) -> float:
    try:
        usage = shutil.disk_usage(str(path if path.exists() else path.parent))
        return usage.free / (1024**3)
    except Exception:
        return -1.0


def detect_comfy_root(start: Path) -> Optional[Path]:
    """
    Accept:
      - ComfyUI portable root (has ComfyUI/models)
      - ComfyUI folder itself (has models/)
      - models/ parent
    """
    start = start.resolve()
    candidates = [
        start / "ComfyUI",
        start,
        start.parent if start.name.lower() == "models" else None,
    ]
    for c in candidates:
        if c is None:
            continue
        if (c / "models").is_dir():
            return c
        if (c / "ComfyUI" / "models").is_dir():
            return c / "ComfyUI"
    return None


def prompt_path(msg: str) -> Path:
    while True:
        raw = input(msg).strip().strip('"')
        if not raw:
            print("Please enter a path.")
            continue
        p = Path(raw).expanduser()
        try:
            p.mkdir(parents=True, exist_ok=True)
        except Exception as e:
            print(f"Cannot create folder: {e}")
            continue
        return p.resolve()


def ensure_hf() -> None:
    try:
        import huggingface_hub  # noqa: F401
    except ImportError:
        print("Installing huggingface_hub …")
        import subprocess

        subprocess.check_call(
            [sys.executable, "-m", "pip", "install", "-U", "huggingface_hub", "hf_transfer"],
            stdout=sys.stdout,
            stderr=sys.stderr,
        )


def download_one(m: ModelFile, models_root: Path, cache: Path) -> bool:
    from huggingface_hub import hf_hub_download

    dest = models_root / m.dest_rel
    dest.parent.mkdir(parents=True, exist_ok=True)
    print(f"\n>>> {m.label}")
    print(f"    repo:  {m.repo}")
    print(f"    file:  {m.remote}")
    print(f"    dest:  {dest}")
    try:
        path = hf_hub_download(
            repo_id=m.repo,
            filename=m.remote,
            local_dir=str(cache),
            local_dir_use_symlinks=False,
            resume_download=True,
        )
        src = Path(path)
        if src.resolve() != dest.resolve():
            # Atomic-ish replace
            tmp = dest.with_suffix(dest.suffix + ".partial")
            shutil.copy2(src, tmp)
            tmp.replace(dest)
        size = dest.stat().st_size / (1024**3)
        print(f"    OK     {size:.2f} GB")
        return True
    except Exception as e:
        print(f"    FAIL   {e}")
        print(
            f"    Manual: https://huggingface.co/{m.repo}/resolve/main/{m.remote}"
        )
        return False


def main() -> int:
    parser = argparse.ArgumentParser(description="Fenix AI Studio → ComfyUI model downloader")
    parser.add_argument(
        "--comfy",
        type=Path,
        default=None,
        help="ComfyUI root (folder that contains models/). Default: auto from CWD.",
    )
    parser.add_argument(
        "--dest",
        type=Path,
        default=None,
        help="Force download root (creates diffusion_models/ text_encoders/ vae/ under it).",
    )
    parser.add_argument(
        "--optional",
        action="store_true",
        help="Also download optional FastLoRA turbo pack.",
    )
    parser.add_argument(
        "--check-only",
        action="store_true",
        help="Only report missing files; do not download.",
    )
    parser.add_argument(
        "--yes",
        action="store_true",
        help="Non-interactive: download missing without confirm.",
    )
    args = parser.parse_args()

    print("=" * 60)
    print("  Fenix AI Studio — ComfyUI model setup")
    print("=" * 60)
    print()

    cwd = Path.cwd().resolve()
    comfy: Optional[Path] = None
    models: Optional[Path] = None
    manual_layout = False

    if args.dest:
        models = Path(args.dest).resolve()
        models.mkdir(parents=True, exist_ok=True)
        manual_layout = True
        print(f"Download destination (manual layout): {models}")
    elif args.comfy:
        comfy = detect_comfy_root(Path(args.comfy)) or Path(args.comfy).resolve()
        if not (comfy / "models").is_dir():
            (comfy / "models").mkdir(parents=True, exist_ok=True)
        models = comfy / "models"
        print(f"ComfyUI root: {comfy}")
    else:
        comfy = detect_comfy_root(cwd)
        if comfy:
            models = comfy / "models"
            print(f"Detected ComfyUI: {comfy}")
        else:
            print("Could not find ComfyUI/models next to this script.")
            print("Looked from:", cwd)
            print()
            print("Options:")
            print("  1) Enter path to ComfyUI folder (contains models\\)")
            print("  2) Enter any folder to download ~70GB of files for manual install later")
            print()
            choice = input("Choose 1 or 2 [1]: ").strip() or "1"
            if choice.startswith("2"):
                models = prompt_path("Folder for downloads: ")
                manual_layout = True
            else:
                root = prompt_path("ComfyUI folder path: ")
                comfy = detect_comfy_root(root) or root
                models = comfy / "models"
                models.mkdir(parents=True, exist_ok=True)

    assert models is not None
    models = models.resolve()
    models.mkdir(parents=True, exist_ok=True)
    for sub in ("diffusion_models", "text_encoders", "vae", "loras", "checkpoints"):
        (models / sub).mkdir(parents=True, exist_ok=True)

    pack = list(MODELS)
    if args.optional:
        pack.extend(OPTIONAL)

    print()
    print(f"Models folder: {models}")
    print()

    present: list[ModelFile] = []
    missing: list[ModelFile] = []
    for m in pack:
        if is_present(models, m):
            present.append(m)
            print(f"  [OK]  {m.dest_rel}")
        else:
            missing.append(m)
            print(f"  [ -- ] {m.dest_rel}  (~{m.size_gb:.1f} GB)  [{m.group}]")

    need_gb = sum(m.size_gb for m in missing)
    print()
    print(f"Present: {len(present)}  Missing: {len(missing)}  (~{need_gb:.0f} GB to download)")
    free = free_gb(models)
    if free >= 0:
        print(f"Free disk space here: {free:.0f} GB")
        if missing and free < need_gb + 5:
            print("WARNING: free space may be tight. Free more disk or pick another drive.")

    if not missing:
        print("\nAll required models already present. Restart ComfyUI if it was already running.")
        if manual_layout:
            print(
                "\nManual layout folders ready under:\n"
                f"  {models}\\diffusion_models\n"
                f"  {models}\\text_encoders\n"
                f"  {models}\\vae\n"
                "Copy those into your ComfyUI\\models\\ tree."
            )
        return 0

    if args.check_only:
        print("\n--check-only: not downloading.")
        return 2

    if not args.yes:
        print()
        print("This will download missing files from Hugging Face.")
        print("You need a stable network; large files resume if interrupted.")
        ans = input("Continue? [Y/n]: ").strip().lower()
        if ans in ("n", "no"):
            print("Cancelled.")
            return 3

    ensure_hf()
    # Prefer faster transfers when available
    os.environ.setdefault("HF_HUB_ENABLE_HF_TRANSFER", "1")

    cache = models / "_hf_cache_fenix"
    cache.mkdir(parents=True, exist_ok=True)

    ok = 0
    fail = 0
    for m in missing:
        if download_one(m, models, cache):
            ok += 1
        else:
            fail += 1

    print()
    print("=" * 60)
    print(f"Downloaded OK: {ok}   Failed: {fail}")
    if manual_layout:
        print()
        print("Files are in a portable models layout:")
        print(f"  {models}")
        print("Copy the subfolders into your ComfyUI\\models\\ directory, then restart ComfyUI.")
    else:
        print("Restart ComfyUI so it rescans models/.")
    print("=" * 60)
    return 0 if fail == 0 else 1


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except KeyboardInterrupt:
        print("\nInterrupted.")
        raise SystemExit(130)
