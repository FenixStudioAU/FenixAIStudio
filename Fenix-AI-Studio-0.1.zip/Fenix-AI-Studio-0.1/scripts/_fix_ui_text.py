"""One-shot: fix mojibake and clean user-facing text in frontend HTML/JS."""
from __future__ import annotations

from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
FRONT = ROOT / "frontend"

REPLACEMENTS = [
    ("Local Â· ComfyUI + Ollama", ""),
    ("Loadingâ€¦", "Loading…"),
    ("â† Back", "Back"),
    ("â†", ""),
    ("â†’", "→"),
    ("â†»", "↻"),
    ("Â·", "·"),
    ("â€¦", "…"),
    ("â€”", "—"),
    ("â€“", "–"),
    ("â€œ", "“"),
    ("â€\x9d", "”"),
    ("â€˜", "‘"),
    ("â€™", "’"),
    ("LLMâ€¦", "LLM…"),
    ("modelâ€¦", "model…"),
    ("Messageâ€¦", "Message…"),
    ("Model: â€”", "Model: —"),
    ("None yet â€”", "None yet —"),
    ("â€œMake this a videoâ€\x9d", "“Make this a video”"),
    ("Make this a videoâ€\x9d", "Make this a video”"),
    ("Design â†’ Build â†’ Repair", "Design → Build → Repair"),
    ("One request â†’ one", "One request → one"),
    ("Coder Â· Designer", "Coder · Designer"),
    ("Coder Â· Build", "Coder · Build"),
    ("Chat Â· local Ollama Â· history in this browser", "Local Ollama · history in this browser"),
    # leftover broken sequences
    ("â€", '"'),
]


def fix_file(path: Path) -> int:
    text = path.read_text(encoding="utf-8", errors="replace")
    orig = text
    for a, b in REPLACEMENTS:
        text = text.replace(a, b)
    if text != orig:
        path.write_text(text, encoding="utf-8")
        return 1
    return 0


def main() -> None:
    n = 0
    for p in FRONT.rglob("*"):
        if p.suffix.lower() in {".html", ".js", ".css"}:
            n += fix_file(p)
    print(f"updated {n} files")


if __name__ == "__main__":
    main()
